/* Generated from chicken-syntax.scm by the CHICKEN compiler
   http://www.call-cc.org
   2012-09-24 17:50
   Version 4.8.0 (rev 0db1908)
   linux-unix-gnu-x86-64 [ 64bit manyargs ptables ]
   compiled 2012-09-24 on debian (Linux)
   command line: chicken-syntax.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -feature chicken-bootstrap -no-warnings -specialize -types ./types.db -explicit-use -no-trace -output-file chicken-syntax.c
   unit: chicken_2dsyntax
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[289];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,26),40,102,95,51,52,56,53,32,120,50,52,56,53,32,114,50,52,56,54,32,99,50,52,56,55,41,0,0,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,19),40,102,95,51,53,53,56,32,99,108,97,117,115,101,50,52,55,50,41,0,0,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,50,52,53,53,32,103,50,52,54,55,50,52,55,56,41};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,26),40,102,95,51,53,51,50,32,120,50,52,52,52,32,114,50,52,52,53,32,99,50,52,52,54,41,0,0,0,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,22),40,102,95,51,54,57,52,32,97,110,50,52,50,48,32,97,116,50,52,50,49,41,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,34),40,109,97,112,45,108,111,111,112,50,52,48,49,32,103,50,52,49,51,50,52,50,54,32,103,50,52,49,52,50,52,50,55,41,0,0,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,22),40,102,95,51,55,55,55,32,103,50,51,56,49,50,51,56,50,50,51,56,51,41,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,50,51,54,49,32,103,50,51,55,51,50,51,56,55,41};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,24),40,108,111,111,112,50,32,97,110,97,109,101,115,50,51,53,53,32,105,50,51,53,54,41};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,37),40,108,111,111,112,32,97,114,103,115,50,51,52,50,32,97,110,97,109,101,115,50,51,52,51,32,97,116,121,112,101,115,50,51,52,52,41,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,26),40,102,95,51,54,51,50,32,120,50,51,50,53,32,114,50,51,50,54,32,99,50,51,50,55,41,0,0,0,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,21),40,102,95,51,57,53,49,32,116,101,109,112,50,50,50,57,50,50,56,54,41,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,21),40,102,95,51,57,54,50,32,116,101,109,112,50,50,50,57,50,51,49,52,41,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,25),40,102,95,51,57,57,49,32,116,121,112,101,50,51,50,51,32,118,97,114,50,51,50,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,50,50,57,55,32,103,50,51,48,57,50,51,49,54,41};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,50,50,54,57,32,103,50,50,56,49,50,50,56,56,41};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,32),40,108,111,111,112,50,50,50,52,32,108,50,50,49,57,50,50,54,48,32,108,101,110,50,50,50,48,50,50,54,49,41};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,32),40,108,111,111,112,50,50,50,52,32,108,50,50,49,57,50,50,52,53,32,108,101,110,50,50,50,48,50,50,52,54,41};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,53),40,102,95,51,57,52,49,32,105,110,112,117,116,50,50,49,56,50,50,51,49,32,114,101,110,97,109,101,50,50,50,55,50,50,51,50,32,99,111,109,112,97,114,101,50,50,49,53,50,50,51,51,41,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,26),40,102,95,52,50,48,50,32,120,50,50,48,55,32,114,50,50,48,56,32,99,50,50,48,57,41,0,0,0,0,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,8),40,102,95,52,50,53,50,41};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,59),40,102,95,52,50,54,48,32,116,121,112,101,50,49,56,50,50,49,56,51,50,49,56,56,32,112,114,101,100,50,49,56,52,50,49,56,53,50,49,56,57,32,112,117,114,101,50,49,56,54,50,49,56,55,50,49,57,48,41,0,0,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,26),40,102,95,52,50,51,52,32,120,50,49,55,55,32,114,50,49,55,56,32,99,50,49,55,57,41,0,0,0,0,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,16),40,102,95,52,51,54,53,32,97,114,103,50,49,54,51,41};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,50,49,52,54,32,103,50,49,53,56,50,49,54,55,41};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,26),40,102,95,52,51,50,51,32,120,50,49,51,50,32,114,50,49,51,51,32,99,50,49,51,52,41,0,0,0,0,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,26),40,102,95,52,52,49,55,32,120,50,49,49,53,32,114,50,49,49,54,32,99,50,49,49,55,41,0,0,0,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,32),40,108,111,111,112,50,48,55,54,32,108,50,48,55,49,50,49,48,55,32,108,101,110,50,48,55,50,50,49,48,56,41};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,32),40,108,111,111,112,50,48,55,54,32,108,50,48,55,49,50,48,57,55,32,108,101,110,50,48,55,50,50,48,57,56,41};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,53),40,102,95,52,52,57,49,32,105,110,112,117,116,50,48,55,48,50,48,56,51,32,114,101,110,97,109,101,50,48,55,57,50,48,56,52,32,99,111,109,112,97,114,101,50,48,54,55,50,48,56,53,41,0,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,32),40,108,111,111,112,50,48,50,54,32,108,50,48,50,49,50,48,53,49,32,108,101,110,50,48,50,50,50,48,53,50,41};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,53),40,102,95,52,54,50,49,32,105,110,112,117,116,50,48,50,48,50,48,51,51,32,114,101,110,97,109,101,50,48,50,57,50,48,51,52,32,99,111,109,112,97,114,101,50,48,49,55,50,48,51,53,41,0,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,26),40,102,95,52,56,50,49,32,120,50,48,48,57,32,114,50,48,49,48,32,99,50,48,49,49,41,0,0,0,0,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,29),40,102,95,52,56,51,53,32,102,111,114,109,50,48,48,50,32,114,50,48,48,51,32,99,50,48,48,52,41,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,29),40,102,95,52,56,53,56,32,102,111,114,109,49,57,57,49,32,114,49,57,57,50,32,99,49,57,57,51,41,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,47),40,108,111,111,112,32,120,115,49,57,55,48,32,118,97,114,115,49,57,55,49,32,98,115,49,57,55,50,32,118,97,108,115,49,57,55,51,32,114,101,115,116,49,57,55,52,41,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,29),40,102,95,52,57,49,51,32,102,111,114,109,49,57,54,51,32,114,49,57,54,52,32,99,49,57,54,53,41,0,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,40),40,108,111,111,112,32,120,115,49,57,52,49,32,118,97,114,115,49,57,52,50,32,118,97,108,115,49,57,52,51,32,114,101,115,116,49,57,52,52,41};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,29),40,102,95,53,48,55,57,32,102,111,114,109,49,57,51,52,32,114,49,57,51,53,32,99,49,57,51,54,41,0,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,18),40,102,95,53,52,53,52,32,115,110,97,109,101,49,56,56,56,41,0,0,0,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,22),40,108,111,111,112,32,115,108,111,116,115,49,56,57,55,32,105,49,56,57,56,41,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,56,55,49,32,103,49,56,56,51,49,56,57,48,41};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,56,52,50,32,103,49,56,53,52,49,56,54,48,41};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,29),40,102,95,53,50,51,49,32,102,111,114,109,49,56,50,55,32,114,49,56,50,56,32,99,49,56,50,57,41,0,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,14),40,102,95,53,54,50,52,32,107,49,55,55,57,41,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,55,54,50,32,103,49,55,55,52,49,55,56,52,41};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,20),40,112,97,114,115,101,45,99,108,97,117,115,101,32,99,49,55,52,51,41,0,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,55,57,56,32,103,49,56,49,48,49,56,49,54,41};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,29),40,102,95,53,53,51,57,32,102,111,114,109,49,55,51,49,32,114,49,55,51,50,32,99,49,55,51,51,41,0,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,29),40,102,95,53,55,56,54,32,102,111,114,109,49,55,49,57,32,114,49,55,50,48,32,99,49,55,50,49,41,0,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,29),40,102,95,53,56,55,55,32,102,111,114,109,49,54,57,57,32,114,49,55,48,48,32,99,49,55,48,49,41,0,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,105,49,53,56,50,41,0,0,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,15),40,103,101,110,118,97,114,115,32,110,49,53,56,48,41,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,8),40,102,95,54,48,51,48,41};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,34),40,109,97,112,45,108,111,111,112,49,54,54,54,32,103,49,54,55,56,49,54,56,54,32,103,49,54,55,57,49,54,56,55,41,0,0,0,0,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,27),40,98,117,105,108,100,32,118,97,114,115,50,49,54,52,53,32,118,114,101,115,116,49,54,52,54,41,0,0,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,28),40,102,95,54,48,51,56,32,118,97,114,115,49,49,54,52,49,32,118,97,114,115,50,49,54,52,50,41,0,0,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,35),40,102,95,54,48,49,51,32,118,97,114,115,49,54,50,56,32,97,114,103,99,49,54,50,57,32,114,101,115,116,49,54,51,48,41,0,0,0,0,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,23),40,102,95,54,48,48,53,32,99,49,54,50,54,32,98,111,100,121,49,54,50,55,41,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,35),40,102,95,54,50,50,50,32,118,97,114,115,49,54,48,53,32,97,114,103,99,49,54,48,54,32,114,101,115,116,49,54,48,55,41,0,0,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,14),40,102,95,54,50,49,52,32,99,49,54,48,52,41,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,53,56,55,32,103,49,53,57,57,49,54,48,57,41};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,29),40,102,95,53,57,51,53,32,102,111,114,109,49,53,55,54,32,114,49,53,55,55,32,99,49,53,55,56,41,0,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,27),40,108,111,111,112,32,97,114,103,115,49,53,53,56,32,118,97,114,100,101,102,115,49,53,53,57,41,0,0,0,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,29),40,102,95,54,50,57,56,32,102,111,114,109,49,53,52,52,32,114,49,53,52,53,32,99,49,53,52,54,41,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,29),40,102,95,54,52,50,50,32,102,111,114,109,49,53,50,57,32,114,49,53,51,48,32,99,49,53,51,49,41,0,0,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,48),40,114,101,99,117,114,32,118,97,114,115,49,51,57,48,32,100,101,102,97,117,108,116,101,114,115,49,51,57,49,32,110,111,110,45,100,101,102,97,117,108,116,115,49,51,57,50,41};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,61),40,109,97,107,101,45,105,102,45,116,114,101,101,32,118,97,114,115,49,51,56,52,32,100,101,102,97,117,108,116,101,114,115,49,51,56,53,32,98,111,100,121,45,112,114,111,99,49,51,56,54,32,114,101,115,116,49,51,56,55,41,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,27),40,102,95,54,54,52,57,32,112,114,101,102,105,120,49,52,50,57,32,115,121,109,49,52,51,48,41,0,0,0,0,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,14),40,102,95,54,54,53,57,32,118,49,52,53,49,41,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,16),40,102,95,54,54,55,56,32,118,97,114,49,53,48,56,41};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,58),40,114,101,99,117,114,32,118,97,114,115,49,51,55,53,32,100,101,102,97,117,108,116,101,114,45,110,97,109,101,115,49,51,55,54,32,100,101,102,115,49,51,55,55,32,110,101,120,116,45,103,117,121,49,51,55,56,41,0,0,0,0,0,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,52,57,49,32,103,49,53,48,51,49,53,49,48,41};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,52,54,50,32,103,49,52,55,52,49,52,56,48,41};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,52,51,52,32,103,49,52,52,54,49,52,53,51,41};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,52,48,52,32,103,49,52,49,54,49,52,50,50,41};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,29),40,102,95,54,52,57,50,32,102,111,114,109,49,51,54,49,32,114,49,51,54,50,32,99,49,51,54,51,41,0,0,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,14),40,102,95,54,57,51,55,32,120,49,51,52,52,41,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,51,50,55,32,103,49,51,51,57,49,51,52,57,41};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,30),40,101,120,112,97,110,100,32,99,108,97,117,115,101,115,49,51,48,54,32,101,108,115,101,63,49,51,48,55,41,0,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,29),40,102,95,54,56,53,50,32,102,111,114,109,49,50,57,52,32,114,49,50,57,53,32,99,49,50,57,54,41,0,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,13),40,102,111,108,100,32,98,115,49,50,55,51,41,0,0,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,29),40,102,95,54,57,57,48,32,102,111,114,109,49,50,54,55,32,114,49,50,54,56,32,99,49,50,54,57,41,0,0,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,28),40,113,117,111,116,105,102,121,45,112,114,111,99,32,120,115,49,50,52,57,32,105,100,49,50,53,48,41,0,0,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,29),40,102,95,55,48,55,49,32,102,111,114,109,49,50,52,53,32,114,49,50,52,54,32,99,49,50,52,55,41,0,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,29),40,102,95,55,49,54,48,32,102,111,114,109,49,50,51,55,32,114,49,50,51,56,32,99,49,50,51,57,41,0,0,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,14),40,102,95,55,50,48,55,32,118,49,49,48,55,41,0,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,14),40,102,95,55,50,50,50,32,118,49,49,49,54,41,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,14),40,102,95,55,50,51,54,32,118,49,49,51,57,41,0,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,14),40,102,95,55,50,54,56,32,118,49,50,49,53,41,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,49,57,56,32,103,49,50,49,48,49,50,50,48,41};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,49,55,50,32,103,49,49,56,52,49,49,57,48,41};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,15),40,102,95,55,50,52,55,32,118,98,49,49,54,54,41,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,49,52,57,32,103,49,49,54,49,49,50,50,55,41};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,49,50,50,32,103,49,49,51,52,49,49,52,49,41};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,48,57,48,32,103,49,49,48,50,49,49,48,57,41};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,14),40,102,95,55,52,51,56,32,120,49,48,55,57,41,0,0};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,48,54,50,32,103,49,48,55,52,49,48,56,49,41};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,29),40,102,95,55,49,57,55,32,102,111,114,109,49,48,53,52,32,114,49,48,53,53,32,99,49,48,53,54,41,0,0,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,20),40,102,111,108,100,32,118,98,105,110,100,105,110,103,115,49,48,52,53,41,0,0,0,0};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,29),40,102,95,55,52,56,49,32,102,111,114,109,49,48,51,56,32,114,49,48,51,57,32,99,49,48,52,48,41,0,0,0};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,20),40,97,112,112,101,110,100,42,32,105,108,56,55,57,32,108,56,56,48,41,0,0,0,0};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,19),40,109,97,112,42,32,112,114,111,99,56,56,49,32,108,56,56,50,41,0,0,0,0,0};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,13),40,102,95,55,54,48,51,32,118,57,52,51,41,0,0,0};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,13),40,102,95,55,54,49,56,32,118,57,53,50,41,0,0,0};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,14),40,102,95,55,54,51,49,32,120,49,48,50,55,41,0,0};
static C_char C_TLS li106[] C_aligned={C_lihdr(0,0,13),40,102,95,55,54,53,52,32,118,57,57,50,41,0,0,0};
static C_char C_TLS li107[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,57,55,53,32,103,57,56,55,57,57,52,41,0,0,0};
static C_char C_TLS li108[] C_aligned={C_lihdr(0,0,35),40,102,111,108,100,32,108,108,105,115,116,115,57,54,52,32,101,120,112,115,57,54,53,32,108,108,105,115,116,115,50,57,54,54,41,0,0,0,0,0};
static C_char C_TLS li109[] C_aligned={C_lihdr(0,0,24),40,109,97,112,45,108,111,111,112,49,48,49,48,32,103,49,48,50,50,49,48,50,57,41};
static C_char C_TLS li110[] C_aligned={C_lihdr(0,0,23),40,108,111,111,112,32,108,108,105,115,116,115,57,53,53,32,97,99,99,57,53,54,41,0};
static C_char C_TLS li111[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,57,50,54,32,103,57,51,56,57,52,53,41,0,0,0};
static C_char C_TLS li112[] C_aligned={C_lihdr(0,0,23),40,108,111,111,112,32,108,108,105,115,116,115,57,49,53,32,97,99,99,57,49,54,41,0};
static C_char C_TLS li113[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,56,56,57,32,103,57,48,49,57,48,55,41,0,0,0};
static C_char C_TLS li114[] C_aligned={C_lihdr(0,0,26),40,102,95,55,53,50,55,32,102,111,114,109,56,55,50,32,114,56,55,51,32,99,56,55,52,41,0,0,0,0,0,0};
static C_char C_TLS li115[] C_aligned={C_lihdr(0,0,19),40,102,95,55,57,51,54,32,103,56,53,55,56,53,56,56,53,57,41,0,0,0,0,0};
static C_char C_TLS li116[] C_aligned={C_lihdr(0,0,26),40,102,111,114,45,101,97,99,104,45,108,111,111,112,56,52,52,32,103,56,53,49,56,54,51,41,0,0,0,0,0,0};
static C_char C_TLS li117[] C_aligned={C_lihdr(0,0,26),40,102,95,55,57,51,50,32,102,111,114,109,56,51,57,32,114,56,52,48,32,99,56,52,49,41,0,0,0,0,0,0};
static C_char C_TLS li118[] C_aligned={C_lihdr(0,0,18),40,102,95,56,48,51,54,32,118,56,50,51,32,97,56,50,52,41,0,0,0,0,0,0};
static C_char C_TLS li119[] C_aligned={C_lihdr(0,0,29),40,109,97,112,45,108,111,111,112,56,48,52,32,103,56,49,54,56,50,57,32,103,56,49,55,56,51,48,41,0,0,0};
static C_char C_TLS li120[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,55,55,53,32,103,55,56,55,55,57,51,41,0,0,0};
static C_char C_TLS li121[] C_aligned={C_lihdr(0,0,26),40,102,95,55,57,56,51,32,102,111,114,109,55,53,56,32,114,55,53,57,32,99,55,54,48,41,0,0,0,0,0,0};
static C_char C_TLS li122[] C_aligned={C_lihdr(0,0,26),40,102,95,56,49,50,52,32,102,111,114,109,55,53,49,32,114,55,53,50,32,99,55,53,51,41,0,0,0,0,0,0};
static C_char C_TLS li123[] C_aligned={C_lihdr(0,0,26),40,102,95,56,49,52,55,32,102,111,114,109,55,52,52,32,114,55,52,53,32,99,55,52,54,41,0,0,0,0,0,0};
static C_char C_TLS li124[] C_aligned={C_lihdr(0,0,13),40,102,95,56,50,48,50,32,122,54,48,53,41,0,0,0};
static C_char C_TLS li125[] C_aligned={C_lihdr(0,0,13),40,102,95,56,50,49,52,32,122,54,51,51,41,0,0,0};
static C_char C_TLS li126[] C_aligned={C_lihdr(0,0,19),40,102,95,56,50,55,56,32,97,55,50,55,32,97,50,55,50,56,41,0,0,0,0,0};
static C_char C_TLS li127[] C_aligned={C_lihdr(0,0,29),40,109,97,112,45,108,111,111,112,55,48,56,32,103,55,50,48,55,51,51,32,103,55,50,49,55,51,52,41,0,0,0};
static C_char C_TLS li128[] C_aligned={C_lihdr(0,0,29),40,109,97,112,45,108,111,111,112,54,55,55,32,103,54,56,57,54,57,55,32,103,54,57,48,54,57,56,41,0,0,0};
static C_char C_TLS li129[] C_aligned={C_lihdr(0,0,29),40,109,97,112,45,108,111,111,112,54,52,54,32,103,54,53,56,54,54,54,32,103,54,53,57,54,54,55,41,0,0,0};
static C_char C_TLS li130[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,54,49,54,32,103,54,50,56,54,51,53,41,0,0,0};
static C_char C_TLS li131[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,53,56,56,32,103,54,48,48,54,48,55,41,0,0,0};
static C_char C_TLS li132[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,53,54,49,32,103,53,55,51,53,55,57,41,0,0,0};
static C_char C_TLS li133[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,53,51,52,32,103,53,52,54,53,53,50,41,0,0,0};
static C_char C_TLS li134[] C_aligned={C_lihdr(0,0,26),40,102,95,56,49,54,55,32,102,111,114,109,53,50,50,32,114,53,50,51,32,99,53,50,52,41,0,0,0,0,0,0};
static C_char C_TLS li135[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,115,115,53,48,51,41,0,0,0,0};
static C_char C_TLS li136[] C_aligned={C_lihdr(0,0,26),40,102,95,56,53,53,57,32,102,111,114,109,52,56,56,32,114,52,56,57,32,99,52,57,48,41,0,0,0,0,0,0};
static C_char C_TLS li137[] C_aligned={C_lihdr(0,0,13),40,102,95,56,54,54,51,32,120,50,49,51,41,0,0,0};
static C_char C_TLS li138[] C_aligned={C_lihdr(0,0,13),40,102,95,56,54,55,51,32,120,50,52,49,41,0,0,0};
static C_char C_TLS li139[] C_aligned={C_lihdr(0,0,20),40,102,95,56,55,48,56,32,110,116,52,51,54,32,105,100,52,51,55,41,0,0,0,0};
static C_char C_TLS li140[] C_aligned={C_lihdr(0,0,20),40,102,95,56,55,49,57,32,105,100,52,55,50,32,111,116,52,55,51,41,0,0,0,0};
static C_char C_TLS li141[] C_aligned={C_lihdr(0,0,29),40,109,97,112,45,108,111,111,112,52,53,51,32,103,52,54,53,52,55,56,32,103,52,54,54,52,55,57,41,0,0,0};
static C_char C_TLS li142[] C_aligned={C_lihdr(0,0,29),40,109,97,112,45,108,111,111,112,52,49,55,32,103,52,50,57,52,52,50,32,103,52,51,48,52,52,51,41,0,0,0};
static C_char C_TLS li143[] C_aligned={C_lihdr(0,0,20),40,102,95,56,56,50,54,32,111,116,51,54,52,32,105,100,51,54,53,41,0,0,0,0};
static C_char C_TLS li144[] C_aligned={C_lihdr(0,0,20),40,102,95,56,56,51,57,32,105,100,52,48,48,32,110,116,52,48,49,41,0,0,0,0};
static C_char C_TLS li145[] C_aligned={C_lihdr(0,0,29),40,109,97,112,45,108,111,111,112,51,56,49,32,103,51,57,51,52,48,54,32,103,51,57,52,52,48,55,41,0,0,0};
static C_char C_TLS li146[] C_aligned={C_lihdr(0,0,29),40,109,97,112,45,108,111,111,112,51,52,53,32,103,51,53,55,51,55,48,32,103,51,53,56,51,55,49,41,0,0,0};
static C_char C_TLS li147[] C_aligned={C_lihdr(0,0,29),40,109,97,112,45,108,111,111,112,51,49,49,32,103,51,50,51,51,51,52,32,103,51,50,52,51,51,53,41,0,0,0};
static C_char C_TLS li148[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,110,51,51,49,41,0,0,0,0,0};
static C_char C_TLS li149[] C_aligned={C_lihdr(0,0,29),40,109,97,112,45,108,111,111,112,50,53,52,32,103,50,54,54,51,48,48,32,103,50,54,55,51,48,49,41,0,0,0};
static C_char C_TLS li150[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,50,55,53,32,103,50,56,55,50,57,51,41,0,0,0};
static C_char C_TLS li151[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,50,50,52,32,103,50,51,54,50,52,51,41,0,0,0};
static C_char C_TLS li152[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,49,57,54,32,103,50,48,56,50,49,53,41,0,0,0};
static C_char C_TLS li153[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,49,54,57,32,103,49,56,49,49,56,55,41,0,0,0};
static C_char C_TLS li154[] C_aligned={C_lihdr(0,0,26),40,102,95,56,54,53,48,32,102,111,114,109,49,54,49,32,114,49,54,50,32,99,49,54,51,41,0,0,0,0,0,0};
static C_char C_TLS li155[] C_aligned={C_lihdr(0,0,26),40,102,95,57,49,56,53,32,102,111,114,109,49,52,55,32,114,49,52,56,32,99,49,52,57,41,0,0,0,0,0,0};
static C_char C_TLS li156[] C_aligned={C_lihdr(0,0,25),40,97,57,50,52,51,32,102,111,114,109,49,50,56,32,114,49,50,57,32,99,49,51,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li157[] C_aligned={C_lihdr(0,0,26),40,102,95,57,51,49,54,32,102,111,114,109,49,50,48,32,114,49,50,49,32,99,49,50,50,41,0,0,0,0,0,0};
static C_char C_TLS li158[] C_aligned={C_lihdr(0,0,26),40,102,95,57,51,51,48,32,102,111,114,109,49,49,52,32,114,49,49,53,32,99,49,49,54,41,0,0,0,0,0,0};
static C_char C_TLS li159[] C_aligned={C_lihdr(0,0,26),40,102,95,57,51,52,49,32,102,111,114,109,49,48,55,32,114,49,48,56,32,99,49,48,57,41,0,0,0,0,0,0};
static C_char C_TLS li160[] C_aligned={C_lihdr(0,0,23),40,102,95,57,51,55,57,32,102,111,114,109,56,54,32,114,56,55,32,99,56,56,41,0};
static C_char C_TLS li161[] C_aligned={C_lihdr(0,0,15),40,102,95,57,52,55,51,32,115,108,111,116,52,50,41,0};
static C_char C_TLS li162[] C_aligned={C_lihdr(0,0,22),40,109,97,112,115,108,111,116,115,32,115,108,111,116,115,54,49,32,105,54,50,41,0,0};
static C_char C_TLS li163[] C_aligned={C_lihdr(0,0,18),40,109,97,112,45,108,111,111,112,50,53,32,103,51,55,53,49,41,0,0,0,0,0,0};
static C_char C_TLS li164[] C_aligned={C_lihdr(0,0,20),40,102,95,57,52,53,55,32,120,49,51,32,114,49,52,32,99,49,53,41,0,0,0,0};
static C_char C_TLS li165[] C_aligned={C_lihdr(0,0,20),40,102,95,57,55,52,57,32,102,111,114,109,54,32,114,55,32,99,56,41,0,0,0,0};
static C_char C_TLS li166[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(f_3500)
static void C_ccall f_3500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8629)
static void C_ccall f_8629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6148)
static void C_ccall f_6148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8622)
static void C_ccall f_8622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3535)
static void C_ccall f_3535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3539)
static void C_ccall f_3539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3530)
static void C_ccall f_3530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9530)
static void C_ccall f_9530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3532)
static void C_ccall f_3532(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3399)
static void C_ccall f_3399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3395)
static void C_ccall f_3395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3397)
static void C_ccall f_3397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3391)
static void C_ccall f_3391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3393)
static void C_ccall f_3393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8603)
static void C_fcall f_8603(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5179)
static void C_ccall f_5179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5173)
static void C_ccall f_5173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4598)
static void C_ccall f_4598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9020)
static void C_fcall f_9020(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4066)
static void C_ccall f_4066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3593)
static void C_fcall f_3593(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3591)
static void C_ccall f_3591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4444)
static void C_ccall f_4444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4447)
static void C_ccall f_4447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9031)
static void C_fcall f_9031(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4087)
static void C_ccall f_4087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4089)
static void C_ccall f_4089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4081)
static void C_ccall f_4081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8650)
static void C_ccall f_8650(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8653)
static void C_ccall f_8653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4095)
static void C_ccall f_4095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3558)
static void C_ccall f_3558(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8895)
static void C_fcall f_8895(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4409)
static void C_ccall f_4409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8881)
static void C_ccall f_8881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3541)
static void C_ccall f_3541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4417)
static void C_ccall f_4417(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4415)
static void C_ccall f_4415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9002)
static void C_fcall f_9002(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8113)
static void C_ccall f_8113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9015)
static void C_ccall f_9015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8864)
static void C_fcall f_8864(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8853)
static void C_fcall f_8853(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7473)
static void C_ccall f_7473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5935)
static void C_ccall f_5935(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5933)
static void C_ccall f_5933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5938)
static void C_ccall f_5938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8845)
static void C_ccall f_8845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7479)
static void C_ccall f_7479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7490)
static void C_ccall f_7490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7495)
static void C_fcall f_7495(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5959)
static void C_ccall f_5959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5814)
static void C_ccall f_5814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8826)
static void C_ccall f_8826(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8824)
static void C_ccall f_8824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7481)
static void C_ccall f_7481(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7484)
static void C_ccall f_7484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5946)
static void C_fcall f_5946(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5802)
static void C_ccall f_5802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5940)
static void C_fcall f_5940(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6898)
static void C_ccall f_6898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5032)
static void C_ccall f_5032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8803)
static void C_ccall f_8803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5869)
static void C_ccall f_5869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6876)
static void C_fcall f_6876(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6874)
static void C_ccall f_6874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5915)
static void C_ccall f_5915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4258)
static void C_ccall f_4258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4252)
static void C_ccall f_4252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4260)
static void C_ccall f_4260(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5704)
static void C_ccall f_5704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5701)
static void C_ccall f_5701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8837)
static void C_ccall f_8837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8839)
static void C_ccall f_8839(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4285)
static void C_fcall f_4285(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4525)
static void C_ccall f_4525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8834)
static void C_ccall f_8834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4282)
static void C_ccall f_4282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7874)
static void C_ccall f_7874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4531)
static void C_ccall f_4531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4533)
static void C_ccall f_4533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5723)
static void C_fcall f_5723(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4500)
static void C_ccall f_4500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5712)
static void C_ccall f_5712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4539)
static void C_ccall f_4539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5978)
static void C_ccall f_5978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7149)
static void C_ccall f_7149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5976)
static void C_ccall f_5976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5974)
static void C_ccall f_5974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5972)
static void C_ccall f_5972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5970)
static void C_ccall f_5970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6988)
static void C_ccall f_6988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4510)
static void C_ccall f_4510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5748)
static void C_ccall f_5748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8363)
static void C_fcall f_8363(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6802)
static void C_ccall f_6802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7158)
static void C_ccall f_7158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5968)
static void C_ccall f_5968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5962)
static void C_ccall f_5962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7899)
static void C_fcall f_7899(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4566)
static void C_ccall f_4566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6807)
static void C_fcall f_6807(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4575)
static void C_ccall f_4575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6861)
static void C_ccall f_6861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6863)
static void C_ccall f_6863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6865)
static void C_ccall f_6865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4824)
static void C_ccall f_4824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4821)
static void C_ccall f_4821(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4577)
static void C_ccall f_4577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9472)
static void C_ccall f_9472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9473)
static void C_ccall f_9473(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9470)
static void C_ccall f_9470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7373)
static void C_ccall f_7373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4833)
static void C_ccall f_4833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7378)
static void C_fcall f_7378(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4835)
static void C_ccall f_4835(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4838)
static void C_ccall f_4838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4554)
static void C_ccall f_4554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4547)
static void C_fcall f_4547(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6844)
static void C_ccall f_6844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4844)
static void C_ccall f_4844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7525)
static void C_ccall f_7525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7527)
static void C_ccall f_7527(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4850)
static void C_ccall f_4850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6847)
static void C_ccall f_6847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4856)
static void C_ccall f_4856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4858)
static void C_ccall f_4858(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9468)
static void C_ccall f_9468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9466)
static void C_ccall f_9466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9460)
static void C_ccall f_9460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6933)
static void C_ccall f_6933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4583)
static void C_ccall f_4583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6937)
static void C_ccall f_6937(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6677)
static void C_ccall f_6677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4591)
static void C_fcall f_4591(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6678)
static void C_ccall f_6678(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6673)
static void C_ccall f_6673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6675)
static void C_ccall f_6675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6904)
static void C_ccall f_6904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4328)
static void C_ccall f_4328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4323)
static void C_ccall f_4323(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4326)
static void C_ccall f_4326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6906)
static void C_ccall f_6906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6670)
static void C_ccall f_6670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4321)
static void C_ccall f_4321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4801)
static void C_ccall f_4801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9457)
static void C_ccall f_9457(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9455)
static void C_ccall f_9455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6850)
static void C_ccall f_6850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6852)
static void C_ccall f_6852(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6855)
static void C_ccall f_6855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7562)
static void C_fcall f_7562(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6921)
static void C_ccall f_6921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4819)
static void C_ccall f_4819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7536)
static void C_fcall f_7536(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7530)
static void C_ccall f_7530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6973)
static void C_ccall f_6973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9379)
static void C_ccall f_9379(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9377)
static void C_ccall f_9377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6946)
static void C_ccall f_6946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6948)
static void C_fcall f_6948(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7517)
static void C_ccall f_7517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6687)
static void C_ccall f_6687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6689)
static void C_ccall f_6689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6684)
static void C_ccall f_6684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9382)
static void C_ccall f_9382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6990)
static void C_ccall f_6990(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6993)
static void C_ccall f_6993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8394)
static void C_fcall f_8394(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6697)
static void C_ccall f_6697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6691)
static void C_ccall f_6691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4861)
static void C_ccall f_4861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6665)
static void C_ccall f_6665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8074)
static void C_ccall f_8074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7555)
static void C_ccall f_7555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6649)
static void C_ccall f_6649(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6648)
static void C_ccall f_6648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6641)
static void C_ccall f_6641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3677)
static void C_ccall f_3677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6643)
static void C_ccall f_6643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3673)
static void C_ccall f_3673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7692)
static void C_ccall f_7692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8352)
static void C_fcall f_8352(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6658)
static void C_ccall f_6658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6659)
static void C_ccall f_6659(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3671)
static void C_ccall f_3671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8057)
static void C_fcall f_8057(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7180)
static void C_ccall f_7180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6655)
static void C_ccall f_6655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3662)
static void C_fcall f_3662(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6627)
static void C_ccall f_6627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6481)
static void C_ccall f_6481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4103)
static void C_fcall f_4103(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3653)
static void C_ccall f_3653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3655)
static void C_ccall f_3655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8335)
static void C_ccall f_8335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3651)
static void C_ccall f_3651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6490)
static void C_ccall f_6490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7160)
static void C_ccall f_7160(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7165)
static void C_ccall f_7165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7163)
static void C_ccall f_7163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6608)
static void C_ccall f_6608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6484)
static void C_ccall f_6484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6460)
static void C_ccall f_6460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6916)
static void C_ccall f_6916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6918)
static void C_ccall f_6918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7192)
static void C_ccall f_7192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7195)
static void C_ccall f_7195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7197)
static void C_ccall f_7197(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8318)
static void C_fcall f_8318(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5051)
static void C_ccall f_5051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6492)
static void C_ccall f_6492(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6495)
static void C_ccall f_6495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4139)
static void C_ccall f_4139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4133)
static void C_ccall f_4133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7448)
static void C_fcall f_7448(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7446)
static void C_ccall f_7446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5454)
static void C_ccall f_5454(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4110)
static void C_ccall f_4110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8307)
static void C_fcall f_8307(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4147)
static void C_fcall f_4147(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8088)
static void C_fcall f_8088(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4122)
static void C_ccall f_4122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3694)
static void C_ccall f_3694(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5421)
static void C_ccall f_5421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6478)
static void C_ccall f_6478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7438)
static void C_ccall f_7438(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7433)
static void C_ccall f_7433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5095)
static void C_fcall f_5095(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_7403)
static void C_ccall f_7403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7408)
static void C_fcall f_7408(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5086)
static void C_ccall f_5086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5088)
static void C_ccall f_5088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5082)
static void C_ccall f_5082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5084)
static void C_ccall f_5084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8046)
static void C_fcall f_8046(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8044)
static void C_ccall f_8044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5079)
static void C_ccall f_5079(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5077)
static void C_ccall f_5077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5071)
static void C_ccall f_5071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6639)
static void C_ccall f_6639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3649)
static void C_ccall f_3649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6633)
static void C_ccall f_6633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3646)
static void C_ccall f_3646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3640)
static void C_ccall f_3640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5325)
static void C_ccall f_5325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8572)
static void C_ccall f_8572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8570)
static void C_ccall f_8570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8574)
static void C_ccall f_8574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7348)
static void C_fcall f_7348(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7346)
static void C_ccall f_7346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3632)
static void C_ccall f_3632(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3630)
static void C_ccall f_3630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5355)
static void C_ccall f_5355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3618)
static void C_ccall f_3618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7236)
static void C_ccall f_7236(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6451)
static void C_ccall f_6451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7337)
static void C_ccall f_7337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7242)
static void C_ccall f_7242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7247)
static void C_ccall f_7247(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7245)
static void C_ccall f_7245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3417)
static void C_ccall f_3417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3415)
static void C_ccall f_3415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3419)
static void C_ccall f_3419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6425)
static void C_ccall f_6425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6422)
static void C_ccall f_6422(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6420)
static void C_ccall f_6420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7307)
static void C_ccall f_7307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3411)
static void C_ccall f_3411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3407)
static void C_ccall f_3407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3405)
static void C_ccall f_3405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3409)
static void C_ccall f_3409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8526)
static void C_fcall f_8526(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7312)
static void C_fcall f_7312(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6427)
static void C_ccall f_6427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3403)
static void C_ccall f_3403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3401)
static void C_ccall f_3401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7222)
static void C_ccall f_7222(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7221)
static void C_ccall f_7221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3478)
static void C_ccall f_3478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3473)
static void C_ccall f_3473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3475)
static void C_ccall f_3475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3471)
static void C_ccall f_3471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3467)
static void C_ccall f_3467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3469)
static void C_ccall f_3469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3463)
static void C_ccall f_3463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3465)
static void C_ccall f_3465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3461)
static void C_ccall f_3461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9548)
static void C_ccall f_9548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9215)
static void C_fcall f_9215(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3435)
static void C_ccall f_3435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3437)
static void C_ccall f_3437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3439)
static void C_ccall f_3439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3431)
static void C_ccall f_3431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3433)
static void C_ccall f_3433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9242)
static void C_ccall f_9242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3425)
static void C_ccall f_3425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3427)
static void C_ccall f_3427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3429)
static void C_ccall f_3429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7960)
static void C_fcall f_7960(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3421)
static void C_ccall f_3421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3423)
static void C_ccall f_3423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3383)
static void C_ccall f_3383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3380)
static void C_ccall f_3380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7969)
static void C_ccall f_7969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3387)
static void C_ccall f_3387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3498)
static void C_ccall f_3498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3385)
static void C_ccall f_3385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3496)
static void C_ccall f_3496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3951)
static void C_ccall f_3951(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3950)
static void C_ccall f_3950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9244)
static void C_ccall f_9244(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9248)
static void C_ccall f_9248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3485)
static void C_ccall f_3485(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3483)
static void C_ccall f_3483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3488)
static void C_ccall f_3488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3389)
static void C_ccall f_3389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7943)
static void C_ccall f_7943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3480)
static void C_ccall f_3480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9122)
static void C_fcall f_9122(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3941)
static void C_ccall f_3941(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7956)
static void C_ccall f_7956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7950)
static void C_ccall f_7950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9147)
static void C_ccall f_9147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3961)
static void C_ccall f_3961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3962)
static void C_ccall f_3962(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3459)
static void C_ccall f_3459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3457)
static void C_ccall f_3457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3455)
static void C_ccall f_3455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3453)
static void C_ccall f_3453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3451)
static void C_ccall f_3451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9152)
static void C_fcall f_9152(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5686)
static void C_ccall f_5686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3449)
static void C_ccall f_3449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3447)
static void C_ccall f_3447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3445)
static void C_ccall f_3445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3443)
static void C_ccall f_3443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8568)
static void C_ccall f_8568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3441)
static void C_ccall f_3441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8562)
static void C_ccall f_8562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3939)
static void C_ccall f_3939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8557)
static void C_ccall f_8557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8559)
static void C_ccall f_8559(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9117)
static void C_ccall f_9117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9665)
static void C_ccall f_9665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9662)
static void C_ccall f_9662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9677)
static void C_ccall f_9677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3991)
static void C_ccall f_3991(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7932)
static void C_ccall f_7932(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7935)
static void C_ccall f_7935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7936)
static void C_ccall f_7936(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7930)
static void C_ccall f_7930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6777)
static void C_fcall f_6777(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3989)
static void C_ccall f_3989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3983)
static void C_ccall f_3983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6030)
static void C_ccall f_6030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6036)
static void C_ccall f_6036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6041)
static void C_ccall f_6041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6038)
static void C_ccall f_6038(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4370)
static void C_ccall f_4370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6013)
static void C_ccall f_6013(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6016)
static void C_ccall f_6016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4384)
static void C_fcall f_4384(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7041)
static void C_ccall f_7041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4382)
static void C_ccall f_4382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3975)
static void C_ccall f_3975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5137)
static void C_ccall f_5137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4365)
static void C_ccall f_4365(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7027)
static void C_ccall f_7027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5892)
static void C_ccall f_5892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4363)
static void C_ccall f_4363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5129)
static void C_ccall f_5129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4610)
static void C_ccall f_4610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4619)
static void C_ccall f_4619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7983)
static void C_ccall f_7983(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7981)
static void C_ccall f_7981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7986)
static void C_ccall f_7986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5880)
static void C_ccall f_5880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5159)
static void C_ccall f_5159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5157)
static void C_ccall f_5157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5875)
static void C_ccall f_5875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5872)
static void C_ccall f_5872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5877)
static void C_ccall f_5877(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4630)
static void C_fcall f_4630(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4638)
static void C_ccall f_4638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6717)
static void C_fcall f_6717(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5994)
static void C_ccall f_5994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4650)
static void C_ccall f_4650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8299)
static void C_ccall f_8299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5980)
static void C_ccall f_5980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5982)
static void C_ccall f_5982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5984)
static void C_ccall f_5984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5986)
static void C_ccall f_5986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5988)
static void C_ccall f_5988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5117)
static void C_ccall f_5117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4621)
static void C_ccall f_4621(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9587)
static void C_ccall f_9587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5111)
static void C_ccall f_5111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5106)
static void C_ccall f_5106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5104)
static void C_ccall f_5104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6742)
static void C_ccall f_6742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4674)
static void C_ccall f_4674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9590)
static void C_fcall f_9590(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6747)
static void C_fcall f_6747(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4695)
static void C_ccall f_4695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4662)
static void C_ccall f_4662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9550)
static void C_fcall f_9550(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9567)
static void C_ccall f_9567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9565)
static void C_ccall f_9565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9563)
static void C_ccall f_9563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4689)
static void C_ccall f_4689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9578)
static void C_ccall f_9578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5296)
static void C_fcall f_5296(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5292)
static void C_fcall f_5292(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8278)
static void C_ccall f_8278(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8276)
static void C_ccall f_8276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5277)
static void C_fcall f_5277(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5275)
static void C_ccall f_5275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9062)
static void C_fcall f_9062(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8232)
static void C_ccall f_8232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4036)
static void C_ccall f_4036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8223)
static void C_ccall f_8223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8220)
static void C_ccall f_8220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8786)
static void C_fcall f_8786(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4041)
static void C_fcall f_4041(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9092)
static void C_fcall f_9092(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8466)
static void C_fcall f_8466(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8461)
static void C_ccall f_8461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7280)
static void C_ccall f_7280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7282)
static void C_fcall f_7282(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7109)
static void C_ccall f_7109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7274)
static void C_ccall f_7274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7112)
static void C_ccall f_7112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4205)
static void C_ccall f_4205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4202)
static void C_ccall f_4202(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4200)
static void C_ccall f_4200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4003)
static void C_ccall f_4003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8775)
static void C_fcall f_8775(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8243)
static void C_ccall f_8243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7002)
static void C_fcall f_7002(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4011)
static void C_fcall f_4011(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4220)
static void C_ccall f_4220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4237)
static void C_ccall f_4237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4234)
static void C_ccall f_4234(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7268)
static void C_ccall f_7268(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7266)
static void C_ccall f_7266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4232)
static void C_ccall f_4232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4245)
static void C_ccall f_4245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8706)
static void C_ccall f_8706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8708)
static void C_ccall f_8708(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5497)
static void C_fcall f_5497(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8733)
static void C_fcall f_8733(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5492)
static void C_ccall f_5492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8761)
static void C_ccall f_8761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8719)
static void C_ccall f_8719(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8717)
static void C_ccall f_8717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8714)
static void C_ccall f_8714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5467)
static void C_fcall f_5467(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5465)
static void C_ccall f_5465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9414)
static void C_fcall f_9414(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8496)
static void C_fcall f_8496(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8491)
static void C_ccall f_8491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8725)
static void C_ccall f_8725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4994)
static void C_ccall f_4994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9401)
static void C_ccall f_9401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4996)
static void C_ccall f_4996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4974)
static void C_ccall f_4974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6350)
static void C_ccall f_6350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6359)
static void C_ccall f_6359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3754)
static void C_ccall f_3754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8436)
static void C_fcall f_8436(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8744)
static void C_fcall f_8744(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9305)
static void C_ccall f_9305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6325)
static void C_ccall f_6325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6327)
static void C_fcall f_6327(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9314)
static void C_ccall f_9314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9316)
static void C_ccall f_9316(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9319)
static void C_ccall f_9319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3703)
static void C_ccall f_3703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8405)
static void C_fcall f_8405(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3716)
static void C_fcall f_3716(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9328)
static void C_ccall f_9328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3733)
static void C_ccall f_3733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3705)
static void C_fcall f_3705(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9339)
static void C_ccall f_9339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8969)
static void C_fcall f_8969(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9330)
static void C_ccall f_9330(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8213)
static void C_ccall f_8213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8214)
static void C_ccall f_8214(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9344)
static void C_ccall f_9344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8958)
static void C_fcall f_8958(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8956)
static void C_ccall f_8956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9341)
static void C_ccall f_9341(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8201)
static void C_ccall f_8201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8202)
static void C_ccall f_8202(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8208)
static void C_ccall f_8208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8949)
static void C_ccall f_8949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8946)
static void C_ccall f_8946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4954)
static void C_ccall f_4954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5786)
static void C_ccall f_5786(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5784)
static void C_ccall f_5784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5789)
static void C_ccall f_5789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4966)
static void C_ccall f_4966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3760)
static void C_ccall f_3760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8923)
static void C_ccall f_8923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5775)
static void C_ccall f_5775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5778)
static void C_ccall f_5778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3777)
static void C_ccall f_3777(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3813)
static void C_ccall f_3813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6575)
static void C_fcall f_6575(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3769)
static void C_fcall f_3769(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8906)
static void C_fcall f_8906(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3843)
static void C_ccall f_3843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5793)
static void C_ccall f_5793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5791)
static void C_ccall f_5791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6588)
static void C_ccall f_6588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3827)
static void C_fcall f_3827(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3825)
static void C_ccall f_3825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3786)
static void C_ccall f_3786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3788)
static void C_fcall f_3788(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4174)
static void C_ccall f_4174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5311)
static void C_ccall f_5311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6284)
static void C_ccall f_6284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6287)
static void C_ccall f_6287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5305)
static void C_ccall f_5305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5308)
static void C_fcall f_5308(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6281)
static void C_ccall f_6281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9712)
static void C_ccall f_9712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9716)
static void C_fcall f_9716(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5302)
static void C_fcall f_5302(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6298)
static void C_ccall f_6298(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6296)
static void C_ccall f_6296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6290)
static void C_ccall f_6290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4154)
static void C_ccall f_4154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8939)
static void C_ccall f_8939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5624)
static void C_ccall f_5624(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4131)
static void C_ccall f_4131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4165)
static void C_fcall f_4165(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9692)
static void C_ccall f_9692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9697)
static void C_ccall f_9697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6278)
static void C_ccall f_6278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8036)
static void C_ccall f_8036(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4940)
static void C_ccall f_4940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4945)
static void C_ccall f_4945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4938)
static void C_ccall f_4938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9752)
static void C_ccall f_9752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8022)
static void C_ccall f_8022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4913)
static void C_ccall f_4913(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4916)
static void C_ccall f_4916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4911)
static void C_ccall f_4911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3874)
static void C_fcall f_3874(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5662)
static void C_ccall f_5662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4920)
static void C_ccall f_4920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4922)
static void C_ccall f_4922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6514)
static void C_ccall f_6514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6511)
static void C_ccall f_6511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4918)
static void C_ccall f_4918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6519)
static void C_fcall f_6519(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6517)
static void C_ccall f_6517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4929)
static void C_fcall f_4929(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_6537)
static void C_ccall f_6537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3888)
static void C_ccall f_3888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5635)
static void C_ccall f_5635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7794)
static void C_fcall f_7794(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5637)
static void C_fcall f_5637(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7789)
static void C_ccall f_7789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6301)
static void C_ccall f_6301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6552)
static void C_ccall f_6552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5554)
static void C_fcall f_5554(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5552)
static void C_ccall f_5552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5558)
static void C_fcall f_5558(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5550)
static void C_ccall f_5550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6558)
static void C_ccall f_6558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(C_chicken_2dsyntax_toplevel)
C_externexport void C_ccall C_chicken_2dsyntax_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6310)
static void C_ccall f_6310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6312)
static void C_ccall f_6312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6314)
static void C_ccall f_6314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6316)
static void C_ccall f_6316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6561)
static void C_ccall f_6561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5542)
static void C_ccall f_5542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4710)
static void C_fcall f_4710(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5544)
static void C_ccall f_5544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5546)
static void C_ccall f_5546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5548)
static void C_ccall f_5548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6569)
static void C_fcall f_6569(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4720)
static void C_ccall f_4720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7858)
static void C_ccall f_7858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5562)
static void C_fcall f_5562(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7863)
static void C_fcall f_7863(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5560)
static void C_fcall f_5560(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7833)
static void C_fcall f_7833(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8193)
static void C_ccall f_8193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8198)
static void C_ccall f_8198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8191)
static void C_ccall f_8191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4768)
static void C_ccall f_4768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8185)
static void C_ccall f_8185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4766)
static void C_ccall f_4766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7828)
static void C_ccall f_7828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9275)
static void C_fcall f_9275(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7822)
static void C_ccall f_7822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6414)
static void C_ccall f_6414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7764)
static void C_fcall f_7764(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6060)
static void C_fcall f_6060(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6257)
static void C_ccall f_6257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7740)
static void C_ccall f_7740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6058)
static void C_ccall f_6058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4774)
static void C_ccall f_4774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4789)
static void C_ccall f_4789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7094)
static void C_fcall f_7094(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7584)
static void C_ccall f_7584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7587)
static void C_ccall f_7587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5010)
static void C_ccall f_5010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4782)
static void C_fcall f_4782(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6222)
static void C_ccall f_6222(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9257)
static void C_fcall f_9257(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5016)
static void C_ccall f_5016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9749)
static void C_ccall f_9749(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9747)
static void C_ccall f_9747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6230)
static void C_ccall f_6230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9741)
static void C_ccall f_9741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6232)
static void C_fcall f_6232(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5537)
static void C_ccall f_5537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5539)
static void C_ccall f_5539(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5531)
static void C_ccall f_5531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7701)
static void C_fcall f_7701(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8165)
static void C_ccall f_8165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8167)
static void C_ccall f_8167(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6214)
static void C_ccall f_6214(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7710)
static void C_ccall f_7710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6071)
static void C_fcall f_6071(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9298)
static void C_ccall f_9298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7618)
static void C_ccall f_7618(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7617)
static void C_ccall f_7617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7612)
static void C_ccall f_7612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9290)
static void C_ccall f_9290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7074)
static void C_fcall f_7074(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7071)
static void C_ccall f_7071(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7086)
static void C_ccall f_7086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7626)
static void C_ccall f_7626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7078)
static void C_ccall f_7078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4489)
static void C_ccall f_4489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8124)
static void C_ccall f_8124(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8122)
static void C_ccall f_8122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8127)
static void C_ccall f_8127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4491)
static void C_ccall f_4491(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6188)
static void C_ccall f_6188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7609)
static void C_ccall f_7609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9188)
static void C_ccall f_9188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7603)
static void C_ccall f_7603(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7602)
static void C_ccall f_7602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7600)
static void C_ccall f_7600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9183)
static void C_ccall f_9183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9185)
static void C_ccall f_9185(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9197)
static void C_ccall f_9197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7654)
static void C_ccall f_7654(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7665)
static void C_ccall f_7665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7667)
static void C_fcall f_7667(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7660)
static void C_ccall f_7660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7213)
static void C_ccall f_7213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7216)
static void C_ccall f_7216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6025)
static void C_fcall f_6025(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7639)
static void C_fcall f_7639(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7637)
static void C_ccall f_7637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7631)
static void C_ccall f_7631(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8672)
static void C_ccall f_8672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7054)
static void C_ccall f_7054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8679)
static void C_ccall f_8679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8673)
static void C_ccall f_8673(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6028)
static void C_ccall f_6028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7069)
static void C_ccall f_7069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7084)
static void C_fcall f_7084(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5229)
static void C_ccall f_5229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5223)
static void C_ccall f_5223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6003)
static void C_ccall f_6003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6005)
static void C_ccall f_6005(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8150)
static void C_ccall f_8150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5257)
static void C_ccall f_5257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7200)
static void C_ccall f_7200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7207)
static void C_ccall f_7207(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7206)
static void C_ccall f_7206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8145)
static void C_ccall f_8145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5252)
static void C_ccall f_5252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5250)
static void C_ccall f_5250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8147)
static void C_ccall f_8147(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8682)
static void C_ccall f_8682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8688)
static void C_ccall f_8688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8636)
static void C_ccall f_8636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5234)
static void C_ccall f_5234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5231)
static void C_ccall f_5231(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6102)
static void C_fcall f_6102(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8669)
static void C_ccall f_8669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8663)
static void C_ccall f_8663(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8662)
static void C_ccall f_8662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4420)
static void C_ccall f_4420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4422)
static void C_ccall f_4422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4424)
static void C_ccall f_4424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4426)
static void C_ccall f_4426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6157)
static void C_ccall f_6157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8613)
static void C_ccall f_8613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3567)
static void C_ccall f_3567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9500)
static void C_ccall f_9500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3561)
static void C_ccall f_3561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8648)
static void C_ccall f_8648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5246)
static void C_ccall f_5246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5244)
static void C_ccall f_5244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3518)
static void C_ccall f_3518(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_8603)
static void C_fcall trf_8603(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8603(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8603(t0,t1,t2);}

C_noret_decl(trf_9020)
static void C_fcall trf_9020(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9020(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9020(t0,t1,t2,t3);}

C_noret_decl(trf_3593)
static void C_fcall trf_3593(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3593(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3593(t0,t1,t2);}

C_noret_decl(trf_9031)
static void C_fcall trf_9031(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9031(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9031(t0,t1);}

C_noret_decl(trf_8895)
static void C_fcall trf_8895(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8895(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8895(t0,t1,t2,t3);}

C_noret_decl(trf_9002)
static void C_fcall trf_9002(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9002(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9002(t0,t1,t2);}

C_noret_decl(trf_8864)
static void C_fcall trf_8864(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8864(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8864(t0,t1);}

C_noret_decl(trf_8853)
static void C_fcall trf_8853(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8853(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8853(t0,t1,t2,t3);}

C_noret_decl(trf_7495)
static void C_fcall trf_7495(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7495(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7495(t0,t1,t2);}

C_noret_decl(trf_5946)
static void C_fcall trf_5946(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5946(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5946(t0,t1,t2);}

C_noret_decl(trf_5940)
static void C_fcall trf_5940(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5940(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5940(t0,t1,t2);}

C_noret_decl(trf_6876)
static void C_fcall trf_6876(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6876(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6876(t0,t1,t2,t3);}

C_noret_decl(trf_4285)
static void C_fcall trf_4285(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4285(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4285(t0,t1);}

C_noret_decl(trf_5723)
static void C_fcall trf_5723(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5723(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5723(t0,t1,t2);}

C_noret_decl(trf_8363)
static void C_fcall trf_8363(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8363(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8363(t0,t1);}

C_noret_decl(trf_7899)
static void C_fcall trf_7899(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7899(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7899(t0,t1,t2);}

C_noret_decl(trf_6807)
static void C_fcall trf_6807(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6807(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6807(t0,t1,t2);}

C_noret_decl(trf_7378)
static void C_fcall trf_7378(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7378(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7378(t0,t1,t2);}

C_noret_decl(trf_4547)
static void C_fcall trf_4547(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4547(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4547(t0,t1,t2,t3);}

C_noret_decl(trf_4591)
static void C_fcall trf_4591(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4591(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4591(t0,t1,t2,t3);}

C_noret_decl(trf_7562)
static void C_fcall trf_7562(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7562(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7562(t0,t1,t2,t3);}

C_noret_decl(trf_7536)
static void C_fcall trf_7536(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7536(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7536(t0,t1,t2,t3);}

C_noret_decl(trf_6948)
static void C_fcall trf_6948(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6948(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6948(t0,t1,t2);}

C_noret_decl(trf_8394)
static void C_fcall trf_8394(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8394(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8394(t0,t1,t2,t3);}

C_noret_decl(trf_8352)
static void C_fcall trf_8352(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8352(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8352(t0,t1,t2,t3);}

C_noret_decl(trf_8057)
static void C_fcall trf_8057(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8057(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8057(t0,t1);}

C_noret_decl(trf_3662)
static void C_fcall trf_3662(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3662(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3662(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4103)
static void C_fcall trf_4103(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4103(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4103(t0,t1,t2,t3);}

C_noret_decl(trf_8318)
static void C_fcall trf_8318(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8318(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8318(t0,t1);}

C_noret_decl(trf_7448)
static void C_fcall trf_7448(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7448(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7448(t0,t1,t2);}

C_noret_decl(trf_8307)
static void C_fcall trf_8307(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8307(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8307(t0,t1,t2,t3);}

C_noret_decl(trf_4147)
static void C_fcall trf_4147(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4147(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4147(t0,t1,t2,t3);}

C_noret_decl(trf_8088)
static void C_fcall trf_8088(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8088(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8088(t0,t1,t2);}

C_noret_decl(trf_5095)
static void C_fcall trf_5095(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5095(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5095(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_7408)
static void C_fcall trf_7408(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7408(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7408(t0,t1,t2);}

C_noret_decl(trf_8046)
static void C_fcall trf_8046(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8046(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8046(t0,t1,t2,t3);}

C_noret_decl(trf_7348)
static void C_fcall trf_7348(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7348(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7348(t0,t1,t2);}

C_noret_decl(trf_8526)
static void C_fcall trf_8526(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8526(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8526(t0,t1,t2);}

C_noret_decl(trf_7312)
static void C_fcall trf_7312(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7312(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7312(t0,t1,t2);}

C_noret_decl(trf_9215)
static void C_fcall trf_9215(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9215(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9215(t0,t1);}

C_noret_decl(trf_7960)
static void C_fcall trf_7960(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7960(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7960(t0,t1,t2);}

C_noret_decl(trf_9122)
static void C_fcall trf_9122(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9122(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9122(t0,t1,t2);}

C_noret_decl(trf_9152)
static void C_fcall trf_9152(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9152(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9152(t0,t1,t2);}

C_noret_decl(trf_6777)
static void C_fcall trf_6777(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6777(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6777(t0,t1,t2);}

C_noret_decl(trf_4384)
static void C_fcall trf_4384(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4384(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4384(t0,t1,t2);}

C_noret_decl(trf_4630)
static void C_fcall trf_4630(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4630(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4630(t0,t1);}

C_noret_decl(trf_6717)
static void C_fcall trf_6717(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6717(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6717(t0,t1,t2);}

C_noret_decl(trf_9590)
static void C_fcall trf_9590(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9590(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9590(t0,t1);}

C_noret_decl(trf_6747)
static void C_fcall trf_6747(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6747(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6747(t0,t1,t2);}

C_noret_decl(trf_9550)
static void C_fcall trf_9550(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9550(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9550(t0,t1,t2,t3);}

C_noret_decl(trf_5296)
static void C_fcall trf_5296(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5296(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5296(t0,t1);}

C_noret_decl(trf_5292)
static void C_fcall trf_5292(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5292(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5292(t0,t1);}

C_noret_decl(trf_5277)
static void C_fcall trf_5277(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5277(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5277(t0,t1,t2,t3);}

C_noret_decl(trf_9062)
static void C_fcall trf_9062(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9062(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9062(t0,t1,t2);}

C_noret_decl(trf_8786)
static void C_fcall trf_8786(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8786(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8786(t0,t1);}

C_noret_decl(trf_4041)
static void C_fcall trf_4041(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4041(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4041(t0,t1,t2);}

C_noret_decl(trf_9092)
static void C_fcall trf_9092(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9092(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9092(t0,t1,t2);}

C_noret_decl(trf_8466)
static void C_fcall trf_8466(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8466(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8466(t0,t1,t2);}

C_noret_decl(trf_7282)
static void C_fcall trf_7282(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7282(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7282(t0,t1,t2);}

C_noret_decl(trf_8775)
static void C_fcall trf_8775(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8775(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8775(t0,t1,t2,t3);}

C_noret_decl(trf_7002)
static void C_fcall trf_7002(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7002(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7002(t0,t1,t2);}

C_noret_decl(trf_4011)
static void C_fcall trf_4011(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4011(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4011(t0,t1,t2);}

C_noret_decl(trf_5497)
static void C_fcall trf_5497(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5497(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5497(t0,t1,t2);}

C_noret_decl(trf_8733)
static void C_fcall trf_8733(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8733(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8733(t0,t1,t2,t3);}

C_noret_decl(trf_5467)
static void C_fcall trf_5467(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5467(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5467(t0,t1,t2);}

C_noret_decl(trf_9414)
static void C_fcall trf_9414(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9414(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9414(t0,t1);}

C_noret_decl(trf_8496)
static void C_fcall trf_8496(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8496(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8496(t0,t1,t2);}

C_noret_decl(trf_8436)
static void C_fcall trf_8436(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8436(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8436(t0,t1,t2);}

C_noret_decl(trf_8744)
static void C_fcall trf_8744(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8744(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8744(t0,t1);}

C_noret_decl(trf_6327)
static void C_fcall trf_6327(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6327(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6327(t0,t1,t2,t3);}

C_noret_decl(trf_8405)
static void C_fcall trf_8405(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8405(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8405(t0,t1);}

C_noret_decl(trf_3716)
static void C_fcall trf_3716(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3716(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3716(t0,t1);}

C_noret_decl(trf_3705)
static void C_fcall trf_3705(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3705(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3705(t0,t1,t2,t3);}

C_noret_decl(trf_8969)
static void C_fcall trf_8969(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8969(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8969(t0,t1);}

C_noret_decl(trf_8958)
static void C_fcall trf_8958(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8958(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8958(t0,t1,t2,t3);}

C_noret_decl(trf_6575)
static void C_fcall trf_6575(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6575(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6575(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3769)
static void C_fcall trf_3769(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3769(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3769(t0,t1);}

C_noret_decl(trf_8906)
static void C_fcall trf_8906(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8906(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8906(t0,t1);}

C_noret_decl(trf_3827)
static void C_fcall trf_3827(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3827(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3827(t0,t1,t2,t3);}

C_noret_decl(trf_3788)
static void C_fcall trf_3788(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3788(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3788(t0,t1,t2);}

C_noret_decl(trf_5308)
static void C_fcall trf_5308(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5308(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5308(t0,t1);}

C_noret_decl(trf_9716)
static void C_fcall trf_9716(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9716(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9716(t0,t1,t2);}

C_noret_decl(trf_5302)
static void C_fcall trf_5302(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5302(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5302(t0,t1);}

C_noret_decl(trf_4165)
static void C_fcall trf_4165(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4165(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4165(t0,t1);}

C_noret_decl(trf_3874)
static void C_fcall trf_3874(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3874(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3874(t0,t1);}

C_noret_decl(trf_6519)
static void C_fcall trf_6519(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6519(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_6519(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_4929)
static void C_fcall trf_4929(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4929(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_4929(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_7794)
static void C_fcall trf_7794(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7794(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7794(t0,t1,t2,t3);}

C_noret_decl(trf_5637)
static void C_fcall trf_5637(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5637(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5637(t0,t1,t2);}

C_noret_decl(trf_5554)
static void C_fcall trf_5554(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5554(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5554(t0,t1,t2);}

C_noret_decl(trf_5558)
static void C_fcall trf_5558(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5558(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5558(t0,t1);}

C_noret_decl(trf_4710)
static void C_fcall trf_4710(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4710(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4710(t0,t1);}

C_noret_decl(trf_6569)
static void C_fcall trf_6569(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6569(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_6569(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_5562)
static void C_fcall trf_5562(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5562(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5562(t0,t1);}

C_noret_decl(trf_7863)
static void C_fcall trf_7863(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7863(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7863(t0,t1,t2,t3);}

C_noret_decl(trf_5560)
static void C_fcall trf_5560(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5560(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5560(t0,t1);}

C_noret_decl(trf_7833)
static void C_fcall trf_7833(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7833(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7833(t0,t1,t2);}

C_noret_decl(trf_9275)
static void C_fcall trf_9275(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9275(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9275(t0,t1);}

C_noret_decl(trf_7764)
static void C_fcall trf_7764(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7764(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7764(t0,t1,t2);}

C_noret_decl(trf_6060)
static void C_fcall trf_6060(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6060(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6060(t0,t1,t2,t3);}

C_noret_decl(trf_7094)
static void C_fcall trf_7094(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7094(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7094(t0,t1);}

C_noret_decl(trf_4782)
static void C_fcall trf_4782(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4782(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4782(t0,t1,t2,t3);}

C_noret_decl(trf_9257)
static void C_fcall trf_9257(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9257(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9257(t0,t1);}

C_noret_decl(trf_6232)
static void C_fcall trf_6232(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6232(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6232(t0,t1,t2);}

C_noret_decl(trf_7701)
static void C_fcall trf_7701(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7701(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7701(t0,t1);}

C_noret_decl(trf_6071)
static void C_fcall trf_6071(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6071(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6071(t0,t1);}

C_noret_decl(trf_7074)
static void C_fcall trf_7074(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7074(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7074(t0,t1,t2,t3);}

C_noret_decl(trf_7667)
static void C_fcall trf_7667(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7667(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7667(t0,t1,t2);}

C_noret_decl(trf_6025)
static void C_fcall trf_6025(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6025(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6025(t0,t1);}

C_noret_decl(trf_7639)
static void C_fcall trf_7639(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7639(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_7639(t0,t1,t2,t3,t4);}

C_noret_decl(trf_7084)
static void C_fcall trf_7084(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7084(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7084(t0,t1);}

C_noret_decl(trf_6102)
static void C_fcall trf_6102(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6102(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6102(t0,t1,t2,t3);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

/* k3499 in k3497 in k3495 in k3487 */
static void C_ccall f_3500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3500,2,t0,t1);}
t2=C_a_i_list(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t3=C_a_i_list(&a,2,((C_word*)t0)[2],lf[15]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3518,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:1306: ##compiler#check-and-validate-type */
t5=*((C_word*)lf[18]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,t1,lf[12],((C_word*)t0)[3]);}

/* k8627 in k8620 in loop in k8571 in k8569 in k8567 in k8561 */
static void C_ccall f_8629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8629,2,t0,t1);}
if(C_truep(t1)){
t2=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t3=C_slot(((C_word*)t0)[3],C_fix(1));
/* chicken-syntax.scm:261: loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_8603(t4,((C_word*)t0)[5],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8636,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:259: c */
t3=((C_word*)t0)[8];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[9],((C_word*)t0)[10]);}}

/* k6147 in build */
static void C_ccall f_6148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6148,2,t0,t1);}
t2=C_i_car(((C_word*)t0)[2]);
t3=C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]);
t4=C_a_i_list(&a,2,t2,t3);
t5=C_a_i_list(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t6=C_a_i_list(&a,2,t1,t5);
t7=C_a_i_list(&a,2,t4,t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6157,a[2]=((C_word*)t0)[6],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t9=((C_word*)t0)[2];
t10=C_u_i_cdr(t9);
if(C_truep(C_i_pairp(t10))){
t11=((C_word*)t0)[2];
t12=C_u_i_cdr(t11);
/* chicken-syntax.scm:814: build */
t13=((C_word*)((C_word*)t0)[7])[1];
f_6102(t13,t8,t12,t1);}
else{
/* chicken-syntax.scm:815: build */
t11=((C_word*)((C_word*)t0)[7])[1];
f_6102(t11,t8,C_SCHEME_END_OF_LIST,t1);}}

/* k8620 in loop in k8571 in k8569 in k8567 in k8561 */
static void C_ccall f_8622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8622,2,t0,t1);}
if(C_truep(t1)){
t2=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t3=C_slot(((C_word*)t0)[3],C_fix(1));
/* chicken-syntax.scm:261: loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_8603(t4,((C_word*)t0)[5],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8629,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm:258: c */
t3=((C_word*)t0)[9];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[10],((C_word*)t0)[12]);}}

/* k3534 */
static void C_ccall f_3535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3535,2,t0,t1);}
t2=C_i_memq(lf[13],*((C_word*)lf[14]+1));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3539,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:1273: gensym */
t4=*((C_word*)lf[32]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k3538 in k3534 */
static void C_ccall f_3539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3539,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3541,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:1274: get-line-number */
t3=*((C_word*)lf[31]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k3529 in k3470 in k3468 in k3466 in k3464 in k3462 in k3460 in k3458 in k3456 in k3454 in k3452 in k3450 in k3448 in k3446 in k3444 in k3442 in k3440 in k3438 in k3436 in k3434 in k3432 in k3430 in ... */
static void C_ccall f_3530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:1267: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[25],C_SCHEME_END_OF_LIST,t1);}

/* k9528 in k9471 in k9469 in k9467 in k9465 in k9459 */
static void C_ccall f_9530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9530,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9697,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9712,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=((C_word*)t0)[6];
/* ##sys#string-append */
t5=*((C_word*)lf[278]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[280],t4);}

/* f_3532 in k3470 in k3468 in k3466 in k3464 in k3462 in k3460 in k3458 in k3456 in k3454 in k3452 in k3450 in k3448 in k3446 in k3444 in k3442 in k3440 in k3438 in k3436 in k3434 in k3432 in k3430 in ... */
static void C_ccall f_3532(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3532,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3535,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:1271: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[25],t2,lf[33]);}

/* k3398 in k3396 in k3394 in k3392 in k3390 in k3388 in k3386 in k3384 in k3382 in k3379 */
static void C_ccall f_3399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3399,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3401,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8648,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8650,a[2]=((C_word)li154),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:211: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k3394 in k3392 in k3390 in k3388 in k3386 in k3384 in k3382 in k3379 */
static void C_ccall f_3395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3395,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3397,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9242,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[179]+1);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9244,a[2]=((C_word)li156),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:170: ##sys#er-transformer */
t6=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t3,t5);}

/* k3396 in k3394 in k3392 in k3390 in k3388 in k3386 in k3384 in k3382 in k3379 */
static void C_ccall f_3397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3397,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3399,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9183,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9185,a[2]=((C_word)li155),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:191: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k3390 in k3388 in k3386 in k3384 in k3382 in k3379 */
static void C_ccall f_3391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3391,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3393,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9328,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9330,a[2]=((C_word)li158),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:157: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k3392 in k3390 in k3388 in k3386 in k3384 in k3382 in k3379 */
static void C_ccall f_3393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3393,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3395,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9314,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9316,a[2]=((C_word)li157),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:163: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* loop in k8571 in k8569 in k8567 in k8561 */
static void C_fcall f_8603(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8603,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=t2;
t4=C_u_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8613,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8622,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t5,a[9]=((C_word*)t0)[6],a[10]=t4,a[11]=((C_word*)t0)[7],a[12]=((C_word*)t0)[8],tmp=(C_word)a,a+=13,tmp);
/* chicken-syntax.scm:257: c */
t7=((C_word*)t0)[6];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t4,((C_word*)t0)[9]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5177 in k5155 in loop in k5087 in k5085 in k5083 in k5081 */
static void C_ccall f_5179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5179,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
if(C_truep(C_i_nullp(t3))){
/* chicken-syntax.scm:1003: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_5095(t4,((C_word*)t0)[4],C_SCHEME_END_OF_LIST,((C_word*)t0)[5],((C_word*)t0)[6],C_SCHEME_TRUE);}
else{
/* chicken-syntax.scm:1004: syntax-error */
t4=*((C_word*)lf[45]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[4],lf[107],lf[108],((C_word*)t0)[7]);}}
else{
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=((C_word*)t0)[2];
t5=C_u_i_car(t4);
t6=C_a_i_cons(&a,2,t5,((C_word*)t0)[6]);
/* chicken-syntax.scm:1007: loop */
t7=((C_word*)((C_word*)t0)[3])[1];
f_5095(t7,((C_word*)t0)[4],t3,((C_word*)t0)[5],t6,C_SCHEME_FALSE);}}

/* k5172 in k5155 in loop in k5087 in k5085 in k5083 in k5081 */
static void C_ccall f_5173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:999: r */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],t1);}

/* k4596 in loop2076 in k4581 in k4576 in k4573 */
static void C_ccall f_4598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4598,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_eqp(((C_word*)t0)[3],C_SCHEME_END_OF_LIST));}
else{
t2=C_i_cdr(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4610,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:1100: ##sys#+ */
t4=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[5],C_fix(-1));}}

/* map-loop254 in k8937 in k8680 in k8670 in k8660 in k8652 */
static void C_fcall f_9020(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9020,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_a_i_list(&a,2,t6,t7);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9031,a[2]=((C_word*)t0)[2],a[3]=t9,a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t11=t10;
f_9031(t11,C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t9));}
else{
t11=C_mutate(((C_word *)((C_word*)t0)[4])+1,t9);
t12=t10;
f_9031(t12,t11);}}
else{
t6=((C_word*)((C_word*)t0)[4])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k4065 in map-loop2269 in k3948 */
static void C_ccall f_4066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4066,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4041(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4041(t6,((C_word*)t0)[5],t5);}}

/* map-loop2455 in k3540 in k3538 in k3534 */
static void C_fcall f_3593(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3593,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3618,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-syntax.scm:1279: g2461 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3589 in k3540 in k3538 in k3534 */
static void C_ccall f_3591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3591,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=C_a_i_cons(&a,2,lf[29],t3);
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_list(&a,3,lf[30],((C_word*)t0)[5],t4));}

/* k4443 in k4425 in k4423 in k4421 in k4419 */
static void C_ccall f_4444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4444,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4447,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_eqp(lf[44],t1);
if(C_truep(t3)){
t4=C_a_i_list(&a,2,((C_word*)t0)[2],lf[44]);
t5=C_a_i_list(&a,4,lf[16],((C_word*)t0)[3],((C_word*)t0)[4],t4);
t6=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_list(&a,2,lf[17],t5));}
else{
if(C_truep(C_i_symbolp(t1))){
t4=C_a_i_list(&a,2,lf[81],t1);
t5=C_a_i_list(&a,2,((C_word*)t0)[2],t4);
t6=C_a_i_list(&a,4,lf[16],((C_word*)t0)[3],((C_word*)t0)[4],t5);
t7=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_list(&a,2,lf[17],t6));}
else{
if(C_truep(C_i_listp(t1))){
/* chicken-syntax.scm:1126: ##sys#validate-exports */
t4=*((C_word*)lf[71]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t1,lf[79]);}
else{
t4=C_i_caddr(((C_word*)t0)[6]);
/* chicken-syntax.scm:1128: syntax-error-hook */
t5=*((C_word*)lf[82]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,lf[79],lf[83],t4);}}}}

/* k4445 in k4443 in k4425 in k4423 in k4421 in k4419 */
static void C_ccall f_4447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4447,2,t0,t1);}
t2=C_a_i_list(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_list(&a,4,lf[16],((C_word*)t0)[3],((C_word*)t0)[4],t2);
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_list(&a,2,lf[17],t3));}

/* k9030 in map-loop254 in k8937 in k8680 in k8670 in k8660 in k8652 */
static void C_fcall f_9031(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[3]);
t3=C_slot(((C_word*)t0)[4],C_fix(1));
t4=C_slot(((C_word*)t0)[5],C_fix(1));
t5=((C_word*)((C_word*)t0)[6])[1];
f_9020(t5,((C_word*)t0)[7],t3,t4);}

/* k4085 in k4079 */
static void C_ccall f_4087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4087,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4089,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cdr(((C_word*)t0)[2]);
/* chicken-syntax.scm:1196: ##sys#length */
t4=*((C_word*)lf[59]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t2=((C_word*)t0)[3];
f_3950(2,t2,C_SCHEME_FALSE);}}

/* k4088 in k4085 in k4079 */
static void C_ccall f_4089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4089,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4095,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:1196: ##sys#>= */
t3=*((C_word*)lf[58]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,C_fix(0));}

/* k4079 */
static void C_ccall f_4081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4081,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4087,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cdr(((C_word*)t0)[2]);
/* chicken-syntax.scm:1196: ##sys#list? */
t4=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t2=((C_word*)t0)[3];
f_3950(2,t2,C_SCHEME_FALSE);}}

/* f_8650 in k3398 in k3396 in k3394 in k3392 in k3390 in k3388 in k3386 in k3384 in k3382 in k3379 */
static void C_ccall f_8650(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8650,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8653,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:213: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[248],t2,lf[249]);}

/* k8652 */
static void C_ccall f_8653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8653,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=((C_word*)t0)[2];
t4=C_u_i_cdr(t3);
t5=C_u_i_cdr(t4);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=*((C_word*)lf[112]+1);
t11=C_i_check_list_2(t2,lf[28]);
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8662,a[2]=((C_word*)t0)[3],a[3]=t5,a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9152,a[2]=t9,a[3]=t14,a[4]=t7,a[5]=((C_word)li153),tmp=(C_word)a,a+=6,tmp));
t16=((C_word*)t14)[1];
f_9152(t16,t12,t2);}

/* k4093 in k4088 in k4085 in k4079 */
static void C_ccall f_4095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4095,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_cdr(((C_word*)t0)[2]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4103,a[2]=t4,a[3]=((C_word)li16),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_4103(t6,((C_word*)t0)[3],t2,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
f_3950(2,t2,C_SCHEME_FALSE);}}

/* f_3558 in k3540 in k3538 in k3534 */
static void C_ccall f_3558(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3558,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3561,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=C_i_car(t2);
/* chicken-syntax.scm:1280: ##sys#strip-syntax */
t5=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* map-loop345 in k8687 in k8680 in k8670 in k8660 in k8652 */
static void C_fcall f_8895(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8895,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8923,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=t1,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t7=C_slot(t2,C_fix(0));
t8=C_slot(t3,C_fix(0));
/* chicken-syntax.scm:228: g351 */
t9=((C_word*)t0)[5];
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t6,t7,t8);}
else{
t6=((C_word*)((C_word*)t0)[4])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k4408 in map-loop2146 in k4327 in k4325 */
static void C_ccall f_4409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4409,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4384(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4384(t6,((C_word*)t0)[5],t5);}}

/* k8880 in map-loop381 in k8832 in k8687 in k8680 in k8670 in k8660 in k8652 */
static void C_ccall f_8881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8881,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8864,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t4=t3;
f_8864(t4,C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2));}
else{
t4=C_mutate(((C_word *)((C_word*)t0)[7])+1,t2);
t5=t3;
f_8864(t5,t4);}}

/* k3540 in k3538 in k3534 */
static void C_ccall f_3541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3541,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=C_a_i_list(&a,2,((C_word*)t0)[3],t2);
t4=C_a_i_list(&a,1,t3);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3558,a[2]=((C_word*)t0)[4],a[3]=((C_word)li1),tmp=(C_word)a,a+=4,tmp);
t10=((C_word*)t0)[2];
t11=C_u_i_cdr(t10);
t12=C_u_i_cdr(t11);
t13=C_i_check_list_2(t12,lf[28]);
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3591,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t15=C_SCHEME_UNDEFINED;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_set_block_item(t16,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3593,a[2]=t8,a[3]=t16,a[4]=t6,a[5]=t9,a[6]=((C_word)li2),tmp=(C_word)a,a+=7,tmp));
t18=((C_word*)t16)[1];
f_3593(t18,t14,t12);}

/* f_4417 in k3458 in k3456 in k3454 in k3452 in k3450 in k3448 in k3446 in k3444 in k3442 in k3440 in k3438 in k3436 in k3434 in k3432 in k3430 in k3428 in k3426 in k3424 in k3422 in k3420 in k3418 in ... */
static void C_ccall f_4417(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4417,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4420,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:1111: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[79],t2,lf[85]);}

/* k4414 in k3458 in k3456 in k3454 in k3452 in k3450 in k3448 in k3446 in k3444 in k3442 in k3440 in k3438 in k3436 in k3434 in k3432 in k3430 in k3428 in k3426 in k3424 in k3422 in k3420 in k3418 in ... */
static void C_ccall f_4415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:1107: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[79],C_SCHEME_END_OF_LIST,t1);}

/* loop in k8944 in k8937 in k8680 in k8670 in k8660 in k8652 */
static void C_fcall f_9002(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_9002,NULL,3,t0,t1,t2);}
t3=C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9015,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=C_fixnum_difference(t2,C_fix(1));
/* chicken-syntax.scm:225: loop */
t7=t4;
t8=t5;
t1=t7;
t2=t8;
goto loop;}}

/* k8112 in map-loop775 in k7985 */
static void C_ccall f_8113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8113,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8088(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8088(t6,((C_word*)t0)[5],t5);}}

/* k9014 in loop in k8944 in k8937 in k8680 in k8670 in k8660 in k8652 */
static void C_ccall f_9015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9015,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,C_SCHEME_FALSE,t1));}

/* k8863 in k8880 in map-loop381 in k8832 in k8687 in k8680 in k8670 in k8660 in k8652 */
static void C_fcall f_8864(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[3]);
t3=C_slot(((C_word*)t0)[4],C_fix(1));
t4=C_slot(((C_word*)t0)[5],C_fix(1));
t5=((C_word*)((C_word*)t0)[6])[1];
f_8853(t5,((C_word*)t0)[7],t3,t4);}

/* map-loop381 in k8832 in k8687 in k8680 in k8670 in k8660 in k8652 */
static void C_fcall f_8853(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8853,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8881,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=t1,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t7=C_slot(t2,C_fix(0));
t8=C_slot(t3,C_fix(0));
/* chicken-syntax.scm:230: g387 */
t9=((C_word*)t0)[5];
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t6,t7,t8);}
else{
t6=((C_word*)((C_word*)t0)[4])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k7472 in map-loop1062 in k7199 */
static void C_ccall f_7473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7473,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7448(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7448(t6,((C_word*)t0)[5],t5);}}

/* f_5935 in k6277 in k6280 in k6283 in k6286 in k6289 in k3434 in k3432 in k3430 in k3428 in k3426 in k3424 in k3422 in k3420 in k3418 in k3416 in k3413 in k3410 in k3408 in k3406 in k3404 in k3402 in ... */
static void C_ccall f_5935(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5935,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5938,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:766: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[154],t2,lf[169]);}

/* k5932 in k6277 in k6280 in k6283 in k6286 in k6289 in k3434 in k3432 in k3430 in k3428 in k3426 in k3424 in k3422 in k3420 in k3418 in k3416 in k3413 in k3410 in k3408 in k3406 in k3404 in k3402 in ... */
static void C_ccall f_5933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:757: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[154],((C_word*)t0)[3],t1);}

/* k5937 */
static void C_ccall f_5938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5938,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5940,a[2]=((C_word*)t0)[2],a[3]=((C_word)li52),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5970,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:772: require */
t4=*((C_word*)lf[167]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[168]);}

/* k8843 in k8832 in k8687 in k8680 in k8670 in k8660 in k8652 */
static void C_ccall f_8845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8845,2,t0,t1);}
t2=C_a_i_list(&a,1,lf[223]);
t3=C_a_i_list(&a,1,t2);
/* chicken-syntax.scm:214: ##sys#append */
t4=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t1,t3);}

/* k7478 in k3416 in k3413 in k3410 in k3408 in k3406 in k3404 in k3402 in k3400 in k3398 in k3396 in k3394 in k3392 in k3390 in k3388 in k3386 in k3384 in k3382 in k3379 */
static void C_ccall f_7479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:410: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[213],C_SCHEME_END_OF_LIST,t1);}

/* k7489 in k7483 */
static void C_ccall f_7490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7490,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7495,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,a[5]=((C_word)li99),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_7495(t5,((C_word*)t0)[3],((C_word*)t0)[4]);}

/* fold in k7489 in k7483 */
static void C_fcall f_7495(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7495,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,lf[30],t3));}
else{
t3=C_i_car(t2);
t4=C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7517,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=t2;
t7=C_u_i_cdr(t6);
/* chicken-syntax.scm:422: fold */
t10=t5;
t11=t7;
t1=t10;
t2=t11;
goto loop;}}

/* k5958 in loop in genvars in k5937 */
static void C_ccall f_5959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5959,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5962,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* chicken-syntax.scm:771: loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_5946(t4,t2,t3);}

/* k5813 in k5801 in k5792 in k5790 in k5788 */
static void C_ccall f_5814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[111],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5814,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=C_a_i_list(&a,1,t2);
t4=C_i_caddr(((C_word*)t0)[2]);
t5=C_a_i_list(&a,3,lf[97],C_SCHEME_END_OF_LIST,t4);
t6=C_a_i_list(&a,2,((C_word*)t0)[3],t5);
t7=C_a_i_list(&a,3,lf[97],t3,t6);
t8=((C_word*)t0)[2];
t9=C_u_i_cdr(t8);
t10=C_u_i_cdr(t9);
t11=C_u_i_cdr(t10);
t12=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t11);
t13=C_a_i_cons(&a,2,lf[97],t12);
t14=C_a_i_list(&a,3,lf[139],lf[140],((C_word*)t0)[4]);
t15=C_a_i_list(&a,3,lf[97],C_SCHEME_END_OF_LIST,t14);
t16=C_a_i_list(&a,2,((C_word*)t0)[3],t15);
t17=C_a_i_list(&a,3,lf[97],((C_word*)t0)[4],t16);
t18=C_a_i_list(&a,3,lf[141],t13,t17);
t19=C_a_i_list(&a,3,lf[97],C_SCHEME_END_OF_LIST,t18);
t20=C_a_i_list(&a,3,t1,t7,t19);
t21=C_a_i_list(&a,3,lf[97],((C_word*)t0)[5],t20);
t22=C_a_i_list(&a,2,((C_word*)t0)[6],t21);
t23=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t23+1)))(2,t23,C_a_i_list(&a,1,t22));}

/* f_8826 in k8687 in k8680 in k8670 in k8660 in k8652 */
static void C_ccall f_8826(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8826,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_list(&a,3,lf[211],t2,t3));}

/* k8823 in k8687 in k8680 in k8670 in k8660 in k8652 */
static void C_ccall f_8824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8824,2,t0,t1);}
t2=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=C_a_i_cons(&a,2,lf[97],t2);
t4=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[2]);
t5=C_a_i_cons(&a,2,lf[97],t4);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8706,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8708,a[2]=((C_word)li139),tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8714,a[2]=t6,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8775,a[2]=t10,a[3]=t14,a[4]=t8,a[5]=t11,a[6]=((C_word)li142),tmp=(C_word)a,a+=7,tmp));
t16=((C_word*)t14)[1];
f_8775(t16,t12,((C_word*)t0)[7],((C_word*)t0)[5]);}

/* f_7481 in k3416 in k3413 in k3410 in k3408 in k3406 in k3404 in k3402 in k3400 in k3398 in k3396 in k3394 in k3392 in k3390 in k3388 in k3386 in k3384 in k3382 in k3379 */
static void C_ccall f_7481(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7481,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7484,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:414: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[213],t2,lf[215]);}

/* k7483 */
static void C_ccall f_7484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7484,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=((C_word*)t0)[2];
t4=C_u_i_cdr(t3);
t5=C_u_i_cdr(t4);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7490,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:417: r */
t7=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,lf[214]);}

/* loop in genvars in k5937 */
static void C_fcall f_5946(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5946,NULL,3,t0,t1,t2);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5959,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5968,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:771: gensym */
t5=*((C_word*)lf[32]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k5801 in k5792 in k5790 in k5788 */
static void C_ccall f_5802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5802,2,t0,t1);}
t2=C_a_i_list(&a,1,((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5814,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm:859: r */
t4=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[138]);}

/* genvars in k5937 */
static void C_fcall f_5940(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5940,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5946,a[2]=t2,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word)li51),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_5946(t6,t1,C_fix(0));}

/* k6897 in expand in k6864 in k6862 in k6860 in k6854 */
static void C_ccall f_6898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6898,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6904,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=C_i_car(((C_word*)t0)[2]);
/* chicken-syntax.scm:516: c */
t4=((C_word*)t0)[9];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[10],t3);}

/* k5031 in k5014 in k4992 in loop in k4921 in k4919 in k4917 in k4915 */
static void C_ccall f_5032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5032,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=((C_word*)t0)[2];
t5=C_u_i_car(t4);
t6=C_a_i_list2(&a,2,t1,t5);
t7=C_a_i_cons(&a,2,t6,((C_word*)t0)[3]);
t8=C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
/* chicken-syntax.scm:1042: loop */
t9=((C_word*)((C_word*)t0)[5])[1];
f_4929(t9,((C_word*)t0)[6],t3,((C_word*)t0)[7],t7,t8,C_SCHEME_FALSE);}

/* k8802 in map-loop417 in k8823 in k8687 in k8680 in k8670 in k8660 in k8652 */
static void C_ccall f_8803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8803,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8786,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t4=t3;
f_8786(t4,C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2));}
else{
t4=C_mutate(((C_word *)((C_word*)t0)[7])+1,t2);
t5=t3;
f_8786(t5,t4);}}

/* k5868 in k5871 in k3438 in k3436 in k3434 in k3432 in k3430 in k3428 in k3426 in k3424 in k3422 in k3420 in k3418 in k3416 in k3413 in k3410 in k3408 in k3406 in k3404 in k3402 in k3400 in k3398 in ... */
static void C_ccall f_5869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5869,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[138],t1);
t3=C_a_i_list(&a,2,((C_word*)t0)[2],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5784,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5786,a[2]=((C_word)li49),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:851: ##sys#er-transformer */
t6=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* expand in k6864 in k6862 in k6860 in k6854 */
static void C_fcall f_6876(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6876,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[191]);}
else{
if(C_truep(C_i_pairp(t2))){
t4=C_slot(t2,C_fix(0));
t5=C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6898,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t5,a[6]=t3,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[6],tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm:515: ##sys#check-syntax */
t7=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,lf[190],t4,lf[196]);}
else{
/* chicken-syntax.scm:511: syntax-error */
t4=*((C_word*)lf[45]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,lf[190],lf[197],t2);}}}

/* k6873 in k6864 in k6862 in k6860 in k6854 */
static void C_ccall f_6874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6874,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,3,lf[30],((C_word*)t0)[3],t1));}

/* k5914 in k5879 */
static void C_ccall f_5915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5915,2,t0,t1);}
t2=C_a_i_list(&a,2,lf[20],((C_word*)t0)[2]);
t3=C_a_i_cons(&a,2,t2,((C_word*)t0)[3]);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,lf[146],t3));}

/* k4257 */
static void C_ccall f_4258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:1174: ##compiler#validate-type */
t2=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* f_4252 in k4244 in k4236 */
static void C_ccall f_4252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4252,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4258,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:1174: ##sys#strip-syntax */
t3=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* f_4260 in k4244 in k4236 */
static void C_ccall f_4260(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[30],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4260,5,t0,t1,t2,t3,t4);}
if(C_truep(t2)){
t5=C_i_cdddr(((C_word*)t0)[2]);
t6=C_a_i_cons(&a,2,((C_word*)t0)[3],t5);
t7=C_a_i_cons(&a,2,((C_word*)t0)[4],t6);
t8=C_a_i_list(&a,2,lf[64],t7);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4282,a[2]=t8,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4285,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=t9,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t11=C_a_i_list(&a,2,lf[66],((C_word*)t0)[4]);
t12=t10;
f_4285(t12,C_a_i_list(&a,1,t11));}
else{
t11=t10;
f_4285(t11,C_SCHEME_END_OF_LIST);}}
else{
/* chicken-syntax.scm:1176: syntax-error */
t5=*((C_word*)lf[45]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t1,lf[62],lf[67],((C_word*)t0)[4],((C_word*)t0)[3]);}}

/* k5703 in k5700 in k5685 in k5551 in k5549 in k5547 in k5545 in k5543 in k5541 */
static void C_ccall f_5704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5704,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_list(&a,3,lf[30],((C_word*)t0)[3],t2);
t4=C_i_cadr(((C_word*)t0)[4]);
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_list(&a,4,((C_word*)t0)[6],((C_word*)t0)[7],t3,t4));}

/* k5700 in k5685 in k5551 in k5549 in k5547 in k5545 in k5543 in k5541 */
static void C_ccall f_5701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5701,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5704,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_i_cddr(((C_word*)t0)[3]);
t8=C_i_check_list_2(t7,lf[28]);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5712,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5723,a[2]=t6,a[3]=t11,a[4]=t4,a[5]=((C_word*)t0)[8],a[6]=((C_word)li47),tmp=(C_word)a,a+=7,tmp));
t13=((C_word*)t11)[1];
f_5723(t13,t9,t7);}

/* k8836 in k8832 in k8687 in k8680 in k8670 in k8660 in k8652 */
static void C_ccall f_8837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:214: ##sys#append */
t2=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* f_8839 in k8832 in k8687 in k8680 in k8670 in k8660 in k8652 */
static void C_ccall f_8839(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8839,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_list(&a,3,lf[211],t2,t3));}

/* k4284 */
static void C_fcall f_4285(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4285,NULL,2,t0,t1);}
if(C_truep(((C_word*)t0)[2])){
t2=C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
t3=C_a_i_list(&a,2,lf[65],t2);
t4=C_a_i_list(&a,1,t3);
/* chicken-syntax.scm:45: ##sys#append */
t5=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[4],t1,t4);}
else{
/* chicken-syntax.scm:45: ##sys#append */
t2=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],t1,C_SCHEME_END_OF_LIST);}}

/* k4523 */
static void C_ccall f_4525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4525,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4531,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cdr(((C_word*)t0)[2]);
/* chicken-syntax.scm:1100: ##sys#list? */
t4=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t2=((C_word*)t0)[3];
f_4500(2,t2,C_SCHEME_FALSE);}}

/* k8832 in k8687 in k8680 in k8670 in k8660 in k8652 */
static void C_ccall f_8834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8834,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8837,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8839,a[2]=((C_word)li144),tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8845,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8853,a[2]=t6,a[3]=t10,a[4]=t4,a[5]=t7,a[6]=((C_word)li145),tmp=(C_word)a,a+=7,tmp));
t12=((C_word*)t10)[1];
f_8853(t12,t8,((C_word*)t0)[3],((C_word*)t0)[4]);}

/* k4281 */
static void C_ccall f_4282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4282,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,lf[37],t2));}

/* k7873 in loop in k7598 in k7529 */
static void C_ccall f_7874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
/* chicken-syntax.scm:381: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7863(t4,((C_word*)t0)[4],t3,t1);}

/* k4529 in k4523 */
static void C_ccall f_4531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4531,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4533,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cdr(((C_word*)t0)[2]);
/* chicken-syntax.scm:1100: ##sys#length */
t4=*((C_word*)lf[59]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t2=((C_word*)t0)[3];
f_4500(2,t2,C_SCHEME_FALSE);}}

/* k4532 in k4529 in k4523 */
static void C_ccall f_4533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4533,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4539,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:1100: ##sys#>= */
t3=*((C_word*)lf[58]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,C_fix(0));}

/* map-loop1798 in k5700 in k5685 in k5551 in k5549 in k5547 in k5545 in k5543 in k5541 */
static void C_fcall f_5723(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5723,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5748,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-syntax.scm:897: g1804 */
t5=((C_word*)t0)[5];
f_5554(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4498 */
static void C_ccall f_4500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4500,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[2]);
t3=C_i_cdr(((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4510,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:1100: rename2079 */
t5=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[87]);}
else{
/* chicken-syntax.scm:1100: ##sys#syntax-rules-mismatch */
t2=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[5]);}}

/* k5710 in k5700 in k5685 in k5551 in k5549 in k5547 in k5545 in k5543 in k5541 */
static void C_ccall f_5712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5712,2,t0,t1);}
t2=C_a_i_list(&a,2,lf[130],((C_word*)t0)[2]);
t3=C_a_i_list(&a,2,((C_word*)t0)[3],t2);
t4=C_a_i_list(&a,1,t3);
/* chicken-syntax.scm:876: ##sys#append */
t5=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[4],t1,t4);}

/* k4537 in k4532 in k4529 in k4523 */
static void C_ccall f_4539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4539,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_cdr(((C_word*)t0)[2]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4547,a[2]=t4,a[3]=((C_word)li27),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_4547(t6,((C_word*)t0)[3],t2,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
f_4500(2,t2,C_SCHEME_FALSE);}}

/* k5977 in k5975 in k5973 in k5971 in k5969 in k5937 */
static void C_ccall f_5978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5978,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5980,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm:781: r */
t3=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[150]);}

/* k7148 */
static void C_ccall f_7149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7149,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,lf[205],t1));}

/* k5975 in k5973 in k5971 in k5969 in k5937 */
static void C_ccall f_5976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5976,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5978,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm:780: r */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[164]);}

/* k5973 in k5971 in k5969 in k5937 */
static void C_ccall f_5974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5974,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5976,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:779: r */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[165]);}

/* k5971 in k5969 in k5937 */
static void C_ccall f_5972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5972,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5974,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:778: genvars */
t3=((C_word*)t0)[5];
f_5940(t3,t2,t1);}

/* k5969 in k5937 */
static void C_ccall f_5970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5970,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5972,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6214,a[2]=((C_word)li60),tmp=(C_word)a,a+=3,tmp);
t8=C_i_cdr(((C_word*)t0)[4]);
t9=C_i_check_list_2(t8,lf[28]);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6230,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6232,a[2]=t6,a[3]=t12,a[4]=t4,a[5]=t7,a[6]=((C_word)li61),tmp=(C_word)a,a+=7,tmp));
t14=((C_word*)t12)[1];
f_6232(t14,t10,t8);}

/* k6987 in k3424 in k3422 in k3420 in k3418 in k3416 in k3413 in k3410 in k3408 in k3406 in k3404 in k3402 in k3400 in k3398 in k3396 in k3394 in k3392 in k3390 in k3388 in k3386 in k3384 in k3382 in ... */
static void C_ccall f_6988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:476: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[200],C_SCHEME_END_OF_LIST,t1);}

/* k4509 in k4498 */
static void C_ccall f_4510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4510,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,t1,t2));}

/* k5747 in map-loop1798 in k5700 in k5685 in k5551 in k5549 in k5547 in k5545 in k5543 in k5541 */
static void C_ccall f_5748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5748,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_5723(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_5723(t6,((C_word*)t0)[5],t5);}}

/* k8362 in map-loop677 in k8230 in k8221 in k8211 in k8199 in k8196 in k8192 in k8190 in k8184 */
static void C_fcall f_8363(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[3]);
t3=C_slot(((C_word*)t0)[4],C_fix(1));
t4=C_slot(((C_word*)t0)[5],C_fix(1));
t5=((C_word*)((C_word*)t0)[6])[1];
f_8352(t5,((C_word*)t0)[7],t3,t4);}

/* k6801 in map-loop1434 in k6646 in k6642 in k6640 in k6494 */
static void C_ccall f_6802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6802,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_6777(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_6777(t6,((C_word*)t0)[5],t5);}}

/* k7157 in k7191 in k3420 in k3418 in k3416 in k3413 in k3410 in k3408 in k3406 in k3404 in k3402 in k3400 in k3398 in k3396 in k3394 in k3392 in k3390 in k3388 in k3386 in k3384 in k3382 in k3379 in ... */
static void C_ccall f_7158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:444: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[207],((C_word*)t0)[3],t1);}

/* k5967 in loop in genvars in k5937 */
static void C_ccall f_5968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:771: r */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],t1);}

/* k5961 in k5958 in loop in genvars in k5937 */
static void C_ccall f_5962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5962,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* map-loop889 in k7529 */
static void C_fcall f_7899(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7899,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_car(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}
else{
t6=C_mutate(((C_word *)((C_word*)t0)[4])+1,t5);
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4565 in k4552 in loop2076 in k4537 in k4532 in k4529 in k4523 */
static void C_ccall f_4566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:1100: loop2076 */
t2=((C_word*)((C_word*)t0)[2])[1];
f_4547(t2,((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* map-loop1404 in k6642 in k6640 in k6494 */
static void C_fcall f_6807(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6807,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_car(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}
else{
t6=C_mutate(((C_word *)((C_word*)t0)[4])+1,t5);
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4573 */
static void C_ccall f_4575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4575,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4577,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_car(((C_word*)t0)[2]);
/* chicken-syntax.scm:1100: ##sys#length */
t4=*((C_word*)lf[59]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t2=((C_word*)t0)[3];
f_4525(2,t2,C_SCHEME_FALSE);}}

/* k6860 in k6854 */
static void C_ccall f_6861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6861,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6863,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm:503: r */
t3=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[27]);}

/* k6862 in k6860 in k6854 */
static void C_ccall f_6863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6863,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6865,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm:504: r */
t3=((C_word*)t0)[7];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[198]);}

/* k6864 in k6862 in k6860 in k6854 */
static void C_ccall f_6865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6865,2,t0,t1);}
t2=C_a_i_list(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t3=C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6874,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6876,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word)li79),tmp=(C_word)a,a+=8,tmp));
t8=((C_word*)t6)[1];
f_6876(t8,t4,((C_word*)t0)[7],C_SCHEME_FALSE);}

/* k4823 */
static void C_ccall f_4824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4824,2,t0,t1);}
t2=C_i_cdr(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_list(&a,3,lf[92],t2,C_SCHEME_TRUE));}

/* f_4821 in k3452 in k3450 in k3448 in k3446 in k3444 in k3442 in k3440 in k3438 in k3436 in k3434 in k3432 in k3430 in k3428 in k3426 in k3424 in k3422 in k3420 in k3418 in k3416 in k3413 in k3410 in ... */
static void C_ccall f_4821(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4821,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4824,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:1081: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[91],t2,lf[93]);}

/* k4576 in k4573 */
static void C_ccall f_4577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4577,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4583,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:1100: ##sys#>= */
t3=*((C_word*)lf[58]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,C_fix(0));}

/* k9471 in k9469 in k9467 in k9465 in k9459 */
static void C_ccall f_9472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9472,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9473,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li161),tmp=(C_word)a,a+=5,tmp);
t7=C_i_check_list_2(((C_word*)t0)[4],lf[28]);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9530,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9716,a[2]=t5,a[3]=t10,a[4]=t3,a[5]=t6,a[6]=((C_word)li163),tmp=(C_word)a,a+=7,tmp));
t12=((C_word*)t10)[1];
f_9716(t12,t8,((C_word*)t0)[4]);}

/* f_9473 in k9471 in k9469 in k9467 in k9465 in k9459 */
static void C_ccall f_9473(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9473,3,t0,t1,t2);}
if(C_truep(C_i_symbolp(t2))){
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9500,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=t2;
t5=C_u_i_car(t4);
/* chicken-syntax.scm:71: c */
t6=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t5,((C_word*)t0)[3]);}
else{
/* chicken-syntax.scm:77: syntax-error */
t3=*((C_word*)lf[45]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,lf[272],lf[273],t2);}}}

/* k9469 in k9467 in k9465 in k9459 */
static void C_ccall f_9470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9470,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9472,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm:66: r */
t3=((C_word*)t0)[8];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[110]);}

/* k7372 in map-loop1149 in k7240 in k7219 in k7205 in k7199 */
static void C_ccall f_7373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7373,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7348(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7348(t6,((C_word*)t0)[5],t5);}}

/* k4832 in k3450 in k3448 in k3446 in k3444 in k3442 in k3440 in k3438 in k3436 in k3434 in k3432 in k3430 in k3428 in k3426 in k3424 in k3422 in k3420 in k3418 in k3416 in k3413 in k3410 in k3408 in ... */
static void C_ccall f_4833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:1066: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[94],C_SCHEME_END_OF_LIST,t1);}

/* map-loop1122 in k7219 in k7205 in k7199 */
static void C_fcall f_7378(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7378,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7403,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-syntax.scm:435: g1128 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* f_4835 in k3450 in k3448 in k3446 in k3444 in k3442 in k3440 in k3438 in k3436 in k3434 in k3432 in k3430 in k3428 in k3426 in k3424 in k3422 in k3420 in k3418 in k3416 in k3413 in k3410 in k3408 in ... */
static void C_ccall f_4835(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4835,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4838,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:1070: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[94],t2,lf[95]);}

/* k4837 */
static void C_ccall f_4838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4838,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4844,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:1071: r */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[76]);}

/* k4552 in loop2076 in k4537 in k4532 in k4529 in k4523 */
static void C_ccall f_4554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4554,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_eqp(((C_word*)t0)[3],C_SCHEME_END_OF_LIST));}
else{
t2=C_i_cdr(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4566,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:1100: ##sys#+ */
t4=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[5],C_fix(-1));}}

/* loop2076 in k4537 in k4532 in k4529 in k4523 */
static void C_fcall f_4547(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4547,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4554,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:1100: ##sys#= */
t5=*((C_word*)lf[57]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,C_fix(0));}

/* k6843 in k6846 in k3428 in k3426 in k3424 in k3422 in k3420 in k3418 in k3416 in k3413 in k3410 in k3408 in k3406 in k3404 in k3402 in k3400 in k3398 in k3396 in k3394 in k3392 in k3390 in k3388 in ... */
static void C_ccall f_6844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6844,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[151],t1);
t3=C_a_i_list(&a,2,((C_word*)t0)[2],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6490,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6492,a[2]=((C_word)li76),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:612: ##sys#er-transformer */
t6=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* k4843 in k4837 */
static void C_ccall f_4844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4844,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4850,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:1072: r */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[47]);}

/* k7524 in k3413 in k3410 in k3408 in k3406 in k3404 in k3402 in k3400 in k3398 in k3396 in k3394 in k3392 in k3390 in k3388 in k3386 in k3384 in k3382 in k3379 */
static void C_ccall f_7525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:356: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[214],C_SCHEME_END_OF_LIST,t1);}

/* f_7527 in k3413 in k3410 in k3408 in k3406 in k3404 in k3402 in k3400 in k3398 in k3396 in k3394 in k3392 in k3390 in k3388 in k3386 in k3384 in k3382 in k3379 */
static void C_ccall f_7527(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7527,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7530,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:360: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[214],t2,lf[216]);}

/* k4849 in k4843 in k4837 */
static void C_ccall f_4850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4850,2,t0,t1);}
t2=C_i_cdr(((C_word*)t0)[2]);
t3=C_a_i_cons(&a,2,t1,t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_list(&a,2,((C_word*)t0)[4],t3));}

/* k6846 in k3428 in k3426 in k3424 in k3422 in k3420 in k3418 in k3416 in k3413 in k3410 in k3408 in k3406 in k3404 in k3402 in k3400 in k3398 in k3396 in k3394 in k3392 in k3390 in k3388 in k3386 in ... */
static void C_ccall f_6847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6847,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[112],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6844,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:611: ##sys#primitive-alias */
t4=*((C_word*)lf[106]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[151]);}

/* k4855 in k3448 in k3446 in k3444 in k3442 in k3440 in k3438 in k3436 in k3434 in k3432 in k3430 in k3428 in k3426 in k3424 in k3422 in k3420 in k3418 in k3416 in k3413 in k3410 in k3408 in k3406 in ... */
static void C_ccall f_4856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:1050: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[96],C_SCHEME_END_OF_LIST,t1);}

/* f_4858 in k3448 in k3446 in k3444 in k3442 in k3440 in k3438 in k3436 in k3434 in k3432 in k3430 in k3428 in k3426 in k3424 in k3422 in k3420 in k3418 in k3416 in k3413 in k3410 in k3408 in k3406 in ... */
static void C_ccall f_4858(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4858,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4861,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:1054: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[96],t2,lf[99]);}

/* k9467 in k9465 in k9459 */
static void C_ccall f_9468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9468,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9470,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm:65: r */
t3=((C_word*)t0)[7];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[122]);}

/* k9465 in k9459 */
static void C_ccall f_9466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9466,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9468,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm:64: r */
t3=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[47]);}

/* k9459 */
static void C_ccall f_9460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9460,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=((C_word*)t0)[2];
t4=C_u_i_cdr(t3);
t5=C_u_i_cdr(t4);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9466,a[2]=((C_word*)t0)[3],a[3]=t5,a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:63: symbol->string */
t7=*((C_word*)lf[180]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}

/* k6932 in k6944 in k6902 in k6897 in expand in k6864 in k6862 in k6860 in k6854 */
static void C_ccall f_6933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6933,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,4,lf[155],((C_word*)t0)[3],((C_word*)t0)[4],t1));}

/* k4581 in k4576 in k4573 */
static void C_ccall f_4583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4583,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[2]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4591,a[2]=t4,a[3]=((C_word)li28),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_4591(t6,((C_word*)t0)[3],t2,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
f_4525(2,t2,C_SCHEME_FALSE);}}

/* f_6937 in k6902 in k6897 in expand in k6864 in k6862 in k6860 in k6854 */
static void C_ccall f_6937(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6937,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_list(&a,3,lf[195],((C_word*)t0)[2],t2));}

/* k6676 in k6674 in k6671 in k6668 in k6646 in k6642 in k6640 in k6494 */
static void C_ccall f_6677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6677,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6678,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li70),tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6687,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[2],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6717,a[2]=t5,a[3]=t9,a[4]=t3,a[5]=t6,a[6]=((C_word)li72),tmp=(C_word)a,a+=7,tmp));
t11=((C_word*)t9)[1];
f_6717(t11,t7,((C_word*)t0)[5]);}

/* loop2076 in k4581 in k4576 in k4573 */
static void C_fcall f_4591(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4591,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4598,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:1100: ##sys#= */
t5=*((C_word*)lf[57]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,C_fix(0));}

/* f_6678 in k6676 in k6674 in k6671 in k6668 in k6646 in k6642 in k6640 in k6494 */
static void C_ccall f_6678(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6678,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6684,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:671: prefix-sym */
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[183],t2);}

/* k6671 in k6668 in k6646 in k6642 in k6640 in k6494 */
static void C_ccall f_6673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6673,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6675,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm:666: r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[186]);}

/* k6674 in k6671 in k6668 in k6646 in k6642 in k6640 in k6494 */
static void C_ccall f_6675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6675,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6677,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* chicken-syntax.scm:669: r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[185]);}

/* k6902 in k6897 in expand in k6864 in k6862 in k6860 in k6854 */
static void C_ccall f_6904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6904,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6906,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:517: expand */
t3=((C_word*)((C_word*)t0)[4])[1];
f_6876(t3,t2,((C_word*)t0)[5],C_SCHEME_TRUE);}
else{
if(C_truep(((C_word*)t0)[6])){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6916,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6921,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:522: ##sys#strip-syntax */
t4=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6937,a[2]=((C_word*)t0)[7],a[3]=((C_word)li77),tmp=(C_word)a,a+=4,tmp);
t7=C_u_i_car(((C_word*)t0)[2]);
t8=C_i_check_list_2(t7,lf[28]);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6946,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6948,a[2]=t5,a[3]=t11,a[4]=t3,a[5]=t6,a[6]=((C_word)li78),tmp=(C_word)a,a+=7,tmp));
t13=((C_word*)t11)[1];
f_6948(t13,t9,t7);}}}

/* k4327 in k4325 */
static void C_ccall f_4328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4328,2,t0,t1);}
t2=C_i_cadr(t1);
t3=C_i_car(t2);
t4=C_i_caddr(t1);
t5=t1;
t6=C_u_i_cdr(t5);
t7=C_u_i_cdr(t6);
t8=C_u_i_cdr(t7);
t9=C_a_i_list(&a,2,lf[20],t3);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_FALSE;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4365,a[2]=((C_word)li23),tmp=(C_word)a,a+=3,tmp);
t15=C_u_i_cdr(t2);
t16=C_i_check_list_2(t15,lf[28]);
t17=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4382,a[2]=t8,a[3]=t9,a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t18=C_SCHEME_UNDEFINED;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_set_block_item(t19,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4384,a[2]=t13,a[3]=t19,a[4]=t11,a[5]=t14,a[6]=((C_word)li24),tmp=(C_word)a,a+=7,tmp));
t21=((C_word*)t19)[1];
f_4384(t21,t17,t15);}

/* f_4323 in k3460 in k3458 in k3456 in k3454 in k3452 in k3450 in k3448 in k3446 in k3444 in k3442 in k3440 in k3438 in k3436 in k3434 in k3432 in k3430 in k3428 in k3426 in k3424 in k3422 in k3420 in ... */
static void C_ccall f_4323(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4323,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4326,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:1138: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[70],t2,lf[78]);}

/* k4325 */
static void C_ccall f_4326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4326,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4328,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:1139: ##sys#strip-syntax */
t3=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k6905 in k6902 in k6897 in expand in k6864 in k6862 in k6860 in k6854 */
static void C_ccall f_6906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6906,2,t0,t1);}
t2=C_u_i_cdr(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,lf[26],t2));}

/* k6668 in k6646 in k6642 in k6640 in k6494 */
static void C_ccall f_6670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6670,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=*((C_word*)lf[182]+1);
t7=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6673,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6747,a[2]=t5,a[3]=t9,a[4]=t3,a[5]=((C_word)li73),tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_6747(t11,t7,((C_word*)t0)[9]);}

/* k4320 in k3460 in k3458 in k3456 in k3454 in k3452 in k3450 in k3448 in k3446 in k3444 in k3442 in k3440 in k3438 in k3436 in k3434 in k3432 in k3430 in k3428 in k3426 in k3424 in k3422 in k3420 in ... */
static void C_ccall f_4321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:1134: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[70],C_SCHEME_END_OF_LIST,t1);}

/* k4800 in k4787 in loop2026 in k4772 in k4767 in k4764 in k4628 */
static void C_ccall f_4801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:1089: loop2026 */
t2=((C_word*)((C_word*)t0)[2])[1];
f_4782(t2,((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* f_9457 in k3384 in k3382 in k3379 */
static void C_ccall f_9457(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9457,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9460,a[2]=t2,a[3]=t4,a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:60: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[272],t2,lf[281]);}

/* k9454 in k3384 in k3382 in k3379 */
static void C_ccall f_9455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:56: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[272],C_SCHEME_END_OF_LIST,t1);}

/* k6849 in k3426 in k3424 in k3422 in k3420 in k3418 in k3416 in k3413 in k3410 in k3408 in k3406 in k3404 in k3402 in k3400 in k3398 in k3396 in k3394 in k3392 in k3390 in k3388 in k3386 in k3384 in ... */
static void C_ccall f_6850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:495: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[190],C_SCHEME_END_OF_LIST,t1);}

/* f_6852 in k3426 in k3424 in k3422 in k3420 in k3418 in k3416 in k3413 in k3410 in k3408 in k3406 in k3404 in k3402 in k3400 in k3398 in k3396 in k3394 in k3392 in k3390 in k3388 in k3386 in k3384 in ... */
static void C_ccall f_6852(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6852,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6855,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:499: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[190],t2,lf[199]);}

/* k6854 */
static void C_ccall f_6855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6855,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=((C_word*)t0)[2];
t4=C_u_i_cdr(t3);
t5=C_u_i_cdr(t4);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6861,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t5,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:502: r */
t7=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,lf[173]);}

/* map* in k7529 */
static void C_fcall f_7562(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7562,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
if(C_truep(C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7584,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=C_i_car(t3);
/* chicken-syntax.scm:371: proc */
t6=t2;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
/* chicken-syntax.scm:370: proc */
t4=t2;
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}}}

/* k6920 in k6902 in k6897 in expand in k6864 in k6862 in k6860 in k6854 */
static void C_ccall f_6921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:520: ##sys#notice */
t2=*((C_word*)lf[193]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[194],t1);}

/* k4818 in k3452 in k3450 in k3448 in k3446 in k3444 in k3442 in k3440 in k3438 in k3436 in k3434 in k3432 in k3430 in k3428 in k3426 in k3424 in k3422 in k3420 in k3418 in k3416 in k3413 in k3410 in ... */
static void C_ccall f_4819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:1077: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[91],C_SCHEME_END_OF_LIST,t1);}

/* append* in k7529 */
static void C_fcall f_7536(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7536,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_pairp(t2))){
t4=C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7555,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=t2;
t7=C_u_i_cdr(t6);
/* chicken-syntax.scm:367: append* */
t9=t5;
t10=t7;
t11=t3;
t1=t9;
t2=t10;
t3=t11;
goto loop;}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,t2,t3));}}

/* k7529 */
static void C_ccall f_7530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7530,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=((C_word*)t0)[2];
t4=C_u_i_cdr(t3);
t5=C_u_i_cdr(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7536,a[2]=t7,a[3]=((C_word)li101),tmp=(C_word)a,a+=4,tmp));
t11=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7562,a[2]=t9,a[3]=((C_word)li102),tmp=(C_word)a,a+=4,tmp));
t12=C_SCHEME_END_OF_LIST;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_FALSE;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=*((C_word*)lf[112]+1);
t17=C_i_check_list_2(t2,lf[28]);
t18=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7600,a[2]=((C_word*)t0)[3],a[3]=t5,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t9,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
t19=C_SCHEME_UNDEFINED;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=C_set_block_item(t20,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7899,a[2]=t15,a[3]=t20,a[4]=t13,a[5]=((C_word)li113),tmp=(C_word)a,a+=6,tmp));
t22=((C_word*)t20)[1];
f_7899(t22,t18,t2);}

/* k6972 in map-loop1327 in k6902 in k6897 in expand in k6864 in k6862 in k6860 in k6854 */
static void C_ccall f_6973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6973,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_6948(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_6948(t6,((C_word*)t0)[5],t5);}}

/* f_9379 in k3386 in k3384 in k3382 in k3379 */
static void C_ccall f_9379(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9379,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9382,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:127: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[269],t2,lf[271]);}

/* k9376 in k3386 in k3384 in k3382 in k3379 */
static void C_ccall f_9377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:122: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[269],C_SCHEME_END_OF_LIST,t1);}

/* k6944 in k6902 in k6897 in expand in k6864 in k6862 in k6860 in k6854 */
static void C_ccall f_6946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6946,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_u_i_cdr(((C_word*)t0)[3]);
t4=C_a_i_cons(&a,2,lf[26],t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6933,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:530: expand */
t6=((C_word*)((C_word*)t0)[5])[1];
f_6876(t6,t5,((C_word*)t0)[6],C_SCHEME_FALSE);}

/* map-loop1327 in k6902 in k6897 in expand in k6864 in k6862 in k6860 in k6854 */
static void C_fcall f_6948(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6948,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6973,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-syntax.scm:527: g1333 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7516 in fold in k7489 in k7483 */
static void C_ccall f_7517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7517,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[4],t1));}

/* k6685 in k6676 in k6674 in k6671 in k6668 in k6646 in k6642 in k6640 in k6494 */
static void C_ccall f_6687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6687,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6689,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
t3=((C_word*)t0)[10];
t4=((C_word*)t0)[6];
t5=t1;
t6=((C_word*)t0)[11];
t7=*((C_word*)lf[32]+1);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6511,a[2]=t2,a[3]=t4,a[4]=t6,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:623: reverse */
t9=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t3);}

/* k6688 in k6685 in k6676 in k6674 in k6671 in k6668 in k6646 in k6642 in k6640 in k6494 */
static void C_ccall f_6689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6689,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6691,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm:676: make-if-tree */
t3=((C_word*)t0)[9];
f_6569(t3,t2,((C_word*)t0)[10],((C_word*)t0)[11],((C_word*)t0)[6],((C_word*)t0)[2]);}

/* k6683 */
static void C_ccall f_6684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:671: r */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],t1);}

/* k9381 */
static void C_ccall f_9382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9382,2,t0,t1);}
t2=C_i_cddr(((C_word*)t0)[2]);
if(C_truep(C_i_nullp(t2))){
t3=((C_word*)t0)[2];
t4=C_u_i_cdr(t3);
t5=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t4);
t6=C_a_i_cons(&a,2,lf[97],t5);
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_list(&a,3,lf[141],t6,lf[231]));}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9401,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:131: ##sys#check-syntax */
t4=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[269],((C_word*)t0)[2],lf[270]);}}

/* f_6990 in k3424 in k3422 in k3420 in k3418 in k3416 in k3413 in k3410 in k3408 in k3406 in k3404 in k3402 in k3400 in k3398 in k3396 in k3394 in k3392 in k3390 in k3388 in k3386 in k3384 in k3382 in ... */
static void C_ccall f_6990(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6990,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6993,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:480: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[200],t2,lf[201]);}

/* k6992 */
static void C_ccall f_6993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6993,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=((C_word*)t0)[2];
t4=C_u_i_cdr(t3);
t5=C_u_i_cdr(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7002,a[2]=t5,a[3]=t7,a[4]=((C_word)li81),tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_7002(t9,((C_word*)t0)[3],t2);}

/* map-loop646 in k8221 in k8211 in k8199 in k8196 in k8192 in k8190 in k8184 */
static void C_fcall f_8394(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8394,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_a_i_list(&a,2,t6,t7);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8405,a[2]=((C_word*)t0)[2],a[3]=t9,a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t11=t10;
f_8405(t11,C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t9));}
else{
t11=C_mutate(((C_word *)((C_word*)t0)[4])+1,t9);
t12=t10;
f_8405(t12,t11);}}
else{
t6=((C_word*)((C_word*)t0)[4])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k6696 in k6690 in k6688 in k6685 in k6676 in k6674 in k6671 in k6668 in k6646 in k6642 in k6640 in k6494 */
static void C_ccall f_6697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6697,2,t0,t1);}
t2=C_a_i_list(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t3=C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[5]);
t4=C_a_i_cons(&a,2,lf[97],t3);
t5=C_a_i_list(&a,2,((C_word*)t0)[6],t4);
t6=C_a_i_cons(&a,2,t5,((C_word*)t0)[7]);
t7=C_a_i_cons(&a,2,t2,t6);
t8=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_a_i_list(&a,3,t1,t7,((C_word*)t0)[9]));}

/* k6690 in k6688 in k6685 in k6676 in k6674 in k6671 in k6668 in k6646 in k6642 in k6640 in k6494 */
static void C_ccall f_6691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6691,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6697,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm:679: r */
t3=((C_word*)t0)[9];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[184]);}

/* k4860 */
static void C_ccall f_4861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4861,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
if(C_truep(C_i_pairp(t2))){
t3=C_u_i_car(t2);
t4=C_u_i_cdr(t2);
t5=((C_word*)t0)[2];
t6=C_u_i_cdr(t5);
t7=C_u_i_cdr(t6);
t8=C_a_i_cons(&a,2,t4,t7);
t9=C_a_i_cons(&a,2,lf[97],t8);
t10=C_a_i_list(&a,2,t3,t9);
t11=C_a_i_list(&a,1,t10);
t12=C_u_i_car(t2);
t13=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_a_i_list(&a,3,lf[98],t11,t12));}
else{
t3=((C_word*)t0)[2];
t4=C_u_i_cdr(t3);
t5=C_u_i_cdr(t4);
t6=C_a_i_cons(&a,2,t2,t5);
t7=C_a_i_list(&a,1,t6);
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_a_i_list(&a,3,lf[98],t7,t2));}}

/* k6664 */
static void C_ccall f_6665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:662: r */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],t1);}

/* k8073 in map-loop804 in k8020 in k7985 */
static void C_ccall f_8074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8074,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8057,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t4=t3;
f_8057(t4,C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2));}
else{
t4=C_mutate(((C_word *)((C_word*)t0)[7])+1,t2);
t5=t3;
f_8057(t5,t4);}}

/* k7554 in append* in k7529 */
static void C_ccall f_7555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7555,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* f_6649 in k6646 in k6642 in k6640 in k6494 */
static void C_ccall f_6649(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6649,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6655,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6658,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:657: symbol->string */
t6=*((C_word*)lf[180]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}

/* k6646 in k6642 in k6640 in k6494 */
static void C_ccall f_6648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6648,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6649,a[2]=((C_word)li68),tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6659,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word)li69),tmp=(C_word)a,a+=5,tmp);
t8=C_i_check_list_2(t1,lf[28]);
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6670,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6777,a[2]=t6,a[3]=t11,a[4]=t4,a[5]=t7,a[6]=((C_word)li74),tmp=(C_word)a,a+=7,tmp));
t13=((C_word*)t11)[1];
f_6777(t13,t9,t1);}

/* k6640 in k6494 */
static void C_ccall f_6641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6641,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6643,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm:654: ##sys#check-syntax */
t3=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[177],((C_word*)t0)[5],lf[187]);}

/* k3676 in k3824 in k3672 in k3670 in loop in k3654 in k3652 in k3650 in k3648 in k3645 in k3639 */
static void C_ccall f_3677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[47],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3677,2,t0,t1);}
t2=C_a_i_list(&a,2,lf[35],((C_word*)t0)[2]);
t3=C_a_i_list(&a,2,lf[36],((C_word*)t0)[2]);
t4=C_a_i_list(&a,3,lf[37],t2,t3);
t5=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3694,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp);
t11=((C_word*)t0)[3];
t12=((C_word*)t0)[4];
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3703,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=((C_word*)t0)[7],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3705,a[2]=t9,a[3]=t15,a[4]=t7,a[5]=t10,a[6]=((C_word)li5),tmp=(C_word)a,a+=7,tmp));
t17=((C_word*)t15)[1];
f_3705(t17,t13,t11,t12);}

/* k6642 in k6640 in k6494 */
static void C_ccall f_6643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6643,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=*((C_word*)lf[112]+1);
t7=C_i_check_list_2(((C_word*)t0)[2],lf[28]);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6648,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6807,a[2]=t5,a[3]=t10,a[4]=t3,a[5]=((C_word)li75),tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_6807(t12,t8,((C_word*)t0)[2]);}

/* k3672 in k3670 in loop in k3654 in k3652 in k3650 in k3648 in k3645 in k3639 */
static void C_ccall f_3673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3673,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3825,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3827,a[2]=t4,a[3]=((C_word)li8),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_3827(t6,t2,((C_word*)t0)[10],C_fix(1));}

/* k7691 in map-loop975 in fold in k7635 in k7625 in k7615 in k7601 in k7598 in k7529 */
static void C_ccall f_7692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7692,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7667(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7667(t6,((C_word*)t0)[5],t5);}}

/* map-loop677 in k8230 in k8221 in k8211 in k8199 in k8196 in k8192 in k8190 in k8184 */
static void C_fcall f_8352(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8352,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_a_i_list(&a,2,t6,t7);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8363,a[2]=((C_word*)t0)[2],a[3]=t9,a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t11=t10;
f_8363(t11,C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t9));}
else{
t11=C_mutate(((C_word *)((C_word*)t0)[4])+1,t9);
t12=t10;
f_8363(t12,t11);}}
else{
t6=((C_word*)((C_word*)t0)[4])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k6657 */
static void C_ccall f_6658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:657: string-append */
t2=*((C_word*)lf[179]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* f_6659 in k6646 in k6642 in k6640 in k6494 */
static void C_ccall f_6659(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6659,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6665,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:662: prefix-sym */
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[181],t2);}

/* k3670 in loop in k3654 in k3652 in k3650 in k3648 in k3645 in k3639 */
static void C_ccall f_3671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3671,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3673,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm:1219: reverse */
t3=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[10]);}

/* k8056 in k8073 in map-loop804 in k8020 in k7985 */
static void C_fcall f_8057(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[3]);
t3=C_slot(((C_word*)t0)[4],C_fix(1));
t4=C_slot(((C_word*)t0)[5],C_fix(1));
t5=((C_word*)((C_word*)t0)[6])[1];
f_8046(t5,((C_word*)t0)[7],t3,t4);}

/* k7179 in k7164 in k7162 */
static void C_ccall f_7180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7180,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=C_a_i_list(&a,3,t1,((C_word*)t0)[3],t2);
t4=C_a_i_list(&a,3,lf[97],((C_word*)t0)[3],t3);
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_list(&a,3,lf[141],((C_word*)t0)[5],t4));}

/* k6654 */
static void C_ccall f_6655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:657: string->symbol */
t2=*((C_word*)lf[178]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* loop in k3654 in k3652 in k3650 in k3648 in k3645 in k3639 */
static void C_fcall f_3662(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
loop:
a=C_alloc(11);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3662,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep(C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3671,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t3,a[10]=t4,tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm:1218: reverse */
t6=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}
else{
t5=C_i_car(t2);
if(C_truep(C_i_symbolp(t5))){
t6=t2;
t7=C_u_i_cdr(t6);
t8=C_a_i_cons(&a,2,t5,t3);
t9=C_a_i_cons(&a,2,lf[44],t4);
/* chicken-syntax.scm:1253: loop */
t16=t1;
t17=t7;
t18=t8;
t19=t9;
t1=t16;
t2=t17;
t3=t18;
t4=t19;
goto loop;}
else{
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3874,a[2]=t2,a[3]=t5,a[4]=t3,a[5]=t4,a[6]=((C_word*)t0)[8],a[7]=t1,a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
if(C_truep(C_i_listp(t5))){
t7=C_u_i_length(t5);
t8=C_eqp(C_fix(2),t7);
if(C_truep(t8)){
t9=C_i_car(t5);
t10=t6;
f_3874(t10,C_i_symbolp(t9));}
else{
t9=t6;
f_3874(t9,C_SCHEME_FALSE);}}
else{
t7=t6;
f_3874(t7,C_SCHEME_FALSE);}}}}

/* k6626 in k6632 in k6638 in recur in make-if-tree in k6494 */
static void C_ccall f_6627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6627,2,t0,t1);}
t2=C_a_i_list(&a,2,t1,((C_word*)t0)[2]);
t3=C_a_i_list(&a,2,((C_word*)t0)[2],t2);
t4=C_a_i_list(&a,2,((C_word*)t0)[3],t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6608,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t6=((C_word*)t0)[7];
t7=C_u_i_cdr(t6);
t8=((C_word*)t0)[8];
t9=C_u_i_cdr(t8);
t10=C_a_i_cons(&a,2,((C_word*)t0)[9],((C_word*)t0)[10]);
/* chicken-syntax.scm:649: recur */
t11=((C_word*)((C_word*)t0)[11])[1];
f_6575(t11,t5,t7,t9,t10);}

/* k6480 in k6483 in k3430 in k3428 in k3426 in k3424 in k3422 in k3420 in k3418 in k3416 in k3413 in k3410 in k3408 in k3406 in k3404 in k3402 in k3400 in k3398 in k3396 in k3394 in k3392 in k3390 in ... */
static void C_ccall f_6481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6481,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[112],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6478,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:700: ##sys#primitive-alias */
t4=*((C_word*)lf[106]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[151]);}

/* loop2224 in k4093 in k4088 in k4085 in k4079 */
static void C_fcall f_4103(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4103,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4110,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:1196: ##sys#= */
t5=*((C_word*)lf[57]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,C_fix(0));}

/* k3652 in k3650 in k3648 in k3645 in k3639 */
static void C_ccall f_3653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3653,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3655,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm:1214: r */
t3=((C_word*)t0)[9];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[47]);}

/* k3654 in k3652 in k3650 in k3648 in k3645 in k3639 */
static void C_ccall f_3655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3655,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[2])?C_i_cadddr(((C_word*)t0)[3]):C_i_caddr(((C_word*)t0)[3]));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3662,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[2],a[8]=t4,a[9]=((C_word*)t0)[7],a[10]=((C_word)li9),tmp=(C_word)a,a+=11,tmp));
t6=((C_word*)t4)[1];
f_3662(t6,((C_word*)t0)[8],((C_word*)t0)[9],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* k8334 in map-loop708 in k8241 in k8230 in k8221 in k8211 in k8199 in k8196 in k8192 in k8190 in k8184 */
static void C_ccall f_8335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8335,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8318,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t4=t3;
f_8318(t4,C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2));}
else{
t4=C_mutate(((C_word *)((C_word*)t0)[7])+1,t2);
t5=t3;
f_8318(t5,t4);}}

/* k3650 in k3648 in k3645 in k3639 */
static void C_ccall f_3651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3651,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3653,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=C_i_cdddr(((C_word*)t0)[2]);
if(C_truep(C_i_pairp(t3))){
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
t6=C_u_i_cdr(t5);
t7=C_u_i_car(t6);
/* chicken-syntax.scm:1213: ##sys#strip-syntax */
t8=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t2,t7);}
else{
t4=t2;
f_3653(2,t4,C_SCHEME_FALSE);}}

/* k6489 in k6843 in k6846 in k3428 in k3426 in k3424 in k3422 in k3420 in k3418 in k3416 in k3413 in k3410 in k3408 in k3406 in k3404 in k3402 in k3400 in k3398 in k3396 in k3394 in k3392 in k3390 in ... */
static void C_ccall f_6490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:608: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[177],((C_word*)t0)[3],t1);}

/* f_7160 in k7191 in k3420 in k3418 in k3416 in k3413 in k3410 in k3408 in k3406 in k3404 in k3402 in k3400 in k3398 in k3396 in k3394 in k3392 in k3390 in k3388 in k3386 in k3384 in k3382 in k3379 in ... */
static void C_ccall f_7160(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7160,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7163,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:449: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[207],t2,lf[208]);}

/* k7164 in k7162 */
static void C_ccall f_7165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7165,2,t0,t1);}
t2=C_i_caddr(((C_word*)t0)[2]);
t3=C_a_i_list(&a,3,lf[97],C_SCHEME_END_OF_LIST,t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7180,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:453: r */
t5=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[206]);}

/* k7162 */
static void C_ccall f_7163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7163,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7165,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:450: r */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[173]);}

/* k6607 in k6626 in k6632 in k6638 in recur in make-if-tree in k6494 */
static void C_ccall f_6608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6608,2,t0,t1);}
t2=C_a_i_list(&a,3,lf[30],((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_list(&a,4,lf[155],((C_word*)t0)[4],((C_word*)t0)[5],t2));}

/* k6483 in k3430 in k3428 in k3426 in k3424 in k3422 in k3420 in k3418 in k3416 in k3413 in k3410 in k3408 in k3406 in k3404 in k3402 in k3400 in k3398 in k3396 in k3394 in k3392 in k3390 in k3388 in ... */
static void C_ccall f_6484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6484,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[170],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6481,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:699: ##sys#primitive-alias */
t4=*((C_word*)lf[106]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[112]);}

/* k6459 in k6426 in k6424 */
static void C_ccall f_6460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6460,2,t0,t1);}
t2=C_a_i_list(&a,2,t1,((C_word*)t0)[2]);
t3=C_i_cddr(((C_word*)t0)[3]);
t4=C_i_nullp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:C_i_car(t3));
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6451,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t5,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:708: r */
t7=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,lf[112]);}

/* k6915 in k6902 in k6897 in expand in k6864 in k6862 in k6860 in k6854 */
static void C_ccall f_6916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6916,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6918,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:523: expand */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6876(t3,t2,((C_word*)t0)[4],C_SCHEME_TRUE);}

/* k6917 in k6915 in k6902 in k6897 in expand in k6864 in k6862 in k6860 in k6854 */
static void C_ccall f_6918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[192]);}

/* k7191 in k3420 in k3418 in k3416 in k3413 in k3410 in k3408 in k3406 in k3404 in k3402 in k3400 in k3398 in k3396 in k3394 in k3392 in k3390 in k3388 in k3386 in k3384 in k3382 in k3379 */
static void C_ccall f_7192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7192,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[206],t1);
t3=C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7158,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7160,a[2]=((C_word)li85),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:447: ##sys#er-transformer */
t6=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* k7194 in k3418 in k3416 in k3413 in k3410 in k3408 in k3406 in k3404 in k3402 in k3400 in k3398 in k3396 in k3394 in k3392 in k3390 in k3388 in k3386 in k3384 in k3382 in k3379 */
static void C_ccall f_7195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:424: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[209],C_SCHEME_END_OF_LIST,t1);}

/* f_7197 in k3418 in k3416 in k3413 in k3410 in k3408 in k3406 in k3404 in k3402 in k3400 in k3398 in k3396 in k3394 in k3392 in k3390 in k3388 in k3386 in k3384 in k3382 in k3379 */
static void C_ccall f_7197(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7197,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7200,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:428: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[209],t2,lf[212]);}

/* k8317 in k8334 in map-loop708 in k8241 in k8230 in k8221 in k8211 in k8199 in k8196 in k8192 in k8190 in k8184 */
static void C_fcall f_8318(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[3]);
t3=C_slot(((C_word*)t0)[4],C_fix(1));
t4=C_slot(((C_word*)t0)[5],C_fix(1));
t5=((C_word*)((C_word*)t0)[6])[1];
f_8307(t5,((C_word*)t0)[7],t3,t4);}

/* k5050 in k5014 in k4992 in loop in k4921 in k4919 in k4917 in k4915 */
static void C_ccall f_5051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:1041: r */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],t1);}

/* f_6492 in k6843 in k6846 in k3428 in k3426 in k3424 in k3422 in k3420 in k3418 in k3416 in k3413 in k3410 in k3408 in k3406 in k3404 in k3402 in k3400 in k3398 in k3396 in k3394 in k3392 in k3390 in ... */
static void C_ccall f_6492(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6492,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6495,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:614: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[177],t2,lf[189]);}

/* k6494 */
static void C_ccall f_6495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6495,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=C_i_caddr(((C_word*)t0)[2]);
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
t6=C_u_i_cdr(t5);
t7=C_u_i_cdr(t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6569,a[2]=((C_word*)t0)[3],a[3]=((C_word)li67),tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6641,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t7,a[6]=((C_word*)t0)[4],a[7]=t8,tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm:653: ##sys#check-syntax */
t10=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t9,lf[177],t3,lf[188]);}

/* k4137 in k4132 in k4129 */
static void C_ccall f_4139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4139,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[2]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4147,a[2]=t4,a[3]=((C_word)li17),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_4147(t6,((C_word*)t0)[3],t2,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
f_4081(2,t2,C_SCHEME_FALSE);}}

/* k4132 in k4129 */
static void C_ccall f_4133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4133,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4139,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:1196: ##sys#>= */
t3=*((C_word*)lf[58]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,C_fix(0));}

/* map-loop1062 in k7199 */
static void C_fcall f_7448(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7448,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7473,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-syntax.scm:431: g1068 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7444 in k7199 */
static void C_ccall f_7446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[41]+1),t1);}

/* f_5454 in k5255 in k5251 in k5249 in k5245 in k5243 in k5233 */
static void C_ccall f_5454(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5454,3,t0,t1,t2);}
if(C_truep(C_i_memq(t2,((C_word*)t0)[2]))){
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[114]);}}

/* k4108 in loop2224 in k4093 in k4088 in k4085 in k4079 */
static void C_ccall f_4110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4110,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_eqp(((C_word*)t0)[3],C_SCHEME_END_OF_LIST));}
else{
t2=C_i_cdr(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4122,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:1196: ##sys#+ */
t4=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[5],C_fix(-1));}}

/* map-loop708 in k8241 in k8230 in k8221 in k8211 in k8199 in k8196 in k8192 in k8190 in k8184 */
static void C_fcall f_8307(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8307,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8335,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=t1,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t7=C_slot(t2,C_fix(0));
t8=C_slot(t3,C_fix(0));
/* chicken-syntax.scm:297: g714 */
t9=((C_word*)t0)[5];
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t6,t7,t8);}
else{
t6=((C_word*)((C_word*)t0)[4])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* loop2224 in k4137 in k4132 in k4129 */
static void C_fcall f_4147(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4147,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4154,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:1196: ##sys#= */
t5=*((C_word*)lf[57]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,C_fix(0));}

/* map-loop775 in k7985 */
static void C_fcall f_8088(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8088,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8113,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-syntax.scm:339: g781 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4121 in k4108 in loop2224 in k4093 in k4088 in k4085 in k4079 */
static void C_ccall f_4122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:1196: loop2224 */
t2=((C_word*)((C_word*)t0)[2])[1];
f_4103(t2,((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* f_3694 in k3676 in k3824 in k3672 in k3670 in loop in k3654 in k3652 in k3650 in k3648 in k3645 in k3639 */
static void C_ccall f_3694(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3694,4,t0,t1,t2,t3);}
t4=C_a_i_list(&a,4,lf[38],t3,C_SCHEME_TRUE,t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_list2(&a,2,t2,t4));}

/* k5419 in loop in k5463 in k5255 in k5251 in k5249 in k5245 in k5243 in k5233 */
static void C_ccall f_5421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5292(t2,(C_truep(t1)?C_i_cadr(((C_word*)t0)[3]):C_SCHEME_FALSE));}

/* k6477 in k6480 in k6483 in k3430 in k3428 in k3426 in k3424 in k3422 in k3420 in k3418 in k3416 in k3413 in k3410 in k3408 in k3406 in k3404 in k3402 in k3400 in k3398 in k3396 in k3394 in k3392 in ... */
static void C_ccall f_6478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6478,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[151],t1);
t3=C_a_i_list(&a,3,((C_word*)t0)[2],((C_word*)t0)[3],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6420,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6422,a[2]=((C_word)li65),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:701: ##sys#er-transformer */
t6=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* f_7438 in k7199 */
static void C_ccall f_7438(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7438,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_car(t2));}

/* k7432 in map-loop1090 in k7205 in k7199 */
static void C_ccall f_7433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7433,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7408(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7408(t6,((C_word*)t0)[5],t5);}}

/* loop in k5087 in k5085 in k5083 in k5081 */
static void C_fcall f_5095(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5095,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep(C_i_nullp(t2))){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5104,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:989: reverse */
t7=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t3);}
else{
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5157,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
t7=C_i_car(t2);
/* chicken-syntax.scm:998: c */
t8=((C_word*)t0)[6];
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,((C_word*)t0)[8],t7);}}

/* k7402 in map-loop1122 in k7219 in k7205 in k7199 */
static void C_ccall f_7403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7403,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7378(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7378(t6,((C_word*)t0)[5],t5);}}

/* map-loop1090 in k7205 in k7199 */
static void C_fcall f_7408(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7408,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7433,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-syntax.scm:432: g1096 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5085 in k5083 in k5081 */
static void C_ccall f_5086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5086,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5088,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=C_i_cdr(((C_word*)t0)[2]);
if(C_truep(C_i_nullp(t3))){
/* chicken-syntax.scm:986: syntax-error */
t4=*((C_word*)lf[45]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,lf[107],lf[109],((C_word*)t0)[2]);}
else{
t4=t2;
f_5088(2,t4,C_SCHEME_UNDEFINED);}}

/* k5087 in k5085 in k5083 in k5081 */
static void C_ccall f_5088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5088,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5095,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word)li37),tmp=(C_word)a,a+=10,tmp));
t7=((C_word*)t5)[1];
f_5095(t7,((C_word*)t0)[8],t3,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* k5081 */
static void C_ccall f_5082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5082,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5084,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:983: r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[104]);}

/* k5083 in k5081 */
static void C_ccall f_5084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5084,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5086,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm:984: r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[100]);}

/* map-loop804 in k8020 in k7985 */
static void C_fcall f_8046(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8046,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8074,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=t1,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t7=C_slot(t2,C_fix(0));
t8=C_slot(t3,C_fix(0));
/* chicken-syntax.scm:343: g810 */
t9=((C_word*)t0)[5];
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t6,t7,t8);}
else{
t6=((C_word*)((C_word*)t0)[4])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k8042 in k8020 in k7985 */
static void C_ccall f_8044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8044,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,lf[97],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_list(&a,3,lf[141],((C_word*)t0)[4],t3));}

/* f_5079 in k5222 in k3444 in k3442 in k3440 in k3438 in k3436 in k3434 in k3432 in k3430 in k3428 in k3426 in k3424 in k3422 in k3420 in k3418 in k3416 in k3413 in k3410 in k3408 in k3406 in k3404 in ... */
static void C_ccall f_5079(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5079,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5082,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:982: r */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[105]);}

/* k5076 in k5222 in k3444 in k3442 in k3440 in k3438 in k3436 in k3434 in k3432 in k3430 in k3428 in k3426 in k3424 in k3422 in k3420 in k3418 in k3416 in k3413 in k3410 in k3408 in k3406 in k3404 in ... */
static void C_ccall f_5077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:977: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[107],((C_word*)t0)[3],t1);}

/* k5070 in k3446 in k3444 in k3442 in k3440 in k3438 in k3436 in k3434 in k3432 in k3430 in k3428 in k3426 in k3424 in k3422 in k3420 in k3418 in k3416 in k3413 in k3410 in k3408 in k3406 in k3404 in ... */
static void C_ccall f_5071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5071,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[100],t1);
t3=C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4911,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4913,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:1012: ##sys#er-transformer */
t6=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* k6638 in recur in make-if-tree in k6494 */
static void C_ccall f_6639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6639,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6633,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* chicken-syntax.scm:647: r */
t4=((C_word*)t0)[11];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[112]);}

/* k3648 in k3645 in k3639 */
static void C_ccall f_3649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3649,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3651,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm:1212: ##sys#globalize */
t3=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,C_SCHEME_END_OF_LIST);}

/* k6632 in k6638 in recur in make-if-tree in k6494 */
static void C_ccall f_6633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6633,2,t0,t1);}
t2=C_a_i_list(&a,2,t1,((C_word*)t0)[2]);
t3=C_a_i_list(&a,2,((C_word*)t0)[3],t2);
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6627,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[3],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* chicken-syntax.scm:648: r */
t5=((C_word*)t0)[11];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[151]);}

/* k3645 in k3639 */
static void C_ccall f_3646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3646,2,t0,t1);}
t2=C_u_i_cdr(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3649,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm:1211: gensym */
t4=*((C_word*)lf[32]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[6]);}

/* k3639 */
static void C_ccall f_3640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3640,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3646,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:1209: ##sys#globalize */
t5=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,C_SCHEME_END_OF_LIST);}

/* k5323 in k5301 in k5295 in k5291 in loop in k5463 in k5255 in k5251 in k5249 in k5245 in k5243 in k5233 */
static void C_ccall f_5325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5325,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_5308(t2,C_SCHEME_END_OF_LIST);}
else{
t2=C_a_i_list(&a,2,lf[120],lf[120]);
t3=C_a_i_list(&a,3,t2,((C_word*)t0)[3],((C_word*)t0)[4]);
t4=((C_word*)t0)[2];
f_5308(t4,C_a_i_list(&a,1,t3));}}

/* k8571 in k8569 in k8567 in k8561 */
static void C_ccall f_8572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8572,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8574,a[2]=t5,a[3]=t7,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8603,a[2]=t10,a[3]=t3,a[4]=t7,a[5]=t5,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t1,a[9]=((C_word*)t0)[6],a[10]=((C_word)li135),tmp=(C_word)a,a+=11,tmp));
t12=((C_word*)t10)[1];
f_8603(t12,t8,((C_word*)t0)[7]);}

/* k8569 in k8567 in k8561 */
static void C_ccall f_8570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8570,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8572,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm:250: r */
t3=((C_word*)t0)[7];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[244]);}

/* k8573 in k8571 in k8569 in k8567 in k8561 */
static void C_ccall f_8574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8574,2,t0,t1);}
if(C_truep(C_i_memq(lf[13],*((C_word*)lf[14]+1)))){
t2=(C_truep(((C_word*)((C_word*)t0)[2])[1])?((C_word*)((C_word*)t0)[3])[1]:C_SCHEME_FALSE);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?C_a_i_list(&a,2,lf[238],((C_word*)t0)[5]):(C_truep(((C_word*)((C_word*)t0)[2])[1])?C_a_i_list(&a,2,lf[239],((C_word*)t0)[5]):(C_truep(((C_word*)((C_word*)t0)[3])[1])?((C_word*)t0)[5]:lf[240]))));}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(((C_word*)((C_word*)t0)[6])[1])?((C_word*)t0)[5]:lf[241]));}}

/* map-loop1149 in k7240 in k7219 in k7205 in k7199 */
static void C_fcall f_7348(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7348,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7373,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-syntax.scm:436: g1155 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7344 in k7240 in k7219 in k7205 in k7199 */
static void C_ccall f_7346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:429: ##sys#append */
t2=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,((C_word*)t0)[3]);}

/* f_3632 in k3468 in k3466 in k3464 in k3462 in k3460 in k3458 in k3456 in k3454 in k3452 in k3450 in k3448 in k3446 in k3444 in k3442 in k3440 in k3438 in k3436 in k3434 in k3432 in k3430 in k3428 in ... */
static void C_ccall f_3632(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3632,5,t0,t1,t2,t3,t4);}
if(C_truep(C_i_memq(lf[13],*((C_word*)lf[14]+1)))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3640,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:1206: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[34],t2,lf[49]);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[50]);}}

/* k3629 in k3468 in k3466 in k3464 in k3462 in k3460 in k3458 in k3456 in k3454 in k3452 in k3450 in k3448 in k3446 in k3444 in k3442 in k3440 in k3438 in k3436 in k3434 in k3432 in k3430 in k3428 in ... */
static void C_ccall f_3630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:1200: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[34],C_SCHEME_END_OF_LIST,t1);}

/* k5353 in k5295 in k5291 in loop in k5463 in k5255 in k5251 in k5249 in k5245 in k5243 in k5233 */
static void C_ccall f_5355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5355,2,t0,t1);}
if(C_truep(t1)){
t2=C_a_i_list(&a,3,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4]);
t3=((C_word*)t0)[5];
f_5302(t3,C_a_i_list(&a,3,((C_word*)t0)[6],((C_word*)t0)[7],t2));}
else{
t2=((C_word*)t0)[5];
f_5302(t2,C_a_i_list(&a,3,((C_word*)t0)[6],((C_word*)t0)[7],((C_word*)t0)[3]));}}

/* k3617 in map-loop2455 in k3540 in k3538 in k3534 */
static void C_ccall f_3618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3618,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_3593(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_3593(t6,((C_word*)t0)[5],t5);}}

/* f_7236 in k7219 in k7205 in k7199 */
static void C_ccall f_7236(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7236,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_list(&a,2,t2,lf[210]));}

/* k6450 in k6459 in k6426 in k6424 */
static void C_ccall f_6451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6451,2,t0,t1);}
t2=C_a_i_list(&a,2,t1,((C_word*)t0)[2]);
t3=C_a_i_list(&a,4,lf[155],((C_word*)t0)[3],((C_word*)t0)[4],t2);
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_list(&a,3,lf[30],((C_word*)t0)[6],t3));}

/* k7336 in map-loop1172 */
static void C_ccall f_7337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7337,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7312(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7312(t6,((C_word*)t0)[5],t5);}}

/* k7240 in k7219 in k7205 in k7199 */
static void C_ccall f_7242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7242,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7245,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7247,a[2]=((C_word*)t0)[3],a[3]=((C_word)li92),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7346,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7348,a[2]=t6,a[3]=t10,a[4]=t4,a[5]=t7,a[6]=((C_word)li93),tmp=(C_word)a,a+=7,tmp));
t12=((C_word*)t10)[1];
f_7348(t12,t8,((C_word*)t0)[5]);}

/* f_7247 in k7240 in k7219 in k7205 in k7199 */
static void C_ccall f_7247(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[28],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7247,3,t0,t1,t2);}
t3=C_i_cadr(t2);
t4=C_a_i_list(&a,3,lf[97],C_SCHEME_END_OF_LIST,t3);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=((C_word*)t0)[2];
t10=t2;
t11=C_u_i_car(t10);
t12=C_i_check_list_2(t11,lf[28]);
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7266,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7312,a[2]=t8,a[3]=t15,a[4]=t6,a[5]=t9,a[6]=((C_word)li91),tmp=(C_word)a,a+=7,tmp));
t17=((C_word*)t15)[1];
f_7312(t17,t13,t11);}

/* k7244 in k7240 in k7219 in k7205 in k7199 */
static void C_ccall f_7245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7245,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,lf[30],t2));}

/* k3416 in k3413 in k3410 in k3408 in k3406 in k3404 in k3402 in k3400 in k3398 in k3396 in k3394 in k3392 in k3390 in k3388 in k3386 in k3384 in k3382 in k3379 */
static void C_ccall f_3417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3417,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3419,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7479,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7481,a[2]=((C_word)li100),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:412: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k3413 in k3410 in k3408 in k3406 in k3404 in k3402 in k3400 in k3398 in k3396 in k3394 in k3392 in k3390 in k3388 in k3386 in k3384 in k3382 in k3379 */
static void C_ccall f_3415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3415,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1 /* (set! ##sys#define-values-definition ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3417,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7525,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7527,a[2]=((C_word)li114),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:358: ##sys#er-transformer */
t6=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* k3418 in k3416 in k3413 in k3410 in k3408 in k3406 in k3404 in k3402 in k3400 in k3398 in k3396 in k3394 in k3392 in k3390 in k3388 in k3386 in k3384 in k3382 in k3379 */
static void C_ccall f_3419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3419,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3421,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7195,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7197,a[2]=((C_word)li98),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:426: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k6424 */
static void C_ccall f_6425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6425,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6427,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:704: r */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[173]);}

/* f_6422 in k6477 in k6480 in k6483 in k3430 in k3428 in k3426 in k3424 in k3422 in k3420 in k3418 in k3416 in k3413 in k3410 in k3408 in k3406 in k3404 in k3402 in k3400 in k3398 in k3396 in k3394 in ... */
static void C_ccall f_6422(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6422,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6425,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:703: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[175],t2,lf[176]);}

/* k6419 in k6477 in k6480 in k6483 in k3430 in k3428 in k3426 in k3424 in k3422 in k3420 in k3418 in k3416 in k3413 in k3410 in k3408 in k3406 in k3404 in k3402 in k3400 in k3398 in k3396 in k3394 in ... */
static void C_ccall f_6420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:696: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[175],((C_word*)t0)[3],t1);}

/* k7306 in map-loop1198 in k7264 */
static void C_ccall f_7307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7307,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7282(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7282(t6,((C_word*)t0)[5],t5);}}

/* k3410 in k3408 in k3406 in k3404 in k3402 in k3400 in k3398 in k3396 in k3394 in k3392 in k3390 in k3388 in k3386 in k3384 in k3382 in k3379 */
static void C_ccall f_3411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3411,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3415,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7930,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7932,a[2]=((C_word)li117),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:350: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k3406 in k3404 in k3402 in k3400 in k3398 in k3396 in k3394 in k3392 in k3390 in k3388 in k3386 in k3384 in k3382 in k3379 */
static void C_ccall f_3407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3407,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3409,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8122,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8124,a[2]=((C_word)li122),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:317: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k3404 in k3402 in k3400 in k3398 in k3396 in k3394 in k3392 in k3390 in k3388 in k3386 in k3384 in k3382 in k3379 */
static void C_ccall f_3405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3405,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3407,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8145,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8147,a[2]=((C_word)li123),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:309: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k3408 in k3406 in k3404 in k3402 in k3400 in k3398 in k3396 in k3394 in k3392 in k3390 in k3388 in k3386 in k3384 in k3382 in k3379 */
static void C_ccall f_3409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3409,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3411,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7981,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7983,a[2]=((C_word)li121),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:326: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* map-loop534 in k8192 in k8190 in k8184 */
static void C_fcall f_8526(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8526,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_car(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}
else{
t6=C_mutate(((C_word *)((C_word*)t0)[4])+1,t5);
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* map-loop1172 */
static void C_fcall f_7312(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7312,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7337,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-syntax.scm:439: g1178 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6426 in k6424 */
static void C_ccall f_6427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6427,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=C_a_i_list(&a,2,t1,t2);
t4=C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6460,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:706: r */
t6=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[170]);}

/* k3402 in k3400 in k3398 in k3396 in k3394 in k3392 in k3390 in k3388 in k3386 in k3384 in k3382 in k3379 */
static void C_ccall f_3403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3403,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3405,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8165,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8167,a[2]=((C_word)li134),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:273: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k3400 in k3398 in k3396 in k3394 in k3392 in k3390 in k3388 in k3386 in k3384 in k3382 in k3379 */
static void C_ccall f_3401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3401,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3403,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8557,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8559,a[2]=((C_word)li136),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:243: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* f_7222 in k7219 in k7205 in k7199 */
static void C_ccall f_7222(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7222,3,t0,t1,t2);}
t3=C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_i_cdr(t3));}

/* k7219 in k7205 in k7199 */
static void C_ccall f_7221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7221,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7222,a[2]=t1,a[3]=((C_word)li87),tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7236,a[2]=((C_word)li88),tmp=(C_word)a,a+=3,tmp);
t8=((C_word*)t0)[2];
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7242,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7378,a[2]=t6,a[3]=t11,a[4]=t4,a[5]=t7,a[6]=((C_word)li94),tmp=(C_word)a,a+=7,tmp));
t13=((C_word*)t11)[1];
f_7378(t13,t9,t8);}

/* k3476 in k3474 in k3472 in k3470 in k3468 in k3466 in k3464 in k3462 in k3460 in k3458 in k3456 in k3454 in k3452 in k3450 in k3448 in k3446 in k3444 in k3442 in k3440 in k3438 in k3436 in k3434 in ... */
static void C_ccall f_3478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3478,2,t0,t1);}
t2=C_mutate((C_word*)lf[1]+1 /* (set! ##sys#chicken-macro-environment ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3480,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:1317: register-feature! */
t4=*((C_word*)lf[2]+1);
((C_proc8)(void*)(*((C_word*)t4+1)))(8,t4,t3,lf[3],lf[4],lf[5],lf[6],lf[7],lf[8]);}

/* k3472 in k3470 in k3468 in k3466 in k3464 in k3462 in k3460 in k3458 in k3456 in k3454 in k3452 in k3450 in k3448 in k3446 in k3444 in k3442 in k3440 in k3438 in k3436 in k3434 in k3432 in k3430 in ... */
static void C_ccall f_3473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3473,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3475,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3483,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3485,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:1294: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k3474 in k3472 in k3470 in k3468 in k3466 in k3464 in k3462 in k3460 in k3458 in k3456 in k3454 in k3452 in k3450 in k3448 in k3446 in k3444 in k3442 in k3440 in k3438 in k3436 in k3434 in k3432 in ... */
static void C_ccall f_3475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3475,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3478,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:1311: ##sys#macro-subset */
t3=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],*((C_word*)lf[10]+1));}

/* k3470 in k3468 in k3466 in k3464 in k3462 in k3460 in k3458 in k3456 in k3454 in k3452 in k3450 in k3448 in k3446 in k3444 in k3442 in k3440 in k3438 in k3436 in k3434 in k3432 in k3430 in k3428 in ... */
static void C_ccall f_3471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3471,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3473,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3530,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3532,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:1269: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k3466 in k3464 in k3462 in k3460 in k3458 in k3456 in k3454 in k3452 in k3450 in k3448 in k3446 in k3444 in k3442 in k3440 in k3438 in k3436 in k3434 in k3432 in k3430 in k3428 in k3426 in k3424 in ... */
static void C_ccall f_3467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3467,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3469,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3939,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3941,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:1196: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k3468 in k3466 in k3464 in k3462 in k3460 in k3458 in k3456 in k3454 in k3452 in k3450 in k3448 in k3446 in k3444 in k3442 in k3440 in k3438 in k3436 in k3434 in k3432 in k3430 in k3428 in k3426 in ... */
static void C_ccall f_3469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3469,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3471,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3630,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3632,a[2]=((C_word)li10),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:1202: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k3462 in k3460 in k3458 in k3456 in k3454 in k3452 in k3450 in k3448 in k3446 in k3444 in k3442 in k3440 in k3438 in k3436 in k3434 in k3432 in k3430 in k3428 in k3426 in k3424 in k3422 in k3420 in ... */
static void C_ccall f_3463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3463,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3465,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4232,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4234,a[2]=((C_word)li22),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:1165: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k3464 in k3462 in k3460 in k3458 in k3456 in k3454 in k3452 in k3450 in k3448 in k3446 in k3444 in k3442 in k3440 in k3438 in k3436 in k3434 in k3432 in k3430 in k3428 in k3426 in k3424 in k3422 in ... */
static void C_ccall f_3465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3465,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3467,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4200,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4202,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:1185: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k3460 in k3458 in k3456 in k3454 in k3452 in k3450 in k3448 in k3446 in k3444 in k3442 in k3440 in k3438 in k3436 in k3434 in k3432 in k3430 in k3428 in k3426 in k3424 in k3422 in k3420 in k3418 in ... */
static void C_ccall f_3461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3461,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3463,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4321,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4323,a[2]=((C_word)li25),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:1136: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k9547 in k9676 in k9696 in k9528 in k9471 in k9469 in k9467 in k9465 in k9459 */
static void C_ccall f_9548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9548,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,lf[26],t3));}

/* k9214 in k9196 in k9187 */
static void C_fcall f_9215(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9215,NULL,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[251],t1);
t3=C_a_i_list(&a,4,lf[155],((C_word*)t0)[2],((C_word*)t0)[3],t2);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_list(&a,3,lf[30],((C_word*)t0)[5],t3));}

/* k3434 in k3432 in k3430 in k3428 in k3426 in k3424 in k3422 in k3420 in k3418 in k3416 in k3413 in k3410 in k3408 in k3406 in k3404 in k3402 in k3400 in k3398 in k3396 in k3394 in k3392 in k3390 in ... */
static void C_ccall f_3435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3435,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3437,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6290,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:759: ##sys#primitive-alias */
t4=*((C_word*)lf[106]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[150]);}

/* k3436 in k3434 in k3432 in k3430 in k3428 in k3426 in k3424 in k3422 in k3420 in k3418 in k3416 in k3413 in k3410 in k3408 in k3406 in k3404 in k3402 in k3400 in k3398 in k3396 in k3394 in k3392 in ... */
static void C_ccall f_3437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3437,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3439,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5875,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5877,a[2]=((C_word)li50),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:828: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k3438 in k3436 in k3434 in k3432 in k3430 in k3428 in k3426 in k3424 in k3422 in k3420 in k3418 in k3416 in k3413 in k3410 in k3408 in k3406 in k3404 in k3402 in k3400 in k3398 in k3396 in k3394 in ... */
static void C_ccall f_3439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3439,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3441,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5872,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:849: ##sys#primitive-alias */
t4=*((C_word*)lf[106]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[137]);}

/* k3430 in k3428 in k3426 in k3424 in k3422 in k3420 in k3418 in k3416 in k3413 in k3410 in k3408 in k3406 in k3404 in k3402 in k3400 in k3398 in k3396 in k3394 in k3392 in k3390 in k3388 in k3386 in ... */
static void C_ccall f_3431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3431,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3433,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6484,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:698: ##sys#primitive-alias */
t4=*((C_word*)lf[106]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[170]);}

/* k3432 in k3430 in k3428 in k3426 in k3424 in k3422 in k3420 in k3418 in k3416 in k3413 in k3410 in k3408 in k3406 in k3404 in k3402 in k3400 in k3398 in k3396 in k3394 in k3392 in k3390 in k3388 in ... */
static void C_ccall f_3433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3433,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3435,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6414,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:726: ##sys#primitive-alias */
t4=*((C_word*)lf[106]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[170]);}

/* k9241 in k3394 in k3392 in k3390 in k3388 in k3386 in k3384 in k3382 in k3379 */
static void C_ccall f_9242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:168: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[256],C_SCHEME_END_OF_LIST,t1);}

/* k3424 in k3422 in k3420 in k3418 in k3416 in k3413 in k3410 in k3408 in k3406 in k3404 in k3402 in k3400 in k3398 in k3396 in k3394 in k3392 in k3390 in k3388 in k3386 in k3384 in k3382 in k3379 in ... */
static void C_ccall f_3425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3425,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3427,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6988,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6990,a[2]=((C_word)li82),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:478: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k3426 in k3424 in k3422 in k3420 in k3418 in k3416 in k3413 in k3410 in k3408 in k3406 in k3404 in k3402 in k3400 in k3398 in k3396 in k3394 in k3392 in k3390 in k3388 in k3386 in k3384 in k3382 in ... */
static void C_ccall f_3427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3427,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3429,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6850,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6852,a[2]=((C_word)li80),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:497: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k3428 in k3426 in k3424 in k3422 in k3420 in k3418 in k3416 in k3413 in k3410 in k3408 in k3406 in k3404 in k3402 in k3400 in k3398 in k3396 in k3394 in k3392 in k3390 in k3388 in k3386 in k3384 in ... */
static void C_ccall f_3429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3429,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3431,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6847,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:610: ##sys#primitive-alias */
t4=*((C_word*)lf[106]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[112]);}

/* for-each-loop844 in k7934 */
static void C_fcall f_7960(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7960,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7969,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-syntax.scm:353: g845 */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3420 in k3418 in k3416 in k3413 in k3410 in k3408 in k3406 in k3404 in k3402 in k3400 in k3398 in k3396 in k3394 in k3392 in k3390 in k3388 in k3386 in k3384 in k3382 in k3379 */
static void C_ccall f_3421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3421,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3423,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7192,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:446: ##sys#primitive-alias */
t4=*((C_word*)lf[106]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[206]);}

/* k3422 in k3420 in k3418 in k3416 in k3413 in k3410 in k3408 in k3406 in k3404 in k3402 in k3400 in k3398 in k3396 in k3394 in k3392 in k3390 in k3388 in k3386 in k3384 in k3382 in k3379 */
static void C_ccall f_3423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3423,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3425,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7069,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7071,a[2]=((C_word)li84),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:457: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k3382 in k3379 */
static void C_ccall f_3383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3383,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3385,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9747,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9749,a[2]=((C_word)li165),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:51: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k3379 */
static void C_ccall f_3380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3380,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3383,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:46: ##sys#macro-environment */
t3=*((C_word*)lf[285]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k7968 in for-each-loop844 in k7934 */
static void C_ccall f_7969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_7960(t3,((C_word*)t0)[4],t2);}

/* k3386 in k3384 in k3382 in k3379 */
static void C_ccall f_3387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3387,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3389,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9377,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9379,a[2]=((C_word)li160),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:125: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k3497 in k3495 in k3487 */
static void C_ccall f_3498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3498,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3500,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=C_i_caddr(((C_word*)t0)[4]);
/* chicken-syntax.scm:1301: ##sys#strip-syntax */
t4=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}

/* k3384 in k3382 in k3379 */
static void C_ccall f_3385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3385,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3387,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9455,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9457,a[2]=((C_word)li164),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:58: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k3495 in k3487 */
static void C_ccall f_3496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3496,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3498,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:1300: r */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[20]);}

/* f_3951 in k3948 */
static void C_ccall f_3951(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3951,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_car(t2));}

/* k3948 */
static void C_ccall f_3950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3950,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3951,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp);
t7=C_i_car(((C_word*)t0)[2]);
t8=C_i_check_list_2(t7,lf[28]);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3961,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4041,a[2]=t5,a[3]=t11,a[4]=t3,a[5]=t6,a[6]=((C_word)li15),tmp=(C_word)a,a+=7,tmp));
t13=((C_word*)t11)[1];
f_4041(t13,t9,t7);}
else{
/* chicken-syntax.scm:1196: ##sys#syntax-rules-mismatch */
t2=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[5]);}}

/* a9243 in k3394 in k3392 in k3390 in k3388 in k3386 in k3384 in k3382 in k3379 */
static void C_ccall f_9244(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9244,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9248,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:173: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[256],t2,lf[260]);}

/* k9247 in a9243 in k3394 in k3392 in k3390 in k3388 in k3386 in k3384 in k3382 in k3379 */
static void C_ccall f_9248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9248,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=((C_word*)t0)[2];
t4=C_u_i_cdr(t3);
t5=C_u_i_cdr(t4);
t6=C_i_nullp(t5);
t7=(C_truep(t6)?lf[257]:C_i_car(t5));
t8=t7;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9257,a[2]=t2,a[3]=t9,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_stringp(((C_word*)t9)[1]))){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9298,a[2]=t9,a[3]=t10,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:178: get-line-number */
t12=*((C_word*)lf[31]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,((C_word*)t0)[2]);}
else{
t11=t10;
f_9257(t11,C_SCHEME_UNDEFINED);}}

/* f_3485 in k3472 in k3470 in k3468 in k3466 in k3464 in k3462 in k3460 in k3458 in k3456 in k3454 in k3452 in k3450 in k3448 in k3446 in k3444 in k3442 in k3440 in k3438 in k3436 in k3434 in k3432 in ... */
static void C_ccall f_3485(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3485,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3488,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:1296: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[12],t2,lf[23]);}

/* k3482 in k3472 in k3470 in k3468 in k3466 in k3464 in k3462 in k3460 in k3458 in k3456 in k3454 in k3452 in k3450 in k3448 in k3446 in k3444 in k3442 in k3440 in k3438 in k3436 in k3434 in k3432 in ... */
static void C_ccall f_3483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:1292: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[12],C_SCHEME_END_OF_LIST,t1);}

/* k3487 */
static void C_ccall f_3488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3488,2,t0,t1);}
if(C_truep(C_i_memq(lf[13],*((C_word*)lf[14]+1)))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3496,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_i_cadr(((C_word*)t0)[3]);
/* chicken-syntax.scm:1299: ##sys#strip-syntax */
t4=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[21]);}}

/* k3388 in k3386 in k3384 in k3382 in k3379 */
static void C_ccall f_3389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3389,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3391,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9339,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9341,a[2]=((C_word)li159),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:143: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k7942 */
static void C_ccall f_7943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:353: g860 */
t2=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* k3479 in k3476 in k3474 in k3472 in k3470 in k3468 in k3466 in k3464 in k3462 in k3460 in k3458 in k3456 in k3454 in k3452 in k3450 in k3448 in k3446 in k3444 in k3442 in k3440 in k3438 in k3436 in ... */
static void C_ccall f_3480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* map-loop196 in k8660 in k8652 */
static void C_fcall f_9122(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9122,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9147,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-syntax.scm:217: g202 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* f_3941 in k3466 in k3464 in k3462 in k3460 in k3458 in k3456 in k3454 in k3452 in k3450 in k3448 in k3446 in k3444 in k3442 in k3440 in k3438 in k3436 in k3434 in k3432 in k3430 in k3428 in k3426 in ... */
static void C_ccall f_3941(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3941,5,t0,t1,t2,t3,t4);}
t5=C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3950,a[2]=t5,a[3]=t1,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_pairp(t5))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4081,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4131,a[2]=t5,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t9=C_i_car(t5);
/* chicken-syntax.scm:1196: ##sys#list? */
t10=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t8,t9);}
else{
t7=t6;
f_3950(2,t7,C_SCHEME_FALSE);}}

/* k7955 in k7948 in k7934 */
static void C_ccall f_7956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7956,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,t1,t3));}

/* k7948 in k7934 */
static void C_ccall f_7950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7950,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7956,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:354: r */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[221]);}

/* k9146 in map-loop196 in k8660 in k8652 */
static void C_ccall f_9147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9147,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_9122(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_9122(t6,((C_word*)t0)[5],t5);}}

/* k3959 in k3948 */
static void C_ccall f_3961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3961,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3962,a[2]=((C_word)li12),tmp=(C_word)a,a+=3,tmp);
t7=C_i_car(((C_word*)t0)[2]);
t8=C_i_check_list_2(t7,lf[28]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3975,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4011,a[2]=t5,a[3]=t11,a[4]=t3,a[5]=t6,a[6]=((C_word)li14),tmp=(C_word)a,a+=7,tmp));
t13=((C_word*)t11)[1];
f_4011(t13,t9,t7);}

/* f_3962 in k3959 in k3948 */
static void C_ccall f_3962(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3962,3,t0,t1,t2);}
t3=C_i_cdr(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_i_car(t3));}

/* k3458 in k3456 in k3454 in k3452 in k3450 in k3448 in k3446 in k3444 in k3442 in k3440 in k3438 in k3436 in k3434 in k3432 in k3430 in k3428 in k3426 in k3424 in k3422 in k3420 in k3418 in k3416 in ... */
static void C_ccall f_3459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3459,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3461,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4415,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4417,a[2]=((C_word)li26),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:1109: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k3456 in k3454 in k3452 in k3450 in k3448 in k3446 in k3444 in k3442 in k3440 in k3438 in k3436 in k3434 in k3432 in k3430 in k3428 in k3426 in k3424 in k3422 in k3420 in k3418 in k3416 in k3413 in ... */
static void C_ccall f_3457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3457,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3459,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4489,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4491,a[2]=((C_word)li29),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:1100: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k3454 in k3452 in k3450 in k3448 in k3446 in k3444 in k3442 in k3440 in k3438 in k3436 in k3434 in k3432 in k3430 in k3428 in k3426 in k3424 in k3422 in k3420 in k3418 in k3416 in k3413 in k3410 in ... */
static void C_ccall f_3455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3455,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3457,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4619,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4621,a[2]=((C_word)li31),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:1089: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k3452 in k3450 in k3448 in k3446 in k3444 in k3442 in k3440 in k3438 in k3436 in k3434 in k3432 in k3430 in k3428 in k3426 in k3424 in k3422 in k3420 in k3418 in k3416 in k3413 in k3410 in k3408 in ... */
static void C_ccall f_3453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3453,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3455,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4819,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4821,a[2]=((C_word)li32),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:1079: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k3450 in k3448 in k3446 in k3444 in k3442 in k3440 in k3438 in k3436 in k3434 in k3432 in k3430 in k3428 in k3426 in k3424 in k3422 in k3420 in k3418 in k3416 in k3413 in k3410 in k3408 in k3406 in ... */
static void C_ccall f_3451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3451,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3453,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4833,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4835,a[2]=((C_word)li33),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:1068: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* map-loop169 in k8652 */
static void C_fcall f_9152(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_9152,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_car(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}
else{
t6=C_mutate(((C_word *)((C_word*)t0)[4])+1,t5);
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5685 in k5551 in k5549 in k5547 in k5545 in k5543 in k5541 */
static void C_ccall f_5686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[51],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5686,2,t0,t1);}
t2=C_a_i_list(&a,2,lf[113],lf[128]);
t3=C_a_i_list(&a,3,lf[116],((C_word*)t0)[2],t2);
t4=C_a_i_list(&a,3,lf[129],((C_word*)t0)[2],C_fix(1));
t5=C_a_i_list(&a,3,((C_word*)t0)[3],t3,t4);
t6=C_a_i_list(&a,2,((C_word*)t0)[4],t5);
t7=C_a_i_list(&a,1,t6);
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5701,a[2]=t7,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm:897: r */
t9=((C_word*)t0)[9];
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,lf[131]);}

/* k3448 in k3446 in k3444 in k3442 in k3440 in k3438 in k3436 in k3434 in k3432 in k3430 in k3428 in k3426 in k3424 in k3422 in k3420 in k3418 in k3416 in k3413 in k3410 in k3408 in k3406 in k3404 in ... */
static void C_ccall f_3449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3449,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3451,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4856,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4858,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:1052: ##sys#er-transformer */
t5=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k3446 in k3444 in k3442 in k3440 in k3438 in k3436 in k3434 in k3432 in k3430 in k3428 in k3426 in k3424 in k3422 in k3420 in k3418 in k3416 in k3413 in k3410 in k3408 in k3406 in k3404 in k3402 in ... */
static void C_ccall f_3447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3447,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3449,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5071,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:1011: ##sys#primitive-alias */
t4=*((C_word*)lf[106]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[100]);}

/* k3444 in k3442 in k3440 in k3438 in k3436 in k3434 in k3432 in k3430 in k3428 in k3426 in k3424 in k3422 in k3420 in k3418 in k3416 in k3413 in k3410 in k3408 in k3406 in k3404 in k3402 in k3400 in ... */
static void C_ccall f_3445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3445,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3447,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5223,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:979: ##sys#primitive-alias */
t4=*((C_word*)lf[106]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[100]);}

/* k3442 in k3440 in k3438 in k3436 in k3434 in k3432 in k3430 in k3428 in k3426 in k3424 in k3422 in k3420 in k3418 in k3416 in k3413 in k3410 in k3408 in k3406 in k3404 in k3402 in k3400 in k3398 in ... */
static void C_ccall f_3443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3443,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3445,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5531,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:906: ##sys#primitive-alias */
t4=*((C_word*)lf[106]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[110]);}

/* k8567 in k8561 */
static void C_ccall f_8568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8568,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8570,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm:249: r */
t3=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[245]);}

/* k3440 in k3438 in k3436 in k3434 in k3432 in k3430 in k3428 in k3426 in k3424 in k3422 in k3420 in k3418 in k3416 in k3413 in k3410 in k3408 in k3406 in k3404 in k3402 in k3400 in k3398 in k3396 in ... */
static void C_ccall f_3441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3441,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3443,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5778,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:871: ##sys#primitive-alias */
t4=*((C_word*)lf[106]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[27]);}

/* k8561 */
static void C_ccall f_8562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8562,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=((C_word*)t0)[2];
t4=C_u_i_cdr(t3);
t5=C_u_i_cdr(t4);
t6=C_a_i_cons(&a,2,lf[26],t5);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8568,a[2]=((C_word*)t0)[3],a[3]=t6,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:248: r */
t8=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,lf[246]);}

/* k3938 in k3466 in k3464 in k3462 in k3460 in k3458 in k3456 in k3454 in k3452 in k3450 in k3448 in k3446 in k3444 in k3442 in k3440 in k3438 in k3436 in k3434 in k3432 in k3430 in k3428 in k3426 in ... */
static void C_ccall f_3939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:1194: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[51],C_SCHEME_END_OF_LIST,t1);}

/* k8556 in k3400 in k3398 in k3396 in k3394 in k3392 in k3390 in k3388 in k3386 in k3384 in k3382 in k3379 */
static void C_ccall f_8557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:241: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[237],C_SCHEME_END_OF_LIST,t1);}

/* f_8559 in k3400 in k3398 in k3396 in k3394 in k3392 in k3390 in k3388 in k3386 in k3384 in k3382 in k3379 */
static void C_ccall f_8559(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8559,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8562,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:245: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[237],t2,lf[247]);}

/* k9116 in map-loop224 in k8670 in k8660 in k8652 */
static void C_ccall f_9117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9117,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_9092(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_9092(t6,((C_word*)t0)[5],t5);}}

/* k9664 in k9562 in mapslots in k9676 in k9696 in k9528 in k9471 in k9469 in k9467 in k9465 in k9459 */
static void C_ccall f_9665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:95: string->symbol */
t2=*((C_word*)lf[178]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k9661 in k9564 in k9562 in mapslots in k9676 in k9696 in k9528 in k9471 in k9469 in k9467 in k9465 in k9459 */
static void C_ccall f_9662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:96: string->symbol */
t2=*((C_word*)lf[178]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k9676 in k9696 in k9528 in k9471 in k9469 in k9467 in k9465 in k9459 */
static void C_ccall f_9677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[51],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9677,2,t0,t1);}
t2=C_a_i_list(&a,1,lf[124]);
t3=C_a_i_list(&a,2,lf[20],((C_word*)t0)[2]);
t4=C_a_i_list(&a,3,lf[116],lf[124],t3);
t5=C_a_i_list(&a,3,lf[97],t2,t4);
t6=C_a_i_list(&a,3,((C_word*)t0)[3],t1,t5);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9548,a[2]=t6,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9550,a[2]=((C_word*)t0)[2],a[3]=t9,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],a[7]=((C_word)li162),tmp=(C_word)a,a+=8,tmp));
t11=((C_word*)t9)[1];
f_9550(t11,t7,((C_word*)t0)[8],C_fix(1));}

/* f_3991 in k3982 in k3973 in k3959 in k3948 */
static void C_ccall f_3991(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3991,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4003,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:1196: rename2227 */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[52]);}

/* f_7932 in k3410 in k3408 in k3406 in k3404 in k3402 in k3400 in k3398 in k3396 in k3394 in k3392 in k3390 in k3388 in k3386 in k3384 in k3382 in k3379 */
static void C_ccall f_7932(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7932,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7935,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:352: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[217],t2,lf[222]);}

/* k7934 */
static void C_ccall f_7935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7935,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7936,a[2]=((C_word)li115),tmp=(C_word)a,a+=3,tmp);
t3=C_i_cadr(((C_word*)t0)[2]);
t4=C_i_check_list_2(t3,lf[220]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7950,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7960,a[2]=t7,a[3]=t2,a[4]=((C_word)li116),tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_7960(t9,t5,t3);}

/* f_7936 in k7934 */
static void C_ccall f_7936(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7936,3,t0,t1,t2);}
t3=*((C_word*)lf[218]+1);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7943,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:353: ##sys#current-module */
t5=*((C_word*)lf[219]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k7929 in k3410 in k3408 in k3406 in k3404 in k3402 in k3400 in k3398 in k3396 in k3394 in k3392 in k3390 in k3388 in k3386 in k3384 in k3382 in k3379 */
static void C_ccall f_7930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:348: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[217],C_SCHEME_END_OF_LIST,t1);}

/* map-loop1434 in k6646 in k6642 in k6640 in k6494 */
static void C_fcall f_6777(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6777,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6802,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-syntax.scm:662: g1440 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3988 in k3982 in k3973 in k3959 in k3948 */
static void C_ccall f_3989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3989,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,((C_word*)t0)[4],t2));}

/* k3982 in k3973 in k3959 in k3948 */
static void C_ccall f_3983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3983,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3989,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3991,a[2]=((C_word*)t0)[4],a[3]=((C_word)li13),tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:1196: ##sys#map-n */
t4=*((C_word*)lf[53]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,t3,((C_word*)t0)[5],((C_word*)t0)[6]);}

/* f_6030 in k6023 in k6015 */
static void C_ccall f_6030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6030,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6036,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:803: take */
t3=*((C_word*)lf[157]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[4]);}

/* k6035 */
static void C_ccall f_6036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:803: split-at! */
t2=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,((C_word*)t0)[3]);}

/* k6040 */
static void C_ccall f_6041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6041,2,t0,t1);}
if(C_truep(C_i_nullp(((C_word*)t0)[2]))){
t2=t1;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=*((C_word*)lf[158]+1);
t7=((C_word*)t0)[2];
t8=((C_word*)t0)[4];
t9=C_i_check_list_2(t7,lf[28]);
t10=C_i_check_list_2(t8,lf[28]);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6058,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6060,a[2]=t5,a[3]=t13,a[4]=t3,a[5]=((C_word)li54),tmp=(C_word)a,a+=6,tmp));
t15=((C_word*)t13)[1];
f_6060(t15,t11,t7,t8);}}

/* f_6038 in k6023 in k6015 */
static void C_ccall f_6038(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6038,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6041,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6102,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t6,a[7]=((C_word*)t0)[7],a[8]=((C_word)li55),tmp=(C_word)a,a+=9,tmp));
t8=((C_word*)t6)[1];
f_6102(t8,t4,t3,((C_word*)t0)[8]);}

/* k4369 */
static void C_ccall f_4370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4370,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* f_6013 */
static void C_ccall f_6013(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6013,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_6016,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,a[7]=((C_word*)t0)[4],a[8]=t4,a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],a[12]=((C_word*)t0)[8],a[13]=((C_word*)t0)[9],a[14]=((C_word*)t0)[10],a[15]=((C_word*)t0)[11],a[16]=((C_word*)t0)[12],tmp=(C_word)a,a+=17,tmp);
t6=C_i_car(((C_word*)t0)[5]);
/* chicken-syntax.scm:795: ##sys#check-syntax */
t7=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t5,lf[154],t6,lf[159]);}

/* k6015 */
static void C_ccall f_6016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6016,2,t0,t1);}
t2=C_fixnum_difference(((C_word*)t0)[2],((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6025,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[8])){
t4=C_eqp(t2,C_fix(0));
t5=t3;
f_6025(t5,(C_truep(t4)?C_SCHEME_TRUE:C_a_i_list(&a,3,((C_word*)t0)[14],((C_word*)t0)[15],t2)));}
else{
t4=t3;
f_6025(t4,C_a_i_list(&a,3,((C_word*)t0)[16],((C_word*)t0)[15],t2));}}

/* map-loop2146 in k4327 in k4325 */
static void C_fcall f_4384(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4384,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4409,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-syntax.scm:1147: g2152 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7040 in fold in k6992 */
static void C_ccall f_7041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7041,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,4,lf[155],((C_word*)t0)[3],t1,C_SCHEME_FALSE));}

/* k4380 in k4327 in k4325 */
static void C_ccall f_4382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4382,2,t0,t1);}
t2=C_a_i_list(&a,2,lf[20],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4363,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:1152: ##sys#validate-exports */
t4=*((C_word*)lf[71]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[6],lf[70]);}

/* k3973 in k3959 in k3948 */
static void C_ccall f_3975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3975,2,t0,t1);}
t2=C_i_cdr(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3983,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:1196: rename2227 */
t4=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[54]);}

/* k5136 in k5105 in k5103 in loop in k5087 in k5085 in k5083 in k5081 */
static void C_ccall f_5137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:992: r */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],t1);}

/* f_4365 in k4327 in k4325 */
static void C_ccall f_4365(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4365,3,t0,t1,t2);}
t3=C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4370,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=C_i_cadr(t2);
/* chicken-syntax.scm:1149: ##sys#validate-exports */
t6=*((C_word*)lf[71]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,lf[70]);}

/* k7026 in fold in k6992 */
static void C_ccall f_7027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7027,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,4,lf[155],((C_word*)t0)[3],t1,C_SCHEME_FALSE));}

/* k5891 in k5879 */
static void C_ccall f_5892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5892,2,t0,t1);}
t2=C_slot(((C_word*)t0)[2],C_fix(0));
t3=C_a_i_list(&a,2,lf[20],t2);
t4=C_slot(((C_word*)t0)[2],C_fix(1));
t5=C_a_i_cons(&a,2,t4,((C_word*)t0)[3]);
t6=C_a_i_cons(&a,2,lf[97],t5);
t7=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_list(&a,3,lf[146],t3,t6));}

/* k4362 in k4380 in k4327 in k4325 */
static void C_ccall f_4363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[57],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4363,2,t0,t1);}
t2=C_a_i_list(&a,2,lf[20],t1);
t3=C_a_i_list(&a,2,lf[20],((C_word*)t0)[2]);
t4=C_a_i_list(&a,5,lf[72],((C_word*)t0)[3],((C_word*)t0)[4],t2,t3);
t5=C_a_i_list(&a,3,lf[73],lf[74],lf[75]);
t6=C_a_i_list(&a,2,lf[76],t4);
t7=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_list(&a,5,lf[77],((C_word*)t0)[6],C_SCHEME_TRUE,t5,t6));}

/* k5128 in k5116 in k5110 in k5105 in k5103 in loop in k5087 in k5085 in k5083 in k5081 */
static void C_ccall f_5129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5129,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_list(&a,3,lf[97],((C_word*)t0)[5],t3));}

/* k4609 in k4596 in loop2076 in k4581 in k4576 in k4573 */
static void C_ccall f_4610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:1100: loop2076 */
t2=((C_word*)((C_word*)t0)[2])[1];
f_4591(t2,((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* k4618 in k3454 in k3452 in k3450 in k3448 in k3446 in k3444 in k3442 in k3440 in k3438 in k3436 in k3434 in k3432 in k3430 in k3428 in k3426 in k3424 in k3422 in k3420 in k3418 in k3416 in k3413 in ... */
static void C_ccall f_4619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:1087: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[88],C_SCHEME_END_OF_LIST,t1);}

/* f_7983 in k3408 in k3406 in k3404 in k3402 in k3400 in k3398 in k3396 in k3394 in k3392 in k3390 in k3388 in k3386 in k3384 in k3382 in k3379 */
static void C_ccall f_7983(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7983,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7986,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:328: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[221],t2,lf[224]);}

/* k7980 in k3408 in k3406 in k3404 in k3402 in k3400 in k3398 in k3396 in k3394 in k3392 in k3390 in k3388 in k3386 in k3384 in k3382 in k3379 */
static void C_ccall f_7981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:324: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[221],C_SCHEME_END_OF_LIST,t1);}

/* k7985 */
static void C_ccall f_7986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7986,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=C_i_caddr(((C_word*)t0)[2]);
if(C_truep(C_i_nullp(t2))){
t4=C_a_i_list(&a,3,lf[97],C_SCHEME_END_OF_LIST,t3);
t5=C_a_i_list(&a,1,lf[223]);
t6=C_a_i_list(&a,3,lf[97],C_SCHEME_END_OF_LIST,t5);
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_list(&a,3,lf[141],t4,t6));}
else{
t4=C_i_cdr(t2);
if(C_truep(C_i_nullp(t4))){
t5=C_u_i_car(t2);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_list(&a,3,lf[211],t5,t3));}
else{
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=*((C_word*)lf[32]+1);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8022,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8088,a[2]=t8,a[3]=t12,a[4]=t6,a[5]=t9,a[6]=((C_word)li120),tmp=(C_word)a,a+=7,tmp));
t14=((C_word*)t12)[1];
f_8088(t14,t10,t2);}}}

/* k5879 */
static void C_ccall f_5880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5880,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=((C_word*)t0)[2];
t4=C_u_i_cdr(t3);
t5=C_u_i_cdr(t4);
if(C_truep(C_i_pairp(t2))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5892,a[2]=t2,a[3]=t5,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=C_a_i_cons(&a,2,t2,t5);
/* chicken-syntax.scm:834: ##sys#check-syntax */
t8=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t6,lf[145],t7,lf[147]);}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5915,a[2]=t2,a[3]=t5,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=C_a_i_cons(&a,2,t2,t5);
/* chicken-syntax.scm:841: ##sys#check-syntax */
t8=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t6,lf[145],t7,lf[148]);}}

/* k5158 in k5155 in loop in k5087 in k5085 in k5083 in k5081 */
static void C_ccall f_5159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5159,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=C_a_i_cons(&a,2,t1,((C_word*)t0)[3]);
t5=C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
/* chicken-syntax.scm:1000: loop */
t6=((C_word*)((C_word*)t0)[5])[1];
f_5095(t6,((C_word*)t0)[6],t3,t4,t5,C_SCHEME_FALSE);}

/* k5155 in loop in k5087 in k5085 in k5083 in k5081 */
static void C_ccall f_5157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5157,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5159,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5173,a[2]=((C_word*)t0)[7],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:999: gensym */
t4=*((C_word*)lf[32]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5179,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[2];
t4=C_u_i_car(t3);
/* chicken-syntax.scm:1001: c */
t5=((C_word*)t0)[9];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,((C_word*)t0)[10],t4);}}

/* k5874 in k3436 in k3434 in k3432 in k3430 in k3428 in k3426 in k3424 in k3422 in k3420 in k3418 in k3416 in k3413 in k3410 in k3408 in k3406 in k3404 in k3402 in k3400 in k3398 in k3396 in k3394 in ... */
static void C_ccall f_5875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:826: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[145],C_SCHEME_END_OF_LIST,t1);}

/* k5871 in k3438 in k3436 in k3434 in k3432 in k3430 in k3428 in k3426 in k3424 in k3422 in k3420 in k3418 in k3416 in k3413 in k3410 in k3408 in k3406 in k3404 in k3402 in k3400 in k3398 in k3396 in ... */
static void C_ccall f_5872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5872,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[137],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5869,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:850: ##sys#primitive-alias */
t4=*((C_word*)lf[106]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[138]);}

/* f_5877 in k3436 in k3434 in k3432 in k3430 in k3428 in k3426 in k3424 in k3422 in k3420 in k3418 in k3416 in k3413 in k3410 in k3408 in k3406 in k3404 in k3402 in k3400 in k3398 in k3396 in k3394 in ... */
static void C_ccall f_5877(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5877,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5880,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:830: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[145],t2,lf[149]);}

/* k4628 */
static void C_fcall f_4630(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4630,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4638,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:1089: rename2029 */
t4=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[89]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4650,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[2]))){
t3=C_i_car(((C_word*)t0)[2]);
if(C_truep(C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4766,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=C_i_cdr(((C_word*)t0)[2]);
/* chicken-syntax.scm:1089: ##sys#list? */
t6=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t4=t2;
f_4650(2,t4,C_SCHEME_FALSE);}}
else{
t3=t2;
f_4650(2,t3,C_SCHEME_FALSE);}}}

/* k4637 in k4628 */
static void C_ccall f_4638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4638,2,t0,t1);}
t2=C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[2],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,t1,t3));}

/* map-loop1491 in k6676 in k6674 in k6671 in k6668 in k6646 in k6642 in k6640 in k6494 */
static void C_fcall f_6717(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6717,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6742,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-syntax.scm:671: g1497 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5993 in k5987 in k5985 in k5983 in k5981 in k5979 in k5977 in k5975 in k5973 in k5971 in k5969 in k5937 */
static void C_ccall f_5994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5994,2,t0,t1);}
t2=C_a_i_list(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t3=C_a_i_list(&a,2,((C_word*)t0)[4],t2);
t4=C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6003,a[2]=t4,a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6005,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[12],a[11]=((C_word)li58),tmp=(C_word)a,a+=12,tmp);
t7=((C_word*)t0)[13];
t8=C_u_i_cdr(t7);
/* chicken-syntax.scm:790: fold-right */
t9=*((C_word*)lf[161]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t5,t6,lf[162],t8);}

/* k4648 in k4628 */
static void C_ccall f_4650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4650,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[2]);
t3=C_i_car(t2);
t4=C_i_car(((C_word*)t0)[2]);
t5=C_i_cdr(t4);
t6=C_i_cdr(((C_word*)t0)[2]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4662,a[2]=t5,a[3]=t6,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:1089: rename2029 */
t8=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,lf[88]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4710,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[2]))){
t3=C_i_cdr(((C_word*)t0)[2]);
if(C_truep(C_i_pairp(t3))){
t4=C_i_cdr(t3);
t5=t2;
f_4710(t5,C_eqp(t4,C_SCHEME_END_OF_LIST));}
else{
t4=t2;
f_4710(t4,C_SCHEME_FALSE);}}
else{
t3=t2;
f_4710(t3,C_SCHEME_FALSE);}}}

/* k8297 in k8241 in k8230 in k8221 in k8211 in k8199 in k8196 in k8192 in k8190 in k8184 */
static void C_ccall f_8299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8299,2,t0,t1);}
t2=C_a_i_list(&a,3,lf[211],((C_word*)t0)[2],C_SCHEME_TRUE);
t3=C_a_i_list(&a,1,t2);
/* chicken-syntax.scm:280: ##sys#append */
t4=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[3],t1,t3);}

/* k5979 in k5977 in k5975 in k5973 in k5971 in k5969 in k5937 */
static void C_ccall f_5980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5980,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5982,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm:782: r */
t3=((C_word*)t0)[7];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[152]);}

/* k5981 in k5979 in k5977 in k5975 in k5973 in k5971 in k5969 in k5937 */
static void C_ccall f_5982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5982,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5984,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm:783: r */
t3=((C_word*)t0)[7];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[112]);}

/* k5983 in k5981 in k5979 in k5977 in k5975 in k5973 in k5971 in k5969 in k5937 */
static void C_ccall f_5984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5984,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5986,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* chicken-syntax.scm:784: r */
t3=((C_word*)t0)[7];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[151]);}

/* k5985 in k5983 in k5981 in k5979 in k5977 in k5975 in k5973 in k5971 in k5969 in k5937 */
static void C_ccall f_5986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5986,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5988,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* chicken-syntax.scm:785: r */
t3=((C_word*)t0)[8];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[153]);}

/* k5987 in k5985 in k5983 in k5981 in k5979 in k5977 in k5975 in k5973 in k5971 in k5969 in k5937 */
static void C_ccall f_5988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5988,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5994,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* chicken-syntax.scm:787: append */
t3=*((C_word*)lf[163]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[6],((C_word*)t0)[2]);}

/* k5116 in k5110 in k5105 in k5103 in loop in k5087 in k5085 in k5083 in k5081 */
static void C_ccall f_5117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5117,2,t0,t1);}
t2=C_i_car(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5129,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
t6=C_a_i_list(&a,1,((C_word*)t0)[5]);
/* chicken-syntax.scm:992: ##sys#append */
t7=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t3,t5,t6);}

/* f_4621 in k3454 in k3452 in k3450 in k3448 in k3446 in k3444 in k3442 in k3440 in k3438 in k3436 in k3434 in k3432 in k3430 in k3428 in k3426 in k3424 in k3422 in k3420 in k3418 in k3416 in k3413 in ... */
static void C_ccall f_4621(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4621,5,t0,t1,t2,t3,t4);}
t5=C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4630,a[2]=t5,a[3]=t1,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_pairp(t5))){
t7=C_i_cdr(t5);
t8=t6;
f_4630(t8,C_eqp(t7,C_SCHEME_END_OF_LIST));}
else{
t7=t6;
f_4630(t7,C_SCHEME_FALSE);}}

/* k9586 in k9566 in k9564 in k9562 in mapslots in k9676 in k9696 in k9528 in k9471 in k9469 in k9467 in k9465 in k9459 */
static void C_ccall f_9587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9587,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[26],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9578,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_slot(((C_word*)t0)[3],C_fix(1));
t5=C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* chicken-syntax.scm:120: mapslots */
t6=((C_word*)((C_word*)t0)[5])[1];
f_9550(t6,t3,t4,t5);}

/* k5110 in k5105 in k5103 in loop in k5087 in k5085 in k5083 in k5081 */
static void C_ccall f_5111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5111,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5117,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:992: ##sys#append */
t3=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[5],t1);}

/* k5105 in k5103 in loop in k5087 in k5085 in k5083 in k5081 */
static void C_ccall f_5106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5106,2,t0,t1);}
if(C_truep(((C_word*)t0)[2])){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5111,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5137,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:992: gensym */
t4=*((C_word*)lf[32]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=C_i_car(t1);
t3=C_a_i_list(&a,2,lf[26],t2);
t4=t1;
t5=C_u_i_cdr(t4);
t6=C_a_i_cons(&a,2,t3,t5);
t7=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_list(&a,3,lf[97],((C_word*)t0)[5],t6));}}

/* k5103 in loop in k5087 in k5085 in k5083 in k5081 */
static void C_ccall f_5104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5104,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5106,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:990: reverse */
t3=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}

/* k6741 in map-loop1491 in k6676 in k6674 in k6671 in k6668 in k6646 in k6642 in k6640 in k6494 */
static void C_ccall f_6742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6742,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_6717(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_6717(t6,((C_word*)t0)[5],t5);}}

/* k4673 in k4661 in k4648 in k4628 */
static void C_ccall f_4674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4674,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4695,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm:1089: rename2029 */
t3=((C_word*)t0)[7];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[90]);}

/* k9589 in k9566 in k9564 in k9562 in mapslots in k9676 in k9696 in k9528 in k9471 in k9469 in k9467 in k9465 in k9459 */
static void C_fcall f_9590(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[66],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9590,NULL,2,t0,t1);}
if(C_truep(((C_word*)t0)[2])){
t2=C_a_i_list(&a,1,lf[124]);
t3=C_a_i_list(&a,2,lf[113],((C_word*)t0)[3]);
t4=C_a_i_list(&a,3,lf[117],lf[124],t3);
t5=C_a_i_list(&a,2,lf[118],t4);
t6=C_a_i_list(&a,3,lf[119],lf[124],((C_word*)t0)[4]);
t7=C_a_i_list(&a,4,lf[97],t2,t5,t6);
t8=C_a_i_list(&a,3,((C_word*)t0)[5],t7,((C_word*)t0)[6]);
t9=C_a_i_list(&a,3,((C_word*)t0)[7],((C_word*)t0)[8],t8);
t10=C_a_i_list(&a,1,t9);
/* chicken-syntax.scm:45: ##sys#append */
t11=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,((C_word*)t0)[9],t1,t10);}
else{
t2=C_a_i_list(&a,1,lf[124]);
t3=C_a_i_list(&a,2,lf[113],((C_word*)t0)[3]);
t4=C_a_i_list(&a,3,lf[117],lf[124],t3);
t5=C_a_i_list(&a,2,lf[118],t4);
t6=C_a_i_list(&a,3,lf[119],lf[124],((C_word*)t0)[4]);
t7=C_a_i_list(&a,4,lf[97],t2,t5,t6);
t8=C_a_i_list(&a,3,((C_word*)t0)[7],((C_word*)t0)[8],t7);
t9=C_a_i_list(&a,1,t8);
/* chicken-syntax.scm:45: ##sys#append */
t10=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,((C_word*)t0)[9],t1,t9);}}

/* map-loop1462 in k6668 in k6646 in k6642 in k6640 in k6494 */
static void C_fcall f_6747(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6747,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_cadr(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}
else{
t6=C_mutate(((C_word *)((C_word*)t0)[4])+1,t5);
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4694 in k4673 in k4661 in k4648 in k4628 */
static void C_ccall f_4695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4695,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t3=C_a_i_cons(&a,2,t1,t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4689,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:1089: rename2029 */
t5=((C_word*)t0)[8];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[20]);}

/* k4661 in k4648 in k4628 */
static void C_ccall f_4662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4662,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4674,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm:1089: rename2029 */
t3=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[24]);}

/* mapslots in k9676 in k9696 in k9528 in k9471 in k9469 in k9467 in k9465 in k9459 */
static void C_fcall f_9550(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9550,NULL,4,t0,t1,t2,t3);}
t4=C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t4)){
t5=t2;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=C_i_car(t2);
t6=C_i_symbolp(t5);
t7=C_i_not(t6);
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9563,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=t7,a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[6],tmp=(C_word)a,a+=11,tmp);
if(C_truep(t7)){
t9=C_i_cadr(t5);
/* chicken-syntax.scm:94: symbol->string */
t10=*((C_word*)lf[180]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t8,t9);}
else{
/* chicken-syntax.scm:94: symbol->string */
t9=*((C_word*)lf[180]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t5);}}}

/* k9566 in k9564 in k9562 in mapslots in k9676 in k9696 in k9528 in k9471 in k9469 in k9467 in k9465 in k9459 */
static void C_ccall f_9567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[79],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9567,2,t0,t1);}
t2=C_a_i_list(&a,2,lf[124],lf[274]);
t3=C_a_i_list(&a,2,lf[113],((C_word*)t0)[2]);
t4=C_a_i_list(&a,3,lf[117],lf[124],t3);
t5=C_a_i_list(&a,2,lf[118],t4);
t6=C_a_i_list(&a,4,lf[121],lf[124],((C_word*)t0)[3],lf[274]);
t7=C_a_i_list(&a,4,lf[97],t2,t5,t6);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9587,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9590,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[8],a[6]=t7,a[7]=((C_word*)t0)[9],a[8]=t1,a[9]=t8,tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[7])){
t10=t9;
f_9590(t10,C_SCHEME_END_OF_LIST);}
else{
t10=C_a_i_list(&a,3,((C_word*)t0)[9],((C_word*)t0)[10],t7);
t11=t9;
f_9590(t11,C_a_i_list(&a,1,t10));}}

/* k9564 in k9562 in mapslots in k9676 in k9696 in k9528 in k9471 in k9469 in k9467 in k9465 in k9459 */
static void C_ccall f_9565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9565,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9567,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9662,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:96: string-append */
t4=*((C_word*)lf[179]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[10],lf[275],((C_word*)t0)[11]);}

/* k9562 in mapslots in k9676 in k9696 in k9528 in k9471 in k9469 in k9467 in k9465 in k9459 */
static void C_ccall f_9563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9563,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_9565,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9665,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:95: string-append */
t4=*((C_word*)lf[179]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[10],lf[276],t1,lf[277]);}

/* k4688 in k4694 in k4673 in k4661 in k4648 in k4628 */
static void C_ccall f_4689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4689,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,t1,t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=C_a_i_cons(&a,2,((C_word*)t0)[2],t7);
t9=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_a_i_cons(&a,2,((C_word*)t0)[6],t8));}

/* k9577 in k9586 in k9566 in k9564 in k9562 in mapslots in k9676 in k9696 in k9528 in k9471 in k9469 in k9467 in k9465 in k9459 */
static void C_ccall f_9578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9578,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* k5295 in k5291 in loop in k5463 in k5255 in k5251 in k5249 in k5245 in k5243 in k5233 */
static void C_fcall f_5296(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5296,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5302,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
t3=C_u_i_cdr(((C_word*)t0)[8]);
t4=C_u_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5355,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[13],a[4]=t1,a[5]=t2,a[6]=((C_word*)t0)[10],a[7]=t4,tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[7])){
t6=C_u_i_cdr(((C_word*)t0)[8]);
t7=C_u_i_car(t6);
/* chicken-syntax.scm:962: c */
t8=((C_word*)t0)[9];
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t5,((C_word*)t0)[7],t7);}
else{
t6=t5;
f_5355(2,t6,C_SCHEME_FALSE);}}

/* k5291 in loop in k5463 in k5255 in k5251 in k5249 in k5245 in k5243 in k5233 */
static void C_fcall f_5292(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[128],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5292,NULL,2,t0,t1);}
t2=C_a_i_list(&a,1,((C_word*)t0)[2]);
t3=C_a_i_list(&a,2,lf[113],((C_word*)t0)[3]);
t4=C_i_cadr(((C_word*)t0)[4]);
t5=C_a_i_list(&a,2,lf[113],t4);
t6=C_a_i_list(&a,4,lf[117],((C_word*)t0)[2],t3,t5);
t7=C_a_i_list(&a,2,lf[118],t6);
t8=C_a_i_list(&a,3,lf[119],((C_word*)t0)[2],((C_word*)t0)[5]);
t9=C_a_i_list(&a,4,lf[97],t2,t7,t8);
t10=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5296,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=t1,a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=t9,tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[9])){
t11=C_a_i_list(&a,2,((C_word*)t0)[2],((C_word*)t0)[14]);
t12=C_a_i_list(&a,2,lf[113],((C_word*)t0)[3]);
t13=C_a_i_list(&a,2,lf[113],t1);
t14=C_a_i_list(&a,4,lf[117],((C_word*)t0)[2],t12,t13);
t15=C_a_i_list(&a,2,lf[118],t14);
t16=C_a_i_list(&a,4,lf[121],((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[14]);
t17=t10;
f_5296(t17,C_a_i_list(&a,4,lf[97],t11,t15,t16));}
else{
t11=t10;
f_5296(t11,C_SCHEME_FALSE);}}

/* f_8278 in k8241 in k8230 in k8221 in k8211 in k8199 in k8196 in k8192 in k8190 in k8184 */
static void C_ccall f_8278(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[42],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8278,4,t0,t1,t2,t3);}
t4=C_a_i_list(&a,1,t2);
t5=C_a_i_list(&a,2,lf[233],t4);
t6=C_a_i_list(&a,1,t5);
t7=C_a_i_list(&a,3,t2,t3,((C_word*)t0)[2]);
t8=C_a_i_list(&a,3,lf[211],t3,lf[233]);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_a_i_list(&a,4,lf[30],t6,t7,t8));}

/* k8275 in k8241 in k8230 in k8221 in k8211 in k8199 in k8196 in k8192 in k8190 in k8184 */
static void C_ccall f_8276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[69],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8276,2,t0,t1);}
t2=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=C_a_i_cons(&a,2,lf[97],t2);
t4=C_a_i_list(&a,2,((C_word*)t0)[2],t3);
t5=C_a_i_list(&a,1,t4);
t6=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
t7=C_a_i_cons(&a,2,lf[97],t6);
t8=C_a_i_list(&a,4,lf[232],((C_word*)t0)[2],t7,((C_word*)t0)[2]);
t9=C_a_i_list(&a,3,lf[30],t5,t8);
t10=C_a_i_list(&a,3,lf[30],((C_word*)t0)[4],t9);
t11=C_a_i_list(&a,3,lf[30],((C_word*)t0)[5],t10);
t12=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_a_i_list(&a,3,lf[30],((C_word*)t0)[7],t11));}

/* loop in k5463 in k5255 in k5251 in k5249 in k5245 in k5243 in k5233 */
static void C_fcall f_5277(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5277,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=C_i_car(t2);
t5=C_i_cddr(t4);
t6=C_i_pairp(t5);
t7=(C_truep(t6)?C_i_caddr(t4):C_SCHEME_FALSE);
t8=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_5292,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t3,a[6]=t1,a[7]=t2,a[8]=((C_word*)t0)[4],a[9]=t6,a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[6],a[12]=t7,a[13]=((C_word*)t0)[7],a[14]=((C_word*)t0)[8],tmp=(C_word)a,a+=15,tmp);
if(C_truep(C_i_pairp(t7))){
t9=C_u_i_cdr(t7);
if(C_truep(C_i_pairp(t9))){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5421,a[2]=t8,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t11=C_u_i_car(t7);
/* chicken-syntax.scm:941: c */
t12=((C_word*)t0)[5];
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t10,lf[122],t11);}
else{
t10=t8;
f_5292(t10,C_SCHEME_FALSE);}}
else{
t9=t8;
f_5292(t9,C_SCHEME_FALSE);}}}

/* k5274 in k5463 in k5255 in k5251 in k5249 in k5245 in k5243 in k5233 */
static void C_ccall f_5275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5275,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,lf[26],t3));}

/* map-loop275 in k8680 in k8670 in k8660 in k8652 */
static void C_fcall f_9062(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_9062,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_cadr(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}
else{
t6=C_mutate(((C_word *)((C_word*)t0)[4])+1,t5);
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8230 in k8221 in k8211 in k8199 in k8196 in k8192 in k8190 in k8184 */
static void C_ccall f_8232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8232,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=*((C_word*)lf[231]+1);
t7=C_i_check_list_2(((C_word*)t0)[2],lf[28]);
t8=C_i_check_list_2(((C_word*)t0)[3],lf[28]);
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8243,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t1,a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[2],tmp=(C_word)a,a+=9,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8352,a[2]=t5,a[3]=t11,a[4]=t3,a[5]=((C_word)li128),tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_8352(t13,t9,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k4035 in map-loop2297 in k3959 in k3948 */
static void C_ccall f_4036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4036,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4011(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4011(t6,((C_word*)t0)[5],t5);}}

/* k8221 in k8211 in k8199 in k8196 in k8192 in k8190 in k8184 */
static void C_ccall f_8223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8223,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=*((C_word*)lf[231]+1);
t7=C_i_check_list_2(((C_word*)t0)[2],lf[28]);
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8232,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[2],tmp=(C_word)a,a+=9,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8394,a[2]=t5,a[3]=t10,a[4]=t3,a[5]=((C_word)li129),tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_8394(t12,t8,((C_word*)t0)[2],((C_word*)t0)[8]);}

/* k8219 */
static void C_ccall f_8220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:287: r */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],t1);}

/* k8785 in k8802 in map-loop417 in k8823 in k8687 in k8680 in k8670 in k8660 in k8652 */
static void C_fcall f_8786(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[3]);
t3=C_slot(((C_word*)t0)[4],C_fix(1));
t4=C_slot(((C_word*)t0)[5],C_fix(1));
t5=((C_word*)((C_word*)t0)[6])[1];
f_8775(t5,((C_word*)t0)[7],t3,t4);}

/* map-loop2269 in k3948 */
static void C_fcall f_4041(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4041,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4066,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-syntax.scm:1196: g2275 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* map-loop224 in k8670 in k8660 in k8652 */
static void C_fcall f_9092(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9092,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9117,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-syntax.scm:218: g230 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* map-loop588 in k8199 in k8196 in k8192 in k8190 in k8184 */
static void C_fcall f_8466(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8466,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8491,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-syntax.scm:286: g594 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8460 in map-loop616 in k8211 in k8199 in k8196 in k8192 in k8190 in k8184 */
static void C_ccall f_8461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8461,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8436(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8436(t6,((C_word*)t0)[5],t5);}}

/* k7278 in k7264 */
static void C_ccall f_7280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7280,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,lf[97],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_list(&a,3,lf[141],((C_word*)t0)[4],t3));}

/* map-loop1198 in k7264 */
static void C_fcall f_7282(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7282,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7307,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-syntax.scm:440: g1204 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7108 in k7083 in k7077 in quotify-proc */
static void C_ccall f_7109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_7094(t2,C_i_not(t1));}

/* k7273 */
static void C_ccall f_7274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7274,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,3,lf[211],((C_word*)t0)[3],t1));}

/* k7111 in k7083 in k7077 in quotify-proc */
static void C_ccall f_7112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[2];
t3=C_u_i_car(t2);
/* chicken-syntax.scm:469: c */
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[4],t1,t3);}

/* k4204 */
static void C_ccall f_4205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4205,2,t0,t1);}
if(C_truep(C_i_memq(lf[13],*((C_word*)lf[14]+1)))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4220,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cadr(((C_word*)t0)[2]);
/* chicken-syntax.scm:1190: ##compiler#check-and-validate-type */
t4=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,lf[52]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_i_caddr(((C_word*)t0)[2]));}}

/* f_4202 in k3464 in k3462 in k3460 in k3458 in k3456 in k3454 in k3452 in k3450 in k3448 in k3446 in k3444 in k3442 in k3440 in k3438 in k3436 in k3434 in k3432 in k3430 in k3428 in k3426 in k3424 in ... */
static void C_ccall f_4202(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4202,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4205,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:1187: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[52],t2,lf[61]);}

/* k4199 in k3464 in k3462 in k3460 in k3458 in k3456 in k3454 in k3452 in k3450 in k3448 in k3446 in k3444 in k3442 in k3440 in k3438 in k3436 in k3434 in k3432 in k3430 in k3428 in k3426 in k3424 in ... */
static void C_ccall f_4200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:1183: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[52],C_SCHEME_END_OF_LIST,t1);}

/* k4002 */
static void C_ccall f_4003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4003,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=C_a_i_cons(&a,2,t1,t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_cons(&a,2,((C_word*)t0)[2],t5));}

/* map-loop417 in k8823 in k8687 in k8680 in k8670 in k8660 in k8652 */
static void C_fcall f_8775(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8775,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8803,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=t1,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t7=C_slot(t2,C_fix(0));
t8=C_slot(t3,C_fix(0));
/* chicken-syntax.scm:235: g423 */
t9=((C_word*)t0)[5];
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t6,t7,t8);}
else{
t6=((C_word*)((C_word*)t0)[4])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k8241 in k8230 in k8221 in k8211 in k8199 in k8196 in k8192 in k8190 in k8184 */
static void C_ccall f_8243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[38],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8243,2,t0,t1);}
t2=C_a_i_list(&a,2,((C_word*)t0)[2],C_SCHEME_FALSE);
t3=C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8276,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8278,a[2]=((C_word*)t0)[2],a[3]=((C_word)li126),tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8299,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8307,a[2]=t8,a[3]=t12,a[4]=t6,a[5]=t9,a[6]=((C_word)li127),tmp=(C_word)a,a+=7,tmp));
t14=((C_word*)t12)[1];
f_8307(t14,t10,((C_word*)t0)[7],((C_word*)t0)[8]);}

/* fold in k6992 */
static void C_fcall f_7002(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(14);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7002,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,lf[26],((C_word*)t0)[2]));}
else{
t3=C_i_car(t2);
t4=t2;
t5=C_u_i_cdr(t4);
if(C_truep(C_i_pairp(t3))){
t6=C_i_cdr(t3);
if(C_truep(C_i_nullp(t6))){
t7=C_u_i_car(t3);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7041,a[2]=t1,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:489: fold */
t16=t8;
t17=t5;
t1=t16;
t2=t17;
goto loop;}
else{
t7=C_u_i_car(t3);
t8=C_i_cadr(t3);
t9=C_a_i_list(&a,2,t7,t8);
t10=C_a_i_list(&a,1,t9);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7054,a[2]=t7,a[3]=t1,a[4]=t10,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:493: fold */
t16=t11;
t17=t5;
t1=t16;
t2=t17;
goto loop;}}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7027,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:488: fold */
t16=t6;
t17=t5;
t1=t16;
t2=t17;
goto loop;}}}

/* map-loop2297 in k3959 in k3948 */
static void C_fcall f_4011(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4011,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4036,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-syntax.scm:1196: g2303 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4219 in k4204 */
static void C_ccall f_4220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4220,2,t0,t1);}
t2=C_i_caddr(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_list(&a,4,lf[38],t1,C_SCHEME_TRUE,t2));}

/* k4236 */
static void C_ccall f_4237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4237,2,t0,t1);}
if(C_truep(C_i_memq(lf[13],*((C_word*)lf[14]+1)))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4245,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_caddr(((C_word*)t0)[2]);
/* chicken-syntax.scm:1170: ##sys#strip-syntax */
t4=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[68]);}}

/* f_4234 in k3462 in k3460 in k3458 in k3456 in k3454 in k3452 in k3450 in k3448 in k3446 in k3444 in k3442 in k3440 in k3438 in k3436 in k3434 in k3432 in k3430 in k3428 in k3426 in k3424 in k3422 in ... */
static void C_ccall f_4234(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4234,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4237,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:1167: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[62],t2,lf[69]);}

/* f_7268 in k7264 */
static void C_ccall f_7268(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7268,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7274,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:440: lookup */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k7264 */
static void C_ccall f_7266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7266,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7268,a[2]=((C_word*)t0)[2],a[3]=((C_word)li89),tmp=(C_word)a,a+=4,tmp);
t7=((C_word*)t0)[3];
t8=C_u_i_car(t7);
t9=C_i_check_list_2(t8,lf[28]);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7280,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7282,a[2]=t5,a[3]=t12,a[4]=t3,a[5]=t6,a[6]=((C_word)li90),tmp=(C_word)a,a+=7,tmp));
t14=((C_word*)t12)[1];
f_7282(t14,t10,t8);}

/* k4231 in k3462 in k3460 in k3458 in k3456 in k3454 in k3452 in k3450 in k3448 in k3446 in k3444 in k3442 in k3440 in k3438 in k3436 in k3434 in k3432 in k3430 in k3428 in k3426 in k3424 in k3422 in ... */
static void C_ccall f_4232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:1163: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[62],C_SCHEME_END_OF_LIST,t1);}

/* k4244 in k4236 */
static void C_ccall f_4245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4245,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4252,a[2]=t1,a[3]=t2,a[4]=((C_word)li20),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4260,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,a[5]=((C_word)li21),tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:1170: ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[3],t3,t4);}

/* k8705 in k8823 in k8687 in k8680 in k8670 in k8660 in k8652 */
static void C_ccall f_8706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8706,2,t0,t1);}
t2=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=C_a_i_cons(&a,2,lf[97],t2);
t4=C_a_i_list(&a,4,lf[232],((C_word*)t0)[2],((C_word*)t0)[3],t3);
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_list(&a,3,lf[30],((C_word*)t0)[5],t4));}

/* f_8708 in k8823 in k8687 in k8680 in k8670 in k8660 in k8652 */
static void C_ccall f_8708(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8708,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_list(&a,3,lf[211],t2,t3));}

/* map-loop1842 in k5251 in k5249 in k5245 in k5243 in k5233 */
static void C_fcall f_5497(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5497,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_car(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}
else{
t6=C_mutate(((C_word *)((C_word*)t0)[4])+1,t5);
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* map-loop453 in k8712 in k8823 in k8687 in k8680 in k8670 in k8660 in k8652 */
static void C_fcall f_8733(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8733,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8761,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=t1,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t7=C_slot(t2,C_fix(0));
t8=C_slot(t3,C_fix(0));
/* chicken-syntax.scm:237: g459 */
t9=((C_word*)t0)[5];
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t6,t7,t8);}
else{
t6=((C_word*)((C_word*)t0)[4])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k5491 in map-loop1871 in k5255 in k5251 in k5249 in k5245 in k5243 in k5233 */
static void C_ccall f_5492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5492,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_5467(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_5467(t6,((C_word*)t0)[5],t5);}}

/* k8760 in map-loop453 in k8712 in k8823 in k8687 in k8680 in k8670 in k8660 in k8652 */
static void C_ccall f_8761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8761,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8744,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t4=t3;
f_8744(t4,C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2));}
else{
t4=C_mutate(((C_word *)((C_word*)t0)[7])+1,t2);
t5=t3;
f_8744(t5,t4);}}

/* f_8719 in k8712 in k8823 in k8687 in k8680 in k8670 in k8660 in k8652 */
static void C_ccall f_8719(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8719,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_list(&a,3,lf[211],t2,t3));}

/* k8716 in k8712 in k8823 in k8687 in k8680 in k8670 in k8660 in k8652 */
static void C_ccall f_8717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:214: ##sys#append */
t2=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* k8712 in k8823 in k8687 in k8680 in k8670 in k8660 in k8652 */
static void C_ccall f_8714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8714,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8717,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8719,a[2]=((C_word)li140),tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8725,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8733,a[2]=t6,a[3]=t10,a[4]=t4,a[5]=t7,a[6]=((C_word)li141),tmp=(C_word)a,a+=7,tmp));
t12=((C_word*)t10)[1];
f_8733(t12,t8,((C_word*)t0)[3],((C_word*)t0)[4]);}

/* map-loop1871 in k5255 in k5251 in k5249 in k5245 in k5243 in k5233 */
static void C_fcall f_5467(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5467,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5492,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-syntax.scm:927: g1877 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5463 in k5255 in k5251 in k5249 in k5245 in k5243 in k5233 */
static void C_ccall f_5465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[62],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5465,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,lf[115],t2);
t4=C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[4],t3);
t5=C_a_i_list(&a,2,((C_word*)t0)[5],((C_word*)t0)[6]);
t6=C_a_i_list(&a,2,lf[113],((C_word*)t0)[7]);
t7=C_a_i_list(&a,3,lf[116],((C_word*)t0)[6],t6);
t8=C_a_i_list(&a,3,((C_word*)t0)[3],t5,t7);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5275,a[2]=t8,a[3]=t4,a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5277,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t11,a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word)li40),tmp=(C_word)a,a+=10,tmp));
t13=((C_word*)t11)[1];
f_5277(t13,t9,((C_word*)t0)[12],C_fix(1));}

/* k9412 in k9400 in k9381 */
static void C_fcall f_9414(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9414,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[2]);
t3=C_a_i_list(&a,2,t2,((C_word*)t0)[3]);
t4=C_a_i_list(&a,1,t3);
t5=C_a_i_cons(&a,2,t4,((C_word*)t0)[4]);
t6=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_cons(&a,2,lf[30],t5));}
else{
t2=C_a_i_list(&a,3,lf[97],C_SCHEME_END_OF_LIST,((C_word*)t0)[3]);
t3=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[4]);
t4=C_a_i_cons(&a,2,lf[97],t3);
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_list(&a,3,lf[141],t2,t4));}}

/* map-loop561 in k8196 in k8192 in k8190 in k8184 */
static void C_fcall f_8496(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8496,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_cadr(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}
else{
t6=C_mutate(((C_word *)((C_word*)t0)[4])+1,t5);
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8490 in map-loop588 in k8199 in k8196 in k8192 in k8190 in k8184 */
static void C_ccall f_8491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8491,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8466(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8466(t6,((C_word*)t0)[5],t5);}}

/* k8723 in k8712 in k8823 in k8687 in k8680 in k8670 in k8660 in k8652 */
static void C_ccall f_8725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8725,2,t0,t1);}
t2=C_a_i_list(&a,1,lf[223]);
t3=C_a_i_list(&a,1,t2);
/* chicken-syntax.scm:214: ##sys#append */
t4=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t1,t3);}

/* k4992 in loop in k4921 in k4919 in k4917 in k4915 */
static void C_ccall f_4994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4994,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4996,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5010,a[2]=((C_word*)t0)[8],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:1032: gensym */
t4=*((C_word*)lf[32]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5016,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=((C_word*)t0)[2];
t4=C_u_i_car(t3);
/* chicken-syntax.scm:1034: c */
t5=((C_word*)t0)[10];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,((C_word*)t0)[11],t4);}}

/* k9400 in k9381 */
static void C_ccall f_9401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9401,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=C_i_caddr(((C_word*)t0)[2]);
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
t6=C_u_i_cdr(t5);
t7=C_u_i_cdr(t6);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9414,a[2]=t2,a[3]=t3,a[4]=t7,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_pairp(t2))){
t9=C_u_i_cdr(t2);
t10=t8;
f_9414(t10,C_i_nullp(t9));}
else{
t9=t8;
f_9414(t9,C_SCHEME_FALSE);}}

/* k4995 in k4992 in loop in k4921 in k4919 in k4917 in k4915 */
static void C_ccall f_4996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4996,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=C_a_i_cons(&a,2,t1,((C_word*)t0)[3]);
t5=C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
/* chicken-syntax.scm:1033: loop */
t6=((C_word*)((C_word*)t0)[5])[1];
f_4929(t6,((C_word*)t0)[6],t3,t4,((C_word*)t0)[7],t5,C_SCHEME_FALSE);}

/* k4973 in k4939 in k4937 in loop in k4921 in k4919 in k4917 in k4915 */
static void C_ccall f_4974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:1024: r */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],t1);}

/* k6349 in loop in k6315 in k6313 in k6311 in k6309 in k6300 */
static void C_ccall f_6350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[76],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6350,2,t0,t1);}
t2=C_u_i_car(((C_word*)t0)[2]);
t3=C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]);
t4=C_i_cadr(((C_word*)t0)[2]);
t5=C_a_i_list(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t6=C_a_i_list(&a,4,lf[155],t3,t4,t5);
t7=C_a_i_list(&a,2,t2,t6);
t8=C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]);
t9=C_a_i_list(&a,2,lf[20],C_SCHEME_END_OF_LIST);
t10=C_a_i_list(&a,2,((C_word*)t0)[6],((C_word*)t0)[4]);
t11=C_a_i_list(&a,4,lf[155],t8,t9,t10);
t12=C_a_i_list(&a,2,t1,t11);
t13=C_a_i_list(&a,2,t7,t12);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6359,a[2]=((C_word*)t0)[7],a[3]=t13,tmp=(C_word)a,a+=4,tmp);
t15=((C_word*)t0)[8];
t16=C_u_i_cdr(t15);
/* chicken-syntax.scm:751: loop */
t17=((C_word*)((C_word*)t0)[9])[1];
f_6327(t17,t14,t1,t16);}

/* k6358 in k6349 in loop in k6315 in k6313 in k6311 in k6309 in k6300 */
static void C_ccall f_6359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6359,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,3,lf[30],((C_word*)t0)[3],t1));}

/* k3753 in k3824 in k3672 in k3670 in loop in k3654 in k3652 in k3650 in k3648 in k3645 in k3639 */
static void C_ccall f_3754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:1226: ##sys#put! */
t2=*((C_word*)lf[39]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],((C_word*)t0)[3],lf[40],t1);}

/* map-loop616 in k8211 in k8199 in k8196 in k8192 in k8190 in k8184 */
static void C_fcall f_8436(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8436,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8461,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-syntax.scm:287: g622 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8743 in k8760 in map-loop453 in k8712 in k8823 in k8687 in k8680 in k8670 in k8660 in k8652 */
static void C_fcall f_8744(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[3]);
t3=C_slot(((C_word*)t0)[4],C_fix(1));
t4=C_slot(((C_word*)t0)[5],C_fix(1));
t5=((C_word*)((C_word*)t0)[6])[1];
f_8733(t5,((C_word*)t0)[7],t3,t4);}

/* k9303 in k9297 in k9247 in a9243 in k3394 in k3392 in k3390 in k3388 in k3386 in k3384 in k3382 in k3379 */
static void C_ccall f_9305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
t3=((C_word*)t0)[3];
f_9257(t3,t2);}

/* k6324 in k6315 in k6313 in k6311 in k6309 in k6300 */
static void C_ccall f_6325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6325,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,3,lf[30],((C_word*)t0)[3],t1));}

/* loop in k6315 in k6313 in k6311 in k6309 in k6300 */
static void C_fcall f_6327(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6327,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t3))){
t4=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[2]);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_cons(&a,2,lf[30],t4));}
else{
t4=C_i_car(t3);
if(C_truep(C_i_pairp(t4))){
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6350,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,a[8]=t3,a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm:744: r */
t6=((C_word*)t0)[7];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[172]);}
else{
t5=C_a_i_list(&a,2,t4,t2);
t6=C_a_i_list(&a,1,t5);
t7=C_a_i_cons(&a,2,t6,((C_word*)t0)[2]);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_a_i_cons(&a,2,lf[30],t7));}}}

/* k9313 in k3392 in k3390 in k3388 in k3386 in k3384 in k3382 in k3379 */
static void C_ccall f_9314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:161: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[261],C_SCHEME_END_OF_LIST,t1);}

/* f_9316 in k3392 in k3390 in k3388 in k3386 in k3384 in k3382 in k3379 */
static void C_ccall f_9316(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9316,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9319,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:165: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[261],t2,lf[263]);}

/* k9318 */
static void C_ccall f_9319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9319,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_list(&a,2,lf[262],t2));}

/* k3701 in k3676 in k3824 in k3672 in k3670 in loop in k3654 in k3652 in k3650 in k3648 in k3645 in k3639 */
static void C_ccall f_3703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3703,2,t0,t1);}
t2=C_a_i_list(&a,3,lf[30],t1,((C_word*)t0)[2]);
t3=C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[4],t2);
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_list(&a,3,lf[26],((C_word*)t0)[6],t3));}

/* k8404 in map-loop646 in k8221 in k8211 in k8199 in k8196 in k8192 in k8190 in k8184 */
static void C_fcall f_8405(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[3]);
t3=C_slot(((C_word*)t0)[4],C_fix(1));
t4=C_slot(((C_word*)t0)[5],C_fix(1));
t5=((C_word*)((C_word*)t0)[6])[1];
f_8394(t5,((C_word*)t0)[7],t3,t4);}

/* k3715 in k3732 in map-loop2401 in k3676 in k3824 in k3672 in k3670 in loop in k3654 in k3652 in k3650 in k3648 in k3645 in k3639 */
static void C_fcall f_3716(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[3]);
t3=C_slot(((C_word*)t0)[4],C_fix(1));
t4=C_slot(((C_word*)t0)[5],C_fix(1));
t5=((C_word*)((C_word*)t0)[6])[1];
f_3705(t5,((C_word*)t0)[7],t3,t4);}

/* k9327 in k3390 in k3388 in k3386 in k3384 in k3382 in k3379 */
static void C_ccall f_9328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:155: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[264],C_SCHEME_END_OF_LIST,t1);}

/* k3732 in map-loop2401 in k3676 in k3824 in k3672 in k3670 in loop in k3654 in k3652 in k3650 in k3648 in k3645 in k3639 */
static void C_ccall f_3733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3733,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3716,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t4=t3;
f_3716(t4,C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2));}
else{
t4=C_mutate(((C_word *)((C_word*)t0)[7])+1,t2);
t5=t3;
f_3716(t5,t4);}}

/* map-loop2401 in k3676 in k3824 in k3672 in k3670 in loop in k3654 in k3652 in k3650 in k3648 in k3645 in k3639 */
static void C_fcall f_3705(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3705,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3733,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=t1,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t7=C_slot(t2,C_fix(0));
t8=C_slot(t3,C_fix(0));
/* chicken-syntax.scm:1246: g2407 */
t9=((C_word*)t0)[5];
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t6,t7,t8);}
else{
t6=((C_word*)((C_word*)t0)[4])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k9338 in k3388 in k3386 in k3384 in k3382 in k3379 */
static void C_ccall f_9339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:141: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[265],C_SCHEME_END_OF_LIST,t1);}

/* k8968 in map-loop311 in k8948 in k8944 in k8937 in k8680 in k8670 in k8660 in k8652 */
static void C_fcall f_8969(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[3]);
t3=C_slot(((C_word*)t0)[4],C_fix(1));
t4=C_slot(((C_word*)t0)[5],C_fix(1));
t5=((C_word*)((C_word*)t0)[6])[1];
f_8958(t5,((C_word*)t0)[7],t3,t4);}

/* f_9330 in k3390 in k3388 in k3386 in k3384 in k3382 in k3379 */
static void C_ccall f_9330(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9330,5,t0,t1,t2,t3,t4);}
t5=C_i_cdr(t2);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_cons(&a,2,lf[37],t5));}

/* k8211 in k8199 in k8196 in k8192 in k8190 in k8184 */
static void C_ccall f_8213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8213,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8214,a[2]=((C_word*)t0)[2],a[3]=((C_word)li125),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8223,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8436,a[2]=t5,a[3]=t9,a[4]=t3,a[5]=t6,a[6]=((C_word)li130),tmp=(C_word)a,a+=7,tmp));
t11=((C_word*)t9)[1];
f_8436(t11,t7,((C_word*)t0)[8]);}

/* f_8214 in k8211 in k8199 in k8196 in k8192 in k8190 in k8184 */
static void C_ccall f_8214(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8214,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8220,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:287: gensym */
t4=*((C_word*)lf[32]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k9343 */
static void C_ccall f_9344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[57],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9344,2,t0,t1);}
t2=C_a_i_list(&a,1,lf[266]);
t3=C_i_cdr(((C_word*)t0)[2]);
t4=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t3);
t5=C_a_i_cons(&a,2,lf[97],t4);
t6=C_a_i_list(&a,1,lf[267]);
t7=C_a_i_list(&a,2,lf[268],t6);
t8=C_a_i_list(&a,3,lf[139],lf[140],t1);
t9=C_a_i_list(&a,4,lf[97],t1,t7,t8);
t10=C_a_i_list(&a,3,lf[141],t5,t9);
t11=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_a_i_list(&a,3,lf[26],t2,t10));}

/* map-loop311 in k8948 in k8944 in k8937 in k8680 in k8670 in k8660 in k8652 */
static void C_fcall f_8958(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8958,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_a_i_list(&a,2,t6,t7);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8969,a[2]=((C_word*)t0)[2],a[3]=t9,a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t11=t10;
f_8969(t11,C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t9));}
else{
t11=C_mutate(((C_word *)((C_word*)t0)[4])+1,t9);
t12=t10;
f_8969(t12,t11);}}
else{
t6=((C_word*)((C_word*)t0)[4])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k8954 in k8948 in k8944 in k8937 in k8680 in k8670 in k8660 in k8652 */
static void C_ccall f_8956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:214: ##sys#append */
t2=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* f_9341 in k3388 in k3386 in k3384 in k3382 in k3379 */
static void C_ccall f_9341(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9341,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9344,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:145: r */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[233]);}

/* k8199 in k8196 in k8192 in k8190 in k8184 */
static void C_ccall f_8201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8201,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8202,a[2]=((C_word*)t0)[2],a[3]=((C_word)li124),tmp=(C_word)a,a+=4,tmp);
t7=C_i_check_list_2(((C_word*)t0)[3],lf[28]);
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8213,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[3],tmp=(C_word)a,a+=9,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8466,a[2]=t5,a[3]=t10,a[4]=t3,a[5]=t6,a[6]=((C_word)li131),tmp=(C_word)a,a+=7,tmp));
t12=((C_word*)t10)[1];
f_8466(t12,t8,((C_word*)t0)[3]);}

/* f_8202 in k8199 in k8196 in k8192 in k8190 in k8184 */
static void C_ccall f_8202(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8202,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8208,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_symbolp(t2))){
/* chicken-syntax.scm:277: gensym */
t4=*((C_word*)lf[32]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}
else{
/* chicken-syntax.scm:278: gensym */
t4=*((C_word*)lf[32]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[230]);}}

/* k8207 */
static void C_ccall f_8208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:286: r */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],t1);}

/* k8948 in k8944 in k8937 in k8680 in k8670 in k8660 in k8652 */
static void C_ccall f_8949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8949,2,t0,t1);}
t2=C_i_check_list_2(((C_word*)t0)[2],lf[28]);
t3=C_i_check_list_2(t1,lf[28]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8956,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8958,a[2]=((C_word*)t0)[5],a[3]=t6,a[4]=((C_word*)t0)[6],a[5]=((C_word)li147),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_8958(t8,t4,((C_word*)t0)[2],t1);}

/* k8944 in k8937 in k8680 in k8670 in k8660 in k8652 */
static void C_ccall f_8946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8946,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=*((C_word*)lf[231]+1);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8949,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t5,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t8=C_u_i_length(((C_word*)t0)[4]);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9002,a[2]=t10,a[3]=((C_word)li148),tmp=(C_word)a,a+=4,tmp));
t12=((C_word*)t10)[1];
f_9002(t12,t7,t8);}

/* k4953 in k4944 in k4939 in k4937 in loop in k4921 in k4919 in k4917 in k4915 */
static void C_ccall f_4954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4954,2,t0,t1);}
t2=C_i_car(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4966,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
t6=C_a_i_list(&a,1,((C_word*)t0)[6]);
/* chicken-syntax.scm:1024: ##sys#append */
t7=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t3,t5,t6);}

/* f_5786 in k5868 in k5871 in k3438 in k3436 in k3434 in k3432 in k3430 in k3428 in k3426 in k3424 in k3422 in k3420 in k3418 in k3416 in k3413 in k3410 in k3408 in k3406 in k3404 in k3402 in k3400 in ... */
static void C_ccall f_5786(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5786,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5789,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:853: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[132],t2,lf[144]);}

/* k5783 in k5868 in k5871 in k3438 in k3436 in k3434 in k3432 in k3430 in k3428 in k3426 in k3424 in k3422 in k3420 in k3418 in k3416 in k3413 in k3410 in k3408 in k3406 in k3404 in k3402 in k3400 in ... */
static void C_ccall f_5784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:847: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[132],((C_word*)t0)[3],t1);}

/* k5788 */
static void C_ccall f_5789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5789,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5791,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:854: r */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[143]);}

/* k4965 in k4953 in k4944 in k4939 in k4937 in loop in k4921 in k4919 in k4917 in k4915 */
static void C_ccall f_4966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4966,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=C_a_i_list(&a,3,lf[97],((C_word*)t0)[4],t3);
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_list(&a,3,lf[30],((C_word*)t0)[6],t4));}

/* k3759 in k3768 in k3824 in k3672 in k3670 in loop in k3654 in k3652 in k3650 in k3648 in k3645 in k3639 */
static void C_ccall f_3760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=t1;
/* chicken-syntax.scm:1228: ##sys#append */
t3=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],((C_word*)t0)[3],t2);}
else{
/* chicken-syntax.scm:1228: ##sys#append */
t2=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],C_SCHEME_END_OF_LIST);}}

/* k8922 in map-loop345 in k8687 in k8680 in k8670 in k8660 in k8652 */
static void C_ccall f_8923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8923,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8906,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t4=t3;
f_8906(t4,C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2));}
else{
t4=C_mutate(((C_word *)((C_word*)t0)[7])+1,t2);
t5=t3;
f_8906(t5,t4);}}

/* k5774 in k5777 in k3440 in k3438 in k3436 in k3434 in k3432 in k3430 in k3428 in k3426 in k3424 in k3422 in k3420 in k3418 in k3416 in k3413 in k3410 in k3408 in k3406 in k3404 in k3402 in k3400 in ... */
static void C_ccall f_5775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5775,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[126],t1);
t3=C_a_i_list(&a,2,((C_word*)t0)[2],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5537,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5539,a[2]=((C_word)li48),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:873: ##sys#er-transformer */
t6=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* k5777 in k3440 in k3438 in k3436 in k3434 in k3432 in k3430 in k3428 in k3426 in k3424 in k3422 in k3420 in k3418 in k3416 in k3413 in k3410 in k3408 in k3406 in k3404 in k3402 in k3400 in k3398 in ... */
static void C_ccall f_5778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5778,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[27],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5775,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:872: ##sys#primitive-alias */
t4=*((C_word*)lf[106]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[126]);}

/* f_3777 in k3824 in k3672 in k3670 in loop in k3654 in k3652 in k3650 in k3648 in k3645 in k3639 */
static void C_ccall f_3777(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3777,3,t0,t1,t2);}
t3=*((C_word*)lf[18]+1);
/* chicken-syntax.scm:1233: g2384 */
t4=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,lf[34]);}

/* k3812 in map-loop2361 in k3824 in k3672 in k3670 in loop in k3654 in k3652 in k3650 in k3648 in k3645 in k3639 */
static void C_ccall f_3813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3813,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_3788(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_3788(t6,((C_word*)t0)[5],t5);}}

/* recur in make-if-tree in k6494 */
static void C_fcall f_6575(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6575,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep(C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6588,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:643: reverse */
t6=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}
else{
t5=C_i_car(t2);
t6=C_a_i_list(&a,2,lf[170],((C_word*)t0)[3]);
t7=C_i_car(t3);
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6639,a[2]=t7,a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=t1,a[6]=t6,a[7]=t2,a[8]=t3,a[9]=t4,a[10]=((C_word*)t0)[4],a[11]=((C_word*)t0)[5],tmp=(C_word)a,a+=12,tmp);
/* chicken-syntax.scm:646: reverse */
t9=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t4);}}

/* k3768 in k3824 in k3672 in k3670 in loop in k3654 in k3652 in k3650 in k3648 in k3645 in k3639 */
static void C_fcall f_3769(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3769,NULL,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_list1(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3760,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:1239: ##compiler#variable-mark */
t5=*((C_word*)lf[42]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[4],lf[40]);}

/* k8905 in k8922 in map-loop345 in k8687 in k8680 in k8670 in k8660 in k8652 */
static void C_fcall f_8906(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[3]);
t3=C_slot(((C_word*)t0)[4],C_fix(1));
t4=C_slot(((C_word*)t0)[5],C_fix(1));
t5=((C_word*)((C_word*)t0)[6])[1];
f_8895(t5,((C_word*)t0)[7],t3,t4);}

/* k3842 in loop2 in k3672 in k3670 in loop in k3654 in k3652 in k3650 in k3648 in k3645 in k3639 */
static void C_ccall f_3843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3843,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* k5792 in k5790 in k5788 */
static void C_ccall f_5793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5793,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5802,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:856: r */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[137]);}

/* k5790 in k5788 */
static void C_ccall f_5791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5791,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5793,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:855: r */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[142]);}

/* k6587 in recur in make-if-tree in k6494 */
static void C_ccall f_6588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6588,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* loop2 in k3672 in k3670 in loop in k3654 in k3652 in k3650 in k3648 in k3645 in k3639 */
static void C_fcall f_3827(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3827,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=C_a_i_vector1(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3843,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=C_i_cdr(t2);
t7=C_fixnum_plus(t3,C_fix(1));
/* chicken-syntax.scm:1225: loop2 */
t9=t5;
t10=t6;
t11=t7;
t1=t9;
t2=t10;
t3=t11;
goto loop;}}

/* k3824 in k3672 in k3670 in loop in k3654 in k3652 in k3650 in k3648 in k3645 in k3639 */
static void C_ccall f_3825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[40],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3825,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3677,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3754,a[2]=t3,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3769,a[2]=((C_word*)t0)[5],a[3]=t4,a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t6=(C_truep(((C_word*)t0)[10])?C_i_pairp(((C_word*)t0)[10]):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3777,a[2]=((C_word)li6),tmp=(C_word)a,a+=3,tmp);
t12=((C_word*)t0)[10];
t13=C_i_check_list_2(t12,lf[28]);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3786,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t15=C_SCHEME_UNDEFINED;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_set_block_item(t16,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3788,a[2]=t10,a[3]=t16,a[4]=t8,a[5]=t11,a[6]=((C_word)li7),tmp=(C_word)a,a+=7,tmp));
t18=((C_word*)t16)[1];
f_3788(t18,t14,t12);}
else{
t7=t5;
f_3769(t7,C_a_i_list1(&a,1,t2));}}

/* k3784 in k3824 in k3672 in k3670 in loop in k3654 in k3652 in k3650 in k3648 in k3645 in k3639 */
static void C_ccall f_3786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3786,2,t0,t1);}
t2=((C_word*)t0)[2];
f_3769(t2,C_a_i_list2(&a,2,t1,((C_word*)t0)[3]));}

/* map-loop2361 in k3824 in k3672 in k3670 in loop in k3654 in k3652 in k3650 in k3648 in k3645 in k3639 */
static void C_fcall f_3788(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3788,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3813,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-syntax.scm:1233: g2367 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4173 in k4163 in k4152 in loop2224 in k4137 in k4132 in k4129 */
static void C_ccall f_4174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:1196: loop2224 */
t2=((C_word*)((C_word*)t0)[2])[1];
f_4147(t2,((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* k5310 in k5307 in k5301 in k5295 in k5291 in loop in k5463 in k5255 in k5251 in k5249 in k5245 in k5243 in k5233 */
static void C_ccall f_5311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:936: ##sys#append */
t2=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* k6283 in k6286 in k6289 in k3434 in k3432 in k3430 in k3428 in k3426 in k3424 in k3422 in k3420 in k3418 in k3416 in k3413 in k3410 in k3408 in k3406 in k3404 in k3402 in k3400 in k3398 in k3396 in ... */
static void C_ccall f_6284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6284,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[151],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6281,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:762: ##sys#primitive-alias */
t4=*((C_word*)lf[106]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[152]);}

/* k6286 in k6289 in k3434 in k3432 in k3430 in k3428 in k3426 in k3424 in k3422 in k3420 in k3418 in k3416 in k3413 in k3410 in k3408 in k3406 in k3404 in k3402 in k3400 in k3398 in k3396 in k3394 in ... */
static void C_ccall f_6287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6287,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[112],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6284,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:761: ##sys#primitive-alias */
t4=*((C_word*)lf[106]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[151]);}

/* k5304 in k5301 in k5295 in k5291 in loop in k5463 in k5255 in k5251 in k5249 in k5245 in k5243 in k5233 */
static void C_ccall f_5305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5305,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* k5307 in k5301 in k5295 in k5291 in loop in k5463 in k5255 in k5251 in k5249 in k5245 in k5243 in k5233 */
static void C_fcall f_5308(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5308,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5311,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[3];
t4=C_u_i_cdr(t3);
t5=C_fixnum_increase(((C_word*)t0)[4]);
/* chicken-syntax.scm:972: loop */
t6=((C_word*)((C_word*)t0)[5])[1];
f_5277(t6,t2,t4,t5);}

/* k6280 in k6283 in k6286 in k6289 in k3434 in k3432 in k3430 in k3428 in k3426 in k3424 in k3422 in k3420 in k3418 in k3416 in k3413 in k3410 in k3408 in k3406 in k3404 in k3402 in k3400 in k3398 in ... */
static void C_ccall f_6281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6281,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[152],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6278,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:763: ##sys#primitive-alias */
t4=*((C_word*)lf[106]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[153]);}

/* k9711 in k9528 in k9471 in k9469 in k9467 in k9465 in k9459 */
static void C_ccall f_9712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:82: string->symbol */
t2=*((C_word*)lf[178]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* map-loop25 in k9471 in k9469 in k9467 in k9465 in k9459 */
static void C_fcall f_9716(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9716,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9741,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-syntax.scm:68: g31 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5301 in k5295 in k5291 in loop in k5463 in k5255 in k5251 in k5249 in k5245 in k5243 in k5233 */
static void C_fcall f_5302(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5302,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5305,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5308,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[6])){
if(C_truep(((C_word*)t0)[7])){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5325,a[2]=t3,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t5=C_i_cadr(((C_word*)t0)[9]);
/* chicken-syntax.scm:967: c */
t6=((C_word*)t0)[10];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)t0)[7],t5);}
else{
t4=C_a_i_list(&a,3,((C_word*)t0)[11],((C_word*)t0)[12],((C_word*)t0)[8]);
t5=t3;
f_5308(t5,C_a_i_list(&a,1,t4));}}
else{
t4=t3;
f_5308(t4,C_SCHEME_END_OF_LIST);}}

/* f_6298 in k6413 in k3432 in k3430 in k3428 in k3426 in k3424 in k3422 in k3420 in k3418 in k3416 in k3413 in k3410 in k3408 in k3406 in k3404 in k3402 in k3400 in k3398 in k3396 in k3394 in k3392 in ... */
static void C_ccall f_6298(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6298,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6301,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:729: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[171],t2,lf[174]);}

/* k6295 in k6413 in k3432 in k3430 in k3428 in k3426 in k3424 in k3422 in k3420 in k3418 in k3416 in k3413 in k3410 in k3408 in k3406 in k3404 in k3402 in k3400 in k3398 in k3396 in k3394 in k3392 in ... */
static void C_ccall f_6296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:724: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[171],((C_word*)t0)[3],t1);}

/* k6289 in k3434 in k3432 in k3430 in k3428 in k3426 in k3424 in k3422 in k3420 in k3418 in k3416 in k3413 in k3410 in k3408 in k3406 in k3404 in k3402 in k3400 in k3398 in k3396 in k3394 in k3392 in ... */
static void C_ccall f_6290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6290,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[150],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6287,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:760: ##sys#primitive-alias */
t4=*((C_word*)lf[106]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[112]);}

/* k4152 in loop2224 in k4137 in k4132 in k4129 */
static void C_ccall f_4154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4154,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_eqp(((C_word*)t0)[3],C_SCHEME_END_OF_LIST));}
else{
t2=C_i_car(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4165,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_pairp(t2))){
t4=C_i_cdr(t2);
if(C_truep(C_i_pairp(t4))){
t5=C_i_cdr(t4);
t6=t3;
f_4165(t6,C_eqp(t5,C_SCHEME_END_OF_LIST));}
else{
t5=t3;
f_4165(t5,C_SCHEME_FALSE);}}
else{
t4=t3;
f_4165(t4,C_SCHEME_FALSE);}}}

/* k8937 in k8680 in k8670 in k8660 in k8652 */
static void C_ccall f_8939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8939,2,t0,t1);}
t2=C_i_check_list_2(((C_word*)t0)[2],lf[28]);
t3=C_i_check_list_2(t1,lf[28]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8946,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9020,a[2]=((C_word*)t0)[6],a[3]=t6,a[4]=((C_word*)t0)[7],a[5]=((C_word)li149),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_9020(t8,t4,((C_word*)t0)[2],t1);}

/* f_5624 in k5561 in k5559 in k5557 in parse-clause in k5551 in k5549 in k5547 in k5545 in k5543 in k5541 */
static void C_ccall f_5624(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5624,3,t0,t1,t2);}
t3=C_a_i_list(&a,2,lf[113],t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_list(&a,3,((C_word*)t0)[2],t3,((C_word*)t0)[3]));}

/* k4129 */
static void C_ccall f_4131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4131,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4133,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_car(((C_word*)t0)[2]);
/* chicken-syntax.scm:1196: ##sys#length */
t4=*((C_word*)lf[59]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t2=((C_word*)t0)[3];
f_4081(2,t2,C_SCHEME_FALSE);}}

/* k4163 in k4152 in loop2224 in k4137 in k4132 in k4129 */
static void C_fcall f_4165(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4165,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_cdr(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4174,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:1196: ##sys#+ */
t4=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[5],C_fix(-1));}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k9691 in k9696 in k9528 in k9471 in k9469 in k9467 in k9465 in k9459 */
static void C_ccall f_9692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:87: string->symbol */
t2=*((C_word*)lf[178]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k9696 in k9528 in k9471 in k9469 in k9467 in k9465 in k9459 */
static void C_ccall f_9697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9697,2,t0,t1);}
t2=C_a_i_list(&a,2,lf[113],((C_word*)t0)[2]);
t3=C_a_i_cons(&a,2,t2,((C_word*)t0)[3]);
t4=C_a_i_cons(&a,2,lf[115],t3);
t5=C_a_i_list(&a,3,lf[97],((C_word*)t0)[3],t4);
t6=C_a_i_list(&a,3,((C_word*)t0)[4],t1,t5);
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9677,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t6,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9692,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=((C_word*)t0)[7];
/* ##sys#string-append */
t10=*((C_word*)lf[278]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t8,t9,lf[279]);}

/* k6277 in k6280 in k6283 in k6286 in k6289 in k3434 in k3432 in k3430 in k3428 in k3426 in k3424 in k3422 in k3420 in k3418 in k3416 in k3413 in k3410 in k3408 in k3406 in k3404 in k3402 in k3400 in ... */
static void C_ccall f_6278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6278,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[153],t1);
t3=C_a_i_list(&a,5,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5933,a[2]=((C_word*)t0)[6],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5935,a[2]=((C_word)li62),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:764: ##sys#er-transformer */
t6=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* f_8036 in k8020 in k7985 */
static void C_ccall f_8036(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8036,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_list(&a,3,lf[211],t2,t3));}

/* k4939 in k4937 in loop in k4921 in k4919 in k4917 in k4915 */
static void C_ccall f_4940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4940,2,t0,t1);}
if(C_truep(((C_word*)t0)[2])){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4945,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4974,a[2]=((C_word*)t0)[7],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:1024: gensym */
t4=*((C_word*)lf[32]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=C_i_car(t1);
t3=t1;
t4=C_u_i_cdr(t3);
t5=C_a_i_cons(&a,2,t2,t4);
t6=C_a_i_list(&a,3,lf[97],((C_word*)t0)[6],t5);
t7=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_list(&a,3,lf[30],((C_word*)t0)[5],t6));}}

/* k4944 in k4939 in k4937 in loop in k4921 in k4919 in k4917 in k4915 */
static void C_ccall f_4945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4945,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4954,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:1024: ##sys#append */
t3=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[6],t1);}

/* k4937 in loop in k4921 in k4919 in k4917 in k4915 */
static void C_ccall f_4938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4938,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4940,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm:1022: reverse */
t3=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[7]);}

/* k9751 */
static void C_ccall f_9752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9752,2,t0,t1);}
t2=C_i_cdr(((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,lf[283],t2));}

/* k8020 in k7985 */
static void C_ccall f_8022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8022,2,t0,t1);}
t2=C_a_i_list(&a,3,lf[97],C_SCHEME_END_OF_LIST,((C_word*)t0)[2]);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8036,a[2]=((C_word)li118),tmp=(C_word)a,a+=3,tmp);
t8=C_i_check_list_2(t1,lf[28]);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8044,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8046,a[2]=t6,a[3]=t11,a[4]=t4,a[5]=t7,a[6]=((C_word)li119),tmp=(C_word)a,a+=7,tmp));
t13=((C_word*)t11)[1];
f_8046(t13,t9,((C_word*)t0)[4],t1);}

/* f_4913 in k5070 in k3446 in k3444 in k3442 in k3440 in k3438 in k3436 in k3434 in k3432 in k3430 in k3428 in k3426 in k3424 in k3422 in k3420 in k3418 in k3416 in k3413 in k3410 in k3408 in k3406 in ... */
static void C_ccall f_4913(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4913,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4916,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:1014: r */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[100]);}

/* k4915 */
static void C_ccall f_4916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4916,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4918,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:1015: r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[105]);}

/* k4910 in k5070 in k3446 in k3444 in k3442 in k3440 in k3438 in k3436 in k3434 in k3432 in k3430 in k3428 in k3426 in k3424 in k3422 in k3420 in k3418 in k3416 in k3413 in k3410 in k3408 in k3406 in ... */
static void C_ccall f_4911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:1009: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[101],((C_word*)t0)[3],t1);}

/* k3872 in loop in k3654 in k3652 in k3650 in k3648 in k3645 in k3639 */
static void C_fcall f_3874(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3874,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=C_i_car(((C_word*)t0)[3]);
t5=C_a_i_cons(&a,2,t4,((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3888,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t3,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
t7=C_i_cadr(((C_word*)t0)[3]);
/* chicken-syntax.scm:1259: ##compiler#check-and-validate-type */
t8=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,lf[34]);}
else{
/* chicken-syntax.scm:1263: syntax-error */
t2=*((C_word*)lf[45]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[7],lf[34],lf[46],((C_word*)t0)[3],((C_word*)t0)[8]);}}

/* k5661 in map-loop1762 in k5561 in k5559 in k5557 in parse-clause in k5551 in k5549 in k5547 in k5545 in k5543 in k5541 */
static void C_ccall f_5662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5662,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_5637(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_5637(t6,((C_word*)t0)[5],t5);}}

/* k4919 in k4917 in k4915 */
static void C_ccall f_4920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4920,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4922,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=C_i_cdr(((C_word*)t0)[2]);
if(C_truep(C_i_nullp(t3))){
/* chicken-syntax.scm:1018: syntax-error */
t4=*((C_word*)lf[45]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,lf[101],lf[103],((C_word*)t0)[2]);}
else{
t4=t2;
f_4922(2,t4,C_SCHEME_UNDEFINED);}}

/* k4921 in k4919 in k4917 in k4915 */
static void C_ccall f_4922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4922,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4929,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word)li35),tmp=(C_word)a,a+=10,tmp));
t7=((C_word*)t5)[1];
f_4929(t7,((C_word*)t0)[8],t3,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* k6513 in k6510 in k6685 in k6676 in k6674 in k6671 in k6668 in k6646 in k6642 in k6640 in k6494 */
static void C_ccall f_6514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6514,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6517,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:625: reverse */
t3=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k6510 in k6685 in k6676 in k6674 in k6671 in k6668 in k6646 in k6642 in k6640 in k6494 */
static void C_ccall f_6511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6511,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6514,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:624: reverse */
t3=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k4917 in k4915 */
static void C_ccall f_4918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4918,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4920,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm:1016: r */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[104]);}

/* recur in k6516 in k6513 in k6510 in k6685 in k6676 in k6674 in k6671 in k6668 in k6646 in k6642 in k6640 in k6494 */
static void C_fcall f_6519(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6519,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep(C_i_nullp(t2))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=C_i_cdr(t2);
t7=C_i_car(t3);
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6552,a[2]=t5,a[3]=t7,a[4]=t1,a[5]=t3,a[6]=t4,a[7]=((C_word*)t0)[2],a[8]=t6,tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm:630: reverse */
t9=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t6);}}

/* k6516 in k6513 in k6510 in k6685 in k6676 in k6674 in k6671 in k6668 in k6646 in k6642 in k6640 in k6494 */
static void C_ccall f_6517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6517,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6519,a[2]=t3,a[3]=((C_word)li71),tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_6519(t5,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],t1,((C_word*)t0)[5]);}

/* loop in k4921 in k4919 in k4917 in k4915 */
static void C_fcall f_4929(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4929,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
if(C_truep(C_i_nullp(t2))){
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4938,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t4,a[6]=((C_word*)t0)[3],a[7]=t5,tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm:1021: reverse */
t8=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t3);}
else{
t7=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4994,a[2]=t2,a[3]=t3,a[4]=t5,a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t4,a[8]=((C_word*)t0)[3],a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],tmp=(C_word)a,a+=12,tmp);
t8=C_i_car(t2);
/* chicken-syntax.scm:1031: c */
t9=((C_word*)t0)[6];
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,((C_word*)t0)[8],t8);}}

/* k6536 in k6557 in k6551 in recur in k6516 in k6513 in k6510 in k6685 in k6676 in k6674 in k6671 in k6668 in k6646 in k6642 in k6640 in k6494 */
static void C_ccall f_6537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6537,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* k3887 in k3872 in loop in k3654 in k3652 in k3650 in k3648 in k3645 in k3639 */
static void C_ccall f_3888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3888,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[2]);
/* chicken-syntax.scm:1255: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3662(t3,((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6],t2);}

/* k5633 in k5561 in k5559 in k5557 in parse-clause in k5551 in k5549 in k5547 in k5545 in k5543 in k5541 */
static void C_ccall f_5635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5635,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
if(C_truep(((C_word*)t0)[4])){
t4=C_a_i_list(&a,2,((C_word*)t0)[4],((C_word*)t0)[5]);
t5=C_a_i_list(&a,1,t4);
t6=C_a_i_cons(&a,2,t5,((C_word*)t0)[6]);
t7=C_a_i_cons(&a,2,lf[30],t6);
t8=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_a_i_list(&a,2,t3,t7));}
else{
t4=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,((C_word*)t0)[6]);
t5=C_a_i_cons(&a,2,lf[30],t4);
t6=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_list(&a,2,t3,t5));}}

/* loop in k7615 in k7601 in k7598 in k7529 */
static void C_fcall f_7794(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7794,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
/* chicken-syntax.scm:386: reverse */
t4=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t4=C_i_car(t2);
if(C_truep(C_i_pairp(t4))){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7828,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:390: map* */
t6=((C_word*)((C_word*)t0)[3])[1];
f_7562(t6,t5,((C_word*)t0)[4],t4);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7822,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:389: lookup */
t6=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}}}

/* map-loop1762 in k5561 in k5559 in k5557 in parse-clause in k5551 in k5549 in k5547 in k5545 in k5543 in k5541 */
static void C_fcall f_5637(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5637,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5662,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-syntax.scm:890: g1768 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7788 in map-loop1010 in k7625 in k7615 in k7601 in k7598 in k7529 */
static void C_ccall f_7789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7789,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7764(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7764(t6,((C_word*)t0)[5],t5);}}

/* k6300 */
static void C_ccall f_6301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6301,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=C_i_caddr(((C_word*)t0)[2]);
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
t6=C_u_i_cdr(t5);
t7=C_u_i_cdr(t6);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6310,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t7,a[5]=((C_word*)t0)[4],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:733: r */
t9=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,lf[170]);}

/* k6551 in recur in k6516 in k6513 in k6510 in k6685 in k6676 in k6674 in k6671 in k6668 in k6646 in k6642 in k6640 in k6494 */
static void C_ccall f_6552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6552,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6558,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6561,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:631: reverse */
t4=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[8]);}

/* parse-clause in k5551 in k5549 in k5547 in k5545 in k5543 in k5541 */
static void C_fcall f_5554(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5554,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5558,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t4=C_i_car(t2);
if(C_truep(C_i_symbolp(t4))){
t5=t2;
t6=t3;
f_5558(t6,C_u_i_car(t5));}
else{
t5=t3;
f_5558(t5,C_SCHEME_FALSE);}}

/* k5551 in k5549 in k5547 in k5545 in k5543 in k5541 */
static void C_ccall f_5552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5552,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5554,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word)li46),tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5686,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=t2,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm:894: r */
t4=((C_word*)t0)[8];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[132]);}

/* k5557 in parse-clause in k5551 in k5549 in k5547 in k5545 in k5543 in k5541 */
static void C_fcall f_5558(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5558,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5560,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t1)){
t3=t2;
f_5560(t3,C_i_cadr(((C_word*)t0)[8]));}
else{
t3=((C_word*)t0)[8];
t4=t2;
f_5560(t4,C_u_i_car(t3));}}

/* k5549 in k5547 in k5545 in k5543 in k5541 */
static void C_ccall f_5550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5550,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5552,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm:880: r */
t3=((C_word*)t0)[7];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[27]);}

/* k6557 in k6551 in recur in k6516 in k6513 in k6510 in k6685 in k6676 in k6674 in k6671 in k6668 in k6646 in k6642 in k6640 in k6494 */
static void C_ccall f_6558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6558,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_list(&a,3,lf[97],((C_word*)t0)[3],t2);
t4=C_a_i_list(&a,2,((C_word*)t0)[4],t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6537,a[2]=((C_word*)t0)[5],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=((C_word*)t0)[6];
t7=C_u_i_cdr(t6);
t8=((C_word*)t0)[7];
t9=C_u_i_cdr(t8);
t10=((C_word*)t0)[6];
t11=C_u_i_car(t10);
/* chicken-syntax.scm:632: recur */
t12=((C_word*)((C_word*)t0)[8])[1];
f_6519(t12,t5,((C_word*)t0)[9],t7,t9,t11);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_chicken_2dsyntax_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_chicken_2dsyntax_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("chicken_2dsyntax_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(3864)){
C_save(t1);
C_rereclaim2(3864*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,289);
lf[0]=C_h_intern(&lf[0],28,"\003sysdefine-values-definition");
lf[1]=C_h_intern(&lf[1],29,"\003syschicken-macro-environment");
lf[2]=C_h_intern(&lf[2],17,"register-feature!");
lf[3]=C_h_intern(&lf[3],6,"srfi-8");
lf[4]=C_h_intern(&lf[4],7,"srfi-11");
lf[5]=C_h_intern(&lf[5],7,"srfi-15");
lf[6]=C_h_intern(&lf[6],7,"srfi-16");
lf[7]=C_h_intern(&lf[7],7,"srfi-26");
lf[8]=C_h_intern(&lf[8],7,"srfi-31");
lf[9]=C_h_intern(&lf[9],16,"\003sysmacro-subset");
lf[10]=C_h_intern(&lf[10],29,"\003sysdefault-macro-environment");
lf[11]=C_h_intern(&lf[11],28,"\003sysextend-macro-environment");
lf[12]=C_h_intern(&lf[12],11,"define-type");
lf[13]=C_h_intern(&lf[13],10,"\000compiling");
lf[14]=C_h_intern(&lf[14],12,"\003sysfeatures");
lf[15]=C_h_intern(&lf[15],26,"\010compilertype-abbreviation");
lf[16]=C_h_intern(&lf[16],16,"\003sysput/restore!");
lf[17]=C_h_intern(&lf[17],24,"\004coreelaborationtimeonly");
lf[18]=C_h_intern(&lf[18],32,"\010compilercheck-and-validate-type");
lf[19]=C_h_intern(&lf[19],16,"\003sysstrip-syntax");
lf[20]=C_h_intern(&lf[20],5,"quote");
lf[21]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[22]=C_h_intern(&lf[22],16,"\003syscheck-syntax");
lf[23]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[24]=C_h_intern(&lf[24],18,"\003syser-transformer");
lf[25]=C_h_intern(&lf[25],17,"compiler-typecase");
lf[26]=C_h_intern(&lf[26],10,"\004corebegin");
lf[27]=C_h_intern(&lf[27],4,"else");
lf[28]=C_h_intern(&lf[28],3,"map");
lf[29]=C_h_intern(&lf[29],13,"\004coretypecase");
lf[30]=C_h_intern(&lf[30],8,"\004corelet");
lf[31]=C_h_intern(&lf[31],15,"get-line-number");
lf[32]=C_h_intern(&lf[32],6,"gensym");
lf[33]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001\376\377\001\000\000\000\001");
lf[34]=C_h_intern(&lf[34],21,"define-specialization");
lf[35]=C_h_intern(&lf[35],6,"inline");
lf[36]=C_h_intern(&lf[36],4,"hide");
lf[37]=C_h_intern(&lf[37],12,"\004coredeclare");
lf[38]=C_h_intern(&lf[38],8,"\004corethe");
lf[39]=C_h_intern(&lf[39],8,"\003sysput!");
lf[40]=C_h_intern(&lf[40],30,"\010compilerlocal-specializations");
lf[41]=C_h_intern(&lf[41],10,"\003sysappend");
lf[42]=C_h_intern(&lf[42],22,"\010compilervariable-mark");
lf[43]=C_h_intern(&lf[43],7,"reverse");
lf[44]=C_h_intern(&lf[44],1,"\052");
lf[45]=C_h_intern(&lf[45],12,"syntax-error");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\027invalid argument syntax");
lf[47]=C_h_intern(&lf[47],6,"define");
lf[48]=C_h_intern(&lf[48],13,"\003sysglobalize");
lf[49]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000"
"\000\376\377\001\000\000\000\001");
lf[50]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[51]=C_h_intern(&lf[51],6,"assume");
lf[52]=C_h_intern(&lf[52],3,"the");
lf[53]=C_h_intern(&lf[53],9,"\003sysmap-n");
lf[54]=C_h_intern(&lf[54],3,"let");
lf[55]=C_h_intern(&lf[55],25,"\003syssyntax-rules-mismatch");
lf[56]=C_h_intern(&lf[56],5,"\003sys+");
lf[57]=C_h_intern(&lf[57],5,"\003sys=");
lf[58]=C_h_intern(&lf[58],6,"\003sys>=");
lf[59]=C_h_intern(&lf[59],10,"\003syslength");
lf[60]=C_h_intern(&lf[60],9,"\003syslist\077");
lf[61]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[62]=C_h_intern(&lf[62],1,":");
lf[63]=C_h_intern(&lf[63],22,"\010compilervalidate-type");
lf[64]=C_h_intern(&lf[64],4,"type");
lf[65]=C_h_intern(&lf[65],9,"predicate");
lf[66]=C_h_intern(&lf[66],4,"pure");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid type syntax");
lf[68]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[69]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[70]=C_h_intern(&lf[70],7,"functor");
lf[71]=C_h_intern(&lf[71],20,"\003sysvalidate-exports");
lf[72]=C_h_intern(&lf[72],20,"\003sysregister-functor");
lf[73]=C_h_intern(&lf[73],6,"import");
lf[74]=C_h_intern(&lf[74],6,"scheme");
lf[75]=C_h_intern(&lf[75],7,"chicken");
lf[76]=C_h_intern(&lf[76],16,"begin-for-syntax");
lf[77]=C_h_intern(&lf[77],11,"\004coremodule");
lf[78]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\003\000\000\002\376"
"\001\000\000\001_\376\001\000\000\001_");
lf[79]=C_h_intern(&lf[79],16,"define-interface");
lf[80]=C_h_intern(&lf[80],14,"\004coreinterface");
lf[81]=C_h_intern(&lf[81],10,"\000interface");
lf[82]=C_h_intern(&lf[82],17,"syntax-error-hook");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000\017invalid exports");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000-`\052\047 is not allowed as a name for an interface");
lf[85]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[86]=C_h_intern(&lf[86],19,"let-compiler-syntax");
lf[87]=C_h_intern(&lf[87],24,"\004corelet-compiler-syntax");
lf[88]=C_h_intern(&lf[88],22,"define-compiler-syntax");
lf[89]=C_h_intern(&lf[89],27,"\004coredefine-compiler-syntax");
lf[90]=C_h_intern(&lf[90],6,"lambda");
lf[91]=C_h_intern(&lf[91],3,"use");
lf[92]=C_h_intern(&lf[92],22,"\004corerequire-extension");
lf[93]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[94]=C_h_intern(&lf[94],17,"define-for-syntax");
lf[95]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[96]=C_h_intern(&lf[96],3,"rec");
lf[97]=C_h_intern(&lf[97],11,"\004corelambda");
lf[98]=C_h_intern(&lf[98],11,"\004coreletrec");
lf[99]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[100]=C_h_intern(&lf[100],5,"apply");
lf[101]=C_h_intern(&lf[101],4,"cute");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000+tail patterns after <...> are not supported");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\047you need to supply at least a procedure");
lf[104]=C_h_intern(&lf[104],5,"<...>");
lf[105]=C_h_intern(&lf[105],2,"<>");
lf[106]=C_h_intern(&lf[106],19,"\003sysprimitive-alias");
lf[107]=C_h_intern(&lf[107],3,"cut");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000+tail patterns after <...> are not supported");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\047you need to supply at least a procedure");
lf[110]=C_h_intern(&lf[110],18,"getter-with-setter");
lf[111]=C_h_intern(&lf[111],18,"define-record-type");
lf[112]=C_h_intern(&lf[112],3,"car");
lf[113]=C_h_intern(&lf[113],10,"\004corequote");
lf[114]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[115]=C_h_intern(&lf[115],18,"\003sysmake-structure");
lf[116]=C_h_intern(&lf[116],14,"\003sysstructure\077");
lf[117]=C_h_intern(&lf[117],19,"\003syscheck-structure");
lf[118]=C_h_intern(&lf[118],10,"\004corecheck");
lf[119]=C_h_intern(&lf[119],13,"\003sysblock-ref");
lf[120]=C_h_intern(&lf[120],10,"\003syssetter");
lf[121]=C_h_intern(&lf[121],14,"\003sysblock-set!");
lf[122]=C_h_intern(&lf[122],6,"setter");
lf[123]=C_h_intern(&lf[123],1,"y");
lf[124]=C_h_intern(&lf[124],1,"x");
lf[125]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\000\000\000\002\376\001\000\000\010variable\376\377\001\000\000\000\001\376\003\000\000\002\376\001\000\000\010variable\376\001\000"
"\000\001_");
lf[126]=C_h_intern(&lf[126],4,"memv");
lf[127]=C_h_intern(&lf[127],14,"condition-case");
lf[128]=C_h_intern(&lf[128],9,"condition");
lf[129]=C_h_intern(&lf[129],8,"\003sysslot");
lf[130]=C_h_intern(&lf[130],10,"\003syssignal");
lf[131]=C_h_intern(&lf[131],4,"cond");
lf[132]=C_h_intern(&lf[132],17,"handle-exceptions");
lf[133]=C_h_intern(&lf[133],3,"and");
lf[134]=C_h_intern(&lf[134],4,"kvar");
lf[135]=C_h_intern(&lf[135],5,"exvar");
lf[136]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[137]=C_h_intern(&lf[137],30,"call-with-current-continuation");
lf[138]=C_h_intern(&lf[138],22,"with-exception-handler");
lf[139]=C_h_intern(&lf[139],9,"\003sysapply");
lf[140]=C_h_intern(&lf[140],10,"\003sysvalues");
lf[141]=C_h_intern(&lf[141],20,"\003syscall-with-values");
lf[142]=C_h_intern(&lf[142],4,"args");
lf[143]=C_h_intern(&lf[143],1,"k");
lf[144]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[145]=C_h_intern(&lf[145],21,"define-record-printer");
lf[146]=C_h_intern(&lf[146],27,"\003sysregister-record-printer");
lf[147]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\006symbol\376\377\016\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[148]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[149]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[150]=C_h_intern(&lf[150],2,">=");
lf[151]=C_h_intern(&lf[151],3,"cdr");
lf[152]=C_h_intern(&lf[152],3,"eq\077");
lf[153]=C_h_intern(&lf[153],6,"length");
lf[154]=C_h_intern(&lf[154],11,"case-lambda");
lf[155]=C_h_intern(&lf[155],7,"\004coreif");
lf[156]=C_h_intern(&lf[156],9,"split-at!");
lf[157]=C_h_intern(&lf[157],4,"take");
lf[158]=C_h_intern(&lf[158],4,"list");
lf[159]=C_h_intern(&lf[159],11,"lambda-list");
lf[160]=C_h_intern(&lf[160],25,"\003sysdecompose-lambda-list");
lf[161]=C_h_intern(&lf[161],10,"fold-right");
lf[162]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\012\004corecheck\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011\003syserror\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016\004coreimmutable\376\003\000\000\002\376\003"
"\000\000\002\376\001\000\000\012\004corequote\376\003\000\000\002\376B\000\0000no matching clause in call to \047case-lambda\047 form\376\377\016\376"
"\377\016\376\377\016\376\377\016");
lf[163]=C_h_intern(&lf[163],6,"append");
lf[164]=C_h_intern(&lf[164],4,"lvar");
lf[165]=C_h_intern(&lf[165],4,"rvar");
lf[166]=C_h_intern(&lf[166],3,"min");
lf[167]=C_h_intern(&lf[167],7,"require");
lf[168]=C_h_intern(&lf[168],6,"srfi-1");
lf[169]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[170]=C_h_intern(&lf[170],5,"null\077");
lf[171]=C_h_intern(&lf[171],14,"let-optionals\052");
lf[172]=C_h_intern(&lf[172],4,"tmp2");
lf[173]=C_h_intern(&lf[173],3,"tmp");
lf[174]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\004list\376\001\000\000\001_");
lf[175]=C_h_intern(&lf[175],8,"optional");
lf[176]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\001");
lf[177]=C_h_intern(&lf[177],13,"let-optionals");
lf[178]=C_h_intern(&lf[178],14,"string->symbol");
lf[179]=C_h_intern(&lf[179],13,"string-append");
lf[180]=C_h_intern(&lf[180],14,"symbol->string");
lf[181]=C_decode_literal(C_heaptop,"\376B\000\000\001%");
lf[182]=C_h_intern(&lf[182],4,"cadr");
lf[183]=C_decode_literal(C_heaptop,"\376B\000\000\004def-");
lf[184]=C_h_intern(&lf[184],4,"let\052");
lf[185]=C_h_intern(&lf[185],6,"_%rest");
lf[186]=C_h_intern(&lf[186],4,"body");
lf[187]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[188]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000");
lf[189]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[190]=C_h_intern(&lf[190],6,"select");
lf[191]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[192]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\012\004corebegin\376\377\016");
lf[193]=C_h_intern(&lf[193],10,"\003sysnotice");
lf[194]=C_decode_literal(C_heaptop,"\376B\000\0005non-`else\047 clause following `else\047 clause in `select\047");
lf[195]=C_h_intern(&lf[195],8,"\003syseqv\077");
lf[196]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\000\016invalid syntax");
lf[198]=C_h_intern(&lf[198],2,"or");
lf[199]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[200]=C_h_intern(&lf[200],8,"and-let\052");
lf[201]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\001\000\000\001_");
lf[202]=C_h_intern(&lf[202],13,"define-inline");
lf[203]=C_decode_literal(C_heaptop,"\376B\000\000\052invalid substitution form - must be lambda");
lf[204]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[205]=C_h_intern(&lf[205],18,"\004coredefine-inline");
lf[206]=C_h_intern(&lf[206],8,"list-ref");
lf[207]=C_h_intern(&lf[207],9,"nth-value");
lf[208]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[209]=C_h_intern(&lf[209],13,"letrec-values");
lf[210]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[211]=C_h_intern(&lf[211],9,"\004coreset!");
lf[212]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\004list\376\001\000\000\001_");
lf[213]=C_h_intern(&lf[213],11,"let\052-values");
lf[214]=C_h_intern(&lf[214],10,"let-values");
lf[215]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\004list\376\001\000\000\001_");
lf[216]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\004list\376\001\000\000\001_");
lf[217]=C_h_intern(&lf[217],13,"define-values");
lf[218]=C_h_intern(&lf[218],19,"\003sysregister-export");
lf[219]=C_h_intern(&lf[219],18,"\003syscurrent-module");
lf[220]=C_h_intern(&lf[220],8,"for-each");
lf[221]=C_h_intern(&lf[221],11,"set!-values");
lf[222]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\001\000\000\010variable\376\377\001\000\000\000\000\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[223]=C_h_intern(&lf[223],14,"\004coreundefined");
lf[224]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\001\000\000\010variable\376\377\001\000\000\000\000\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[225]=C_h_intern(&lf[225],6,"unless");
lf[226]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[227]=C_h_intern(&lf[227],4,"when");
lf[228]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[229]=C_h_intern(&lf[229],12,"parameterize");
lf[230]=C_decode_literal(C_heaptop,"\376B\000\000\011parameter");
lf[231]=C_h_intern(&lf[231],8,"\003syslist");
lf[232]=C_h_intern(&lf[232],16,"\003sysdynamic-wind");
lf[233]=C_h_intern(&lf[233],1,"t");
lf[234]=C_h_intern(&lf[234],4,"mode");
lf[235]=C_h_intern(&lf[235],4,"swap");
lf[236]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[237]=C_h_intern(&lf[237],9,"eval-when");
lf[238]=C_h_intern(&lf[238],19,"\004corecompiletimetoo");
lf[239]=C_h_intern(&lf[239],20,"\004corecompiletimeonly");
lf[240]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[241]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[242]=C_h_intern(&lf[242],9,"\003syserror");
lf[243]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid situation specifier");
lf[244]=C_h_intern(&lf[244],4,"load");
lf[245]=C_h_intern(&lf[245],7,"compile");
lf[246]=C_h_intern(&lf[246],4,"eval");
lf[247]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[248]=C_h_intern(&lf[248],9,"fluid-let");
lf[249]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\001\000\000\001_");
lf[250]=C_h_intern(&lf[250],6,"ensure");
lf[251]=C_h_intern(&lf[251],15,"\003syssignal-hook");
lf[252]=C_h_intern(&lf[252],11,"\000type-error");
lf[253]=C_decode_literal(C_heaptop,"\376B\000\000\033argument has incorrect type");
lf[254]=C_h_intern(&lf[254],14,"\004coreimmutable");
lf[255]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\003");
lf[256]=C_h_intern(&lf[256],6,"assert");
lf[257]=C_decode_literal(C_heaptop,"\376B\000\000\020assertion failed");
lf[258]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[259]=C_decode_literal(C_heaptop,"\376B\000\000\002) ");
lf[260]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[261]=C_h_intern(&lf[261],7,"include");
lf[262]=C_h_intern(&lf[262],12,"\004coreinclude");
lf[263]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006string\376\377\016");
lf[264]=C_h_intern(&lf[264],7,"declare");
lf[265]=C_h_intern(&lf[265],4,"time");
lf[266]=C_h_intern(&lf[266],15,"\003sysstart-timer");
lf[267]=C_h_intern(&lf[267],14,"\003sysstop-timer");
lf[268]=C_h_intern(&lf[268],17,"\003sysdisplay-times");
lf[269]=C_h_intern(&lf[269],7,"receive");
lf[270]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\013lambda-list\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[271]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[272]=C_h_intern(&lf[272],13,"define-record");
lf[273]=C_decode_literal(C_heaptop,"\376B\000\000\032invalid slot specification");
lf[274]=C_h_intern(&lf[274],3,"val");
lf[275]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[276]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[277]=C_decode_literal(C_heaptop,"\376B\000\000\005-set!");
lf[278]=C_h_intern(&lf[278],17,"\003sysstring-append");
lf[279]=C_decode_literal(C_heaptop,"\376B\000\000\001\077");
lf[280]=C_decode_literal(C_heaptop,"\376B\000\000\005make-");
lf[281]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\001\000\000\001_");
lf[282]=C_h_intern(&lf[282],15,"define-constant");
lf[283]=C_h_intern(&lf[283],20,"\004coredefine-constant");
lf[284]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[285]=C_h_intern(&lf[285],21,"\003sysmacro-environment");
lf[286]=C_h_intern(&lf[286],11,"\003sysprovide");
lf[287]=C_h_intern(&lf[287],19,"chicken-more-macros");
lf[288]=C_h_intern(&lf[288],14,"chicken-syntax");
C_register_lf2(lf,289,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3380,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:38: ##sys#provide */
t3=*((C_word*)lf[286]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[287],lf[288]);}

/* k6309 in k6300 */
static void C_ccall f_6310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6310,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6312,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm:734: r */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[112]);}

/* k6311 in k6309 in k6300 */
static void C_ccall f_6312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6312,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6314,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm:735: r */
t3=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[151]);}

/* k6313 in k6311 in k6309 in k6300 */
static void C_ccall f_6314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6314,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6316,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm:736: r */
t3=((C_word*)t0)[7];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[173]);}

/* k6315 in k6313 in k6311 in k6309 in k6300 */
static void C_ccall f_6316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6316,2,t0,t1);}
t2=C_a_i_list(&a,2,t1,((C_word*)t0)[2]);
t3=C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6325,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6327,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t6,a[7]=((C_word*)t0)[8],a[8]=((C_word)li63),tmp=(C_word)a,a+=9,tmp));
t8=((C_word*)t6)[1];
f_6327(t8,t4,t1,((C_word*)t0)[9]);}

/* k6560 in k6551 in recur in k6516 in k6513 in k6510 in k6685 in k6676 in k6674 in k6671 in k6668 in k6646 in k6642 in k6640 in k6494 */
static void C_ccall f_6561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6561,2,t0,t1);}
t2=C_i_car(((C_word*)t0)[2]);
t3=C_a_i_list(&a,1,t2);
/* chicken-syntax.scm:628: ##sys#append */
t4=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[3],t1,t3);}

/* k5541 */
static void C_ccall f_5542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5542,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5544,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:876: r */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[135]);}

/* k4708 in k4648 in k4628 */
static void C_fcall f_4710(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4710,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[2]);
t3=C_i_cdr(((C_word*)t0)[2]);
t4=C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4720,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:1089: rename2029 */
t6=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[89]);}
else{
/* chicken-syntax.scm:1089: ##sys#syntax-rules-mismatch */
t2=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[5]);}}

/* k5543 in k5541 */
static void C_ccall f_5544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5544,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5546,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:877: r */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[134]);}

/* k5545 in k5543 in k5541 */
static void C_ccall f_5546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5546,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5548,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:878: r */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[133]);}

/* k5547 in k5545 in k5543 in k5541 */
static void C_ccall f_5548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5548,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5550,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm:879: r */
t3=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[126]);}

/* make-if-tree in k6494 */
static void C_fcall f_6569(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6569,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6575,a[2]=t4,a[3]=t5,a[4]=t7,a[5]=((C_word*)t0)[2],a[6]=((C_word)li66),tmp=(C_word)a,a+=7,tmp));
t9=((C_word*)t7)[1];
f_6575(t9,t1,t2,t3,C_SCHEME_END_OF_LIST);}

/* k4719 in k4708 in k4648 in k4628 */
static void C_ccall f_4720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4720,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,t1,t3));}

/* k7857 in map-loop926 in k7601 in k7598 in k7529 */
static void C_ccall f_7858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7858,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7833(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7833(t6,((C_word*)t0)[5],t5);}}

/* k5561 in k5559 in k5557 in parse-clause in k5551 in k5549 in k5547 in k5545 in k5543 in k5541 */
static void C_fcall f_5562(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5562,NULL,2,t0,t1);}
if(C_truep(C_i_nullp(((C_word*)t0)[2]))){
if(C_truep(((C_word*)t0)[3])){
t2=C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]);
t3=C_a_i_list(&a,1,t2);
t4=C_a_i_cons(&a,2,t3,t1);
t5=C_a_i_cons(&a,2,lf[30],t4);
t6=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_list(&a,2,((C_word*)t0)[6],t5));}
else{
t2=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=C_a_i_cons(&a,2,lf[30],t2);
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_list(&a,2,((C_word*)t0)[6],t3));}}
else{
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5624,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word)li44),tmp=(C_word)a,a+=5,tmp);
t7=((C_word*)t0)[2];
t8=C_i_check_list_2(t7,lf[28]);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5635,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5637,a[2]=t5,a[3]=t11,a[4]=t3,a[5]=t6,a[6]=((C_word)li45),tmp=(C_word)a,a+=7,tmp));
t13=((C_word*)t11)[1];
f_5637(t13,t9,t7);}}

/* loop in k7598 in k7529 */
static void C_fcall f_7863(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7863,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
t4=t3;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7874,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_listp(t4))){
/* chicken-syntax.scm:378: append */
t6=*((C_word*)lf[163]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t4,t3);}
else{
if(C_truep(C_i_pairp(t4))){
/* chicken-syntax.scm:379: append* */
t6=((C_word*)((C_word*)t0)[3])[1];
f_7536(t6,t5,t4,t3);}
else{
t6=C_a_i_cons(&a,2,t4,t3);
t7=t2;
t8=C_u_i_cdr(t7);
/* chicken-syntax.scm:381: loop */
t11=t1;
t12=t8;
t13=t6;
t1=t11;
t2=t12;
t3=t13;
goto loop;}}}}

/* k5559 in k5557 in parse-clause in k5551 in k5549 in k5547 in k5545 in k5543 in k5541 */
static void C_fcall f_5560(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5560,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5562,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_5562(t3,C_i_cddr(((C_word*)t0)[9]));}
else{
t3=((C_word*)t0)[9];
t4=t2;
f_5562(t4,C_u_i_cdr(t3));}}

/* map-loop926 in k7601 in k7598 in k7529 */
static void C_fcall f_7833(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7833,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7858,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-syntax.scm:382: g932 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8192 in k8190 in k8184 */
static void C_ccall f_8193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8193,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=*((C_word*)lf[112]+1);
t7=C_i_check_list_2(((C_word*)t0)[2],lf[28]);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8198,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8526,a[2]=t5,a[3]=t10,a[4]=t3,a[5]=((C_word)li133),tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_8526(t12,t8,((C_word*)t0)[2]);}

/* k8196 in k8192 in k8190 in k8184 */
static void C_ccall f_8198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8198,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=*((C_word*)lf[182]+1);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8201,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8496,a[2]=t5,a[3]=t9,a[4]=t3,a[5]=((C_word)li132),tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_8496(t11,t7,((C_word*)t0)[7]);}

/* k8190 in k8184 */
static void C_ccall f_8191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8191,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8193,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:283: r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[234]);}

/* k4767 in k4764 in k4628 */
static void C_ccall f_4768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4768,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4774,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:1089: ##sys#>= */
t3=*((C_word*)lf[58]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,C_fix(0));}

/* k8184 */
static void C_ccall f_8185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8185,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=((C_word*)t0)[2];
t4=C_u_i_cdr(t3);
t5=C_u_i_cdr(t4);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8191,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:282: r */
t7=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,lf[235]);}

/* k4764 in k4628 */
static void C_ccall f_4766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4766,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4768,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cdr(((C_word*)t0)[2]);
/* chicken-syntax.scm:1089: ##sys#length */
t4=*((C_word*)lf[59]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t2=((C_word*)t0)[3];
f_4650(2,t2,C_SCHEME_FALSE);}}

/* k7827 in loop in k7615 in k7601 in k7598 in k7529 */
static void C_ccall f_7828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7828,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
t4=C_u_i_cdr(t3);
/* chicken-syntax.scm:391: loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_7794(t5,((C_word*)t0)[5],t4,t2);}

/* k9274 in k9256 in k9247 in a9243 in k3394 in k3392 in k3390 in k3388 in k3386 in k3384 in k3382 in k3379 */
static void C_fcall f_9275(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9275,NULL,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[2])[1],t1);
t3=C_a_i_cons(&a,2,lf[242],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_list(&a,4,lf[155],((C_word*)t0)[4],((C_word*)t0)[5],t3));}

/* k7821 in loop in k7615 in k7601 in k7598 in k7529 */
static void C_ccall f_7822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7822,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
t4=C_u_i_cdr(t3);
/* chicken-syntax.scm:391: loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_7794(t5,((C_word*)t0)[5],t4,t2);}

/* k6413 in k3432 in k3430 in k3428 in k3426 in k3424 in k3422 in k3420 in k3418 in k3416 in k3413 in k3410 in k3408 in k3406 in k3404 in k3402 in k3400 in k3398 in k3396 in k3394 in k3392 in k3390 in ... */
static void C_ccall f_6414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6414,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[170],t1);
t3=C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6296,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6298,a[2]=((C_word)li64),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:727: ##sys#er-transformer */
t6=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* map-loop1010 in k7625 in k7615 in k7601 in k7598 in k7529 */
static void C_fcall f_7764(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7764,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7789,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-syntax.scm:393: g1016 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* map-loop1666 in k6040 */
static void C_fcall f_6060(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6060,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_a_i_list2(&a,2,t6,t7);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6071,a[2]=((C_word*)t0)[2],a[3]=t9,a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t11=t10;
f_6071(t11,C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t9));}
else{
t11=C_mutate(((C_word *)((C_word*)t0)[4])+1,t9);
t12=t10;
f_6071(t12,t11);}}
else{
t6=((C_word*)((C_word*)t0)[4])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k6256 in map-loop1587 in k5969 in k5937 */
static void C_ccall f_6257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6257,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_6232(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_6232(t6,((C_word*)t0)[5],t5);}}

/* k7739 in k7699 in fold in k7635 in k7625 in k7615 in k7601 in k7598 in k7529 */
static void C_ccall f_7740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7740,2,t0,t1);}
t2=C_a_i_list(&a,3,lf[97],((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_list(&a,3,lf[141],((C_word*)t0)[4],t2));}

/* k6056 in k6040 */
static void C_ccall f_6058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6058,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,3,lf[30],t1,((C_word*)t0)[3]));}

/* k4772 in k4767 in k4764 in k4628 */
static void C_ccall f_4774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4774,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_cdr(((C_word*)t0)[2]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4782,a[2]=t4,a[3]=((C_word)li30),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_4782(t6,((C_word*)t0)[3],t2,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
f_4650(2,t2,C_SCHEME_FALSE);}}

/* k4787 in loop2026 in k4772 in k4767 in k4764 in k4628 */
static void C_ccall f_4789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4789,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_eqp(((C_word*)t0)[3],C_SCHEME_END_OF_LIST));}
else{
t2=C_i_cdr(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4801,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:1089: ##sys#+ */
t4=*((C_word*)lf[56]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[5],C_fix(-1));}}

/* k7092 in k7083 in k7077 in quotify-proc */
static void C_fcall f_7094(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7094,NULL,2,t0,t1);}
if(C_truep(t1)){
/* chicken-syntax.scm:470: syntax-error */
t2=*((C_word*)lf[45]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[202],lf[203],((C_word*)t0)[3],((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list2(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]));}}

/* k7583 in map* in k7529 */
static void C_ccall f_7584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7584,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7587,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[3];
t4=C_u_i_cdr(t3);
/* chicken-syntax.scm:371: map* */
t5=((C_word*)((C_word*)t0)[4])[1];
f_7562(t5,t2,((C_word*)t0)[5],t4);}

/* k7586 in k7583 in map* in k7529 */
static void C_ccall f_7587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7587,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* k5009 in k4992 in loop in k4921 in k4919 in k4917 in k4915 */
static void C_ccall f_5010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:1032: r */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],t1);}

/* loop2026 in k4772 in k4767 in k4764 in k4628 */
static void C_fcall f_4782(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4782,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4789,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:1089: ##sys#= */
t5=*((C_word*)lf[57]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,C_fix(0));}

/* f_6222 */
static void C_ccall f_6222(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6222,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}

/* k9256 in k9247 in a9243 in k3394 in k3392 in k3390 in k3388 in k3386 in k3384 in k3382 in k3379 */
static void C_fcall f_9257(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9257,NULL,2,t0,t1);}
t2=C_a_i_list(&a,2,lf[118],((C_word*)t0)[2]);
t3=C_a_i_list(&a,1,lf[223]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9275,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t5=C_i_length(((C_word*)t0)[5]);
if(C_truep(C_fixnum_greaterp(t5,C_fix(1)))){
t6=t4;
f_9275(t6,C_i_cdr(((C_word*)t0)[5]));}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9290,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:186: ##sys#strip-syntax */
t7=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[2]);}}

/* k5014 in k4992 in loop in k4921 in k4919 in k4917 in k4915 */
static void C_ccall f_5016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5016,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
if(C_truep(C_i_nullp(t3))){
/* chicken-syntax.scm:1036: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4929(t4,((C_word*)t0)[4],C_SCHEME_END_OF_LIST,((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[7],C_SCHEME_TRUE);}
else{
/* chicken-syntax.scm:1037: syntax-error */
t4=*((C_word*)lf[45]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[4],lf[101],lf[102],((C_word*)t0)[8]);}}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5032,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5051,a[2]=((C_word*)t0)[9],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:1041: gensym */
t4=*((C_word*)lf[32]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* f_9749 in k3382 in k3379 */
static void C_ccall f_9749(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9749,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9752,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:53: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[282],t2,lf[284]);}

/* k9746 in k3382 in k3379 */
static void C_ccall f_9747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:48: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[282],C_SCHEME_END_OF_LIST,t1);}

/* k6228 in k5969 in k5937 */
static void C_ccall f_6230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[166]+1),t1);}

/* k9740 in map-loop25 in k9471 in k9469 in k9467 in k9465 in k9459 */
static void C_ccall f_9741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9741,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_9716(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_9716(t6,((C_word*)t0)[5],t5);}}

/* map-loop1587 in k5969 in k5937 */
static void C_fcall f_6232(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6232,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6257,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-syntax.scm:773: g1593 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5536 in k5774 in k5777 in k3440 in k3438 in k3436 in k3434 in k3432 in k3430 in k3428 in k3426 in k3424 in k3422 in k3420 in k3418 in k3416 in k3413 in k3410 in k3408 in k3406 in k3404 in k3402 in ... */
static void C_ccall f_5537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:869: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[127],((C_word*)t0)[3],t1);}

/* f_5539 in k5774 in k5777 in k3440 in k3438 in k3436 in k3434 in k3432 in k3430 in k3428 in k3426 in k3424 in k3422 in k3420 in k3418 in k3416 in k3413 in k3410 in k3408 in k3406 in k3404 in k3402 in ... */
static void C_ccall f_5539(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5539,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5542,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:875: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[127],t2,lf[136]);}

/* k5530 in k3442 in k3440 in k3438 in k3436 in k3434 in k3432 in k3430 in k3428 in k3426 in k3424 in k3422 in k3420 in k3418 in k3416 in k3413 in k3410 in k3408 in k3406 in k3404 in k3402 in k3400 in ... */
static void C_ccall f_5531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5531,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[110],t1);
t3=C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5229,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5231,a[2]=((C_word)li43),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:907: ##sys#er-transformer */
t6=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* k7699 in fold in k7635 in k7625 in k7615 in k7601 in k7598 in k7529 */
static void C_fcall f_7701(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7701,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_caar(((C_word*)t0)[2]);
t3=C_i_car(((C_word*)t0)[3]);
t4=C_a_i_list(&a,2,t2,t3);
t5=C_a_i_list(&a,1,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7710,a[2]=((C_word*)t0)[4],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=C_i_cdr(((C_word*)t0)[5]);
t8=((C_word*)t0)[3];
t9=C_u_i_cdr(t8);
t10=((C_word*)t0)[2];
t11=C_u_i_cdr(t10);
/* chicken-syntax.scm:402: fold */
t12=((C_word*)((C_word*)t0)[6])[1];
f_7639(t12,t6,t7,t9,t11);}
else{
t2=C_i_car(((C_word*)t0)[3]);
t3=C_a_i_list(&a,3,lf[97],C_SCHEME_END_OF_LIST,t2);
t4=((C_word*)t0)[2];
t5=C_u_i_car(t4);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7740,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=C_i_cdr(((C_word*)t0)[5]);
t8=((C_word*)t0)[3];
t9=C_u_i_cdr(t8);
t10=((C_word*)t0)[2];
t11=C_u_i_cdr(t10);
/* chicken-syntax.scm:408: fold */
t12=((C_word*)((C_word*)t0)[6])[1];
f_7639(t12,t6,t7,t9,t11);}}

/* k8164 in k3402 in k3400 in k3398 in k3396 in k3394 in k3392 in k3390 in k3388 in k3386 in k3384 in k3382 in k3379 */
static void C_ccall f_8165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:271: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[229],C_SCHEME_END_OF_LIST,t1);}

/* f_8167 in k3402 in k3400 in k3398 in k3396 in k3394 in k3392 in k3390 in k3388 in k3386 in k3384 in k3382 in k3379 */
static void C_ccall f_8167(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8167,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8185,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:279: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[229],t2,lf[236]);}

/* f_6214 in k5969 in k5937 */
static void C_ccall f_6214(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6214,3,t0,t1,t2);}
t3=C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6222,a[2]=((C_word)li59),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:774: ##sys#decompose-lambda-list */
t5=*((C_word*)lf[160]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* k7709 in k7699 in fold in k7635 in k7625 in k7615 in k7601 in k7598 in k7529 */
static void C_ccall f_7710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7710,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,3,lf[30],((C_word*)t0)[3],t1));}

/* k6070 in map-loop1666 in k6040 */
static void C_fcall f_6071(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[3]);
t3=C_slot(((C_word*)t0)[4],C_fix(1));
t4=C_slot(((C_word*)t0)[5],C_fix(1));
t5=((C_word*)((C_word*)t0)[6])[1];
f_6060(t5,((C_word*)t0)[7],t3,t4);}

/* k9297 in k9247 in a9243 in k3394 in k3392 in k3390 in k3388 in k3386 in k3384 in k3382 in k3379 */
static void C_ccall f_9298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9298,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9305,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:179: string-append */
t3=*((C_word*)lf[179]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[258],t1,lf[259],((C_word*)((C_word*)t0)[2])[1]);}
else{
t2=((C_word*)t0)[3];
f_9257(t2,C_SCHEME_FALSE);}}

/* f_7618 in k7615 in k7601 in k7598 in k7529 */
static void C_ccall f_7618(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7618,3,t0,t1,t2);}
t3=C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_i_cdr(t3));}

/* k7615 in k7601 in k7598 in k7529 */
static void C_ccall f_7617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7617,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7618,a[2]=t1,a[3]=((C_word)li104),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7626,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7794,a[2]=t5,a[3]=((C_word*)t0)[7],a[4]=t2,a[5]=((C_word)li110),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_7794(t7,t3,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);}

/* k7611 */
static void C_ccall f_7612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:382: r */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],t1);}

/* k9289 in k9256 in k9247 in a9243 in k3394 in k3392 in k3390 in k3388 in k3386 in k3384 in k3382 in k3379 */
static void C_ccall f_9290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9290,2,t0,t1);}
t2=C_a_i_list(&a,2,lf[113],t1);
t3=((C_word*)t0)[2];
f_9275(t3,C_a_i_list(&a,1,t2));}

/* quotify-proc */
static void C_fcall f_7074(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7074,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7078,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:461: ##sys#check-syntax */
t5=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,t3,t2,lf[204]);}

/* f_7071 in k3422 in k3420 in k3418 in k3416 in k3413 in k3410 in k3408 in k3406 in k3404 in k3402 in k3400 in k3398 in k3396 in k3394 in k3392 in k3390 in k3388 in k3386 in k3384 in k3382 in k3379 in ... */
static void C_ccall f_7071(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7071,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7074,a[2]=t4,a[3]=t3,a[4]=((C_word)li83),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7149,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t7=C_i_cdr(t2);
/* chicken-syntax.scm:474: quotify-proc */
t8=t5;
f_7074(t8,t6,t7,lf[202]);}

/* k7085 in k7083 in k7077 in quotify-proc */
static void C_ccall f_7086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7086,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list2(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]));}

/* k7625 in k7615 in k7601 in k7598 in k7529 */
static void C_ccall f_7626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7626,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7631,a[2]=((C_word)li105),tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7637,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7764,a[2]=t5,a[3]=t9,a[4]=t3,a[5]=t6,a[6]=((C_word)li109),tmp=(C_word)a,a+=7,tmp));
t11=((C_word*)t9)[1];
f_7764(t11,t7,((C_word*)t0)[7]);}

/* k7077 in quotify-proc */
static void C_ccall f_7078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7078,2,t0,t1);}
t2=C_i_car(((C_word*)t0)[2]);
t3=(C_truep(C_i_pairp(t2))?C_u_i_car(t2):t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7084,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_pairp(t2))){
t5=C_u_i_cdr(t2);
t6=((C_word*)t0)[2];
t7=C_u_i_cdr(t6);
t8=C_a_i_cons(&a,2,t5,t7);
t9=t4;
f_7084(t9,C_a_i_cons(&a,2,lf[97],t8));}
else{
t5=t4;
f_7084(t5,C_i_cadr(((C_word*)t0)[2]));}}

/* k4488 in k3456 in k3454 in k3452 in k3450 in k3448 in k3446 in k3444 in k3442 in k3440 in k3438 in k3436 in k3434 in k3432 in k3430 in k3428 in k3426 in k3424 in k3422 in k3420 in k3418 in k3416 in ... */
static void C_ccall f_4489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:1098: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[86],C_SCHEME_END_OF_LIST,t1);}

/* f_8124 in k3406 in k3404 in k3402 in k3400 in k3398 in k3396 in k3394 in k3392 in k3390 in k3388 in k3386 in k3384 in k3382 in k3379 */
static void C_ccall f_8124(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8124,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8127,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:319: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[225],t2,lf[226]);}

/* k8121 in k3406 in k3404 in k3402 in k3400 in k3398 in k3396 in k3394 in k3392 in k3390 in k3388 in k3386 in k3384 in k3382 in k3379 */
static void C_ccall f_8122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:315: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[225],C_SCHEME_END_OF_LIST,t1);}

/* k8126 */
static void C_ccall f_8127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8127,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=C_a_i_list(&a,1,lf[223]);
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
t6=C_u_i_cdr(t5);
t7=C_a_i_cons(&a,2,lf[26],t6);
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_a_i_list(&a,4,lf[155],t2,t3,t7));}

/* f_4491 in k3456 in k3454 in k3452 in k3450 in k3448 in k3446 in k3444 in k3442 in k3440 in k3438 in k3436 in k3434 in k3432 in k3430 in k3428 in k3426 in k3424 in k3422 in k3420 in k3418 in k3416 in ... */
static void C_ccall f_4491(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4491,5,t0,t1,t2,t3,t4);}
t5=C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4500,a[2]=t5,a[3]=t1,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_pairp(t5))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4525,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4575,a[2]=t5,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t9=C_i_car(t5);
/* chicken-syntax.scm:1100: ##sys#list? */
t10=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t8,t9);}
else{
t7=t6;
f_4500(2,t7,C_SCHEME_FALSE);}}

/* k6187 in build */
static void C_ccall f_6188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:810: r */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],t1);}

/* k7608 */
static void C_ccall f_7609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7609,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* k9187 */
static void C_ccall f_9188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9188,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=C_i_caddr(((C_word*)t0)[2]);
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
t6=C_u_i_cdr(t5);
t7=C_u_i_cdr(t6);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9197,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:197: r */
t9=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,lf[173]);}

/* f_7603 in k7601 in k7598 in k7529 */
static void C_ccall f_7603(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7603,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7609,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7612,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:382: gensym */
t5=*((C_word*)lf[32]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k7601 in k7598 in k7529 */
static void C_ccall f_7602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7602,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7603,a[2]=((C_word*)t0)[2],a[3]=((C_word)li103),tmp=(C_word)a,a+=4,tmp);
t7=t1;
t8=C_i_check_list_2(t7,lf[28]);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7617,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7833,a[2]=t5,a[3]=t11,a[4]=t3,a[5]=t6,a[6]=((C_word)li111),tmp=(C_word)a,a+=7,tmp));
t13=((C_word*)t11)[1];
f_7833(t13,t9,t7);}

/* k7598 in k7529 */
static void C_ccall f_7600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7600,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7602,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7863,a[2]=t4,a[3]=((C_word*)t0)[7],a[4]=((C_word)li112),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_7863(t6,t2,t1,C_SCHEME_END_OF_LIST);}

/* k9182 in k3396 in k3394 in k3392 in k3390 in k3388 in k3386 in k3384 in k3382 in k3379 */
static void C_ccall f_9183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:188: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[250],C_SCHEME_END_OF_LIST,t1);}

/* f_9185 in k3396 in k3394 in k3392 in k3390 in k3388 in k3386 in k3384 in k3382 in k3379 */
static void C_ccall f_9185(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9185,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9188,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:193: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[250],t2,lf[255]);}

/* k9196 in k9187 */
static void C_ccall f_9197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[57],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9197,2,t0,t1);}
t2=C_a_i_list(&a,2,t1,((C_word*)t0)[2]);
t3=C_a_i_list(&a,1,t2);
t4=C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t5=C_a_i_list(&a,2,lf[118],t4);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9215,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[5]))){
t7=t6;
f_9215(t7,C_a_i_cons(&a,2,lf[252],((C_word*)t0)[5]));}
else{
t7=C_a_i_list(&a,2,lf[113],lf[253]);
t8=C_a_i_list(&a,2,lf[254],t7);
t9=C_a_i_list(&a,2,lf[113],((C_word*)t0)[3]);
t10=C_a_i_list(&a,3,t8,t1,t9);
t11=t6;
f_9215(t11,C_a_i_cons(&a,2,lf[252],t10));}}

/* f_7654 in fold in k7635 in k7625 in k7615 in k7601 in k7598 in k7529 */
static void C_ccall f_7654(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7654,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7660,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:397: lookup */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k7663 in fold in k7635 in k7625 in k7615 in k7601 in k7598 in k7529 */
static void C_ccall f_7665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7665,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,lf[30],t2));}

/* map-loop975 in fold in k7635 in k7625 in k7615 in k7601 in k7598 in k7529 */
static void C_fcall f_7667(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7667,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7692,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* chicken-syntax.scm:397: g981 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7659 */
static void C_ccall f_7660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7660,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,2,((C_word*)t0)[3],t1));}

/* k7212 */
static void C_ccall f_7213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7213,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* k7215 */
static void C_ccall f_7216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:432: r */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],t1);}

/* k6023 in k6015 */
static void C_fcall f_6025(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6025,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6028,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6030,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word)li53),tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6038,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[13],a[9]=((C_word)li56),tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm:802: ##sys#call-with-values */
C_call_with_values(4,0,t2,t3,t4);}

/* fold in k7635 in k7625 in k7615 in k7601 in k7598 in k7529 */
static void C_fcall f_7639(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7639,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep(C_i_nullp(t2))){
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7654,a[2]=((C_word*)t0)[2],a[3]=((C_word)li106),tmp=(C_word)a,a+=4,tmp);
t10=((C_word*)t0)[3];
t11=C_i_check_list_2(t10,lf[28]);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7665,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7667,a[2]=t8,a[3]=t14,a[4]=t6,a[5]=t9,a[6]=((C_word)li107),tmp=(C_word)a,a+=7,tmp));
t16=((C_word*)t14)[1];
f_7667(t16,t12,t10);}
else{
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7701,a[2]=t4,a[3]=t3,a[4]=t1,a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t6=C_i_car(t4);
if(C_truep(C_i_pairp(t6))){
t7=C_i_cdar(t4);
t8=t5;
f_7701(t8,C_i_nullp(t7));}
else{
t7=t5;
f_7701(t7,C_SCHEME_FALSE);}}}

/* k7635 in k7625 in k7615 in k7601 in k7598 in k7529 */
static void C_ccall f_7637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7637,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7639,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word)li108),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_7639(t5,((C_word*)t0)[5],((C_word*)t0)[6],t1,((C_word*)t0)[7]);}

/* f_7631 in k7625 in k7615 in k7601 in k7598 in k7529 */
static void C_ccall f_7631(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7631,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_cadr(t2));}

/* k8670 in k8660 in k8652 */
static void C_ccall f_8672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8672,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8673,a[2]=((C_word*)t0)[2],a[3]=((C_word)li138),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8682,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9092,a[2]=t5,a[3]=t9,a[4]=t3,a[5]=t6,a[6]=((C_word)li151),tmp=(C_word)a,a+=7,tmp));
t11=((C_word*)t9)[1];
f_9092(t11,t7,((C_word*)t0)[6]);}

/* k7053 in fold in k6992 */
static void C_ccall f_7054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7054,2,t0,t1);}
t2=C_a_i_list(&a,4,lf[155],((C_word*)t0)[2],t1,C_SCHEME_FALSE);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_list(&a,3,lf[30],((C_word*)t0)[4],t2));}

/* k8678 */
static void C_ccall f_8679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:218: r */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],t1);}

/* f_8673 in k8670 in k8660 in k8652 */
static void C_ccall f_8673(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8673,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8679,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:218: gensym */
t4=*((C_word*)lf[32]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6027 in k6023 in k6015 */
static void C_ccall f_6028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6028,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,4,lf[155],((C_word*)t0)[3],t1,((C_word*)t0)[4]));}

/* k7068 in k3422 in k3420 in k3418 in k3416 in k3413 in k3410 in k3408 in k3406 in k3404 in k3402 in k3400 in k3398 in k3396 in k3394 in k3392 in k3390 in k3388 in k3386 in k3384 in k3382 in k3379 in ... */
static void C_ccall f_7069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:455: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[202],C_SCHEME_END_OF_LIST,t1);}

/* k7083 in k7077 in quotify-proc */
static void C_fcall f_7084(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7084,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7086,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=C_i_pairp(t1);
t4=C_i_not(t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7094,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t4)){
t6=t5;
f_7094(t6,t4);}
else{
t6=C_i_car(t1);
t7=C_eqp(lf[97],t6);
if(C_truep(t7)){
t8=t5;
f_7094(t8,C_SCHEME_FALSE);}
else{
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7109,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7112,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t8,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:469: r */
t10=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,lf[90]);}}}

/* k5228 in k5530 in k3442 in k3440 in k3438 in k3436 in k3434 in k3432 in k3430 in k3428 in k3426 in k3424 in k3422 in k3420 in k3418 in k3416 in k3413 in k3410 in k3408 in k3406 in k3404 in k3402 in ... */
static void C_ccall f_5229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:904: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[111],((C_word*)t0)[3],t1);}

/* k5222 in k3444 in k3442 in k3440 in k3438 in k3436 in k3434 in k3432 in k3430 in k3428 in k3426 in k3424 in k3422 in k3420 in k3418 in k3416 in k3413 in k3410 in k3408 in k3406 in k3404 in k3402 in ... */
static void C_ccall f_5223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5223,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[100],t1);
t3=C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5077,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5079,a[2]=((C_word)li38),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:980: ##sys#er-transformer */
t6=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* k6002 in k5993 in k5987 in k5985 in k5983 in k5981 in k5979 in k5977 in k5975 in k5973 in k5971 in k5969 in k5937 */
static void C_ccall f_6003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6003,2,t0,t1);}
t2=C_a_i_list(&a,3,lf[30],((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_list(&a,3,lf[97],((C_word*)t0)[4],t2));}

/* f_6005 in k5993 in k5987 in k5985 in k5983 in k5981 in k5979 in k5977 in k5975 in k5973 in k5971 in k5969 in k5937 */
static void C_ccall f_6005(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6005,4,t0,t1,t2,t3);}
t4=C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6013,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word)li57),tmp=(C_word)a,a+=14,tmp);
/* chicken-syntax.scm:792: ##sys#decompose-lambda-list */
t6=*((C_word*)lf[160]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t4,t5);}

/* k8149 */
static void C_ccall f_8150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8150,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=((C_word*)t0)[2];
t4=C_u_i_cdr(t3);
t5=C_u_i_cdr(t4);
t6=C_a_i_cons(&a,2,lf[26],t5);
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_list(&a,3,lf[155],t2,t6));}

/* k5255 in k5251 in k5249 in k5245 in k5243 in k5233 */
static void C_ccall f_5257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5257,2,t0,t1);}
t2=C_a_i_list(&a,2,lf[113],((C_word*)t0)[2]);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5454,a[2]=((C_word*)t0)[3],a[3]=((C_word)li39),tmp=(C_word)a,a+=4,tmp);
t8=C_i_check_list_2(t1,lf[28]);
t9=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5465,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[2],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5467,a[2]=t6,a[3]=t11,a[4]=t4,a[5]=t7,a[6]=((C_word)li41),tmp=(C_word)a,a+=7,tmp));
t13=((C_word*)t11)[1];
f_5467(t13,t9,t1);}

/* k7199 */
static void C_ccall f_7200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7200,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=((C_word*)t0)[2];
t4=C_u_i_cdr(t3);
t5=C_u_i_cdr(t4);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7206,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7438,a[2]=((C_word)li96),tmp=(C_word)a,a+=3,tmp);
t12=C_i_check_list_2(t2,lf[28]);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7446,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7448,a[2]=t10,a[3]=t15,a[4]=t8,a[5]=t11,a[6]=((C_word)li97),tmp=(C_word)a,a+=7,tmp));
t17=((C_word*)t15)[1];
f_7448(t17,t13,t2);}

/* f_7207 in k7205 in k7199 */
static void C_ccall f_7207(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7207,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7213,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7216,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:432: gensym */
t5=*((C_word*)lf[32]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k7205 in k7199 */
static void C_ccall f_7206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7206,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7207,a[2]=((C_word*)t0)[2],a[3]=((C_word)li86),tmp=(C_word)a,a+=4,tmp);
t7=t1;
t8=C_i_check_list_2(t7,lf[28]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7221,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7408,a[2]=t5,a[3]=t11,a[4]=t3,a[5]=t6,a[6]=((C_word)li95),tmp=(C_word)a,a+=7,tmp));
t13=((C_word*)t11)[1];
f_7408(t13,t9,t7);}

/* k8144 in k3404 in k3402 in k3400 in k3398 in k3396 in k3394 in k3392 in k3390 in k3388 in k3386 in k3384 in k3382 in k3379 */
static void C_ccall f_8145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:307: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[227],C_SCHEME_END_OF_LIST,t1);}

/* k5251 in k5249 in k5245 in k5243 in k5233 */
static void C_ccall f_5252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5252,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=*((C_word*)lf[112]+1);
t7=C_i_check_list_2(((C_word*)t0)[2],lf[28]);
t8=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5257,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t1,a[12]=((C_word*)t0)[2],tmp=(C_word)a,a+=13,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5497,a[2]=t5,a[3]=t10,a[4]=t3,a[5]=((C_word)li42),tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_5497(t12,t8,((C_word*)t0)[2]);}

/* k5249 in k5245 in k5243 in k5233 */
static void C_ccall f_5250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5250,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5252,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* chicken-syntax.scm:921: r */
t3=((C_word*)t0)[11];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[123]);}

/* f_8147 in k3404 in k3402 in k3400 in k3398 in k3396 in k3394 in k3392 in k3390 in k3388 in k3386 in k3384 in k3382 in k3379 */
static void C_ccall f_8147(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8147,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8150,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:311: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[227],t2,lf[228]);}

/* k8680 in k8670 in k8660 in k8652 */
static void C_ccall f_8682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8682,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8688,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=*((C_word*)lf[231]+1);
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_FALSE;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=*((C_word*)lf[182]+1);
t13=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8939,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[6],a[6]=t6,a[7]=t4,tmp=(C_word)a,a+=8,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9062,a[2]=t11,a[3]=t15,a[4]=t9,a[5]=((C_word)li150),tmp=(C_word)a,a+=6,tmp));
t17=((C_word*)t15)[1];
f_9062(t17,t13,((C_word*)t0)[6]);}

/* k8687 in k8680 in k8670 in k8660 in k8652 */
static void C_ccall f_8688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8688,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8824,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8826,a[2]=((C_word)li143),tmp=(C_word)a,a+=3,tmp);
t8=C_i_check_list_2(((C_word*)t0)[4],lf[28]);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8834,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8895,a[2]=t6,a[3]=t11,a[4]=t4,a[5]=t7,a[6]=((C_word)li146),tmp=(C_word)a,a+=7,tmp));
t13=((C_word*)t11)[1];
f_8895(t13,t9,((C_word*)t0)[5],((C_word*)t0)[4]);}

/* k8634 in k8627 in k8620 in loop in k8571 in k8569 in k8567 in k8561 */
static void C_ccall f_8636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t3=C_slot(((C_word*)t0)[3],C_fix(1));
/* chicken-syntax.scm:261: loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_8603(t4,((C_word*)t0)[5],t3);}
else{
t2=((C_word*)t0)[3];
t3=C_u_i_car(t2);
/* chicken-syntax.scm:260: ##sys#error */
t4=*((C_word*)lf[242]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[6],lf[243],t3);}}

/* k5233 */
static void C_ccall f_5234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5234,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=C_i_caddr(((C_word*)t0)[2]);
t4=C_i_cadddr(((C_word*)t0)[2]);
t5=C_i_cddddr(((C_word*)t0)[2]);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5244,a[2]=t3,a[3]=t5,a[4]=t2,a[5]=t4,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm:917: r */
t7=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,lf[47]);}

/* f_5231 in k5530 in k3442 in k3440 in k3438 in k3436 in k3434 in k3432 in k3430 in k3428 in k3426 in k3424 in k3422 in k3420 in k3418 in k3416 in k3413 in k3410 in k3408 in k3406 in k3404 in k3402 in ... */
static void C_ccall f_5231(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5231,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5234,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:909: ##sys#check-syntax */
t6=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[111],t2,lf[125]);}

/* build */
static void C_fcall f_6102(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6102,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
if(C_truep(((C_word*)t0)[2])){
t4=C_a_i_list(&a,2,((C_word*)t0)[2],t3);
t5=C_a_i_list(&a,1,t4);
t6=C_i_cdr(((C_word*)t0)[3]);
t7=C_a_i_cons(&a,2,t5,t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_a_i_cons(&a,2,lf[30],t7));}
else{
t4=C_i_cddr(((C_word*)t0)[3]);
if(C_truep(C_i_nullp(t4))){
t5=((C_word*)t0)[3];
t6=C_u_i_cdr(t5);
t7=C_u_i_car(t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t5=((C_word*)t0)[3];
t6=C_u_i_cdr(t5);
t7=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_a_i_cons(&a,2,lf[30],t7));}}}
else{
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6148,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6188,a[2]=((C_word*)t0)[7],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:810: gensym */
t6=*((C_word*)lf[32]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}}

/* k8668 */
static void C_ccall f_8669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:217: r */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],t1);}

/* f_8663 in k8660 in k8652 */
static void C_ccall f_8663(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8663,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8669,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:217: gensym */
t4=*((C_word*)lf[32]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k8660 in k8652 */
static void C_ccall f_8662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8662,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8663,a[2]=((C_word*)t0)[2],a[3]=((C_word)li137),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8672,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9122,a[2]=t5,a[3]=t9,a[4]=t3,a[5]=t6,a[6]=((C_word)li152),tmp=(C_word)a,a+=7,tmp));
t11=((C_word*)t9)[1];
f_9122(t11,t7,((C_word*)t0)[5]);}

/* k4419 */
static void C_ccall f_4420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4420,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4422,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_i_cadr(((C_word*)t0)[3]);
/* chicken-syntax.scm:1112: ##sys#strip-syntax */
t4=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}

/* k4421 in k4419 */
static void C_ccall f_4422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4422,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4424,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:1113: r */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[20]);}

/* k4423 in k4421 in k4419 */
static void C_ccall f_4424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4424,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4426,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=C_eqp(lf[44],((C_word*)t0)[2]);
if(C_truep(t3)){
/* chicken-syntax.scm:1115: syntax-error-hook */
t4=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[79],lf[84]);}
else{
t4=t2;
f_4426(2,t4,C_SCHEME_UNDEFINED);}}

/* k4425 in k4423 in k4421 in k4419 */
static void C_ccall f_4426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4426,2,t0,t1);}
t2=C_a_i_list(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t3=C_a_i_list(&a,2,((C_word*)t0)[2],lf[80]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4444,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t5=C_i_caddr(((C_word*)t0)[5]);
/* chicken-syntax.scm:1122: ##sys#strip-syntax */
t6=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* k6156 in k6147 in build */
static void C_ccall f_6157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6157,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,3,lf[30],((C_word*)t0)[3],t1));}

/* k8612 in loop in k8571 in k8569 in k8567 in k8561 */
static void C_ccall f_8613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
/* chicken-syntax.scm:261: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8603(t3,((C_word*)t0)[4],t2);}

/* k3566 in k3560 */
static void C_ccall f_3567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3567,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=C_a_i_cons(&a,2,lf[26],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_list2(&a,2,t1,t4));}

/* k9498 */
static void C_ccall f_9500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
if(C_truep(C_i_pairp(t3))){
t4=C_i_cadr(((C_word*)t0)[2]);
if(C_truep(C_i_symbolp(t4))){
t5=((C_word*)t0)[2];
t6=C_u_i_cdr(t5);
t7=C_u_i_cdr(t6);
if(C_truep(C_i_nullp(t7))){
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_i_cadr(((C_word*)t0)[2]));}
else{
/* chicken-syntax.scm:77: syntax-error */
t8=*((C_word*)lf[45]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,((C_word*)t0)[3],lf[272],lf[273],((C_word*)t0)[2]);}}
else{
/* chicken-syntax.scm:77: syntax-error */
t5=*((C_word*)lf[45]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[3],lf[272],lf[273],((C_word*)t0)[2]);}}
else{
/* chicken-syntax.scm:77: syntax-error */
t4=*((C_word*)lf[45]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],lf[272],lf[273],((C_word*)t0)[2]);}}
else{
/* chicken-syntax.scm:77: syntax-error */
t2=*((C_word*)lf[45]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[272],lf[273],((C_word*)t0)[2]);}}

/* k3560 */
static void C_ccall f_3561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3561,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3567,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_eqp(t1,lf[27]);
if(C_truep(t3)){
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
t6=C_a_i_cons(&a,2,lf[26],t5);
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_list2(&a,2,lf[27],t6));}
else{
if(C_truep(((C_word*)t0)[4])){
/* chicken-syntax.scm:1285: ##compiler#check-and-validate-type */
t4=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t1,lf[25]);}
else{
t4=t1;
t5=((C_word*)t0)[2];
t6=C_u_i_cdr(t5);
t7=C_a_i_cons(&a,2,lf[26],t6);
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_a_i_list2(&a,2,t4,t7));}}}

/* k8647 in k3398 in k3396 in k3394 in k3392 in k3390 in k3388 in k3386 in k3384 in k3382 in k3379 */
static void C_ccall f_8648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:209: ##sys#extend-macro-environment */
t2=*((C_word*)lf[11]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[248],C_SCHEME_END_OF_LIST,t1);}

/* k5245 in k5243 in k5233 */
static void C_ccall f_5246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5246,2,t0,t1);}
t2=C_i_cdr(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5250,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=t1,a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
/* chicken-syntax.scm:920: r */
t4=((C_word*)t0)[9];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[124]);}

/* k5243 in k5233 */
static void C_ccall f_5244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5244,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5246,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm:918: r */
t3=((C_word*)t0)[8];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[110]);}

/* k3517 in k3499 in k3497 in k3495 in k3487 */
static void C_ccall f_3518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3518,2,t0,t1);}
t2=C_a_i_list(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_list(&a,4,lf[16],((C_word*)t0)[3],((C_word*)t0)[4],t2);
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_list(&a,2,lf[17],t3));}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[707] = {
{"f_3500:chicken_2dsyntax_2escm",(void*)f_3500},
{"f_8629:chicken_2dsyntax_2escm",(void*)f_8629},
{"f_6148:chicken_2dsyntax_2escm",(void*)f_6148},
{"f_8622:chicken_2dsyntax_2escm",(void*)f_8622},
{"f_3535:chicken_2dsyntax_2escm",(void*)f_3535},
{"f_3539:chicken_2dsyntax_2escm",(void*)f_3539},
{"f_3530:chicken_2dsyntax_2escm",(void*)f_3530},
{"f_9530:chicken_2dsyntax_2escm",(void*)f_9530},
{"f_3532:chicken_2dsyntax_2escm",(void*)f_3532},
{"f_3399:chicken_2dsyntax_2escm",(void*)f_3399},
{"f_3395:chicken_2dsyntax_2escm",(void*)f_3395},
{"f_3397:chicken_2dsyntax_2escm",(void*)f_3397},
{"f_3391:chicken_2dsyntax_2escm",(void*)f_3391},
{"f_3393:chicken_2dsyntax_2escm",(void*)f_3393},
{"f_8603:chicken_2dsyntax_2escm",(void*)f_8603},
{"f_5179:chicken_2dsyntax_2escm",(void*)f_5179},
{"f_5173:chicken_2dsyntax_2escm",(void*)f_5173},
{"f_4598:chicken_2dsyntax_2escm",(void*)f_4598},
{"f_9020:chicken_2dsyntax_2escm",(void*)f_9020},
{"f_4066:chicken_2dsyntax_2escm",(void*)f_4066},
{"f_3593:chicken_2dsyntax_2escm",(void*)f_3593},
{"f_3591:chicken_2dsyntax_2escm",(void*)f_3591},
{"f_4444:chicken_2dsyntax_2escm",(void*)f_4444},
{"f_4447:chicken_2dsyntax_2escm",(void*)f_4447},
{"f_9031:chicken_2dsyntax_2escm",(void*)f_9031},
{"f_4087:chicken_2dsyntax_2escm",(void*)f_4087},
{"f_4089:chicken_2dsyntax_2escm",(void*)f_4089},
{"f_4081:chicken_2dsyntax_2escm",(void*)f_4081},
{"f_8650:chicken_2dsyntax_2escm",(void*)f_8650},
{"f_8653:chicken_2dsyntax_2escm",(void*)f_8653},
{"f_4095:chicken_2dsyntax_2escm",(void*)f_4095},
{"f_3558:chicken_2dsyntax_2escm",(void*)f_3558},
{"f_8895:chicken_2dsyntax_2escm",(void*)f_8895},
{"f_4409:chicken_2dsyntax_2escm",(void*)f_4409},
{"f_8881:chicken_2dsyntax_2escm",(void*)f_8881},
{"f_3541:chicken_2dsyntax_2escm",(void*)f_3541},
{"f_4417:chicken_2dsyntax_2escm",(void*)f_4417},
{"f_4415:chicken_2dsyntax_2escm",(void*)f_4415},
{"f_9002:chicken_2dsyntax_2escm",(void*)f_9002},
{"f_8113:chicken_2dsyntax_2escm",(void*)f_8113},
{"f_9015:chicken_2dsyntax_2escm",(void*)f_9015},
{"f_8864:chicken_2dsyntax_2escm",(void*)f_8864},
{"f_8853:chicken_2dsyntax_2escm",(void*)f_8853},
{"f_7473:chicken_2dsyntax_2escm",(void*)f_7473},
{"f_5935:chicken_2dsyntax_2escm",(void*)f_5935},
{"f_5933:chicken_2dsyntax_2escm",(void*)f_5933},
{"f_5938:chicken_2dsyntax_2escm",(void*)f_5938},
{"f_8845:chicken_2dsyntax_2escm",(void*)f_8845},
{"f_7479:chicken_2dsyntax_2escm",(void*)f_7479},
{"f_7490:chicken_2dsyntax_2escm",(void*)f_7490},
{"f_7495:chicken_2dsyntax_2escm",(void*)f_7495},
{"f_5959:chicken_2dsyntax_2escm",(void*)f_5959},
{"f_5814:chicken_2dsyntax_2escm",(void*)f_5814},
{"f_8826:chicken_2dsyntax_2escm",(void*)f_8826},
{"f_8824:chicken_2dsyntax_2escm",(void*)f_8824},
{"f_7481:chicken_2dsyntax_2escm",(void*)f_7481},
{"f_7484:chicken_2dsyntax_2escm",(void*)f_7484},
{"f_5946:chicken_2dsyntax_2escm",(void*)f_5946},
{"f_5802:chicken_2dsyntax_2escm",(void*)f_5802},
{"f_5940:chicken_2dsyntax_2escm",(void*)f_5940},
{"f_6898:chicken_2dsyntax_2escm",(void*)f_6898},
{"f_5032:chicken_2dsyntax_2escm",(void*)f_5032},
{"f_8803:chicken_2dsyntax_2escm",(void*)f_8803},
{"f_5869:chicken_2dsyntax_2escm",(void*)f_5869},
{"f_6876:chicken_2dsyntax_2escm",(void*)f_6876},
{"f_6874:chicken_2dsyntax_2escm",(void*)f_6874},
{"f_5915:chicken_2dsyntax_2escm",(void*)f_5915},
{"f_4258:chicken_2dsyntax_2escm",(void*)f_4258},
{"f_4252:chicken_2dsyntax_2escm",(void*)f_4252},
{"f_4260:chicken_2dsyntax_2escm",(void*)f_4260},
{"f_5704:chicken_2dsyntax_2escm",(void*)f_5704},
{"f_5701:chicken_2dsyntax_2escm",(void*)f_5701},
{"f_8837:chicken_2dsyntax_2escm",(void*)f_8837},
{"f_8839:chicken_2dsyntax_2escm",(void*)f_8839},
{"f_4285:chicken_2dsyntax_2escm",(void*)f_4285},
{"f_4525:chicken_2dsyntax_2escm",(void*)f_4525},
{"f_8834:chicken_2dsyntax_2escm",(void*)f_8834},
{"f_4282:chicken_2dsyntax_2escm",(void*)f_4282},
{"f_7874:chicken_2dsyntax_2escm",(void*)f_7874},
{"f_4531:chicken_2dsyntax_2escm",(void*)f_4531},
{"f_4533:chicken_2dsyntax_2escm",(void*)f_4533},
{"f_5723:chicken_2dsyntax_2escm",(void*)f_5723},
{"f_4500:chicken_2dsyntax_2escm",(void*)f_4500},
{"f_5712:chicken_2dsyntax_2escm",(void*)f_5712},
{"f_4539:chicken_2dsyntax_2escm",(void*)f_4539},
{"f_5978:chicken_2dsyntax_2escm",(void*)f_5978},
{"f_7149:chicken_2dsyntax_2escm",(void*)f_7149},
{"f_5976:chicken_2dsyntax_2escm",(void*)f_5976},
{"f_5974:chicken_2dsyntax_2escm",(void*)f_5974},
{"f_5972:chicken_2dsyntax_2escm",(void*)f_5972},
{"f_5970:chicken_2dsyntax_2escm",(void*)f_5970},
{"f_6988:chicken_2dsyntax_2escm",(void*)f_6988},
{"f_4510:chicken_2dsyntax_2escm",(void*)f_4510},
{"f_5748:chicken_2dsyntax_2escm",(void*)f_5748},
{"f_8363:chicken_2dsyntax_2escm",(void*)f_8363},
{"f_6802:chicken_2dsyntax_2escm",(void*)f_6802},
{"f_7158:chicken_2dsyntax_2escm",(void*)f_7158},
{"f_5968:chicken_2dsyntax_2escm",(void*)f_5968},
{"f_5962:chicken_2dsyntax_2escm",(void*)f_5962},
{"f_7899:chicken_2dsyntax_2escm",(void*)f_7899},
{"f_4566:chicken_2dsyntax_2escm",(void*)f_4566},
{"f_6807:chicken_2dsyntax_2escm",(void*)f_6807},
{"f_4575:chicken_2dsyntax_2escm",(void*)f_4575},
{"f_6861:chicken_2dsyntax_2escm",(void*)f_6861},
{"f_6863:chicken_2dsyntax_2escm",(void*)f_6863},
{"f_6865:chicken_2dsyntax_2escm",(void*)f_6865},
{"f_4824:chicken_2dsyntax_2escm",(void*)f_4824},
{"f_4821:chicken_2dsyntax_2escm",(void*)f_4821},
{"f_4577:chicken_2dsyntax_2escm",(void*)f_4577},
{"f_9472:chicken_2dsyntax_2escm",(void*)f_9472},
{"f_9473:chicken_2dsyntax_2escm",(void*)f_9473},
{"f_9470:chicken_2dsyntax_2escm",(void*)f_9470},
{"f_7373:chicken_2dsyntax_2escm",(void*)f_7373},
{"f_4833:chicken_2dsyntax_2escm",(void*)f_4833},
{"f_7378:chicken_2dsyntax_2escm",(void*)f_7378},
{"f_4835:chicken_2dsyntax_2escm",(void*)f_4835},
{"f_4838:chicken_2dsyntax_2escm",(void*)f_4838},
{"f_4554:chicken_2dsyntax_2escm",(void*)f_4554},
{"f_4547:chicken_2dsyntax_2escm",(void*)f_4547},
{"f_6844:chicken_2dsyntax_2escm",(void*)f_6844},
{"f_4844:chicken_2dsyntax_2escm",(void*)f_4844},
{"f_7525:chicken_2dsyntax_2escm",(void*)f_7525},
{"f_7527:chicken_2dsyntax_2escm",(void*)f_7527},
{"f_4850:chicken_2dsyntax_2escm",(void*)f_4850},
{"f_6847:chicken_2dsyntax_2escm",(void*)f_6847},
{"f_4856:chicken_2dsyntax_2escm",(void*)f_4856},
{"f_4858:chicken_2dsyntax_2escm",(void*)f_4858},
{"f_9468:chicken_2dsyntax_2escm",(void*)f_9468},
{"f_9466:chicken_2dsyntax_2escm",(void*)f_9466},
{"f_9460:chicken_2dsyntax_2escm",(void*)f_9460},
{"f_6933:chicken_2dsyntax_2escm",(void*)f_6933},
{"f_4583:chicken_2dsyntax_2escm",(void*)f_4583},
{"f_6937:chicken_2dsyntax_2escm",(void*)f_6937},
{"f_6677:chicken_2dsyntax_2escm",(void*)f_6677},
{"f_4591:chicken_2dsyntax_2escm",(void*)f_4591},
{"f_6678:chicken_2dsyntax_2escm",(void*)f_6678},
{"f_6673:chicken_2dsyntax_2escm",(void*)f_6673},
{"f_6675:chicken_2dsyntax_2escm",(void*)f_6675},
{"f_6904:chicken_2dsyntax_2escm",(void*)f_6904},
{"f_4328:chicken_2dsyntax_2escm",(void*)f_4328},
{"f_4323:chicken_2dsyntax_2escm",(void*)f_4323},
{"f_4326:chicken_2dsyntax_2escm",(void*)f_4326},
{"f_6906:chicken_2dsyntax_2escm",(void*)f_6906},
{"f_6670:chicken_2dsyntax_2escm",(void*)f_6670},
{"f_4321:chicken_2dsyntax_2escm",(void*)f_4321},
{"f_4801:chicken_2dsyntax_2escm",(void*)f_4801},
{"f_9457:chicken_2dsyntax_2escm",(void*)f_9457},
{"f_9455:chicken_2dsyntax_2escm",(void*)f_9455},
{"f_6850:chicken_2dsyntax_2escm",(void*)f_6850},
{"f_6852:chicken_2dsyntax_2escm",(void*)f_6852},
{"f_6855:chicken_2dsyntax_2escm",(void*)f_6855},
{"f_7562:chicken_2dsyntax_2escm",(void*)f_7562},
{"f_6921:chicken_2dsyntax_2escm",(void*)f_6921},
{"f_4819:chicken_2dsyntax_2escm",(void*)f_4819},
{"f_7536:chicken_2dsyntax_2escm",(void*)f_7536},
{"f_7530:chicken_2dsyntax_2escm",(void*)f_7530},
{"f_6973:chicken_2dsyntax_2escm",(void*)f_6973},
{"f_9379:chicken_2dsyntax_2escm",(void*)f_9379},
{"f_9377:chicken_2dsyntax_2escm",(void*)f_9377},
{"f_6946:chicken_2dsyntax_2escm",(void*)f_6946},
{"f_6948:chicken_2dsyntax_2escm",(void*)f_6948},
{"f_7517:chicken_2dsyntax_2escm",(void*)f_7517},
{"f_6687:chicken_2dsyntax_2escm",(void*)f_6687},
{"f_6689:chicken_2dsyntax_2escm",(void*)f_6689},
{"f_6684:chicken_2dsyntax_2escm",(void*)f_6684},
{"f_9382:chicken_2dsyntax_2escm",(void*)f_9382},
{"f_6990:chicken_2dsyntax_2escm",(void*)f_6990},
{"f_6993:chicken_2dsyntax_2escm",(void*)f_6993},
{"f_8394:chicken_2dsyntax_2escm",(void*)f_8394},
{"f_6697:chicken_2dsyntax_2escm",(void*)f_6697},
{"f_6691:chicken_2dsyntax_2escm",(void*)f_6691},
{"f_4861:chicken_2dsyntax_2escm",(void*)f_4861},
{"f_6665:chicken_2dsyntax_2escm",(void*)f_6665},
{"f_8074:chicken_2dsyntax_2escm",(void*)f_8074},
{"f_7555:chicken_2dsyntax_2escm",(void*)f_7555},
{"f_6649:chicken_2dsyntax_2escm",(void*)f_6649},
{"f_6648:chicken_2dsyntax_2escm",(void*)f_6648},
{"f_6641:chicken_2dsyntax_2escm",(void*)f_6641},
{"f_3677:chicken_2dsyntax_2escm",(void*)f_3677},
{"f_6643:chicken_2dsyntax_2escm",(void*)f_6643},
{"f_3673:chicken_2dsyntax_2escm",(void*)f_3673},
{"f_7692:chicken_2dsyntax_2escm",(void*)f_7692},
{"f_8352:chicken_2dsyntax_2escm",(void*)f_8352},
{"f_6658:chicken_2dsyntax_2escm",(void*)f_6658},
{"f_6659:chicken_2dsyntax_2escm",(void*)f_6659},
{"f_3671:chicken_2dsyntax_2escm",(void*)f_3671},
{"f_8057:chicken_2dsyntax_2escm",(void*)f_8057},
{"f_7180:chicken_2dsyntax_2escm",(void*)f_7180},
{"f_6655:chicken_2dsyntax_2escm",(void*)f_6655},
{"f_3662:chicken_2dsyntax_2escm",(void*)f_3662},
{"f_6627:chicken_2dsyntax_2escm",(void*)f_6627},
{"f_6481:chicken_2dsyntax_2escm",(void*)f_6481},
{"f_4103:chicken_2dsyntax_2escm",(void*)f_4103},
{"f_3653:chicken_2dsyntax_2escm",(void*)f_3653},
{"f_3655:chicken_2dsyntax_2escm",(void*)f_3655},
{"f_8335:chicken_2dsyntax_2escm",(void*)f_8335},
{"f_3651:chicken_2dsyntax_2escm",(void*)f_3651},
{"f_6490:chicken_2dsyntax_2escm",(void*)f_6490},
{"f_7160:chicken_2dsyntax_2escm",(void*)f_7160},
{"f_7165:chicken_2dsyntax_2escm",(void*)f_7165},
{"f_7163:chicken_2dsyntax_2escm",(void*)f_7163},
{"f_6608:chicken_2dsyntax_2escm",(void*)f_6608},
{"f_6484:chicken_2dsyntax_2escm",(void*)f_6484},
{"f_6460:chicken_2dsyntax_2escm",(void*)f_6460},
{"f_6916:chicken_2dsyntax_2escm",(void*)f_6916},
{"f_6918:chicken_2dsyntax_2escm",(void*)f_6918},
{"f_7192:chicken_2dsyntax_2escm",(void*)f_7192},
{"f_7195:chicken_2dsyntax_2escm",(void*)f_7195},
{"f_7197:chicken_2dsyntax_2escm",(void*)f_7197},
{"f_8318:chicken_2dsyntax_2escm",(void*)f_8318},
{"f_5051:chicken_2dsyntax_2escm",(void*)f_5051},
{"f_6492:chicken_2dsyntax_2escm",(void*)f_6492},
{"f_6495:chicken_2dsyntax_2escm",(void*)f_6495},
{"f_4139:chicken_2dsyntax_2escm",(void*)f_4139},
{"f_4133:chicken_2dsyntax_2escm",(void*)f_4133},
{"f_7448:chicken_2dsyntax_2escm",(void*)f_7448},
{"f_7446:chicken_2dsyntax_2escm",(void*)f_7446},
{"f_5454:chicken_2dsyntax_2escm",(void*)f_5454},
{"f_4110:chicken_2dsyntax_2escm",(void*)f_4110},
{"f_8307:chicken_2dsyntax_2escm",(void*)f_8307},
{"f_4147:chicken_2dsyntax_2escm",(void*)f_4147},
{"f_8088:chicken_2dsyntax_2escm",(void*)f_8088},
{"f_4122:chicken_2dsyntax_2escm",(void*)f_4122},
{"f_3694:chicken_2dsyntax_2escm",(void*)f_3694},
{"f_5421:chicken_2dsyntax_2escm",(void*)f_5421},
{"f_6478:chicken_2dsyntax_2escm",(void*)f_6478},
{"f_7438:chicken_2dsyntax_2escm",(void*)f_7438},
{"f_7433:chicken_2dsyntax_2escm",(void*)f_7433},
{"f_5095:chicken_2dsyntax_2escm",(void*)f_5095},
{"f_7403:chicken_2dsyntax_2escm",(void*)f_7403},
{"f_7408:chicken_2dsyntax_2escm",(void*)f_7408},
{"f_5086:chicken_2dsyntax_2escm",(void*)f_5086},
{"f_5088:chicken_2dsyntax_2escm",(void*)f_5088},
{"f_5082:chicken_2dsyntax_2escm",(void*)f_5082},
{"f_5084:chicken_2dsyntax_2escm",(void*)f_5084},
{"f_8046:chicken_2dsyntax_2escm",(void*)f_8046},
{"f_8044:chicken_2dsyntax_2escm",(void*)f_8044},
{"f_5079:chicken_2dsyntax_2escm",(void*)f_5079},
{"f_5077:chicken_2dsyntax_2escm",(void*)f_5077},
{"f_5071:chicken_2dsyntax_2escm",(void*)f_5071},
{"f_6639:chicken_2dsyntax_2escm",(void*)f_6639},
{"f_3649:chicken_2dsyntax_2escm",(void*)f_3649},
{"f_6633:chicken_2dsyntax_2escm",(void*)f_6633},
{"f_3646:chicken_2dsyntax_2escm",(void*)f_3646},
{"f_3640:chicken_2dsyntax_2escm",(void*)f_3640},
{"f_5325:chicken_2dsyntax_2escm",(void*)f_5325},
{"f_8572:chicken_2dsyntax_2escm",(void*)f_8572},
{"f_8570:chicken_2dsyntax_2escm",(void*)f_8570},
{"f_8574:chicken_2dsyntax_2escm",(void*)f_8574},
{"f_7348:chicken_2dsyntax_2escm",(void*)f_7348},
{"f_7346:chicken_2dsyntax_2escm",(void*)f_7346},
{"f_3632:chicken_2dsyntax_2escm",(void*)f_3632},
{"f_3630:chicken_2dsyntax_2escm",(void*)f_3630},
{"f_5355:chicken_2dsyntax_2escm",(void*)f_5355},
{"f_3618:chicken_2dsyntax_2escm",(void*)f_3618},
{"f_7236:chicken_2dsyntax_2escm",(void*)f_7236},
{"f_6451:chicken_2dsyntax_2escm",(void*)f_6451},
{"f_7337:chicken_2dsyntax_2escm",(void*)f_7337},
{"f_7242:chicken_2dsyntax_2escm",(void*)f_7242},
{"f_7247:chicken_2dsyntax_2escm",(void*)f_7247},
{"f_7245:chicken_2dsyntax_2escm",(void*)f_7245},
{"f_3417:chicken_2dsyntax_2escm",(void*)f_3417},
{"f_3415:chicken_2dsyntax_2escm",(void*)f_3415},
{"f_3419:chicken_2dsyntax_2escm",(void*)f_3419},
{"f_6425:chicken_2dsyntax_2escm",(void*)f_6425},
{"f_6422:chicken_2dsyntax_2escm",(void*)f_6422},
{"f_6420:chicken_2dsyntax_2escm",(void*)f_6420},
{"f_7307:chicken_2dsyntax_2escm",(void*)f_7307},
{"f_3411:chicken_2dsyntax_2escm",(void*)f_3411},
{"f_3407:chicken_2dsyntax_2escm",(void*)f_3407},
{"f_3405:chicken_2dsyntax_2escm",(void*)f_3405},
{"f_3409:chicken_2dsyntax_2escm",(void*)f_3409},
{"f_8526:chicken_2dsyntax_2escm",(void*)f_8526},
{"f_7312:chicken_2dsyntax_2escm",(void*)f_7312},
{"f_6427:chicken_2dsyntax_2escm",(void*)f_6427},
{"f_3403:chicken_2dsyntax_2escm",(void*)f_3403},
{"f_3401:chicken_2dsyntax_2escm",(void*)f_3401},
{"f_7222:chicken_2dsyntax_2escm",(void*)f_7222},
{"f_7221:chicken_2dsyntax_2escm",(void*)f_7221},
{"f_3478:chicken_2dsyntax_2escm",(void*)f_3478},
{"f_3473:chicken_2dsyntax_2escm",(void*)f_3473},
{"f_3475:chicken_2dsyntax_2escm",(void*)f_3475},
{"f_3471:chicken_2dsyntax_2escm",(void*)f_3471},
{"f_3467:chicken_2dsyntax_2escm",(void*)f_3467},
{"f_3469:chicken_2dsyntax_2escm",(void*)f_3469},
{"f_3463:chicken_2dsyntax_2escm",(void*)f_3463},
{"f_3465:chicken_2dsyntax_2escm",(void*)f_3465},
{"f_3461:chicken_2dsyntax_2escm",(void*)f_3461},
{"f_9548:chicken_2dsyntax_2escm",(void*)f_9548},
{"f_9215:chicken_2dsyntax_2escm",(void*)f_9215},
{"f_3435:chicken_2dsyntax_2escm",(void*)f_3435},
{"f_3437:chicken_2dsyntax_2escm",(void*)f_3437},
{"f_3439:chicken_2dsyntax_2escm",(void*)f_3439},
{"f_3431:chicken_2dsyntax_2escm",(void*)f_3431},
{"f_3433:chicken_2dsyntax_2escm",(void*)f_3433},
{"f_9242:chicken_2dsyntax_2escm",(void*)f_9242},
{"f_3425:chicken_2dsyntax_2escm",(void*)f_3425},
{"f_3427:chicken_2dsyntax_2escm",(void*)f_3427},
{"f_3429:chicken_2dsyntax_2escm",(void*)f_3429},
{"f_7960:chicken_2dsyntax_2escm",(void*)f_7960},
{"f_3421:chicken_2dsyntax_2escm",(void*)f_3421},
{"f_3423:chicken_2dsyntax_2escm",(void*)f_3423},
{"f_3383:chicken_2dsyntax_2escm",(void*)f_3383},
{"f_3380:chicken_2dsyntax_2escm",(void*)f_3380},
{"f_7969:chicken_2dsyntax_2escm",(void*)f_7969},
{"f_3387:chicken_2dsyntax_2escm",(void*)f_3387},
{"f_3498:chicken_2dsyntax_2escm",(void*)f_3498},
{"f_3385:chicken_2dsyntax_2escm",(void*)f_3385},
{"f_3496:chicken_2dsyntax_2escm",(void*)f_3496},
{"f_3951:chicken_2dsyntax_2escm",(void*)f_3951},
{"f_3950:chicken_2dsyntax_2escm",(void*)f_3950},
{"f_9244:chicken_2dsyntax_2escm",(void*)f_9244},
{"f_9248:chicken_2dsyntax_2escm",(void*)f_9248},
{"f_3485:chicken_2dsyntax_2escm",(void*)f_3485},
{"f_3483:chicken_2dsyntax_2escm",(void*)f_3483},
{"f_3488:chicken_2dsyntax_2escm",(void*)f_3488},
{"f_3389:chicken_2dsyntax_2escm",(void*)f_3389},
{"f_7943:chicken_2dsyntax_2escm",(void*)f_7943},
{"f_3480:chicken_2dsyntax_2escm",(void*)f_3480},
{"f_9122:chicken_2dsyntax_2escm",(void*)f_9122},
{"f_3941:chicken_2dsyntax_2escm",(void*)f_3941},
{"f_7956:chicken_2dsyntax_2escm",(void*)f_7956},
{"f_7950:chicken_2dsyntax_2escm",(void*)f_7950},
{"f_9147:chicken_2dsyntax_2escm",(void*)f_9147},
{"f_3961:chicken_2dsyntax_2escm",(void*)f_3961},
{"f_3962:chicken_2dsyntax_2escm",(void*)f_3962},
{"f_3459:chicken_2dsyntax_2escm",(void*)f_3459},
{"f_3457:chicken_2dsyntax_2escm",(void*)f_3457},
{"f_3455:chicken_2dsyntax_2escm",(void*)f_3455},
{"f_3453:chicken_2dsyntax_2escm",(void*)f_3453},
{"f_3451:chicken_2dsyntax_2escm",(void*)f_3451},
{"f_9152:chicken_2dsyntax_2escm",(void*)f_9152},
{"f_5686:chicken_2dsyntax_2escm",(void*)f_5686},
{"f_3449:chicken_2dsyntax_2escm",(void*)f_3449},
{"f_3447:chicken_2dsyntax_2escm",(void*)f_3447},
{"f_3445:chicken_2dsyntax_2escm",(void*)f_3445},
{"f_3443:chicken_2dsyntax_2escm",(void*)f_3443},
{"f_8568:chicken_2dsyntax_2escm",(void*)f_8568},
{"f_3441:chicken_2dsyntax_2escm",(void*)f_3441},
{"f_8562:chicken_2dsyntax_2escm",(void*)f_8562},
{"f_3939:chicken_2dsyntax_2escm",(void*)f_3939},
{"f_8557:chicken_2dsyntax_2escm",(void*)f_8557},
{"f_8559:chicken_2dsyntax_2escm",(void*)f_8559},
{"f_9117:chicken_2dsyntax_2escm",(void*)f_9117},
{"f_9665:chicken_2dsyntax_2escm",(void*)f_9665},
{"f_9662:chicken_2dsyntax_2escm",(void*)f_9662},
{"f_9677:chicken_2dsyntax_2escm",(void*)f_9677},
{"f_3991:chicken_2dsyntax_2escm",(void*)f_3991},
{"f_7932:chicken_2dsyntax_2escm",(void*)f_7932},
{"f_7935:chicken_2dsyntax_2escm",(void*)f_7935},
{"f_7936:chicken_2dsyntax_2escm",(void*)f_7936},
{"f_7930:chicken_2dsyntax_2escm",(void*)f_7930},
{"f_6777:chicken_2dsyntax_2escm",(void*)f_6777},
{"f_3989:chicken_2dsyntax_2escm",(void*)f_3989},
{"f_3983:chicken_2dsyntax_2escm",(void*)f_3983},
{"f_6030:chicken_2dsyntax_2escm",(void*)f_6030},
{"f_6036:chicken_2dsyntax_2escm",(void*)f_6036},
{"f_6041:chicken_2dsyntax_2escm",(void*)f_6041},
{"f_6038:chicken_2dsyntax_2escm",(void*)f_6038},
{"f_4370:chicken_2dsyntax_2escm",(void*)f_4370},
{"f_6013:chicken_2dsyntax_2escm",(void*)f_6013},
{"f_6016:chicken_2dsyntax_2escm",(void*)f_6016},
{"f_4384:chicken_2dsyntax_2escm",(void*)f_4384},
{"f_7041:chicken_2dsyntax_2escm",(void*)f_7041},
{"f_4382:chicken_2dsyntax_2escm",(void*)f_4382},
{"f_3975:chicken_2dsyntax_2escm",(void*)f_3975},
{"f_5137:chicken_2dsyntax_2escm",(void*)f_5137},
{"f_4365:chicken_2dsyntax_2escm",(void*)f_4365},
{"f_7027:chicken_2dsyntax_2escm",(void*)f_7027},
{"f_5892:chicken_2dsyntax_2escm",(void*)f_5892},
{"f_4363:chicken_2dsyntax_2escm",(void*)f_4363},
{"f_5129:chicken_2dsyntax_2escm",(void*)f_5129},
{"f_4610:chicken_2dsyntax_2escm",(void*)f_4610},
{"f_4619:chicken_2dsyntax_2escm",(void*)f_4619},
{"f_7983:chicken_2dsyntax_2escm",(void*)f_7983},
{"f_7981:chicken_2dsyntax_2escm",(void*)f_7981},
{"f_7986:chicken_2dsyntax_2escm",(void*)f_7986},
{"f_5880:chicken_2dsyntax_2escm",(void*)f_5880},
{"f_5159:chicken_2dsyntax_2escm",(void*)f_5159},
{"f_5157:chicken_2dsyntax_2escm",(void*)f_5157},
{"f_5875:chicken_2dsyntax_2escm",(void*)f_5875},
{"f_5872:chicken_2dsyntax_2escm",(void*)f_5872},
{"f_5877:chicken_2dsyntax_2escm",(void*)f_5877},
{"f_4630:chicken_2dsyntax_2escm",(void*)f_4630},
{"f_4638:chicken_2dsyntax_2escm",(void*)f_4638},
{"f_6717:chicken_2dsyntax_2escm",(void*)f_6717},
{"f_5994:chicken_2dsyntax_2escm",(void*)f_5994},
{"f_4650:chicken_2dsyntax_2escm",(void*)f_4650},
{"f_8299:chicken_2dsyntax_2escm",(void*)f_8299},
{"f_5980:chicken_2dsyntax_2escm",(void*)f_5980},
{"f_5982:chicken_2dsyntax_2escm",(void*)f_5982},
{"f_5984:chicken_2dsyntax_2escm",(void*)f_5984},
{"f_5986:chicken_2dsyntax_2escm",(void*)f_5986},
{"f_5988:chicken_2dsyntax_2escm",(void*)f_5988},
{"f_5117:chicken_2dsyntax_2escm",(void*)f_5117},
{"f_4621:chicken_2dsyntax_2escm",(void*)f_4621},
{"f_9587:chicken_2dsyntax_2escm",(void*)f_9587},
{"f_5111:chicken_2dsyntax_2escm",(void*)f_5111},
{"f_5106:chicken_2dsyntax_2escm",(void*)f_5106},
{"f_5104:chicken_2dsyntax_2escm",(void*)f_5104},
{"f_6742:chicken_2dsyntax_2escm",(void*)f_6742},
{"f_4674:chicken_2dsyntax_2escm",(void*)f_4674},
{"f_9590:chicken_2dsyntax_2escm",(void*)f_9590},
{"f_6747:chicken_2dsyntax_2escm",(void*)f_6747},
{"f_4695:chicken_2dsyntax_2escm",(void*)f_4695},
{"f_4662:chicken_2dsyntax_2escm",(void*)f_4662},
{"f_9550:chicken_2dsyntax_2escm",(void*)f_9550},
{"f_9567:chicken_2dsyntax_2escm",(void*)f_9567},
{"f_9565:chicken_2dsyntax_2escm",(void*)f_9565},
{"f_9563:chicken_2dsyntax_2escm",(void*)f_9563},
{"f_4689:chicken_2dsyntax_2escm",(void*)f_4689},
{"f_9578:chicken_2dsyntax_2escm",(void*)f_9578},
{"f_5296:chicken_2dsyntax_2escm",(void*)f_5296},
{"f_5292:chicken_2dsyntax_2escm",(void*)f_5292},
{"f_8278:chicken_2dsyntax_2escm",(void*)f_8278},
{"f_8276:chicken_2dsyntax_2escm",(void*)f_8276},
{"f_5277:chicken_2dsyntax_2escm",(void*)f_5277},
{"f_5275:chicken_2dsyntax_2escm",(void*)f_5275},
{"f_9062:chicken_2dsyntax_2escm",(void*)f_9062},
{"f_8232:chicken_2dsyntax_2escm",(void*)f_8232},
{"f_4036:chicken_2dsyntax_2escm",(void*)f_4036},
{"f_8223:chicken_2dsyntax_2escm",(void*)f_8223},
{"f_8220:chicken_2dsyntax_2escm",(void*)f_8220},
{"f_8786:chicken_2dsyntax_2escm",(void*)f_8786},
{"f_4041:chicken_2dsyntax_2escm",(void*)f_4041},
{"f_9092:chicken_2dsyntax_2escm",(void*)f_9092},
{"f_8466:chicken_2dsyntax_2escm",(void*)f_8466},
{"f_8461:chicken_2dsyntax_2escm",(void*)f_8461},
{"f_7280:chicken_2dsyntax_2escm",(void*)f_7280},
{"f_7282:chicken_2dsyntax_2escm",(void*)f_7282},
{"f_7109:chicken_2dsyntax_2escm",(void*)f_7109},
{"f_7274:chicken_2dsyntax_2escm",(void*)f_7274},
{"f_7112:chicken_2dsyntax_2escm",(void*)f_7112},
{"f_4205:chicken_2dsyntax_2escm",(void*)f_4205},
{"f_4202:chicken_2dsyntax_2escm",(void*)f_4202},
{"f_4200:chicken_2dsyntax_2escm",(void*)f_4200},
{"f_4003:chicken_2dsyntax_2escm",(void*)f_4003},
{"f_8775:chicken_2dsyntax_2escm",(void*)f_8775},
{"f_8243:chicken_2dsyntax_2escm",(void*)f_8243},
{"f_7002:chicken_2dsyntax_2escm",(void*)f_7002},
{"f_4011:chicken_2dsyntax_2escm",(void*)f_4011},
{"f_4220:chicken_2dsyntax_2escm",(void*)f_4220},
{"f_4237:chicken_2dsyntax_2escm",(void*)f_4237},
{"f_4234:chicken_2dsyntax_2escm",(void*)f_4234},
{"f_7268:chicken_2dsyntax_2escm",(void*)f_7268},
{"f_7266:chicken_2dsyntax_2escm",(void*)f_7266},
{"f_4232:chicken_2dsyntax_2escm",(void*)f_4232},
{"f_4245:chicken_2dsyntax_2escm",(void*)f_4245},
{"f_8706:chicken_2dsyntax_2escm",(void*)f_8706},
{"f_8708:chicken_2dsyntax_2escm",(void*)f_8708},
{"f_5497:chicken_2dsyntax_2escm",(void*)f_5497},
{"f_8733:chicken_2dsyntax_2escm",(void*)f_8733},
{"f_5492:chicken_2dsyntax_2escm",(void*)f_5492},
{"f_8761:chicken_2dsyntax_2escm",(void*)f_8761},
{"f_8719:chicken_2dsyntax_2escm",(void*)f_8719},
{"f_8717:chicken_2dsyntax_2escm",(void*)f_8717},
{"f_8714:chicken_2dsyntax_2escm",(void*)f_8714},
{"f_5467:chicken_2dsyntax_2escm",(void*)f_5467},
{"f_5465:chicken_2dsyntax_2escm",(void*)f_5465},
{"f_9414:chicken_2dsyntax_2escm",(void*)f_9414},
{"f_8496:chicken_2dsyntax_2escm",(void*)f_8496},
{"f_8491:chicken_2dsyntax_2escm",(void*)f_8491},
{"f_8725:chicken_2dsyntax_2escm",(void*)f_8725},
{"f_4994:chicken_2dsyntax_2escm",(void*)f_4994},
{"f_9401:chicken_2dsyntax_2escm",(void*)f_9401},
{"f_4996:chicken_2dsyntax_2escm",(void*)f_4996},
{"f_4974:chicken_2dsyntax_2escm",(void*)f_4974},
{"f_6350:chicken_2dsyntax_2escm",(void*)f_6350},
{"f_6359:chicken_2dsyntax_2escm",(void*)f_6359},
{"f_3754:chicken_2dsyntax_2escm",(void*)f_3754},
{"f_8436:chicken_2dsyntax_2escm",(void*)f_8436},
{"f_8744:chicken_2dsyntax_2escm",(void*)f_8744},
{"f_9305:chicken_2dsyntax_2escm",(void*)f_9305},
{"f_6325:chicken_2dsyntax_2escm",(void*)f_6325},
{"f_6327:chicken_2dsyntax_2escm",(void*)f_6327},
{"f_9314:chicken_2dsyntax_2escm",(void*)f_9314},
{"f_9316:chicken_2dsyntax_2escm",(void*)f_9316},
{"f_9319:chicken_2dsyntax_2escm",(void*)f_9319},
{"f_3703:chicken_2dsyntax_2escm",(void*)f_3703},
{"f_8405:chicken_2dsyntax_2escm",(void*)f_8405},
{"f_3716:chicken_2dsyntax_2escm",(void*)f_3716},
{"f_9328:chicken_2dsyntax_2escm",(void*)f_9328},
{"f_3733:chicken_2dsyntax_2escm",(void*)f_3733},
{"f_3705:chicken_2dsyntax_2escm",(void*)f_3705},
{"f_9339:chicken_2dsyntax_2escm",(void*)f_9339},
{"f_8969:chicken_2dsyntax_2escm",(void*)f_8969},
{"f_9330:chicken_2dsyntax_2escm",(void*)f_9330},
{"f_8213:chicken_2dsyntax_2escm",(void*)f_8213},
{"f_8214:chicken_2dsyntax_2escm",(void*)f_8214},
{"f_9344:chicken_2dsyntax_2escm",(void*)f_9344},
{"f_8958:chicken_2dsyntax_2escm",(void*)f_8958},
{"f_8956:chicken_2dsyntax_2escm",(void*)f_8956},
{"f_9341:chicken_2dsyntax_2escm",(void*)f_9341},
{"f_8201:chicken_2dsyntax_2escm",(void*)f_8201},
{"f_8202:chicken_2dsyntax_2escm",(void*)f_8202},
{"f_8208:chicken_2dsyntax_2escm",(void*)f_8208},
{"f_8949:chicken_2dsyntax_2escm",(void*)f_8949},
{"f_8946:chicken_2dsyntax_2escm",(void*)f_8946},
{"f_4954:chicken_2dsyntax_2escm",(void*)f_4954},
{"f_5786:chicken_2dsyntax_2escm",(void*)f_5786},
{"f_5784:chicken_2dsyntax_2escm",(void*)f_5784},
{"f_5789:chicken_2dsyntax_2escm",(void*)f_5789},
{"f_4966:chicken_2dsyntax_2escm",(void*)f_4966},
{"f_3760:chicken_2dsyntax_2escm",(void*)f_3760},
{"f_8923:chicken_2dsyntax_2escm",(void*)f_8923},
{"f_5775:chicken_2dsyntax_2escm",(void*)f_5775},
{"f_5778:chicken_2dsyntax_2escm",(void*)f_5778},
{"f_3777:chicken_2dsyntax_2escm",(void*)f_3777},
{"f_3813:chicken_2dsyntax_2escm",(void*)f_3813},
{"f_6575:chicken_2dsyntax_2escm",(void*)f_6575},
{"f_3769:chicken_2dsyntax_2escm",(void*)f_3769},
{"f_8906:chicken_2dsyntax_2escm",(void*)f_8906},
{"f_3843:chicken_2dsyntax_2escm",(void*)f_3843},
{"f_5793:chicken_2dsyntax_2escm",(void*)f_5793},
{"f_5791:chicken_2dsyntax_2escm",(void*)f_5791},
{"f_6588:chicken_2dsyntax_2escm",(void*)f_6588},
{"f_3827:chicken_2dsyntax_2escm",(void*)f_3827},
{"f_3825:chicken_2dsyntax_2escm",(void*)f_3825},
{"f_3786:chicken_2dsyntax_2escm",(void*)f_3786},
{"f_3788:chicken_2dsyntax_2escm",(void*)f_3788},
{"f_4174:chicken_2dsyntax_2escm",(void*)f_4174},
{"f_5311:chicken_2dsyntax_2escm",(void*)f_5311},
{"f_6284:chicken_2dsyntax_2escm",(void*)f_6284},
{"f_6287:chicken_2dsyntax_2escm",(void*)f_6287},
{"f_5305:chicken_2dsyntax_2escm",(void*)f_5305},
{"f_5308:chicken_2dsyntax_2escm",(void*)f_5308},
{"f_6281:chicken_2dsyntax_2escm",(void*)f_6281},
{"f_9712:chicken_2dsyntax_2escm",(void*)f_9712},
{"f_9716:chicken_2dsyntax_2escm",(void*)f_9716},
{"f_5302:chicken_2dsyntax_2escm",(void*)f_5302},
{"f_6298:chicken_2dsyntax_2escm",(void*)f_6298},
{"f_6296:chicken_2dsyntax_2escm",(void*)f_6296},
{"f_6290:chicken_2dsyntax_2escm",(void*)f_6290},
{"f_4154:chicken_2dsyntax_2escm",(void*)f_4154},
{"f_8939:chicken_2dsyntax_2escm",(void*)f_8939},
{"f_5624:chicken_2dsyntax_2escm",(void*)f_5624},
{"f_4131:chicken_2dsyntax_2escm",(void*)f_4131},
{"f_4165:chicken_2dsyntax_2escm",(void*)f_4165},
{"f_9692:chicken_2dsyntax_2escm",(void*)f_9692},
{"f_9697:chicken_2dsyntax_2escm",(void*)f_9697},
{"f_6278:chicken_2dsyntax_2escm",(void*)f_6278},
{"f_8036:chicken_2dsyntax_2escm",(void*)f_8036},
{"f_4940:chicken_2dsyntax_2escm",(void*)f_4940},
{"f_4945:chicken_2dsyntax_2escm",(void*)f_4945},
{"f_4938:chicken_2dsyntax_2escm",(void*)f_4938},
{"f_9752:chicken_2dsyntax_2escm",(void*)f_9752},
{"f_8022:chicken_2dsyntax_2escm",(void*)f_8022},
{"f_4913:chicken_2dsyntax_2escm",(void*)f_4913},
{"f_4916:chicken_2dsyntax_2escm",(void*)f_4916},
{"f_4911:chicken_2dsyntax_2escm",(void*)f_4911},
{"f_3874:chicken_2dsyntax_2escm",(void*)f_3874},
{"f_5662:chicken_2dsyntax_2escm",(void*)f_5662},
{"f_4920:chicken_2dsyntax_2escm",(void*)f_4920},
{"f_4922:chicken_2dsyntax_2escm",(void*)f_4922},
{"f_6514:chicken_2dsyntax_2escm",(void*)f_6514},
{"f_6511:chicken_2dsyntax_2escm",(void*)f_6511},
{"f_4918:chicken_2dsyntax_2escm",(void*)f_4918},
{"f_6519:chicken_2dsyntax_2escm",(void*)f_6519},
{"f_6517:chicken_2dsyntax_2escm",(void*)f_6517},
{"f_4929:chicken_2dsyntax_2escm",(void*)f_4929},
{"f_6537:chicken_2dsyntax_2escm",(void*)f_6537},
{"f_3888:chicken_2dsyntax_2escm",(void*)f_3888},
{"f_5635:chicken_2dsyntax_2escm",(void*)f_5635},
{"f_7794:chicken_2dsyntax_2escm",(void*)f_7794},
{"f_5637:chicken_2dsyntax_2escm",(void*)f_5637},
{"f_7789:chicken_2dsyntax_2escm",(void*)f_7789},
{"f_6301:chicken_2dsyntax_2escm",(void*)f_6301},
{"f_6552:chicken_2dsyntax_2escm",(void*)f_6552},
{"f_5554:chicken_2dsyntax_2escm",(void*)f_5554},
{"f_5552:chicken_2dsyntax_2escm",(void*)f_5552},
{"f_5558:chicken_2dsyntax_2escm",(void*)f_5558},
{"f_5550:chicken_2dsyntax_2escm",(void*)f_5550},
{"f_6558:chicken_2dsyntax_2escm",(void*)f_6558},
{"toplevel:chicken_2dsyntax_2escm",(void*)C_chicken_2dsyntax_toplevel},
{"f_6310:chicken_2dsyntax_2escm",(void*)f_6310},
{"f_6312:chicken_2dsyntax_2escm",(void*)f_6312},
{"f_6314:chicken_2dsyntax_2escm",(void*)f_6314},
{"f_6316:chicken_2dsyntax_2escm",(void*)f_6316},
{"f_6561:chicken_2dsyntax_2escm",(void*)f_6561},
{"f_5542:chicken_2dsyntax_2escm",(void*)f_5542},
{"f_4710:chicken_2dsyntax_2escm",(void*)f_4710},
{"f_5544:chicken_2dsyntax_2escm",(void*)f_5544},
{"f_5546:chicken_2dsyntax_2escm",(void*)f_5546},
{"f_5548:chicken_2dsyntax_2escm",(void*)f_5548},
{"f_6569:chicken_2dsyntax_2escm",(void*)f_6569},
{"f_4720:chicken_2dsyntax_2escm",(void*)f_4720},
{"f_7858:chicken_2dsyntax_2escm",(void*)f_7858},
{"f_5562:chicken_2dsyntax_2escm",(void*)f_5562},
{"f_7863:chicken_2dsyntax_2escm",(void*)f_7863},
{"f_5560:chicken_2dsyntax_2escm",(void*)f_5560},
{"f_7833:chicken_2dsyntax_2escm",(void*)f_7833},
{"f_8193:chicken_2dsyntax_2escm",(void*)f_8193},
{"f_8198:chicken_2dsyntax_2escm",(void*)f_8198},
{"f_8191:chicken_2dsyntax_2escm",(void*)f_8191},
{"f_4768:chicken_2dsyntax_2escm",(void*)f_4768},
{"f_8185:chicken_2dsyntax_2escm",(void*)f_8185},
{"f_4766:chicken_2dsyntax_2escm",(void*)f_4766},
{"f_7828:chicken_2dsyntax_2escm",(void*)f_7828},
{"f_9275:chicken_2dsyntax_2escm",(void*)f_9275},
{"f_7822:chicken_2dsyntax_2escm",(void*)f_7822},
{"f_6414:chicken_2dsyntax_2escm",(void*)f_6414},
{"f_7764:chicken_2dsyntax_2escm",(void*)f_7764},
{"f_6060:chicken_2dsyntax_2escm",(void*)f_6060},
{"f_6257:chicken_2dsyntax_2escm",(void*)f_6257},
{"f_7740:chicken_2dsyntax_2escm",(void*)f_7740},
{"f_6058:chicken_2dsyntax_2escm",(void*)f_6058},
{"f_4774:chicken_2dsyntax_2escm",(void*)f_4774},
{"f_4789:chicken_2dsyntax_2escm",(void*)f_4789},
{"f_7094:chicken_2dsyntax_2escm",(void*)f_7094},
{"f_7584:chicken_2dsyntax_2escm",(void*)f_7584},
{"f_7587:chicken_2dsyntax_2escm",(void*)f_7587},
{"f_5010:chicken_2dsyntax_2escm",(void*)f_5010},
{"f_4782:chicken_2dsyntax_2escm",(void*)f_4782},
{"f_6222:chicken_2dsyntax_2escm",(void*)f_6222},
{"f_9257:chicken_2dsyntax_2escm",(void*)f_9257},
{"f_5016:chicken_2dsyntax_2escm",(void*)f_5016},
{"f_9749:chicken_2dsyntax_2escm",(void*)f_9749},
{"f_9747:chicken_2dsyntax_2escm",(void*)f_9747},
{"f_6230:chicken_2dsyntax_2escm",(void*)f_6230},
{"f_9741:chicken_2dsyntax_2escm",(void*)f_9741},
{"f_6232:chicken_2dsyntax_2escm",(void*)f_6232},
{"f_5537:chicken_2dsyntax_2escm",(void*)f_5537},
{"f_5539:chicken_2dsyntax_2escm",(void*)f_5539},
{"f_5531:chicken_2dsyntax_2escm",(void*)f_5531},
{"f_7701:chicken_2dsyntax_2escm",(void*)f_7701},
{"f_8165:chicken_2dsyntax_2escm",(void*)f_8165},
{"f_8167:chicken_2dsyntax_2escm",(void*)f_8167},
{"f_6214:chicken_2dsyntax_2escm",(void*)f_6214},
{"f_7710:chicken_2dsyntax_2escm",(void*)f_7710},
{"f_6071:chicken_2dsyntax_2escm",(void*)f_6071},
{"f_9298:chicken_2dsyntax_2escm",(void*)f_9298},
{"f_7618:chicken_2dsyntax_2escm",(void*)f_7618},
{"f_7617:chicken_2dsyntax_2escm",(void*)f_7617},
{"f_7612:chicken_2dsyntax_2escm",(void*)f_7612},
{"f_9290:chicken_2dsyntax_2escm",(void*)f_9290},
{"f_7074:chicken_2dsyntax_2escm",(void*)f_7074},
{"f_7071:chicken_2dsyntax_2escm",(void*)f_7071},
{"f_7086:chicken_2dsyntax_2escm",(void*)f_7086},
{"f_7626:chicken_2dsyntax_2escm",(void*)f_7626},
{"f_7078:chicken_2dsyntax_2escm",(void*)f_7078},
{"f_4489:chicken_2dsyntax_2escm",(void*)f_4489},
{"f_8124:chicken_2dsyntax_2escm",(void*)f_8124},
{"f_8122:chicken_2dsyntax_2escm",(void*)f_8122},
{"f_8127:chicken_2dsyntax_2escm",(void*)f_8127},
{"f_4491:chicken_2dsyntax_2escm",(void*)f_4491},
{"f_6188:chicken_2dsyntax_2escm",(void*)f_6188},
{"f_7609:chicken_2dsyntax_2escm",(void*)f_7609},
{"f_9188:chicken_2dsyntax_2escm",(void*)f_9188},
{"f_7603:chicken_2dsyntax_2escm",(void*)f_7603},
{"f_7602:chicken_2dsyntax_2escm",(void*)f_7602},
{"f_7600:chicken_2dsyntax_2escm",(void*)f_7600},
{"f_9183:chicken_2dsyntax_2escm",(void*)f_9183},
{"f_9185:chicken_2dsyntax_2escm",(void*)f_9185},
{"f_9197:chicken_2dsyntax_2escm",(void*)f_9197},
{"f_7654:chicken_2dsyntax_2escm",(void*)f_7654},
{"f_7665:chicken_2dsyntax_2escm",(void*)f_7665},
{"f_7667:chicken_2dsyntax_2escm",(void*)f_7667},
{"f_7660:chicken_2dsyntax_2escm",(void*)f_7660},
{"f_7213:chicken_2dsyntax_2escm",(void*)f_7213},
{"f_7216:chicken_2dsyntax_2escm",(void*)f_7216},
{"f_6025:chicken_2dsyntax_2escm",(void*)f_6025},
{"f_7639:chicken_2dsyntax_2escm",(void*)f_7639},
{"f_7637:chicken_2dsyntax_2escm",(void*)f_7637},
{"f_7631:chicken_2dsyntax_2escm",(void*)f_7631},
{"f_8672:chicken_2dsyntax_2escm",(void*)f_8672},
{"f_7054:chicken_2dsyntax_2escm",(void*)f_7054},
{"f_8679:chicken_2dsyntax_2escm",(void*)f_8679},
{"f_8673:chicken_2dsyntax_2escm",(void*)f_8673},
{"f_6028:chicken_2dsyntax_2escm",(void*)f_6028},
{"f_7069:chicken_2dsyntax_2escm",(void*)f_7069},
{"f_7084:chicken_2dsyntax_2escm",(void*)f_7084},
{"f_5229:chicken_2dsyntax_2escm",(void*)f_5229},
{"f_5223:chicken_2dsyntax_2escm",(void*)f_5223},
{"f_6003:chicken_2dsyntax_2escm",(void*)f_6003},
{"f_6005:chicken_2dsyntax_2escm",(void*)f_6005},
{"f_8150:chicken_2dsyntax_2escm",(void*)f_8150},
{"f_5257:chicken_2dsyntax_2escm",(void*)f_5257},
{"f_7200:chicken_2dsyntax_2escm",(void*)f_7200},
{"f_7207:chicken_2dsyntax_2escm",(void*)f_7207},
{"f_7206:chicken_2dsyntax_2escm",(void*)f_7206},
{"f_8145:chicken_2dsyntax_2escm",(void*)f_8145},
{"f_5252:chicken_2dsyntax_2escm",(void*)f_5252},
{"f_5250:chicken_2dsyntax_2escm",(void*)f_5250},
{"f_8147:chicken_2dsyntax_2escm",(void*)f_8147},
{"f_8682:chicken_2dsyntax_2escm",(void*)f_8682},
{"f_8688:chicken_2dsyntax_2escm",(void*)f_8688},
{"f_8636:chicken_2dsyntax_2escm",(void*)f_8636},
{"f_5234:chicken_2dsyntax_2escm",(void*)f_5234},
{"f_5231:chicken_2dsyntax_2escm",(void*)f_5231},
{"f_6102:chicken_2dsyntax_2escm",(void*)f_6102},
{"f_8669:chicken_2dsyntax_2escm",(void*)f_8669},
{"f_8663:chicken_2dsyntax_2escm",(void*)f_8663},
{"f_8662:chicken_2dsyntax_2escm",(void*)f_8662},
{"f_4420:chicken_2dsyntax_2escm",(void*)f_4420},
{"f_4422:chicken_2dsyntax_2escm",(void*)f_4422},
{"f_4424:chicken_2dsyntax_2escm",(void*)f_4424},
{"f_4426:chicken_2dsyntax_2escm",(void*)f_4426},
{"f_6157:chicken_2dsyntax_2escm",(void*)f_6157},
{"f_8613:chicken_2dsyntax_2escm",(void*)f_8613},
{"f_3567:chicken_2dsyntax_2escm",(void*)f_3567},
{"f_9500:chicken_2dsyntax_2escm",(void*)f_9500},
{"f_3561:chicken_2dsyntax_2escm",(void*)f_3561},
{"f_8648:chicken_2dsyntax_2escm",(void*)f_8648},
{"f_5246:chicken_2dsyntax_2escm",(void*)f_5246},
{"f_5244:chicken_2dsyntax_2escm",(void*)f_5244},
{"f_3518:chicken_2dsyntax_2escm",(void*)f_3518},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}

/*
S|applied compiler syntax:
S|  for-each		1
S|  ##sys#map		10
S|  map		37
o|eliminated procedure checks: 653 
o|specializations:
o|  1 (caddr (pair * (pair * pair)))
o|  3 (cadr (pair * pair))
o|  1 (zero? fixnum)
o|  2 (length list)
o|  24 (##sys#check-list (or pair list) *)
o|  6 (cdddr (pair * (pair * pair)))
o|  2 (string-append string string)
o|  48 (cdr pair)
o|  23 (car pair)
o|  17 (cddr (pair * pair))
o|Removed `not' forms: 12 
o|inlining procedure: k3489 
o|inlining procedure: k3489 
o|inlining procedure: k3576 
o|inlining procedure: k3576 
o|inlining procedure: k3596 
o|inlining procedure: k3596 
o|inlining procedure: k3634 
o|inlining procedure: k3665 
o|inlining procedure: k3708 
o|inlining procedure: k3708 
o|inlining procedure: k3761 
o|inlining procedure: k3761 
o|inlining procedure: k3768 
o|propagated global variable: g23842385 ##compiler#check-and-validate-type 
o|inlining procedure: k3791 
o|inlining procedure: k3791 
o|inlining procedure: k3768 
o|inlining procedure: k3830 
o|inlining procedure: k3830 
o|inlining procedure: k3665 
o|inlining procedure: k3869 
o|inlining procedure: k3869 
o|inlining procedure: k3901 
o|inlining procedure: k3901 
o|inlining procedure: k3634 
o|inlining procedure: k3945 
o|inlining procedure: k4014 
o|inlining procedure: k4014 
o|inlining procedure: k4044 
o|inlining procedure: k4044 
o|inlining procedure: k3945 
o|inlining procedure: k4076 
o|inlining procedure: k4090 
o|inlining procedure: k4106 
o|inlining procedure: k4106 
o|inlining procedure: k4090 
o|inlining procedure: k4076 
o|inlining procedure: k4134 
o|inlining procedure: k4150 
o|inlining procedure: k4150 
o|inlining procedure: k4180 
o|inlining procedure: k4180 
o|inlining procedure: k4134 
o|inlining procedure: k4206 
o|inlining procedure: k4206 
o|inlining procedure: k4238 
o|contracted procedure: k4265 
o|inlining procedure: k4262 
o|inlining procedure: k4287 
o|inlining procedure: k4287 
o|inlining procedure: k4262 
o|inlining procedure: k4238 
o|inlining procedure: k4387 
o|inlining procedure: k4387 
o|inlining procedure: k4445 
o|inlining procedure: k4445 
o|inlining procedure: k4460 
o|inlining procedure: k4460 
o|inlining procedure: k4495 
o|inlining procedure: k4495 
o|inlining procedure: k4520 
o|inlining procedure: k4534 
o|inlining procedure: k4550 
o|inlining procedure: k4550 
o|inlining procedure: k4534 
o|inlining procedure: k4520 
o|inlining procedure: k4578 
o|inlining procedure: k4594 
o|inlining procedure: k4594 
o|inlining procedure: k4578 
o|inlining procedure: k4625 
o|inlining procedure: k4625 
o|inlining procedure: k4705 
o|inlining procedure: k4705 
o|inlining procedure: k4738 
o|inlining procedure: k4738 
o|inlining procedure: k4753 
o|inlining procedure: k4769 
o|inlining procedure: k4785 
o|inlining procedure: k4785 
o|inlining procedure: k4769 
o|inlining procedure: k4753 
o|inlining procedure: k4864 
o|inlining procedure: k4864 
o|inlining procedure: k4932 
o|inlining procedure: k4932 
o|inlining procedure: k5011 
o|inlining procedure: k5011 
o|inlining procedure: k5098 
o|inlining procedure: k5098 
o|inlining procedure: k5174 
o|inlining procedure: k5174 
o|inlining procedure: k5280 
o|inlining procedure: k5280 
o|inlining procedure: k5317 
o|inlining procedure: k5317 
o|inlining procedure: k5351 
o|inlining procedure: k5351 
o|inlining procedure: k5410 
o|inlining procedure: k5410 
o|inlining procedure: k5456 
o|inlining procedure: k5456 
o|inlining procedure: k5470 
o|inlining procedure: k5470 
o|inlining procedure: k5500 
o|inlining procedure: k5500 
o|inlining procedure: k5563 
o|inlining procedure: k5573 
o|inlining procedure: k5573 
o|inlining procedure: k5563 
o|inlining procedure: k5600 
o|inlining procedure: k5600 
o|inlining procedure: k5640 
o|inlining procedure: k5640 
o|inlining procedure: k5726 
o|inlining procedure: k5726 
o|inlining procedure: k5885 
o|inlining procedure: k5885 
o|inlining procedure: k5949 
o|inlining procedure: k5949 
o|inlining procedure: k6042 
o|inlining procedure: k6042 
o|inlining procedure: k6063 
o|inlining procedure: k6063 
o|inlining procedure: k6105 
o|inlining procedure: k6128 
o|inlining procedure: k6128 
o|inlining procedure: k6105 
o|inlining procedure: k6156 
o|inlining procedure: k6156 
o|inlining procedure: k6189 
o|inlining procedure: k6189 
o|inlining procedure: k6235 
o|inlining procedure: k6235 
o|inlining procedure: k6330 
o|inlining procedure: k6330 
o|removed unused formal parameters: (rename1388) 
o|inlining procedure: k6578 
o|inlining procedure: k6578 
o|removed unused parameter to known procedure: rename1388 "(chicken-syntax.scm:676) make-if-tree1368" 
o|contracted procedure: "(chicken-syntax.scm:674) make-default-procs1367" 
o|inlining procedure: k6522 
o|inlining procedure: k6522 
o|inlining procedure: k6720 
o|inlining procedure: k6720 
o|inlining procedure: k6750 
o|inlining procedure: k6750 
o|inlining procedure: k6780 
o|inlining procedure: k6780 
o|inlining procedure: k6810 
o|inlining procedure: k6810 
o|inlining procedure: k6879 
o|inlining procedure: k6879 
o|inlining procedure: k6899 
o|inlining procedure: k6899 
o|inlining procedure: k6951 
o|inlining procedure: k6951 
o|inlining procedure: k7005 
o|inlining procedure: k7005 
o|inlining procedure: k7028 
o|inlining procedure: k7028 
o|inlining procedure: k7085 
o|inlining procedure: k7085 
o|inlining procedure: k7098 
o|inlining procedure: k7098 
o|inlining procedure: k7285 
o|inlining procedure: k7285 
o|inlining procedure: k7315 
o|inlining procedure: k7315 
o|inlining procedure: k7351 
o|inlining procedure: k7351 
o|inlining procedure: k7381 
o|inlining procedure: k7381 
o|inlining procedure: k7411 
o|inlining procedure: k7411 
o|inlining procedure: k7451 
o|inlining procedure: k7451 
o|inlining procedure: k7498 
o|inlining procedure: k7498 
o|inlining procedure: k7539 
o|inlining procedure: k7539 
o|inlining procedure: k7565 
o|inlining procedure: k7565 
o|inlining procedure: k7642 
o|inlining procedure: k7670 
o|inlining procedure: k7670 
o|inlining procedure: k7642 
o|inlining procedure: k7767 
o|inlining procedure: k7767 
o|inlining procedure: k7797 
o|inlining procedure: k7797 
o|inlining procedure: k7836 
o|inlining procedure: k7836 
o|inlining procedure: k7866 
o|inlining procedure: k7866 
o|inlining procedure: k7886 
o|inlining procedure: k7886 
o|inlining procedure: k7902 
o|inlining procedure: k7902 
o|inlining procedure: k7963 
o|inlining procedure: k7963 
o|inlining procedure: k7991 
o|inlining procedure: k7991 
o|inlining procedure: k8049 
o|inlining procedure: k8049 
o|inlining procedure: k8091 
o|inlining procedure: k8091 
o|contracted procedure: "(chicken-syntax.scm:286) pname525" 
o|inlining procedure: k8173 
o|inlining procedure: k8173 
o|inlining procedure: k8310 
o|inlining procedure: k8310 
o|inlining procedure: k8355 
o|inlining procedure: k8355 
o|inlining procedure: k8397 
o|inlining procedure: k8397 
o|inlining procedure: k8439 
o|inlining procedure: k8439 
o|inlining procedure: k8469 
o|inlining procedure: k8469 
o|inlining procedure: k8499 
o|inlining procedure: k8499 
o|inlining procedure: k8529 
o|inlining procedure: k8529 
o|inlining procedure: k8575 
o|inlining procedure: k8590 
o|inlining procedure: k8590 
o|inlining procedure: k8575 
o|inlining procedure: k8606 
o|inlining procedure: k8624 
o|inlining procedure: k8624 
o|inlining procedure: k8606 
o|inlining procedure: k8736 
o|inlining procedure: k8736 
o|inlining procedure: k8778 
o|inlining procedure: k8778 
o|inlining procedure: k8856 
o|inlining procedure: k8856 
o|inlining procedure: k8898 
o|inlining procedure: k8898 
o|inlining procedure: k8961 
o|inlining procedure: k8961 
o|inlining procedure: k9005 
o|inlining procedure: k9005 
o|inlining procedure: k9023 
o|inlining procedure: k9023 
o|inlining procedure: k9065 
o|inlining procedure: k9065 
o|inlining procedure: k9095 
o|inlining procedure: k9095 
o|inlining procedure: k9125 
o|inlining procedure: k9125 
o|inlining procedure: k9155 
o|inlining procedure: k9155 
o|inlining procedure: k9217 
o|inlining procedure: k9217 
o|inlining procedure: k9274 
o|inlining procedure: k9274 
o|inlining procedure: k9299 
o|inlining procedure: k9299 
o|inlining procedure: k9383 
o|inlining procedure: k9383 
o|inlining procedure: k9475 
o|inlining procedure: k9475 
o|inlining procedure: k9495 
o|inlining procedure: k9507 
o|inlining procedure: k9507 
o|inlining procedure: k9495 
o|inlining procedure: k9553 
o|inlining procedure: k9553 
o|inlining procedure: k9598 
o|inlining procedure: k9598 
o|inlining procedure: k9667 
o|inlining procedure: k9667 
o|substituted constant variable: a9694 
o|substituted constant variable: a9713 
o|inlining procedure: k9719 
o|inlining procedure: k9719 
o|replaced variables: 554 
o|removed binding forms: 181 
o|substituted constant variable: r34909760 
o|substituted constant variable: r37629771 
o|substituted constant variable: r37629771 
o|substituted constant variable: f_38299777 
o|substituted constant variable: r39029783 
o|substituted constant variable: f_36339784 
o|substituted constant variable: r40919795 
o|substituted constant variable: r40779796 
o|substituted constant variable: r41819801 
o|substituted constant variable: r41359802 
o|substituted constant variable: a42869808 
o|substituted constant variable: r42399810 
o|substituted constant variable: r44469813 
o|substituted constant variable: r44469813 
o|substituted constant variable: r45359825 
o|substituted constant variable: r45219826 
o|substituted constant variable: r45799830 
o|substituted constant variable: r47399836 
o|substituted constant variable: r47709841 
o|substituted constant variable: r47549842 
o|substituted constant variable: f_52799853 
o|substituted constant variable: r54119860 
o|substituted constant variable: f_54559862 
o|converted assignments to bindings: (parse-clause1742) 
o|substituted constant variable: f_59489879 
o|substituted constant variable: r61909891 
o|converted assignments to bindings: (genvars1579) 
o|substituted constant variable: f_65219899 
o|converted assignments to bindings: (make-if-tree1368) 
o|substituted constant variable: f_68789909 
o|substituted constant variable: r70999927 
o|converted assignments to bindings: (quotify-proc1248) 
o|substituted constant variable: f_75649945 
o|substituted constant variable: f_900410005 
o|substituted constant variable: r930010022 
o|substituted constant variable: r950810029 
o|substituted constant variable: r949610030 
o|simplifications: ((let . 4)) 
o|replaced variables: 10 
o|removed binding forms: 586 
o|inlining procedure: k8612 
o|inlining procedure: k8612 
o|inlining procedure: k8612 
o|replaced variables: 1 
o|removed binding forms: 41 
o|removed binding forms: 4 
o|simplifications: ((if . 24) (##core#call . 1135)) 
o|  call simplifications:
o|    string?
o|    length
o|    fx>
o|    cdar
o|    caar
o|    assq	2
o|    not	3
o|    apply	2
o|    fx-	2
o|    fx>=
o|    cddddr
o|    cddr	6
o|    add1
o|    ##sys#call-with-values	2
o|    ##sys#pair?	9
o|    ##sys#eq?	8
o|    ##sys#cdr	28
o|    ##sys#car	19
o|    cdddr	2
o|    cadddr	2
o|    list?	3
o|    fx=
o|    symbol?	8
o|    null?	32
o|    vector
o|    cdr	20
o|    fx+	3
o|    ##sys#check-list	36
o|    pair?	84
o|    cons	75
o|    ##sys#setslot	47
o|    ##sys#slot	129
o|    car	46
o|    eq?	7
o|    list	9
o|    ##sys#cons	155
o|    memq	7
o|    cadr	50
o|    caddr	17
o|    ##sys#list	312
o|contracted procedure: k3492 
o|contracted procedure: k3508 
o|contracted procedure: k3511 
o|contracted procedure: k3514 
o|contracted procedure: k3505 
o|contracted procedure: k3520 
o|contracted procedure: k3523 
o|contracted procedure: k3536 
o|contracted procedure: k3626 
o|contracted procedure: k3623 
o|contracted procedure: k3546 
o|contracted procedure: k3569 
o|contracted procedure: k3573 
o|contracted procedure: k3583 
o|contracted procedure: k3587 
o|contracted procedure: k3555 
o|contracted procedure: k3552 
o|contracted procedure: k3549 
o|contracted procedure: k3598 
o|contracted procedure: k3601 
o|contracted procedure: k3610 
o|contracted procedure: k3620 
o|contracted procedure: k3636 
o|contracted procedure: k3641 
o|contracted procedure: k3643 
o|contracted procedure: k3656 
o|contracted procedure: k3667 
o|contracted procedure: k3674 
o|contracted procedure: k3747 
o|contracted procedure: k3750 
o|contracted procedure: k3682 
o|contracted procedure: k3688 
o|contracted procedure: k3699 
o|contracted procedure: k3691 
o|contracted procedure: k3685 
o|contracted procedure: k3740 
o|contracted procedure: k3710 
o|contracted procedure: k3713 
o|contracted procedure: k3722 
o|contracted procedure: k3725 
o|contracted procedure: k3735 
o|contracted procedure: k3738 
o|contracted procedure: k3765 
o|contracted procedure: k3756 
o|contracted procedure: k3770 
o|contracted procedure: k3782 
o|contracted procedure: k3793 
o|contracted procedure: k3796 
o|contracted procedure: k3805 
o|contracted procedure: k3815 
o|contracted procedure: k3832 
o|contracted procedure: k3839 
o|contracted procedure: k3845 
o|contracted procedure: k3848 
o|contracted procedure: k3850 
o|contracted procedure: k3855 
o|contracted procedure: k3864 
o|contracted procedure: k3867 
o|contracted procedure: k3893 
o|contracted procedure: k3881 
o|contracted procedure: k3884 
o|contracted procedure: k3890 
o|contracted procedure: k3898 
o|contracted procedure: k3904 
o|contracted procedure: k3911 
o|contracted procedure: k3932 
o|contracted procedure: k3921 
o|contracted procedure: k3943 
o|contracted procedure: k3955 
o|contracted procedure: k3957 
o|contracted procedure: k3967 
o|contracted procedure: k3969 
o|contracted procedure: k3971 
o|contracted procedure: k3976 
o|contracted procedure: k3985 
o|contracted procedure: k4008 
o|contracted procedure: k4005 
o|contracted procedure: k3999 
o|contracted procedure: k3996 
o|contracted procedure: k4016 
o|contracted procedure: k4019 
o|contracted procedure: k4028 
o|contracted procedure: k4038 
o|contracted procedure: k4046 
o|contracted procedure: k4049 
o|contracted procedure: k4058 
o|contracted procedure: k4068 
o|contracted procedure: k4073 
o|contracted procedure: k4100 
o|contracted procedure: k4118 
o|contracted procedure: k4124 
o|contracted procedure: k4127 
o|contracted procedure: k4144 
o|contracted procedure: k4161 
o|contracted procedure: k4170 
o|contracted procedure: k4175 
o|contracted procedure: k4178 
o|contracted procedure: k4183 
o|contracted procedure: k4190 
o|contracted procedure: k4193 
o|contracted procedure: k4196 
o|contracted procedure: k4209 
o|contracted procedure: k4222 
o|contracted procedure: k4225 
o|contracted procedure: k4241 
o|contracted procedure: k4246 
o|contracted procedure: k4311 
o|contracted procedure: k4308 
o|contracted procedure: k4305 
o|contracted procedure: k4278 
o|contracted procedure: k4275 
o|contracted procedure: k4296 
o|contracted procedure: k4293 
o|contracted procedure: k4287 
o|contracted procedure: k4302 
o|contracted procedure: k4314 
o|contracted procedure: k4329 
o|contracted procedure: k4331 
o|contracted procedure: k4333 
o|contracted procedure: k4350 
o|contracted procedure: k4367 
o|contracted procedure: k4375 
o|contracted procedure: k4378 
o|contracted procedure: k4353 
o|contracted procedure: k4356 
o|contracted procedure: k4359 
o|contracted procedure: k4338 
o|contracted procedure: k4344 
o|contracted procedure: k4347 
o|contracted procedure: k4389 
o|contracted procedure: k4392 
o|contracted procedure: k4401 
o|contracted procedure: k4411 
o|contracted procedure: k4434 
o|contracted procedure: k4437 
o|contracted procedure: k4431 
o|contracted procedure: k4448 
o|contracted procedure: k4454 
o|inlining procedure: k4445 
o|contracted procedure: k4463 
o|contracted procedure: k4473 
o|contracted procedure: k4476 
o|contracted procedure: k4478 
o|contracted procedure: k4485 
o|contracted procedure: k4493 
o|contracted procedure: k4501 
o|contracted procedure: k4503 
o|contracted procedure: k4512 
o|contracted procedure: k4517 
o|contracted procedure: k4544 
o|contracted procedure: k4562 
o|contracted procedure: k4568 
o|contracted procedure: k4571 
o|contracted procedure: k4588 
o|contracted procedure: k4606 
o|contracted procedure: k4612 
o|contracted procedure: k4615 
o|contracted procedure: k4623 
o|contracted procedure: k4631 
o|contracted procedure: k4643 
o|contracted procedure: k4640 
o|contracted procedure: k4703 
o|contracted procedure: k4651 
o|contracted procedure: k4700 
o|contracted procedure: k4653 
o|contracted procedure: k4655 
o|contracted procedure: k4697 
o|contracted procedure: k4679 
o|contracted procedure: k4691 
o|contracted procedure: k4685 
o|contracted procedure: k4682 
o|contracted procedure: k4676 
o|contracted procedure: k4670 
o|contracted procedure: k4667 
o|contracted procedure: k4664 
o|contracted procedure: k4711 
o|contracted procedure: k4728 
o|contracted procedure: k4713 
o|contracted procedure: k4725 
o|contracted procedure: k4722 
o|contracted procedure: k4733 
o|contracted procedure: k4736 
o|contracted procedure: k4741 
o|contracted procedure: k4748 
o|contracted procedure: k4750 
o|contracted procedure: k4756 
o|contracted procedure: k4758 
o|contracted procedure: k4779 
o|contracted procedure: k4797 
o|contracted procedure: k4803 
o|contracted procedure: k4806 
o|contracted procedure: k4808 
o|contracted procedure: k4815 
o|contracted procedure: k4829 
o|contracted procedure: k4852 
o|contracted procedure: k4846 
o|contracted procedure: k4862 
o|contracted procedure: k4867 
o|contracted procedure: k4887 
o|contracted procedure: k4884 
o|contracted procedure: k4879 
o|contracted procedure: k4874 
o|contracted procedure: k4901 
o|contracted procedure: k4898 
o|contracted procedure: k5067 
o|contracted procedure: k4907 
o|contracted procedure: k4934 
o|contracted procedure: k4962 
o|contracted procedure: k4959 
o|contracted procedure: k4956 
o|contracted procedure: k4950 
o|contracted procedure: k4970 
o|contracted procedure: k4985 
o|contracted procedure: k4982 
o|contracted procedure: k4979 
o|contracted procedure: k5003 
o|contracted procedure: k5006 
o|contracted procedure: k5020 
o|contracted procedure: k5045 
o|contracted procedure: k5039 
o|contracted procedure: k5042 
o|contracted procedure: k5055 
o|contracted procedure: k5064 
o|contracted procedure: k5057 
o|contracted procedure: k5219 
o|contracted procedure: k5073 
o|contracted procedure: k5100 
o|contracted procedure: k5125 
o|contracted procedure: k5122 
o|contracted procedure: k5119 
o|contracted procedure: k5133 
o|contracted procedure: k5150 
o|contracted procedure: k5145 
o|contracted procedure: k5142 
o|contracted procedure: k5166 
o|contracted procedure: k5169 
o|contracted procedure: k5183 
o|contracted procedure: k5200 
o|contracted procedure: k5207 
o|contracted procedure: k5216 
o|contracted procedure: k5209 
o|contracted procedure: k5527 
o|contracted procedure: k5225 
o|contracted procedure: k5235 
o|contracted procedure: k5237 
o|contracted procedure: k5239 
o|contracted procedure: k5241 
o|contracted procedure: k5247 
o|contracted procedure: k5253 
o|contracted procedure: k5451 
o|contracted procedure: k5458 
o|contracted procedure: k5461 
o|contracted procedure: k5448 
o|contracted procedure: k5445 
o|contracted procedure: k5265 
o|contracted procedure: k5436 
o|contracted procedure: k5442 
o|contracted procedure: k5439 
o|contracted procedure: k5271 
o|contracted procedure: k5268 
o|contracted procedure: k5262 
o|contracted procedure: k5282 
o|contracted procedure: k5285 
o|contracted procedure: k5433 
o|contracted procedure: k5287 
o|contracted procedure: k5289 
o|contracted procedure: k5387 
o|contracted procedure: k5399 
o|contracted procedure: k5405 
o|contracted procedure: k5402 
o|contracted procedure: k5396 
o|contracted procedure: k5390 
o|contracted procedure: k5393 
o|contracted procedure: k5293 
o|contracted procedure: k5315 
o|contracted procedure: k5333 
o|contracted procedure: k5330 
o|contracted procedure: k5339 
o|contracted procedure: k5345 
o|contracted procedure: k5351 
o|contracted procedure: k5369 
o|contracted procedure: k5381 
o|contracted procedure: k5384 
o|contracted procedure: k5378 
o|contracted procedure: k5372 
o|contracted procedure: k5375 
o|contracted procedure: k5407 
o|contracted procedure: k5413 
o|contracted procedure: k5472 
o|contracted procedure: k5475 
o|contracted procedure: k5484 
o|contracted procedure: k5494 
o|contracted procedure: k5502 
o|contracted procedure: k5524 
o|contracted procedure: k5521 
o|contracted procedure: k5505 
o|contracted procedure: k5514 
o|contracted procedure: k5768 
o|contracted procedure: k5771 
o|contracted procedure: k5533 
o|contracted procedure: k5566 
o|contracted procedure: k5585 
o|contracted procedure: k5582 
o|contracted procedure: k5579 
o|inlining procedure: k5573 
o|contracted procedure: k5591 
o|inlining procedure: k5573 
o|contracted procedure: k5629 
o|contracted procedure: k5631 
o|contracted procedure: k5621 
o|contracted procedure: k5597 
o|contracted procedure: k5612 
o|contracted procedure: k5609 
o|contracted procedure: k5606 
o|inlining procedure: k5600 
o|contracted procedure: k5618 
o|inlining procedure: k5600 
o|contracted procedure: k5642 
o|contracted procedure: k5645 
o|contracted procedure: k5654 
o|contracted procedure: k5664 
o|contracted procedure: k5679 
o|contracted procedure: k5674 
o|contracted procedure: k5765 
o|contracted procedure: k5759 
o|contracted procedure: k5762 
o|contracted procedure: k5756 
o|contracted procedure: k5753 
o|contracted procedure: k5694 
o|contracted procedure: k5697 
o|contracted procedure: k5688 
o|contracted procedure: k5691 
o|contracted procedure: k5706 
o|contracted procedure: k5708 
o|contracted procedure: k5720 
o|contracted procedure: k5717 
o|contracted procedure: k5714 
o|contracted procedure: k5728 
o|contracted procedure: k5731 
o|contracted procedure: k5740 
o|contracted procedure: k5750 
o|contracted procedure: k5862 
o|contracted procedure: k5865 
o|contracted procedure: k5780 
o|contracted procedure: k5807 
o|contracted procedure: k5859 
o|contracted procedure: k5847 
o|contracted procedure: k5856 
o|contracted procedure: k5853 
o|contracted procedure: k5850 
o|contracted procedure: k5816 
o|contracted procedure: k5840 
o|contracted procedure: k5825 
o|contracted procedure: k5837 
o|contracted procedure: k5834 
o|contracted procedure: k5831 
o|contracted procedure: k5828 
o|contracted procedure: k5822 
o|contracted procedure: k5819 
o|contracted procedure: k5810 
o|contracted procedure: k5804 
o|contracted procedure: k5798 
o|contracted procedure: k5881 
o|contracted procedure: k5888 
o|contracted procedure: k5909 
o|contracted procedure: k5897 
o|contracted procedure: k5906 
o|contracted procedure: k5903 
o|contracted procedure: k5900 
o|contracted procedure: k5912 
o|contracted procedure: k5923 
o|contracted procedure: k5920 
o|contracted procedure: k5926 
o|contracted procedure: k6262 
o|contracted procedure: k6265 
o|contracted procedure: k6268 
o|contracted procedure: k6271 
o|contracted procedure: k6274 
o|contracted procedure: k5929 
o|contracted procedure: k5951 
o|contracted procedure: k5964 
o|contracted procedure: k6211 
o|contracted procedure: k6208 
o|contracted procedure: k5999 
o|contracted procedure: k5996 
o|contracted procedure: k6010 
o|contracted procedure: k6021 
o|contracted procedure: k6045 
o|contracted procedure: k6052 
o|contracted procedure: k6054 
o|contracted procedure: k6095 
o|contracted procedure: k6065 
o|contracted procedure: k6090 
o|contracted procedure: k6093 
o|contracted procedure: k6087 
o|contracted procedure: k6068 
o|contracted procedure: k6077 
o|contracted procedure: k6080 
o|contracted procedure: k6107 
o|contracted procedure: k6126 
o|contracted procedure: k6120 
o|contracted procedure: k6123 
o|contracted procedure: k6117 
o|contracted procedure: k6145 
o|contracted procedure: k6131 
o|contracted procedure: k6140 
o|contracted procedure: k6181 
o|contracted procedure: k6184 
o|contracted procedure: k6172 
o|contracted procedure: k6178 
o|contracted procedure: k6175 
o|contracted procedure: k6153 
o|contracted procedure: k6158 
o|contracted procedure: k6192 
o|contracted procedure: k6203 
o|contracted procedure: k6219 
o|contracted procedure: k6224 
o|contracted procedure: k6226 
o|contracted procedure: k6237 
o|contracted procedure: k6240 
o|contracted procedure: k6249 
o|contracted procedure: k6259 
o|contracted procedure: k6410 
o|contracted procedure: k6292 
o|contracted procedure: k6302 
o|contracted procedure: k6304 
o|contracted procedure: k6407 
o|contracted procedure: k6321 
o|contracted procedure: k6332 
o|contracted procedure: k6339 
o|contracted procedure: k6341 
o|contracted procedure: k6346 
o|contracted procedure: k6386 
o|contracted procedure: k6389 
o|contracted procedure: k6392 
o|contracted procedure: k6383 
o|contracted procedure: k6363 
o|contracted procedure: k6372 
o|contracted procedure: k6375 
o|contracted procedure: k6378 
o|contracted procedure: k6369 
o|contracted procedure: k6366 
o|contracted procedure: k6355 
o|contracted procedure: k6404 
o|contracted procedure: k6401 
o|contracted procedure: k6398 
o|contracted procedure: k6468 
o|contracted procedure: k6471 
o|contracted procedure: k6474 
o|contracted procedure: k6416 
o|contracted procedure: k6465 
o|contracted procedure: k6462 
o|contracted procedure: k6432 
o|contracted procedure: k6438 
o|contracted procedure: k6441 
o|contracted procedure: k6452 
o|contracted procedure: k6443 
o|contracted procedure: k6447 
o|contracted procedure: k6435 
o|contracted procedure: k6837 
o|contracted procedure: k6840 
o|contracted procedure: k6486 
o|contracted procedure: k6496 
o|contracted procedure: k6498 
o|contracted procedure: k6580 
o|contracted procedure: k6589 
o|contracted procedure: k6595 
o|contracted procedure: k6635 
o|contracted procedure: k6598 
o|contracted procedure: k6629 
o|contracted procedure: k6617 
o|contracted procedure: k6623 
o|contracted procedure: k6620 
o|contracted procedure: k6604 
o|contracted procedure: k6601 
o|contracted procedure: k6614 
o|contracted procedure: k6644 
o|contracted procedure: k6666 
o|contracted procedure: k6702 
o|contracted procedure: k6714 
o|contracted procedure: k6711 
o|contracted procedure: k6708 
o|contracted procedure: k6705 
o|contracted procedure: k6699 
o|contracted procedure: k6524 
o|contracted procedure: k6527 
o|contracted procedure: k6545 
o|contracted procedure: k6554 
o|contracted procedure: k6548 
o|contracted procedure: k6533 
o|contracted procedure: k6566 
o|contracted procedure: k6563 
o|contracted procedure: k6722 
o|contracted procedure: k6725 
o|contracted procedure: k6734 
o|contracted procedure: k6744 
o|contracted procedure: k6752 
o|contracted procedure: k6774 
o|contracted procedure: k6771 
o|contracted procedure: k6755 
o|contracted procedure: k6764 
o|contracted procedure: k6782 
o|contracted procedure: k6785 
o|contracted procedure: k6794 
o|contracted procedure: k6804 
o|contracted procedure: k6812 
o|contracted procedure: k6834 
o|contracted procedure: k6831 
o|contracted procedure: k6815 
o|contracted procedure: k6824 
o|contracted procedure: k6856 
o|contracted procedure: k6984 
o|contracted procedure: k6870 
o|contracted procedure: k6881 
o|contracted procedure: k6887 
o|contracted procedure: k6893 
o|contracted procedure: k6895 
o|contracted procedure: k6942 
o|contracted procedure: k6926 
o|contracted procedure: k6929 
o|contracted procedure: k6953 
o|contracted procedure: k6956 
o|contracted procedure: k6965 
o|contracted procedure: k6975 
o|contracted procedure: k6978 
o|contracted procedure: k6994 
o|contracted procedure: k7007 
o|contracted procedure: k7013 
o|contracted procedure: k7019 
o|contracted procedure: k7062 
o|contracted procedure: k7031 
o|contracted procedure: k7059 
o|contracted procedure: k7056 
o|contracted procedure: k7047 
o|contracted procedure: k7050 
o|contracted procedure: k7079 
o|contracted procedure: k7122 
o|contracted procedure: k7090 
o|contracted procedure: k7119 
o|contracted procedure: k7101 
o|contracted procedure: k7124 
o|contracted procedure: k7131 
o|contracted procedure: k7140 
o|contracted procedure: k7151 
o|contracted procedure: k7188 
o|contracted procedure: k7154 
o|contracted procedure: k7185 
o|contracted procedure: k7170 
o|contracted procedure: k7182 
o|contracted procedure: k7176 
o|contracted procedure: k7173 
o|contracted procedure: k7201 
o|contracted procedure: k7217 
o|contracted procedure: k7227 
o|contracted procedure: k7233 
o|contracted procedure: k7342 
o|contracted procedure: k7252 
o|contracted procedure: k7262 
o|contracted procedure: k7276 
o|contracted procedure: k7258 
o|contracted procedure: k7255 
o|contracted procedure: k7287 
o|contracted procedure: k7290 
o|contracted procedure: k7299 
o|contracted procedure: k7309 
o|contracted procedure: k7317 
o|contracted procedure: k7320 
o|contracted procedure: k7329 
o|contracted procedure: k7339 
o|contracted procedure: k7353 
o|contracted procedure: k7356 
o|contracted procedure: k7365 
o|contracted procedure: k7375 
o|contracted procedure: k7383 
o|contracted procedure: k7386 
o|contracted procedure: k7395 
o|contracted procedure: k7405 
o|contracted procedure: k7413 
o|contracted procedure: k7416 
o|contracted procedure: k7425 
o|contracted procedure: k7435 
o|contracted procedure: k7442 
o|contracted procedure: k7453 
o|contracted procedure: k7456 
o|contracted procedure: k7465 
o|contracted procedure: k7475 
o|contracted procedure: k7485 
o|contracted procedure: k7500 
o|contracted procedure: k7507 
o|contracted procedure: k7521 
o|contracted procedure: k7513 
o|contracted procedure: k7531 
o|contracted procedure: k7541 
o|contracted procedure: k7551 
o|contracted procedure: k7567 
o|contracted procedure: k7573 
o|contracted procedure: k7591 
o|contracted procedure: k7596 
o|contracted procedure: k7613 
o|contracted procedure: k7623 
o|contracted procedure: k7644 
o|contracted procedure: k7661 
o|contracted procedure: k7651 
o|contracted procedure: k7672 
o|contracted procedure: k7675 
o|contracted procedure: k7684 
o|contracted procedure: k7694 
o|contracted procedure: k7722 
o|contracted procedure: k7725 
o|contracted procedure: k7719 
o|contracted procedure: k7706 
o|contracted procedure: k7712 
o|contracted procedure: k7749 
o|contracted procedure: k7731 
o|contracted procedure: k7734 
o|contracted procedure: k7742 
o|contracted procedure: k7761 
o|contracted procedure: k7751 
o|contracted procedure: k7758 
o|contracted procedure: k7769 
o|contracted procedure: k7772 
o|contracted procedure: k7781 
o|contracted procedure: k7791 
o|contracted procedure: k7799 
o|contracted procedure: k7805 
o|contracted procedure: k7814 
o|inlining procedure: k7807 
o|inlining procedure: k7807 
o|contracted procedure: k7838 
o|contracted procedure: k7841 
o|contracted procedure: k7850 
o|contracted procedure: k7860 
o|contracted procedure: k7868 
o|contracted procedure: k7871 
o|contracted procedure: k7880 
o|contracted procedure: k7889 
o|inlining procedure: k7873 
o|contracted procedure: k7904 
o|contracted procedure: k7926 
o|contracted procedure: k7923 
o|contracted procedure: k7907 
o|contracted procedure: k7916 
o|contracted procedure: k7944 
o|contracted procedure: k7946 
o|contracted procedure: k7965 
o|contracted procedure: k7974 
o|contracted procedure: k7977 
o|contracted procedure: k7987 
o|contracted procedure: k7989 
o|contracted procedure: k7994 
o|contracted procedure: k8001 
o|contracted procedure: k8007 
o|contracted procedure: k8004 
o|contracted procedure: k8118 
o|contracted procedure: k8012 
o|contracted procedure: k8027 
o|contracted procedure: k8040 
o|contracted procedure: k8033 
o|contracted procedure: k8030 
o|contracted procedure: k8081 
o|contracted procedure: k8051 
o|contracted procedure: k8054 
o|contracted procedure: k8063 
o|contracted procedure: k8066 
o|contracted procedure: k8076 
o|contracted procedure: k8079 
o|contracted procedure: k8093 
o|contracted procedure: k8096 
o|contracted procedure: k8105 
o|contracted procedure: k8115 
o|contracted procedure: k8132 
o|contracted procedure: k8135 
o|contracted procedure: k8138 
o|contracted procedure: k8155 
o|contracted procedure: k8158 
o|contracted procedure: k8186 
o|contracted procedure: k8194 
o|contracted procedure: k8175 
o|contracted procedure: k8209 
o|contracted procedure: k8228 
o|contracted procedure: k8237 
o|contracted procedure: k8239 
o|contracted procedure: k8349 
o|contracted procedure: k8248 
o|contracted procedure: k8272 
o|contracted procedure: k8269 
o|contracted procedure: k8266 
o|contracted procedure: k8254 
o|contracted procedure: k8263 
o|contracted procedure: k8260 
o|contracted procedure: k8257 
o|contracted procedure: k8251 
o|contracted procedure: k8245 
o|contracted procedure: k8234 
o|contracted procedure: k8295 
o|contracted procedure: k8292 
o|contracted procedure: k8283 
o|contracted procedure: k8286 
o|contracted procedure: k8289 
o|contracted procedure: k8304 
o|contracted procedure: k8301 
o|contracted procedure: k8342 
o|contracted procedure: k8312 
o|contracted procedure: k8315 
o|contracted procedure: k8324 
o|contracted procedure: k8327 
o|contracted procedure: k8337 
o|contracted procedure: k8340 
o|contracted procedure: k8387 
o|contracted procedure: k8357 
o|contracted procedure: k8382 
o|contracted procedure: k8385 
o|contracted procedure: k8379 
o|contracted procedure: k8360 
o|contracted procedure: k8369 
o|contracted procedure: k8372 
o|contracted procedure: k8429 
o|contracted procedure: k8399 
o|contracted procedure: k8424 
o|contracted procedure: k8427 
o|contracted procedure: k8421 
o|contracted procedure: k8402 
o|contracted procedure: k8411 
o|contracted procedure: k8414 
o|contracted procedure: k8441 
o|contracted procedure: k8444 
o|contracted procedure: k8453 
o|contracted procedure: k8463 
o|contracted procedure: k8471 
o|contracted procedure: k8474 
o|contracted procedure: k8483 
o|contracted procedure: k8493 
o|contracted procedure: k8501 
o|contracted procedure: k8523 
o|contracted procedure: k8520 
o|contracted procedure: k8504 
o|contracted procedure: k8513 
o|contracted procedure: k8531 
o|contracted procedure: k8553 
o|contracted procedure: k8550 
o|contracted procedure: k8534 
o|contracted procedure: k8543 
o|contracted procedure: k8563 
o|contracted procedure: k8565 
o|contracted procedure: k8578 
o|contracted procedure: k8584 
o|contracted procedure: k8608 
o|contracted procedure: k8618 
o|contracted procedure: k861810318 
o|contracted procedure: k861810322 
o|contracted procedure: k861810326 
o|contracted procedure: k8654 
o|contracted procedure: k8658 
o|contracted procedure: k8820 
o|contracted procedure: k8693 
o|contracted procedure: k8817 
o|contracted procedure: k8696 
o|contracted procedure: k8702 
o|contracted procedure: k8699 
o|contracted procedure: k8690 
o|contracted procedure: k8730 
o|contracted procedure: k8727 
o|contracted procedure: k8768 
o|contracted procedure: k8738 
o|contracted procedure: k8741 
o|contracted procedure: k8750 
o|contracted procedure: k8753 
o|contracted procedure: k8763 
o|contracted procedure: k8766 
o|contracted procedure: k8810 
o|contracted procedure: k8780 
o|contracted procedure: k8783 
o|contracted procedure: k8792 
o|contracted procedure: k8795 
o|contracted procedure: k8805 
o|contracted procedure: k8808 
o|contracted procedure: k8830 
o|contracted procedure: k8850 
o|contracted procedure: k8847 
o|contracted procedure: k8888 
o|contracted procedure: k8858 
o|contracted procedure: k8861 
o|contracted procedure: k8870 
o|contracted procedure: k8873 
o|contracted procedure: k8883 
o|contracted procedure: k8886 
o|contracted procedure: k8930 
o|contracted procedure: k8900 
o|contracted procedure: k8903 
o|contracted procedure: k8912 
o|contracted procedure: k8915 
o|contracted procedure: k8925 
o|contracted procedure: k8928 
o|contracted procedure: k8940 
o|contracted procedure: k8942 
o|contracted procedure: k8950 
o|contracted procedure: k8952 
o|contracted procedure: k8993 
o|contracted procedure: k8963 
o|contracted procedure: k8988 
o|contracted procedure: k8991 
o|contracted procedure: k8985 
o|contracted procedure: k8966 
o|contracted procedure: k8975 
o|contracted procedure: k8978 
o|contracted procedure: k9007 
o|contracted procedure: k9017 
o|contracted procedure: k9055 
o|contracted procedure: k9025 
o|contracted procedure: k9050 
o|contracted procedure: k9053 
o|contracted procedure: k9047 
o|contracted procedure: k9028 
o|contracted procedure: k9037 
o|contracted procedure: k9040 
o|contracted procedure: k9067 
o|contracted procedure: k9089 
o|contracted procedure: k9086 
o|contracted procedure: k9070 
o|contracted procedure: k9079 
o|contracted procedure: k9097 
o|contracted procedure: k9100 
o|contracted procedure: k9109 
o|contracted procedure: k9119 
o|contracted procedure: k9127 
o|contracted procedure: k9130 
o|contracted procedure: k9139 
o|contracted procedure: k9149 
o|contracted procedure: k9157 
o|contracted procedure: k9179 
o|contracted procedure: k9176 
o|contracted procedure: k9160 
o|contracted procedure: k9169 
o|contracted procedure: k9189 
o|contracted procedure: k9191 
o|contracted procedure: k9238 
o|contracted procedure: k9202 
o|contracted procedure: k9235 
o|contracted procedure: k9208 
o|contracted procedure: k9211 
o|contracted procedure: k9205 
o|contracted procedure: k9219 
o|contracted procedure: k9232 
o|contracted procedure: k9226 
o|contracted procedure: k9229 
o|contracted procedure: k9217 
o|contracted procedure: k9249 
o|contracted procedure: k9306 
o|contracted procedure: k9253 
o|contracted procedure: k9262 
o|contracted procedure: k9265 
o|contracted procedure: k9271 
o|contracted procedure: k9268 
o|contracted procedure: k9292 
o|contracted procedure: k9276 
o|contracted procedure: k9286 
o|contracted procedure: k9294 
o|contracted procedure: k9324 
o|contracted procedure: k9335 
o|contracted procedure: k9349 
o|contracted procedure: k9373 
o|contracted procedure: k9370 
o|contracted procedure: k9355 
o|contracted procedure: k9367 
o|contracted procedure: k9361 
o|contracted procedure: k9364 
o|contracted procedure: k9358 
o|contracted procedure: k9352 
o|contracted procedure: k9451 
o|contracted procedure: k9386 
o|contracted procedure: k9396 
o|contracted procedure: k9393 
o|contracted procedure: k9402 
o|contracted procedure: k9404 
o|contracted procedure: k9428 
o|contracted procedure: k9425 
o|contracted procedure: k9422 
o|contracted procedure: k9419 
o|contracted procedure: k9434 
o|contracted procedure: k9440 
o|contracted procedure: k9437 
o|contracted procedure: k9442 
o|contracted procedure: k9461 
o|contracted procedure: k9477 
o|contracted procedure: k9492 
o|contracted procedure: k9504 
o|contracted procedure: k9520 
o|contracted procedure: k9510 
o|inlining procedure: k9483 
o|inlining procedure: k9483 
o|inlining procedure: k9483 
o|inlining procedure: k9483 
o|inlining procedure: k9483 
o|contracted procedure: k9526 
o|contracted procedure: k9708 
o|contracted procedure: k9705 
o|contracted procedure: k9702 
o|contracted procedure: k9699 
o|contracted procedure: k9538 
o|contracted procedure: k9682 
o|contracted procedure: k9688 
o|contracted procedure: k9685 
o|contracted procedure: k9679 
o|contracted procedure: k9544 
o|contracted procedure: k9541 
o|contracted procedure: k9535 
o|contracted procedure: k9555 
o|contracted procedure: k9558 
o|contracted procedure: k9673 
o|contracted procedure: k9560 
o|contracted procedure: k9646 
o|contracted procedure: k9658 
o|contracted procedure: k9655 
o|contracted procedure: k9649 
o|contracted procedure: k9652 
o|contracted procedure: k9568 
o|contracted procedure: k9574 
o|contracted procedure: k9580 
o|contracted procedure: k9583 
o|contracted procedure: k9595 
o|contracted procedure: k9592 
o|contracted procedure: k9607 
o|contracted procedure: k9619 
o|contracted procedure: k9616 
o|contracted procedure: k9610 
o|contracted procedure: k9613 
o|contracted procedure: k9604 
o|contracted procedure: k9625 
o|contracted procedure: k9637 
o|contracted procedure: k9634 
o|contracted procedure: k9628 
o|contracted procedure: k9631 
o|contracted procedure: k9643 
o|contracted procedure: k9667 
o|contracted procedure: k9721 
o|contracted procedure: k9724 
o|contracted procedure: k9733 
o|contracted procedure: k9743 
o|contracted procedure: k9757 
o|simplifications: ((let . 111)) 
o|removed binding forms: 926 
o|inlining procedure: k3566 
o|inlining procedure: k3566 
o|inlining procedure: k3603 
o|inlining procedure: k3603 
o|inlining procedure: k3798 
o|inlining procedure: k3798 
o|inlining procedure: k4021 
o|inlining procedure: k4021 
o|inlining procedure: k4051 
o|inlining procedure: k4051 
o|inlining procedure: k4394 
o|inlining procedure: k4394 
o|inlining procedure: k4440 
o|inlining procedure: k4440 
o|inlining procedure: k4440 
o|inlining procedure: k5477 
o|inlining procedure: k5477 
o|inlining procedure: k5507 
o|inlining procedure: k5507 
o|inlining procedure: k5647 
o|inlining procedure: k5647 
o|inlining procedure: k5733 
o|inlining procedure: k5733 
o|inlining procedure: k6242 
o|inlining procedure: k6242 
o|inlining procedure: k6727 
o|inlining procedure: k6727 
o|inlining procedure: k6757 
o|inlining procedure: k6757 
o|inlining procedure: k6787 
o|inlining procedure: k6787 
o|inlining procedure: k6817 
o|inlining procedure: k6817 
o|inlining procedure: k6958 
o|inlining procedure: k6958 
o|inlining procedure: k7292 
o|inlining procedure: k7292 
o|inlining procedure: k7322 
o|inlining procedure: k7322 
o|inlining procedure: k7358 
o|inlining procedure: k7358 
o|inlining procedure: k7388 
o|inlining procedure: k7388 
o|inlining procedure: k7418 
o|inlining procedure: k7418 
o|inlining procedure: k7458 
o|inlining procedure: k7458 
o|inlining procedure: k7677 
o|inlining procedure: k7677 
o|inlining procedure: k7774 
o|inlining procedure: k7774 
o|inlining procedure: k7843 
o|inlining procedure: k7843 
o|inlining procedure: k7909 
o|inlining procedure: k7909 
o|inlining procedure: k8098 
o|inlining procedure: k8098 
o|inlining procedure: k8446 
o|inlining procedure: k8446 
o|inlining procedure: k8476 
o|inlining procedure: k8476 
o|inlining procedure: k8506 
o|inlining procedure: k8506 
o|inlining procedure: k8536 
o|inlining procedure: k8536 
o|inlining procedure: k9072 
o|inlining procedure: k9072 
o|inlining procedure: k9102 
o|inlining procedure: k9102 
o|inlining procedure: k9132 
o|inlining procedure: k9132 
o|inlining procedure: k9162 
o|inlining procedure: k9162 
o|substituted constant variable: r948410942 
o|substituted constant variable: r948410943 
o|substituted constant variable: r948410944 
o|substituted constant variable: r948410945 
o|inlining procedure: k9598 
o|inlining procedure: k9598 
o|inlining procedure: k9726 
o|inlining procedure: k9726 
o|simplifications: ((let . 1)) 
o|replaced variables: 68 
o|removed binding forms: 4 
o|removed conditional forms: 4 
o|substituted constant variable: a356510950 
o|simplifications: ((if . 1)) 
o|replaced variables: 1 
o|removed binding forms: 120 
o|contracted procedure: k7081 
o|removed binding forms: 3 
o|customizable procedures: (map-loop2550 k9589 mapslots60 k9412 k9256 k9274 k9214 map-loop169186 map-loop196214 map-loop224242 map-loop275292 k9030 map-loop254299 loop330 k8968 map-loop311333 k8905 map-loop345369 k8863 map-loop381405 k8785 map-loop417441 k8743 map-loop453477 loop502 map-loop534551 map-loop561578 map-loop588606 map-loop616634 k8404 map-loop646665 k8362 map-loop677696 k8317 map-loop708732 map-loop775792 k8056 map-loop804828 for-each-loop844862 map-loop889906 loop914 map-loop926944 loop954 map-loop10101028 k7699 fold963 map-loop975993 map*878 append*877 fold1044 map-loop10621080 map-loop10901108 map-loop11221140 map-loop11491226 map-loop11721189 map-loop11981219 quotify-proc1248 k7083 k7092 fold1272 map-loop13271348 expand1305 map-loop14041421 map-loop14341452 map-loop14621479 map-loop14911509 recur1374 make-if-tree1368 recur1389 loop1557 map-loop15871608 genvars1579 k6023 build1644 k6070 map-loop16661685 loop1581 parse-clause1742 map-loop17981815 k5557 k5559 k5561 map-loop17621783 map-loop18421859 map-loop18711889 k5291 k5295 k5301 k5307 loop1896 loop1940 loop1969 k4628 loop20262050 k4708 loop20762096 loop20762106 map-loop21462166 k4284 k4163 loop22242244 loop22242259 map-loop22692287 map-loop22972315 k3872 loop2341 loop22354 map-loop23612386 k3768 k3715 map-loop24012425 map-loop24552477) 
o|calls to known targets: 300 
o|identified direct recursive calls: f_3827 1 
o|identified direct recursive calls: f_3662 1 
o|identified direct recursive calls: f_5497 2 
o|identified direct recursive calls: f_6747 2 
o|identified direct recursive calls: f_6807 2 
o|identified direct recursive calls: f_7002 3 
o|identified direct recursive calls: f_7495 1 
o|identified direct recursive calls: f_7536 1 
o|identified direct recursive calls: f_7863 1 
o|identified direct recursive calls: f_7899 2 
o|identified direct recursive calls: f_8496 2 
o|identified direct recursive calls: f_8526 2 
o|identified direct recursive calls: f_9002 1 
o|identified direct recursive calls: f_9062 2 
o|identified direct recursive calls: f_9152 2 
o|fast box initializations: 74 
*/
/* end of file */
