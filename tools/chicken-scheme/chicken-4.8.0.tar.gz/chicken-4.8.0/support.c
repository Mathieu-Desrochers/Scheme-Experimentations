/* Generated from support.scm by the CHICKEN compiler
   http://www.call-cc.org
   2012-09-24 17:52
   Version 4.8.0 (rev 0db1908)
   linux-unix-gnu-x86-64 [ 64bit manyargs ptables ]
   compiled 2012-09-24 on debian (Linux)
   command line: support.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -feature chicken-bootstrap -no-warnings -specialize -types ./types.db -no-lambda-info -local -no-trace -extend private-namespace.scm -no-trace -output-file support.c
   unit: support
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[560];
static double C_possibly_force_alignment;


/* from k5420 */
static C_word C_fcall stub351(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub351(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_wordstobytes(t0));
return C_r;}

/* from k5413 */
static C_word C_fcall stub346(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub346(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_bytestowords(t0));
return C_r;}

C_noret_decl(f_5319)
static void C_ccall f_5319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5316)
static void C_fcall f_5316(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7682)
static void C_ccall f_7682(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10769)
static void C_ccall f_10769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4688)
static void C_ccall f_4688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8350)
static void C_fcall f_8350(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9708)
static void C_ccall f_9708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7661)
static void C_ccall f_7661(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4675)
static void C_ccall f_4675(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4675)
static void C_ccall f_4675r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5322)
static void C_ccall f_5322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7699)
static void C_ccall f_7699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5327)
static void C_ccall f_5327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13931)
static void C_ccall f_13931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10753)
static void C_fcall f_10753(C_word t0,C_word t1) C_noret;
C_noret_decl(f_13939)
static void C_ccall f_13939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4699)
static void C_ccall f_4699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7788)
static void C_fcall f_7788(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7789)
static void C_ccall f_7789(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8396)
static void C_ccall f_8396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12647)
static void C_ccall f_12647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12643)
static void C_ccall f_12643(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6361)
static void C_ccall f_6361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6363)
static void C_fcall f_6363(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12537)
static void C_ccall f_12537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6367)
static void C_ccall f_6367(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10715)
static void C_fcall f_10715(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10710)
static void C_ccall f_10710(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9207)
static void C_ccall f_9207(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4802)
static void C_ccall f_4802(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4809)
static void C_ccall f_4809(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4806)
static void C_fcall f_4806(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4800)
static void C_ccall f_4800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8651)
static void C_fcall f_8651(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8657)
static void C_ccall f_8657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10739)
static void C_fcall f_10739(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5385)
static void C_ccall f_5385(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8641)
static void C_ccall f_8641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10704)
static void C_ccall f_10704(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4828)
static void C_ccall f_4828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6649)
static void C_fcall f_6649(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4812)
static void C_ccall f_4812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4814)
static void C_ccall f_4814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4816)
static void C_ccall f_4816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5731)
static void C_ccall f_5731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5739)
static void C_fcall f_5739(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5733)
static void C_ccall f_5733(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7771)
static void C_ccall f_7771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10893)
static void C_fcall f_10893(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5762)
static void C_fcall f_5762(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5346)
static void C_ccall f_5346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6639)
static void C_ccall f_6639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10968)
static void C_fcall f_10968(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7333)
static void C_ccall f_7333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10970)
static void C_ccall f_10970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9040)
static void C_fcall f_9040(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9049)
static void C_ccall f_9049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9043)
static void C_ccall f_9043(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9032)
static void C_ccall f_9032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6039)
static void C_ccall f_6039(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6038)
static void C_ccall f_6038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9023)
static void C_ccall f_9023(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_6041)
static void C_ccall f_6041(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6041)
static void C_ccall f_6041r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_7373)
static void C_ccall f_7373(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9018)
static void C_ccall f_9018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8666)
static void C_fcall f_8666(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8664)
static void C_ccall f_8664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7345)
static void C_ccall f_7345(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9086)
static void C_ccall f_9086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8691)
static void C_ccall f_8691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10942)
static void C_fcall f_10942(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9070)
static void C_ccall f_9070(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_13982)
static void C_fcall f_13982(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13980)
static void C_ccall f_13980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9063)
static void C_ccall f_9063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7360)
static void C_ccall f_7360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5784)
static void C_ccall f_5784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5788)
static void C_ccall f_5788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12043)
static void C_ccall f_12043(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9050)
static void C_ccall f_9050(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9056)
static void C_ccall f_9056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9057)
static void C_ccall f_9057(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5776)
static void C_ccall f_5776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8623)
static void C_ccall f_8623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8620)
static void C_ccall f_8620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13962)
static void C_ccall f_13962(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_13962)
static void C_ccall f_13962r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_13967)
static void C_ccall f_13967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6651)
static void C_ccall f_6651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12030)
static void C_ccall f_12030(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7388)
static void C_ccall f_7388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10270)
static void C_ccall f_10270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5715)
static void C_ccall f_5715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13954)
static void C_ccall f_13954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10283)
static void C_ccall f_10283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10277)
static void C_ccall f_10277(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10916)
static void C_fcall f_10916(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12052)
static void C_fcall f_12052(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11144)
static void C_ccall f_11144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9095)
static void C_ccall f_9095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9092)
static void C_ccall f_9092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13920)
static void C_ccall f_13920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12025)
static void C_ccall f_12025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13915)
static void C_ccall f_13915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13913)
static void C_ccall f_13913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5700)
static void C_ccall f_5700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13902)
static void C_ccall f_13902(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13907)
static void C_ccall f_13907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13972)
static void C_ccall f_13972(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5986)
static void C_ccall f_5986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11116)
static void C_ccall f_11116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11114)
static void C_fcall f_11114(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8308)
static void C_fcall f_8308(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8306)
static void C_ccall f_8306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8303)
static void C_ccall f_8303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8300)
static void C_ccall f_8300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14302)
static void C_ccall f_14302(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5276)
static void C_ccall f_5276(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5265)
static void C_ccall f_5265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14325)
static void C_ccall f_14325(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8319)
static void C_fcall f_8319(C_word t0,C_word t1) C_noret;
C_noret_decl(f_14328)
static void C_ccall f_14328(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_14328)
static void C_ccall f_14328r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_9352)
static void C_ccall f_9352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9354)
static void C_ccall f_9354(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9343)
static void C_ccall f_9343(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9339)
static void C_ccall f_9339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9390)
static void C_ccall f_9390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7051)
static void C_ccall f_7051(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7065)
static void C_ccall f_7065(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9365)
static void C_fcall f_9365(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9363)
static void C_ccall f_9363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7062)
static void C_ccall f_7062(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13173)
static void C_ccall f_13173(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_13179)
static void C_fcall f_13179(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13177)
static void C_ccall f_13177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7976)
static void C_ccall f_7976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7970)
static void C_ccall f_7970(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10096)
static void C_ccall f_10096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10090)
static void C_ccall f_10090(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7094)
static void C_ccall f_7094(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13195)
static void C_ccall f_13195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10321)
static void C_ccall f_10321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13182)
static void C_ccall f_13182(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13189)
static void C_ccall f_13189(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13188)
static void C_ccall f_13188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10332)
static void C_ccall f_10332(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10338)
static void C_ccall f_10338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8607)
static void C_fcall f_8607(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5218)
static void C_ccall f_5218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5215)
static void C_ccall f_5215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10075)
static void C_ccall f_10075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10348)
static void C_ccall f_10348(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7031)
static void C_ccall f_7031(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6131)
static void C_fcall f_6131(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_14349)
static void C_ccall f_14349(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_14349)
static void C_ccall f_14349r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_14346)
static void C_ccall f_14346(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7048)
static void C_ccall f_7048(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9969)
static void C_fcall f_9969(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10652)
static void C_ccall f_10652(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10354)
static void C_ccall f_10354(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10656)
static void C_ccall f_10656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7042)
static void C_ccall f_7042(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7040)
static void C_ccall f_7040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12399)
static void C_ccall f_12399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7308)
static void C_fcall f_7308(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7303)
static void C_ccall f_7303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7013)
static void C_ccall f_7013(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9933)
static void C_ccall f_9933(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10125)
static void C_ccall f_10125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9937)
static void C_fcall f_9937(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10127)
static void C_ccall f_10127(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10666)
static void C_ccall f_10666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10658)
static void C_ccall f_10658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14367)
static void C_ccall f_14367(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10135)
static void C_ccall f_10135(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10133)
static void C_ccall f_10133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9903)
static void C_ccall f_9903(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_9903)
static void C_ccall f_9903r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_10671)
static void C_ccall f_10671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10668)
static void C_ccall f_10668(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7022)
static void C_ccall f_7022(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7076)
static void C_ccall f_7076(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10144)
static void C_ccall f_10144(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10681)
static void C_fcall f_10681(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10141)
static void C_ccall f_10141(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9928)
static void C_ccall f_9928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5220)
static void C_ccall f_5220(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10615)
static void C_ccall f_10615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10157)
static void C_ccall f_10157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10610)
static void C_ccall f_10610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14371)
static void C_ccall f_14371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10612)
static void C_ccall f_10612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10151)
static void C_ccall f_10151(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10150)
static void C_ccall f_10150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7080)
static void C_fcall f_7080(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5236)
static void C_ccall f_5236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5238)
static void C_ccall f_5238(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9314)
static void C_fcall f_9314(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5212)
static void C_ccall f_5212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10624)
static void C_ccall f_10624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10626)
static void C_ccall f_10626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10622)
static void C_ccall f_10622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10617)
static void C_ccall f_10617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10619)
static void C_ccall f_10619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5229)
static void C_ccall f_5229(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5227)
static void C_ccall f_5227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13520)
static void C_ccall f_13520(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10636)
static void C_ccall f_10636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10633)
static void C_ccall f_10633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10631)
static void C_ccall f_10631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14392)
static void C_ccall f_14392(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_14392)
static void C_ccall f_14392r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_10629)
static void C_ccall f_10629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5289)
static void C_ccall f_5289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5286)
static void C_ccall f_5286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13515)
static void C_ccall f_13515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9919)
static void C_ccall f_9919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10107)
static void C_ccall f_10107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10645)
static void C_ccall f_10645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10643)
static void C_ccall f_10643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10101)
static void C_ccall f_10101(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10640)
static void C_ccall f_10640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10638)
static void C_ccall f_10638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13504)
static void C_ccall f_13504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10119)
static void C_ccall f_10119(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10117)
static void C_ccall f_10117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10112)
static void C_ccall f_10112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10647)
static void C_ccall f_10647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4904)
static void C_ccall f_4904(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4904)
static void C_ccall f_4904r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4902)
static void C_ccall f_4902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4908)
static void C_ccall f_4908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5244)
static void C_fcall f_5244(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4922)
static void C_fcall f_4922(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7888)
static void C_ccall f_7888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4924)
static void C_ccall f_4924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4925)
static void C_ccall f_4925(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8184)
static void C_ccall f_8184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10604)
static void C_ccall f_10604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4916)
static void C_ccall f_4916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4918)
static void C_ccall f_4918(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4918)
static void C_ccall f_4918r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4910)
static void C_ccall f_4910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7896)
static void C_ccall f_7896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7759)
static void C_ccall f_7759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7756)
static void C_ccall f_7756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10165)
static void C_fcall f_10165(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5291)
static void C_fcall f_5291(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7701)
static void C_fcall f_7701(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9945)
static void C_ccall f_9945(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12741)
static void C_fcall f_12741(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7434)
static void C_ccall f_7434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7439)
static void C_ccall f_7439(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7445)
static void C_ccall f_7445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10859)
static void C_fcall f_10859(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6525)
static void C_ccall f_6525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6523)
static void C_fcall f_6523(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8093)
static void C_ccall f_8093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8126)
static void C_ccall f_8126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8120)
static void C_ccall f_8120(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8127)
static void C_ccall f_8127(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6539)
static void C_ccall f_6539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6533)
static void C_ccall f_6533(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8111)
static void C_ccall f_8111(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8117)
static void C_fcall f_8117(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7422)
static void C_ccall f_7422(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6503)
static void C_ccall f_6503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8101)
static void C_ccall f_8101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8103)
static void C_ccall f_8103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10873)
static void C_fcall f_10873(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10307)
static void C_ccall f_10307(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7479)
static void C_ccall f_7479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7476)
static void C_ccall f_7476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4735)
static void C_ccall f_4735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4749)
static void C_ccall f_4749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13545)
static void C_ccall f_13545(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7470)
static void C_ccall f_7470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10313)
static void C_ccall f_10313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7726)
static void C_ccall f_7726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6514)
static void C_ccall f_6514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10315)
static void C_ccall f_10315(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7485)
static void C_ccall f_7485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4766)
static void C_ccall f_4766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4764)
static void C_ccall f_4764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4760)
static void C_fcall f_4760(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13530)
static void C_fcall f_13530(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10812)
static void C_ccall f_10812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7458)
static void C_ccall f_7458(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7451)
static void C_ccall f_7451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8157)
static void C_ccall f_8157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8159)
static void C_fcall f_8159(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10861)
static void C_ccall f_10861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8140)
static void C_ccall f_8140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8148)
static void C_fcall f_8148(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4777)
static void C_ccall f_4777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8133)
static void C_ccall f_8133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8134)
static void C_ccall f_8134(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13415)
static void C_ccall f_13415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4779)
static void C_ccall f_4779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10360)
static void C_fcall f_10360(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10362)
static void C_ccall f_10362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13406)
static void C_ccall f_13406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10368)
static void C_ccall f_10368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4791)
static void C_ccall f_4791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7741)
static void C_ccall f_7741(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10824)
static void C_fcall f_10824(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4740)
static void C_fcall f_4740(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6583)
static void C_fcall f_6583(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6585)
static void C_ccall f_6585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10385)
static void C_ccall f_10385(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9450)
static void C_ccall f_9450(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9456)
static void C_fcall f_9456(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6593)
static void C_ccall f_6593(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6599)
static void C_ccall f_6599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10391)
static void C_ccall f_10391(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9482)
static void C_ccall f_9482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10399)
static void C_ccall f_10399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10397)
static void C_fcall f_10397(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9488)
static void C_ccall f_9488(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9484)
static void C_ccall f_9484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9486)
static void C_ccall f_9486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5613)
static void C_ccall f_5613(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6563)
static void C_ccall f_6563(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6569)
static void C_ccall f_6569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6571)
static void C_ccall f_6571(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6577)
static void C_ccall f_6577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9469)
static void C_ccall f_9469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4781)
static void C_ccall f_4781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4783)
static void C_ccall f_4783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7140)
static void C_ccall f_7140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7142)
static void C_fcall f_7142(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13596)
static void C_ccall f_13596(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5447)
static void C_fcall f_5447(C_word t0,C_word t1) C_noret;
C_noret_decl(f_13590)
static void C_ccall f_13590(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9494)
static void C_ccall f_9494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9496)
static void C_ccall f_9496(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13584)
static void C_ccall f_13584(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5640)
static void C_ccall f_5640(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7167)
static void C_ccall f_7167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5644)
static void C_fcall f_5644(C_word t0,C_word t1) C_noret;
C_noret_decl(f_13256)
static void C_ccall f_13256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13250)
static void C_ccall f_13250(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9472)
static void C_ccall f_9472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9478)
static void C_ccall f_9478(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7100)
static void C_ccall f_7100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13554)
static void C_fcall f_13554(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7125)
static void C_ccall f_7125(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_13214)
static void C_fcall f_13214(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9896)
static void C_ccall f_9896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9892)
static void C_fcall f_9892(C_word t0,C_word t1) C_noret;
C_noret_decl(f_13207)
static void C_fcall f_13207(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8554)
static void C_ccall f_8554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8556)
static void C_fcall f_8556(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10425)
static void C_ccall f_10425(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8581)
static void C_ccall f_8581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10435)
static void C_ccall f_10435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9991)
static void C_ccall f_9991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8533)
static void C_ccall f_8533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10453)
static void C_ccall f_10453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7187)
static void C_fcall f_7187(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7189)
static void C_ccall f_7189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13235)
static void C_fcall f_13235(C_word t0,C_word t1) C_noret;
C_noret_decl(f_14428)
static void C_ccall f_14428(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5695)
static void C_ccall f_5695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13223)
static void C_ccall f_13223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7195)
static void C_ccall f_7195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14425)
static void C_ccall f_14425(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12834)
static void C_fcall f_12834(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7004)
static void C_ccall f_7004(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5681)
static void C_ccall f_5681(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10608)
static void C_ccall f_10608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10606)
static void C_ccall f_10606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14417)
static void C_ccall f_14417(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_14414)
static void C_ccall f_14414(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_14408)
static void C_ccall f_14408(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_13441)
static void C_ccall f_13441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5679)
static void C_ccall f_5679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13432)
static void C_ccall f_13432(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5548)
static void C_ccall f_5548(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6541)
static void C_ccall f_6541(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6547)
static void C_ccall f_6547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6553)
static void C_fcall f_6553(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6555)
static void C_ccall f_6555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13495)
static void C_fcall f_13495(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5562)
static void C_ccall f_5562(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5568)
static void C_ccall f_5568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13482)
static void C_fcall f_13482(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_13485)
static void C_ccall f_13485(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6405)
static void C_ccall f_6405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5556)
static void C_ccall f_5556(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6413)
static void C_ccall f_6413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9873)
static void C_ccall f_9873(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9871)
static void C_ccall f_9871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9879)
static void C_ccall f_9879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5164)
static void C_ccall f_5164(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6419)
static void C_ccall f_6419(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6428)
static void C_ccall f_6428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6426)
static void C_ccall f_6426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6424)
static void C_ccall f_6424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9881)
static void C_ccall f_9881(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9887)
static void C_ccall f_9887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6437)
static void C_ccall f_6437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7546)
static void C_ccall f_7546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7548)
static void C_fcall f_7548(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5185)
static void C_ccall f_5185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5182)
static void C_ccall f_5182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6439)
static void C_fcall f_6439(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6064)
static void C_ccall f_6064(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6064)
static void C_ccall f_6064r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_13271)
static void C_fcall f_13271(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13264)
static void C_fcall f_13264(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6088)
static void C_ccall f_6088(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6088)
static void C_ccall f_6088r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_6086)
static void C_ccall f_6086(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6085)
static void C_ccall f_6085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5190)
static void C_ccall f_5190(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5904)
static C_word C_fcall f_5904(C_word t0,C_word t1);
C_noret_decl(f_6017)
static void C_ccall f_6017(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6017)
static void C_ccall f_6017r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_6010)
static void C_ccall f_6010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6487)
static void C_ccall f_6487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6489)
static void C_ccall f_6489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6493)
static void C_ccall f_6493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13817)
static void C_ccall f_13817(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6495)
static void C_ccall f_6495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6491)
static void C_ccall f_6491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13809)
static void C_ccall f_13809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13806)
static void C_ccall f_13806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10405)
static void C_ccall f_10405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6057)
static void C_ccall f_6057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4842)
static void C_ccall f_4842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10419)
static void C_ccall f_10419(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9530)
static void C_ccall f_9530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13869)
static void C_ccall f_13869(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9535)
static void C_ccall f_9535(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13280)
static void C_ccall f_13280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4833)
static void C_fcall f_4833(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_14074)
static void C_ccall f_14074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14076)
static void C_ccall f_14076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9524)
static void C_ccall f_9524(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4869)
static void C_ccall f_4869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14463)
static void C_ccall f_14463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13842)
static void C_ccall f_13842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14460)
static void C_ccall f_14460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4853)
static void C_fcall f_4853(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7573)
static void C_ccall f_7573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12871)
static void C_fcall f_12871(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10044)
static void C_fcall f_10044(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_14451)
static void C_ccall f_14451(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_14450)
static void C_ccall f_14450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13835)
static void C_ccall f_13835(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4881)
static void C_ccall f_4881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4887)
static void C_ccall f_4887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14445)
static void C_ccall f_14445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8983)
static void C_ccall f_8983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14440)
static void C_ccall f_14440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7414)
static void C_fcall f_7414(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4877)
static void C_ccall f_4877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4875)
static void C_ccall f_4875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14436)
static void C_ccall f_14436(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4879)
static void C_ccall f_4879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12814)
static void C_fcall f_12814(C_word t0,C_word t1) C_noret;
C_noret_decl(f_13897)
static void C_ccall f_13897(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13892)
static void C_ccall f_13892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7527)
static void C_ccall f_7527(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10461)
static void C_ccall f_10461(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_10033)
static void C_ccall f_10033(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10039)
static void C_ccall f_10039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13888)
static void C_ccall f_13888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13883)
static void C_ccall f_13883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7538)
static void C_fcall f_7538(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4896)
static void C_ccall f_4896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14499)
static void C_ccall f_14499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10470)
static void C_ccall f_10470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9408)
static void C_fcall f_9408(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10006)
static void C_fcall f_10006(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_13872)
static void C_ccall f_13872(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13877)
static void C_ccall f_13877(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_14487)
static void C_ccall f_14487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10485)
static void C_ccall f_10485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10481)
static void C_ccall f_10481(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_14478)
static void C_fcall f_14478(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8993)
static void C_fcall f_8993(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10490)
static void C_ccall f_10490(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10492)
static void C_ccall f_10492(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12850)
static void C_fcall f_12850(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10028)
static void C_ccall f_10028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14473)
static void C_ccall f_14473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8922)
static void C_ccall f_8922(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8924)
static void C_ccall f_8924(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9419)
static void C_fcall f_9419(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9592)
static void C_fcall f_9592(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9595)
static void C_ccall f_9595(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9581)
static void C_ccall f_9581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9586)
static void C_ccall f_9586(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6607)
static void C_ccall f_6607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6601)
static void C_ccall f_6601(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8907)
static void C_ccall f_8907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8902)
static void C_ccall f_8902(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5361)
static void C_ccall f_5361(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5365)
static void C_ccall f_5365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6627)
static void C_fcall f_6627(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5992)
static void C_ccall f_5992(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5990)
static void C_ccall f_5990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8965)
static void C_ccall f_8965(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5994)
static void C_ccall f_5994(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5994)
static void C_ccall f_5994r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(C_support_toplevel)
C_externexport void C_ccall C_support_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9556)
static void C_fcall f_9556(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9554)
static void C_ccall f_9554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8939)
static void C_ccall f_8939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5943)
static void C_ccall f_5943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9543)
static void C_ccall f_9543(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9541)
static void C_ccall f_9541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9549)
static void C_ccall f_9549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8943)
static void C_ccall f_8943(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5939)
static void C_ccall f_5939(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8942)
static void C_ccall f_8942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5100)
static void C_ccall f_5100(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5106)
static void C_fcall f_5106(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_14114)
static void C_ccall f_14114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14117)
static void C_ccall f_14117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14119)
static void C_ccall f_14119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8915)
static void C_ccall f_8915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8917)
static void C_ccall f_8917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8912)
static void C_ccall f_8912(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7845)
static void C_ccall f_7845(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12102)
static void C_fcall f_12102(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8508)
static void C_fcall f_8508(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_14136)
static void C_ccall f_14136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14133)
static void C_ccall f_14133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6205)
static void C_ccall f_6205(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_7863)
static void C_fcall f_7863(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6200)
static void C_ccall f_6200(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7861)
static void C_ccall f_7861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14124)
static void C_fcall f_14124(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6209)
static void C_ccall f_6209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7810)
static void C_fcall f_7810(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_14150)
static void C_fcall f_14150(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_14159)
static void C_ccall f_14159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5138)
static void C_fcall f_5138(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8958)
static void C_ccall f_8958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5132)
static void C_ccall f_5132(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7808)
static void C_ccall f_7808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8881)
static void C_ccall f_8881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8884)
static void C_ccall f_8884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8896)
static void C_ccall f_8896(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_9196)
static void C_ccall f_9196(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9195)
static void C_ccall f_9195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9193)
static void C_ccall f_9193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14503)
static void C_ccall f_14503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14501)
static void C_ccall f_14501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14505)
static void C_ccall f_14505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14508)
static void C_ccall f_14508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14523)
static void C_ccall f_14523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13326)
static void C_ccall f_13326(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13325)
static void C_ccall f_13325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14529)
static void C_ccall f_14529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14101)
static void C_ccall f_14101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14106)
static void C_ccall f_14106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13312)
static void C_ccall f_13312(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_14511)
static void C_ccall f_14511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13316)
static void C_fcall f_13316(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_14514)
static void C_ccall f_14514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14516)
static void C_ccall f_14516(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_14516)
static void C_ccall f_14516r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_13319)
static void C_ccall f_13319(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6469)
static void C_ccall f_6469(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6473)
static void C_fcall f_6473(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6478)
static void C_ccall f_6478(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9518)
static void C_fcall f_9518(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9183)
static void C_ccall f_9183(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9181)
static void C_ccall f_9181(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9186)
static void C_ccall f_9186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9512)
static void C_ccall f_9512(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9510)
static void C_ccall f_9510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9188)
static void C_ccall f_9188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6296)
static void C_fcall f_6296(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6294)
static void C_ccall f_6294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6290)
static void C_ccall f_6290(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_6290)
static void C_ccall f_6290r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_9504)
static void C_ccall f_9504(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9502)
static void C_ccall f_9502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9161)
static void C_ccall f_9161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7835)
static void C_ccall f_7835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11608)
static void C_ccall f_11608(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11602)
static void C_ccall f_11602(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6246)
static void C_ccall f_6246(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_9813)
static void C_fcall f_9813(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9810)
static void C_ccall f_9810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11615)
static void C_ccall f_11615(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9141)
static void C_ccall f_9141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9145)
static void C_ccall f_9145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9146)
static void C_ccall f_9146(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11611)
static void C_ccall f_11611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6250)
static void C_ccall f_6250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9827)
static void C_ccall f_9827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9120)
static void C_ccall f_9120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9126)
static void C_ccall f_9126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8858)
static void C_fcall f_8858(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8852)
static void C_ccall f_8852(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8869)
static void C_ccall f_8869(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9105)
static void C_ccall f_9105(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8066)
static void C_ccall f_8066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8068)
static void C_fcall f_8068(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9865)
static void C_ccall f_9865(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9139)
static void C_ccall f_9139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8053)
static void C_ccall f_8053(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11539)
static void C_ccall f_11539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9791)
static void C_ccall f_9791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11556)
static void C_ccall f_11556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11666)
static void C_fcall f_11666(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4941)
static void C_fcall f_4941(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10531)
static void C_ccall f_10531(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10537)
static void C_ccall f_10537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11649)
static void C_ccall f_11649(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4936)
static void C_ccall f_4936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4934)
static void C_ccall f_4934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11643)
static void C_ccall f_11643(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4967)
static void C_ccall f_4967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4969)
static void C_ccall f_4969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14544)
static void C_ccall f_14544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14540)
static void C_ccall f_14540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14546)
static void C_ccall f_14546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7505)
static void C_ccall f_7505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7502)
static void C_ccall f_7502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11658)
static void C_fcall f_11658(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4963)
static void C_ccall f_4963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4965)
static void C_ccall f_4965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4961)
static void C_ccall f_4961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5436)
static void C_ccall f_5436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7514)
static void C_ccall f_7514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4950)
static void C_ccall f_4950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14562)
static void C_ccall f_14562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14564)
static void C_ccall f_14564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13365)
static void C_ccall f_13365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14560)
static void C_ccall f_14560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12404)
static void C_ccall f_12404(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12408)
static void C_ccall f_12408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14566)
static void C_ccall f_14566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5423)
static void C_ccall f_5423(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5423)
static void C_ccall f_5423r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4978)
static void C_ccall f_4978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14551)
static void C_ccall f_14551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5416)
static void C_ccall f_5416(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_14557)
static void C_ccall f_14557(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9804)
static void C_ccall f_9804(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9800)
static void C_ccall f_9800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4976)
static void C_ccall f_4976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4974)
static void C_ccall f_4974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14585)
static void C_ccall f_14585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13347)
static void C_fcall f_13347(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5409)
static void C_ccall f_5409(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5407)
static void C_ccall f_5407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11585)
static void C_ccall f_11585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4999)
static void C_ccall f_4999(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_14571)
static void C_ccall f_14571(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13332)
static void C_ccall f_13332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13333)
static void C_ccall f_13333(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_14579)
static void C_ccall f_14579(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_14577)
static void C_ccall f_14577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4995)
static void C_ccall f_4995(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_13339)
static void C_ccall f_13339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11677)
static void C_fcall f_11677(C_word t0,C_word t1) C_noret;
C_noret_decl(f_13398)
static void C_ccall f_13398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11573)
static void C_ccall f_11573(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11544)
static void C_ccall f_11544(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_13375)
static void C_ccall f_13375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6192)
static void C_ccall f_6192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13371)
static void C_ccall f_13371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14080)
static void C_ccall f_14080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9682)
static void C_ccall f_9682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14084)
static void C_ccall f_14084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14082)
static void C_ccall f_14082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9778)
static void C_fcall f_9778(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4702)
static void C_ccall f_4702(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4702)
static void C_ccall f_4702r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_11638)
static void C_ccall f_11638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14088)
static void C_ccall f_14088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4706)
static void C_fcall f_4706(C_word t0,C_word t1) C_noret;
C_noret_decl(f_14086)
static void C_ccall f_14086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5491)
static void C_fcall f_5491(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_14091)
static void C_ccall f_14091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14092)
static void C_ccall f_14092(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9785)
static void C_ccall f_9785(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9673)
static void C_fcall f_9673(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11688)
static void C_fcall f_11688(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6188)
static void C_ccall f_6188(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6188)
static void C_ccall f_6188r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5489)
static void C_ccall f_5489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14061)
static void C_ccall f_14061(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_14060)
static void C_ccall f_14060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9660)
static void C_ccall f_9660(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9666)
static void C_ccall f_9666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4725)
static void C_ccall f_4725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11693)
static void C_ccall f_11693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14067)
static void C_ccall f_14067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4729)
static void C_ccall f_4729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14068)
static void C_ccall f_14068(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11697)
static void C_ccall f_11697(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4726)
static void C_ccall f_4726(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5476)
static void C_ccall f_5476(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6151)
static void C_fcall f_6151(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9653)
static void C_ccall f_9653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9651)
static void C_ccall f_9651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9659)
static void C_ccall f_9659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4715)
static void C_ccall f_4715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4712)
static void C_ccall f_4712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4717)
static void C_ccall f_4717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11084)
static void C_ccall f_11084(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5464)
static void C_ccall f_5464(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6160)
static void C_ccall f_6160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11080)
static void C_ccall f_11080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9642)
static void C_ccall f_9642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9647)
static void C_ccall f_9647(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6140)
static void C_ccall f_6140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6111)
static void C_fcall f_6111(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13730)
static void C_ccall f_13730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6120)
static void C_ccall f_6120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8435)
static void C_ccall f_8435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8438)
static void C_ccall f_8438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6171)
static void C_ccall f_6171(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6175)
static void C_ccall f_6175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13710)
static void C_ccall f_13710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5005)
static void C_fcall f_5005(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5037)
static void C_ccall f_5037(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_13718)
static void C_ccall f_13718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5030)
static void C_ccall f_5030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13742)
static void C_ccall f_13742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13745)
static void C_ccall f_13745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6980)
static void C_ccall f_6980(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6986)
static void C_ccall f_6986(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8445)
static void C_fcall f_8445(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_13777)
static void C_ccall f_13777(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_13771)
static void C_ccall f_13771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8479)
static void C_ccall f_8479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8293)
static void C_ccall f_8293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8290)
static void C_ccall f_8290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13754)
static void C_ccall f_13754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13759)
static void C_ccall f_13759(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8467)
static void C_ccall f_8467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13751)
static void C_ccall f_13751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13782)
static void C_ccall f_13782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13784)
static void C_ccall f_13784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13780)
static void C_ccall f_13780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13789)
static void C_ccall f_13789(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8489)
static void C_ccall f_8489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13612)
static void C_ccall f_13612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13614)
static void C_ccall f_13614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13616)
static void C_ccall f_13616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13618)
static void C_ccall f_13618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9272)
static void C_fcall f_9272(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9270)
static void C_ccall f_9270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6995)
static void C_ccall f_6995(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10567)
static void C_fcall f_10567(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13763)
static void C_ccall f_13763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14240)
static void C_ccall f_14240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10576)
static void C_ccall f_10576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14249)
static void C_ccall f_14249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14245)
static void C_fcall f_14245(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9261)
static void C_ccall f_9261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5807)
static void C_ccall f_5807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14236)
static void C_ccall f_14236(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6972)
static void C_ccall f_6972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6974)
static void C_ccall f_6974(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10587)
static void C_ccall f_10587(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9255)
static void C_ccall f_9255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5800)
static void C_ccall f_5800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5802)
static void C_ccall f_5802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5803)
static void C_ccall f_5803(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13621)
static void C_ccall f_13621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10593)
static void C_ccall f_10593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13624)
static void C_ccall f_13624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13627)
static void C_ccall f_13627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10598)
static void C_ccall f_10598(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_14214)
static void C_ccall f_14214(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_14266)
static void C_ccall f_14266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5817)
static void C_ccall f_5817(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6722)
static void C_ccall f_6722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6724)
static void C_ccall f_6724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6726)
static void C_ccall f_6726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14208)
static void C_ccall f_14208(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6720)
static void C_fcall f_6720(C_word t0,C_word t1) C_noret;
C_noret_decl(f_13605)
static void C_ccall f_13605(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_13605)
static void C_ccall f_13605r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_14277)
static void C_ccall f_14277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5812)
static void C_ccall f_5812(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11019)
static void C_fcall f_11019(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9218)
static void C_fcall f_9218(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5059)
static void C_fcall f_5059(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9216)
static void C_ccall f_9216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5051)
static void C_ccall f_5051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9283)
static void C_fcall f_9283(C_word t0,C_word t1) C_noret;
C_noret_decl(f_14007)
static void C_ccall f_14007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5828)
static void C_ccall f_5828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5822)
static void C_ccall f_5822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11042)
static void C_fcall f_11042(C_word t0,C_word t1) C_noret;
C_noret_decl(f_14037)
static void C_ccall f_14037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5831)
static void C_ccall f_5831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5839)
static void C_ccall f_5839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7270)
static void C_ccall f_7270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14288)
static void C_ccall f_14288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5865)
static void C_ccall f_5865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14012)
static void C_fcall f_14012(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5527)
static void C_ccall f_5527(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_14290)
static void C_ccall f_14290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14225)
static void C_ccall f_14225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14223)
static void C_ccall f_14223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14297)
static void C_ccall f_14297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9249)
static void C_ccall f_9249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5048)
static void C_ccall f_5048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5041)
static void C_fcall f_5041(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9243)
static void C_ccall f_9243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14042)
static void C_ccall f_14042(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_14046)
static void C_ccall f_14046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7276)
static void C_ccall f_7276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7278)
static void C_fcall f_7278(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5515)
static void C_ccall f_5515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7252)
static void C_ccall f_7252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11005)
static void C_fcall f_11005(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11007)
static void C_ccall f_11007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7920)
static void C_fcall f_7920(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5027)
static void C_ccall f_5027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5533)
static void C_fcall f_5533(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7918)
static void C_ccall f_7918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13634)
static void C_ccall f_13634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13630)
static void C_ccall f_13630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7903)
static void C_ccall f_7903(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_14051)
static void C_fcall f_14051(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7901)
static void C_ccall f_7901(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_14054)
static void C_ccall f_14054(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13665)
static void C_ccall f_13665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13660)
static void C_ccall f_13660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5882)
static void C_ccall f_5882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7963)
static void C_ccall f_7963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13645)
static void C_ccall f_13645(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5573)
static void C_ccall f_5573(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5571)
static void C_ccall f_5571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7954)
static void C_ccall f_7954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7956)
static void C_ccall f_7956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7951)
static void C_fcall f_7951(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8783)
static void C_ccall f_8783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7945)
static void C_ccall f_7945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5891)
static void C_ccall f_5891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5894)
static void C_ccall f_5894(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5898)
static void C_ccall f_5898(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6337)
static void C_ccall f_6337(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5841)
static void C_ccall f_5841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f15836)
static void C_ccall f15836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5844)
static void C_ccall f_5844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6396)
static void C_fcall f_6396(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6390)
static void C_ccall f_6390(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5870)
static void C_ccall f_5870(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5877)
static void C_ccall f_5877(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5877)
static void C_ccall f_5877r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5876)
static void C_ccall f_5876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7257)
static void C_ccall f_7257(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7255)
static void C_ccall f_7255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7230)
static void C_ccall f_7230(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_14170)
static void C_ccall f_14170(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_14174)
static void C_ccall f_14174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8716)
static void C_fcall f_8716(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8714)
static void C_ccall f_8714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9617)
static void C_fcall f_9617(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9615)
static void C_ccall f_9615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7238)
static void C_ccall f_7238(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13695)
static void C_ccall f_13695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12513)
static void C_fcall f_12513(C_word t0,C_word t1) C_noret;
C_noret_decl(f_13697)
static void C_fcall f_13697(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_14177)
static void C_fcall f_14177(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6341)
static void C_ccall f_6341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6346)
static void C_ccall f_6346(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7249)
static void C_ccall f_7249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6355)
static void C_ccall f_6355(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_13670)
static void C_ccall f_13670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9715)
static void C_ccall f_9715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9712)
static void C_ccall f_9712(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9711)
static void C_ccall f_9711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12072)
static void C_ccall f_12072(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9728)
static void C_fcall f_9728(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9723)
static void C_ccall f_9723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8758)
static void C_fcall f_8758(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8756)
static void C_ccall f_8756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9720)
static void C_ccall f_9720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8750)
static void C_ccall f_8750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13656)
static void C_fcall f_13656(C_word t0,C_word t1) C_noret;
C_noret_decl(f_13652)
static void C_ccall f_13652(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_13652)
static void C_ccall f_13652r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_9737)
static void C_ccall f_9737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14192)
static void C_ccall f_14192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14189)
static void C_ccall f_14189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9749)
static void C_ccall f_9749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9757)
static void C_ccall f_9757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9751)
static void C_ccall f_9751(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8741)
static void C_ccall f_8741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12669)
static void C_fcall f_12669(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8207)
static void C_fcall f_8207(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12068)
static void C_ccall f_12068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8205)
static void C_ccall f_8205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12063)
static void C_fcall f_12063(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10192)
static void C_ccall f_10192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8232)
static void C_ccall f_8232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10186)
static void C_ccall f_10186(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10184)
static void C_ccall f_10184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10178)
static void C_ccall f_10178(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10690)
static void C_ccall f_10690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10235)
static void C_ccall f_10235(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7602)
static void C_ccall f_7602(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7648)
static void C_ccall f_7648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10244)
static void C_ccall f_10244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10238)
static void C_ccall f_10238(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7623)
static void C_fcall f_7623(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7621)
static void C_ccall f_7621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8417)
static void C_ccall f_8417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4665)
static void C_ccall f_4665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4663)
static void C_ccall f_4663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4669)
static void C_ccall f_4669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8375)
static void C_ccall f_8375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5310)
static void C_fcall f_5310(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10264)
static void C_ccall f_10264(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10261)
static void C_ccall f_10261(C_word c,C_word t0,C_word t1,C_word t2) C_noret;

C_noret_decl(trf_5316)
static void C_fcall trf_5316(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5316(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5316(t0,t1);}

C_noret_decl(trf_8350)
static void C_fcall trf_8350(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8350(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8350(t0,t1,t2);}

C_noret_decl(trf_10753)
static void C_fcall trf_10753(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10753(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10753(t0,t1);}

C_noret_decl(trf_7788)
static void C_fcall trf_7788(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7788(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7788(t0,t1);}

C_noret_decl(trf_6363)
static void C_fcall trf_6363(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6363(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6363(t0,t1);}

C_noret_decl(trf_10715)
static void C_fcall trf_10715(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10715(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10715(t0,t1,t2);}

C_noret_decl(trf_4806)
static void C_fcall trf_4806(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4806(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4806(t0,t1,t2);}

C_noret_decl(trf_8651)
static void C_fcall trf_8651(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8651(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8651(t0,t1);}

C_noret_decl(trf_10739)
static void C_fcall trf_10739(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10739(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10739(t0,t1);}

C_noret_decl(trf_6649)
static void C_fcall trf_6649(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6649(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6649(t0,t1);}

C_noret_decl(trf_5739)
static void C_fcall trf_5739(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5739(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5739(t0,t1,t2);}

C_noret_decl(trf_10893)
static void C_fcall trf_10893(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10893(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10893(t0,t1);}

C_noret_decl(trf_5762)
static void C_fcall trf_5762(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5762(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5762(t0,t1);}

C_noret_decl(trf_10968)
static void C_fcall trf_10968(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10968(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10968(t0,t1);}

C_noret_decl(trf_9040)
static void C_fcall trf_9040(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9040(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9040(t0,t1,t2,t3);}

C_noret_decl(trf_8666)
static void C_fcall trf_8666(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8666(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8666(t0,t1,t2);}

C_noret_decl(trf_10942)
static void C_fcall trf_10942(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10942(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10942(t0,t1);}

C_noret_decl(trf_13982)
static void C_fcall trf_13982(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13982(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_13982(t0,t1,t2);}

C_noret_decl(trf_10916)
static void C_fcall trf_10916(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10916(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10916(t0,t1);}

C_noret_decl(trf_12052)
static void C_fcall trf_12052(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12052(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12052(t0,t1);}

C_noret_decl(trf_11114)
static void C_fcall trf_11114(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11114(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11114(t0,t1);}

C_noret_decl(trf_8308)
static void C_fcall trf_8308(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8308(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8308(t0,t1,t2,t3);}

C_noret_decl(trf_8319)
static void C_fcall trf_8319(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8319(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8319(t0,t1);}

C_noret_decl(trf_9365)
static void C_fcall trf_9365(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9365(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9365(t0,t1,t2);}

C_noret_decl(trf_13179)
static void C_fcall trf_13179(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13179(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_13179(t0,t1,t2);}

C_noret_decl(trf_8607)
static void C_fcall trf_8607(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8607(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_8607(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6131)
static void C_fcall trf_6131(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6131(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6131(t0,t1,t2);}

C_noret_decl(trf_9969)
static void C_fcall trf_9969(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9969(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9969(t0,t1,t2,t3);}

C_noret_decl(trf_7308)
static void C_fcall trf_7308(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7308(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7308(t0,t1,t2);}

C_noret_decl(trf_9937)
static void C_fcall trf_9937(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9937(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9937(t0,t1,t2,t3);}

C_noret_decl(trf_10681)
static void C_fcall trf_10681(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10681(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10681(t0,t1,t2);}

C_noret_decl(trf_7080)
static void C_fcall trf_7080(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7080(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7080(t0,t1,t2);}

C_noret_decl(trf_9314)
static void C_fcall trf_9314(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9314(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9314(t0,t1,t2);}

C_noret_decl(trf_5244)
static void C_fcall trf_5244(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5244(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5244(t0,t1,t2,t3);}

C_noret_decl(trf_4922)
static void C_fcall trf_4922(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4922(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4922(t0,t1);}

C_noret_decl(trf_10165)
static void C_fcall trf_10165(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10165(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10165(t0,t1);}

C_noret_decl(trf_5291)
static void C_fcall trf_5291(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5291(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5291(t0,t1,t2);}

C_noret_decl(trf_7701)
static void C_fcall trf_7701(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7701(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7701(t0,t1,t2);}

C_noret_decl(trf_12741)
static void C_fcall trf_12741(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12741(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12741(t0,t1);}

C_noret_decl(trf_10859)
static void C_fcall trf_10859(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10859(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10859(t0,t1);}

C_noret_decl(trf_6523)
static void C_fcall trf_6523(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6523(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6523(t0,t1);}

C_noret_decl(trf_8117)
static void C_fcall trf_8117(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8117(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8117(t0,t1,t2);}

C_noret_decl(trf_10873)
static void C_fcall trf_10873(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10873(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10873(t0,t1);}

C_noret_decl(trf_4760)
static void C_fcall trf_4760(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4760(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4760(t0,t1,t2);}

C_noret_decl(trf_13530)
static void C_fcall trf_13530(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13530(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_13530(t0,t1);}

C_noret_decl(trf_8159)
static void C_fcall trf_8159(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8159(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8159(t0,t1,t2);}

C_noret_decl(trf_8148)
static void C_fcall trf_8148(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8148(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8148(t0,t1);}

C_noret_decl(trf_10360)
static void C_fcall trf_10360(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10360(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10360(t0,t1);}

C_noret_decl(trf_10824)
static void C_fcall trf_10824(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10824(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10824(t0,t1);}

C_noret_decl(trf_4740)
static void C_fcall trf_4740(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4740(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4740(t0,t1,t2);}

C_noret_decl(trf_6583)
static void C_fcall trf_6583(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6583(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6583(t0,t1);}

C_noret_decl(trf_9456)
static void C_fcall trf_9456(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9456(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9456(t0,t1,t2);}

C_noret_decl(trf_10397)
static void C_fcall trf_10397(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10397(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10397(t0,t1);}

C_noret_decl(trf_7142)
static void C_fcall trf_7142(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7142(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7142(t0,t1,t2);}

C_noret_decl(trf_5447)
static void C_fcall trf_5447(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5447(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5447(t0,t1);}

C_noret_decl(trf_5644)
static void C_fcall trf_5644(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5644(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5644(t0,t1);}

C_noret_decl(trf_13554)
static void C_fcall trf_13554(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13554(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_13554(t0,t1,t2);}

C_noret_decl(trf_13214)
static void C_fcall trf_13214(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13214(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_13214(t0,t1,t2);}

C_noret_decl(trf_9892)
static void C_fcall trf_9892(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9892(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9892(t0,t1);}

C_noret_decl(trf_13207)
static void C_fcall trf_13207(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13207(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_13207(t0,t1);}

C_noret_decl(trf_8556)
static void C_fcall trf_8556(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8556(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8556(t0,t1,t2);}

C_noret_decl(trf_7187)
static void C_fcall trf_7187(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7187(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7187(t0,t1);}

C_noret_decl(trf_13235)
static void C_fcall trf_13235(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13235(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_13235(t0,t1);}

C_noret_decl(trf_12834)
static void C_fcall trf_12834(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12834(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12834(t0,t1);}

C_noret_decl(trf_6553)
static void C_fcall trf_6553(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6553(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6553(t0,t1);}

C_noret_decl(trf_13495)
static void C_fcall trf_13495(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13495(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_13495(t0,t1,t2);}

C_noret_decl(trf_13482)
static void C_fcall trf_13482(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13482(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_13482(t0,t1,t2,t3);}

C_noret_decl(trf_7548)
static void C_fcall trf_7548(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7548(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7548(t0,t1,t2);}

C_noret_decl(trf_6439)
static void C_fcall trf_6439(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6439(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6439(t0,t1,t2);}

C_noret_decl(trf_13271)
static void C_fcall trf_13271(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13271(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_13271(t0,t1,t2);}

C_noret_decl(trf_13264)
static void C_fcall trf_13264(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13264(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_13264(t0,t1);}

C_noret_decl(trf_4833)
static void C_fcall trf_4833(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4833(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4833(t0,t1,t2);}

C_noret_decl(trf_4853)
static void C_fcall trf_4853(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4853(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4853(t0,t1,t2);}

C_noret_decl(trf_12871)
static void C_fcall trf_12871(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12871(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12871(t0,t1);}

C_noret_decl(trf_10044)
static void C_fcall trf_10044(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10044(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10044(t0,t1,t2,t3);}

C_noret_decl(trf_7414)
static void C_fcall trf_7414(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7414(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_7414(t0,t1,t2,t3,t4);}

C_noret_decl(trf_12814)
static void C_fcall trf_12814(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12814(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12814(t0,t1);}

C_noret_decl(trf_7538)
static void C_fcall trf_7538(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7538(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7538(t0,t1);}

C_noret_decl(trf_9408)
static void C_fcall trf_9408(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9408(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9408(t0,t1,t2,t3);}

C_noret_decl(trf_10006)
static void C_fcall trf_10006(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10006(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10006(t0,t1,t2,t3);}

C_noret_decl(trf_14478)
static void C_fcall trf_14478(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14478(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_14478(t0,t1,t2);}

C_noret_decl(trf_8993)
static void C_fcall trf_8993(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8993(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8993(t0,t1,t2);}

C_noret_decl(trf_12850)
static void C_fcall trf_12850(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12850(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12850(t0,t1);}

C_noret_decl(trf_9419)
static void C_fcall trf_9419(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9419(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9419(t0,t1);}

C_noret_decl(trf_9592)
static void C_fcall trf_9592(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9592(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9592(t0,t1,t2);}

C_noret_decl(trf_6627)
static void C_fcall trf_6627(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6627(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6627(t0,t1,t2);}

C_noret_decl(trf_9556)
static void C_fcall trf_9556(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9556(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9556(t0,t1,t2);}

C_noret_decl(trf_5106)
static void C_fcall trf_5106(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5106(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5106(t0,t1,t2,t3);}

C_noret_decl(trf_12102)
static void C_fcall trf_12102(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12102(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12102(t0,t1);}

C_noret_decl(trf_8508)
static void C_fcall trf_8508(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8508(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8508(t0,t1,t2);}

C_noret_decl(trf_7863)
static void C_fcall trf_7863(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7863(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7863(t0,t1,t2);}

C_noret_decl(trf_14124)
static void C_fcall trf_14124(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14124(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_14124(t0,t1,t2);}

C_noret_decl(trf_7810)
static void C_fcall trf_7810(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7810(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7810(t0,t1,t2);}

C_noret_decl(trf_14150)
static void C_fcall trf_14150(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14150(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_14150(t0,t1,t2);}

C_noret_decl(trf_5138)
static void C_fcall trf_5138(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5138(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5138(t0,t1,t2,t3);}

C_noret_decl(trf_13316)
static void C_fcall trf_13316(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13316(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_13316(t0,t1,t2,t3);}

C_noret_decl(trf_6473)
static void C_fcall trf_6473(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6473(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6473(t0,t1);}

C_noret_decl(trf_9518)
static void C_fcall trf_9518(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9518(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9518(t0,t1,t2);}

C_noret_decl(trf_6296)
static void C_fcall trf_6296(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6296(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6296(t0,t1);}

C_noret_decl(trf_9813)
static void C_fcall trf_9813(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9813(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9813(t0,t1);}

C_noret_decl(trf_8858)
static void C_fcall trf_8858(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8858(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8858(t0,t1,t2);}

C_noret_decl(trf_8068)
static void C_fcall trf_8068(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8068(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8068(t0,t1,t2);}

C_noret_decl(trf_11666)
static void C_fcall trf_11666(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11666(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11666(t0,t1);}

C_noret_decl(trf_4941)
static void C_fcall trf_4941(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4941(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4941(t0,t1,t2);}

C_noret_decl(trf_11658)
static void C_fcall trf_11658(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11658(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11658(t0,t1);}

C_noret_decl(trf_13347)
static void C_fcall trf_13347(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13347(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_13347(t0,t1);}

C_noret_decl(trf_11677)
static void C_fcall trf_11677(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11677(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11677(t0,t1);}

C_noret_decl(trf_9778)
static void C_fcall trf_9778(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9778(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9778(t0,t1);}

C_noret_decl(trf_4706)
static void C_fcall trf_4706(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4706(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4706(t0,t1);}

C_noret_decl(trf_5491)
static void C_fcall trf_5491(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5491(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5491(t0,t1,t2);}

C_noret_decl(trf_9673)
static void C_fcall trf_9673(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9673(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9673(t0,t1,t2);}

C_noret_decl(trf_11688)
static void C_fcall trf_11688(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11688(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11688(t0,t1);}

C_noret_decl(trf_6151)
static void C_fcall trf_6151(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6151(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6151(t0,t1,t2);}

C_noret_decl(trf_6111)
static void C_fcall trf_6111(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6111(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6111(t0,t1,t2);}

C_noret_decl(trf_5005)
static void C_fcall trf_5005(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5005(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5005(t0,t1,t2);}

C_noret_decl(trf_8445)
static void C_fcall trf_8445(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8445(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8445(t0,t1,t2,t3);}

C_noret_decl(trf_9272)
static void C_fcall trf_9272(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9272(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9272(t0,t1,t2,t3);}

C_noret_decl(trf_10567)
static void C_fcall trf_10567(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10567(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10567(t0,t1,t2);}

C_noret_decl(trf_14245)
static void C_fcall trf_14245(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14245(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_14245(t0,t1);}

C_noret_decl(trf_6720)
static void C_fcall trf_6720(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6720(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6720(t0,t1);}

C_noret_decl(trf_11019)
static void C_fcall trf_11019(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11019(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11019(t0,t1);}

C_noret_decl(trf_9218)
static void C_fcall trf_9218(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9218(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9218(t0,t1,t2);}

C_noret_decl(trf_5059)
static void C_fcall trf_5059(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5059(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5059(t0,t1,t2,t3);}

C_noret_decl(trf_9283)
static void C_fcall trf_9283(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9283(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9283(t0,t1);}

C_noret_decl(trf_11042)
static void C_fcall trf_11042(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11042(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11042(t0,t1);}

C_noret_decl(trf_14012)
static void C_fcall trf_14012(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14012(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_14012(t0,t1,t2);}

C_noret_decl(trf_5041)
static void C_fcall trf_5041(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5041(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5041(t0,t1);}

C_noret_decl(trf_7278)
static void C_fcall trf_7278(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7278(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7278(t0,t1,t2);}

C_noret_decl(trf_11005)
static void C_fcall trf_11005(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11005(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11005(t0,t1);}

C_noret_decl(trf_7920)
static void C_fcall trf_7920(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7920(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7920(t0,t1,t2);}

C_noret_decl(trf_5533)
static void C_fcall trf_5533(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5533(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5533(t0,t1,t2,t3);}

C_noret_decl(trf_14051)
static void C_fcall trf_14051(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14051(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_14051(t0,t1,t2,t3);}

C_noret_decl(trf_7951)
static void C_fcall trf_7951(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7951(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7951(t0,t1);}

C_noret_decl(trf_6396)
static void C_fcall trf_6396(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6396(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6396(t0,t1,t2);}

C_noret_decl(trf_8716)
static void C_fcall trf_8716(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8716(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8716(t0,t1,t2);}

C_noret_decl(trf_9617)
static void C_fcall trf_9617(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9617(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9617(t0,t1,t2);}

C_noret_decl(trf_12513)
static void C_fcall trf_12513(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12513(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12513(t0,t1);}

C_noret_decl(trf_13697)
static void C_fcall trf_13697(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13697(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_13697(t0,t1,t2,t3,t4);}

C_noret_decl(trf_14177)
static void C_fcall trf_14177(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14177(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_14177(t0,t1);}

C_noret_decl(trf_9728)
static void C_fcall trf_9728(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9728(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9728(t0,t1,t2);}

C_noret_decl(trf_8758)
static void C_fcall trf_8758(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8758(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8758(t0,t1,t2);}

C_noret_decl(trf_13656)
static void C_fcall trf_13656(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13656(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_13656(t0,t1);}

C_noret_decl(trf_12669)
static void C_fcall trf_12669(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12669(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12669(t0,t1);}

C_noret_decl(trf_8207)
static void C_fcall trf_8207(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8207(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8207(t0,t1,t2);}

C_noret_decl(trf_12063)
static void C_fcall trf_12063(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12063(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12063(t0,t1);}

C_noret_decl(trf_7623)
static void C_fcall trf_7623(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7623(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7623(t0,t1,t2);}

C_noret_decl(trf_5310)
static void C_fcall trf_5310(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5310(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5310(t0,t1);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr8)
static void C_fcall tr8(C_proc8 k) C_regparm C_noret;
C_regparm static void C_fcall tr8(C_proc8 k){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
(k)(8,t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* k5318 in k5315 in k5308 in loop in k5288 in c-ify-string in k4697 in k4664 in k4662 */
static void C_ccall f_5319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5319,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5322,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[4];
t4=C_u_i_cdr(t3);
/* support.scm:197: loop */
t5=((C_word*)((C_word*)t0)[5])[1];
f_5291(t5,t2,t4);}

/* k5315 in k5308 in loop in k5288 in c-ify-string in k4697 in k4664 in k4662 */
static void C_fcall f_5316(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5316,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5319,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5327,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm:196: number->string */
C_number_to_string(4,0,t3,((C_word*)t0)[5],C_fix(8));}

/* f_7682 in k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_7682(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7682,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_record4(&a,4,lf[208],t2,t3,t4));}

/* k10768 in k10751 in k10737 in repeat */
static void C_ccall f_10769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10769,2,t0,t1);}
t2=C_a_i_list(&a,2,t1,((C_word*)t0)[2]);
t3=C_a_i_list(&a,1,t2);
t4=(C_truep(*((C_word*)lf[348]+1))?t1:C_a_i_list(&a,2,lf[356],t1));
t5=C_a_i_list(&a,2,lf[95],C_SCHEME_FALSE);
t6=C_a_i_list(&a,4,lf[222],t1,t4,t5);
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_list(&a,3,lf[105],t3,t6));}

/* k4687 in bomb in k4664 in k4662 */
static void C_ccall f_4688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
C_apply(5,0,((C_word*)t0)[3],*((C_word*)lf[4]+1),t1,t3);}

/* map-loop1590 in k8289 in k8146 in k8138 in k8131 in k8124 in walk in build-expression-tree in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_8350(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8350,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8375,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:639: g1596 */
t5=((C_word*)((C_word*)t0)[5])[1];
f_8117(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* f_9708 in k9650 in emit-global-inline-file in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_9708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9708,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9711,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9749,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm:803: chicken-version */
t4=*((C_word*)lf[302]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* f_7661 in k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_7661(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7661,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_record4(&a,4,lf[208],t2,t3,t4));}

/* ##compiler#bomb in k4664 in k4662 */
static void C_ccall f_4675(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_4675r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4675r(t0,t1,t2);}}

static void C_ccall f_4675r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4688,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=t2;
t5=C_u_i_car(t4);
/* support.scm:49: string-append */
t6=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,lf[6],t5);}
else{
/* support.scm:50: error */
t3=*((C_word*)lf[4]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,lf[7]);}}

/* k5321 in k5318 in k5315 in k5308 in loop in k5288 in c-ify-string in k4697 in k4664 in k4662 */
static void C_ccall f_5322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:192: append */
t2=*((C_word*)lf[68]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[69],((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* k7697 in k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_7699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:589: g1279 */
t2=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[241],((C_word*)t0)[4],t1);}

/* k5326 in k5315 in k5308 in loop in k5288 in c-ify-string in k4697 in k4664 in k4662 */
static void C_ccall f_5327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->list */
t2=*((C_word*)lf[70]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k13930 */
static void C_ccall f_13931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13931,2,t0,t1);}
t2=C_i_length(t1);
t3=C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13939,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* support.scm:1483: debugging */
t5=*((C_word*)lf[11]+1);
f_4702(5,t5,t4,lf[256],lf[515],((C_word*)t0)[4]);}
else{
/* support.scm:1486: bomb */
t4=*((C_word*)lf[3]+1);
f_4675(4,t4,((C_word*)t0)[3],lf[516],((C_word*)t0)[4]);}}

/* k10751 in k10737 in repeat */
static void C_fcall f_10753(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10753,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(*((C_word*)lf[348]+1))?((C_word*)t0)[3]:C_a_i_list(&a,2,lf[353],((C_word*)t0)[3])));}
else{
t2=C_eqp(((C_word*)t0)[4],lf[354]);
t3=(C_truep(t2)?t2:C_eqp(((C_word*)t0)[4],lf[355]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10769,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1025: gensym */
t5=*((C_word*)lf[106]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=C_eqp(((C_word*)t0)[4],lf[357]);
t5=(C_truep(t4)?t4:C_eqp(((C_word*)t0)[4],lf[358]));
if(C_truep(t5)){
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(*((C_word*)lf[348]+1))?((C_word*)t0)[3]:C_a_i_list(&a,2,lf[356],((C_word*)t0)[3])));}
else{
t6=C_eqp(((C_word*)t0)[4],lf[359]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10812,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1037: gensym */
t8=*((C_word*)lf[106]+1);
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t7=C_eqp(((C_word*)t0)[4],lf[361]);
if(C_truep(t7)){
if(C_truep(*((C_word*)lf[348]+1))){
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,((C_word*)t0)[3]);}
else{
t8=C_a_i_list(&a,2,lf[95],lf[359]);
t9=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_a_i_list(&a,3,lf[360],t8,((C_word*)t0)[3]));}}
else{
t8=C_eqp(((C_word*)t0)[4],lf[362]);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10859,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t8)){
t10=t9;
f_10859(t10,t8);}
else{
t10=C_eqp(((C_word*)t0)[4],lf[412]);
if(C_truep(t10)){
t11=t9;
f_10859(t11,t10);}
else{
t11=C_eqp(((C_word*)t0)[4],lf[413]);
if(C_truep(t11)){
t12=t9;
f_10859(t12,t11);}
else{
t12=C_eqp(((C_word*)t0)[4],lf[414]);
if(C_truep(t12)){
t13=t9;
f_10859(t13,t12);}
else{
t13=C_eqp(((C_word*)t0)[4],lf[415]);
if(C_truep(t13)){
t14=t9;
f_10859(t14,t13);}
else{
t14=C_eqp(((C_word*)t0)[4],lf[416]);
if(C_truep(t14)){
t15=t9;
f_10859(t15,t14);}
else{
t15=C_eqp(((C_word*)t0)[4],lf[417]);
t16=t9;
f_10859(t16,(C_truep(t15)?t15:C_eqp(((C_word*)t0)[4],lf[418])));}}}}}}}}}}}}

/* k13938 in k13930 */
static void C_ccall f_13939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_car(((C_word*)t0)[2]);
/* support.scm:1484: k */
t3=((C_word*)t0)[3];
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[4],C_SCHEME_TRUE,((C_word*)t0)[5],t2,C_SCHEME_FALSE);}

/* k4697 in k4664 in k4662 */
static void C_ccall f_4699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word ab[59],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4699,2,t0,t1);}
t2=C_mutate((C_word*)lf[8]+1 /* (set! ##compiler#collected-debugging-output ...) */,t1);
t3=C_mutate((C_word*)lf[9]+1 /* (set! +logged-debugging-modes+ ...) */,lf[10]);
t4=C_mutate((C_word*)lf[11]+1 /* (set! ##compiler#debugging ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4702,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[21]+1 /* (set! ##compiler#with-debugging-output ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4802,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[26]+1 /* (set! ##compiler#quit ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4904,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[31]+1 /* (set! ##sys#syntax-error-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4918,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[40]+1 /* (set! syntax-error ...) */,*((C_word*)lf[31]+1));
t9=C_mutate((C_word*)lf[41]+1 /* (set! ##compiler#emit-syntax-trace-info ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4995,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[42]+1 /* (set! map-llist ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4999,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[43]+1 /* (set! ##compiler#check-signature ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5037,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[46]+1 /* (set! ##compiler#posq ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5100,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[47]+1 /* (set! ##compiler#posv ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5132,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[48]+1 /* (set! ##compiler#stringify ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5164,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[52]+1 /* (set! ##compiler#symbolify ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5190,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[54]+1 /* (set! ##compiler#slashify ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5220,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[59]+1 /* (set! ##compiler#uncommentify ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5229,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[62]+1 /* (set! ##compiler#build-lambda-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5238,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate((C_word*)lf[63]+1 /* (set! ##compiler#string->c-identifier ...) */,*((C_word*)lf[64]+1));
t20=C_mutate((C_word*)lf[65]+1 /* (set! ##compiler#c-ify-string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5276,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate((C_word*)lf[74]+1 /* (set! ##compiler#valid-c-identifier? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5361,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate((C_word*)lf[76]+1 /* (set! ##compiler#words ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5409,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate((C_word*)lf[77]+1 /* (set! ##compiler#words->bytes ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5416,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate((C_word*)lf[78]+1 /* (set! ##compiler#check-and-open-input-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5423,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate((C_word*)lf[85]+1 /* (set! ##compiler#close-checked-input-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5464,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate((C_word*)lf[88]+1 /* (set! ##compiler#fold-inner ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5476,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[90]+1 /* (set! ##compiler#follow-without-loop ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5527,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate((C_word*)lf[91]+1 /* (set! ##compiler#sort-symbols ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5556,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate((C_word*)lf[94]+1 /* (set! ##compiler#constant? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5573,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate((C_word*)lf[96]+1 /* (set! ##compiler#collapsable-literal? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5613,tmp=(C_word)a,a+=2,tmp));
t31=C_mutate((C_word*)lf[97]+1 /* (set! ##compiler#immediate? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5640,tmp=(C_word)a,a+=2,tmp));
t32=C_mutate((C_word*)lf[99]+1 /* (set! ##compiler#basic-literal? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5681,tmp=(C_word)a,a+=2,tmp));
t33=C_mutate((C_word*)lf[102]+1 /* (set! ##compiler#canonicalize-begin-body ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5733,tmp=(C_word)a,a+=2,tmp));
t34=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5800,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:298: condition-predicate */
t35=*((C_word*)lf[559]+1);
((C_proc3)(void*)(*((C_word*)t35+1)))(3,t35,t34,lf[513]);}

/* k7786 in k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_7788(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7788,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7789,tmp=(C_word)a,a+=2,tmp);
t3=((C_word*)t0)[2];
t4=C_u_i_car(t3);
t5=C_i_cadr(((C_word*)t0)[2]);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=((C_word*)t0)[2];
t11=C_u_i_cdr(t10);
t12=C_u_i_cdr(t11);
t13=C_i_check_list_2(t12,lf[160]);
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7808,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t15=C_SCHEME_UNDEFINED;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_set_block_item(t16,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7810,a[2]=t9,a[3]=t16,a[4]=t7,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t18=((C_word*)t16)[1];
f_7810(t18,t14,t12);}
else{
t2=C_eqp(((C_word*)t0)[5],lf[247]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7845,tmp=(C_word)a,a+=2,tmp);
t4=C_a_i_list1(&a,1,C_SCHEME_TRUE);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=((C_word*)t0)[2];
t10=C_u_i_cdr(t9);
t11=C_i_check_list_2(t10,lf[160]);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7861,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7863,a[2]=t8,a[3]=t14,a[4]=t6,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t16=((C_word*)t14)[1];
f_7863(t16,t12,t10);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7896,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7901,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* support.scm:604: ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[3],t3,t4);}}}

/* f_7789 in k7786 in k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_7789(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7789,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_record4(&a,4,lf[208],t2,t3,t4));}

/* k8395 in k8146 in k8138 in k8131 in k8124 in walk in build-expression-tree in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_8396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8396,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list3(&a,3,((C_word*)t0)[3],((C_word*)t0)[4],t1));}

/* k12646 in foreign-type->scrutiny-type in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_12647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12647,2,t0,t1);}
t2=t1;
t3=C_eqp(t2,lf[436]);
if(C_truep(t3)){
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[193]);}
else{
t4=C_eqp(t2,lf[346]);
t5=(C_truep(t4)?t4:C_eqp(t2,lf[347]));
if(C_truep(t5)){
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[346]);}
else{
t6=C_eqp(t2,lf[350]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12669,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t6)){
t8=t7;
f_12669(t8,t6);}
else{
t8=C_eqp(t2,lf[421]);
if(C_truep(t8)){
t9=t7;
f_12669(t9,t8);}
else{
t9=C_eqp(t2,lf[422]);
if(C_truep(t9)){
t10=t7;
f_12669(t10,t9);}
else{
t10=C_eqp(t2,lf[423]);
if(C_truep(t10)){
t11=t7;
f_12669(t11,t10);}
else{
t11=C_eqp(t2,lf[424]);
if(C_truep(t11)){
t12=t7;
f_12669(t12,t11);}
else{
t12=C_eqp(t2,lf[425]);
if(C_truep(t12)){
t13=t7;
f_12669(t13,t12);}
else{
t13=C_eqp(t2,lf[426]);
t14=t7;
f_12669(t14,(C_truep(t13)?t13:C_eqp(t2,lf[427])));}}}}}}}}}

/* ##compiler#foreign-type->scrutiny-type in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_12643(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_12643,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12647,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm:1252: final-foreign-type */
t5=*((C_word*)lf[431]+1);
f_11602(3,t5,t4,t2);}

/* k6360 in get-line-2 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_6361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6361,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6363,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=C_i_cdr(t1);
t4=t2;
f_6363(t4,C_i_assq(((C_word*)t0)[4],t3));}
else{
t3=t2;
f_6363(t3,C_SCHEME_FALSE);}}

/* k6362 in k6360 in get-line-2 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_6363(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6363,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6367,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:417: g723 */
t3=t2;
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[3],t1);}
else{
/* support.scm:422: values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[4],C_SCHEME_FALSE);}}

/* k12536 in k12511 in k12407 in finish-foreign-result in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_12537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[60],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12537,2,t0,t1);}
t2=C_a_i_list(&a,2,t1,((C_word*)t0)[2]);
t3=C_a_i_list(&a,1,t2);
t4=C_a_i_list(&a,2,lf[450],t1);
t5=C_a_i_list(&a,2,lf[451],t4);
t6=C_i_caddr(((C_word*)t0)[3]);
t7=C_a_i_list(&a,2,lf[95],lf[385]);
t8=C_a_i_list(&a,4,lf[452],t6,t7,t1);
t9=C_a_i_list(&a,4,lf[453],t1,t5,t8);
t10=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_a_i_list(&a,3,lf[105],t3,t9));}

/* f_6367 in k6362 in k6360 in get-line-2 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_6367(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6367,3,t0,t1,t2);}
t3=C_i_car(((C_word*)t0)[2]);
t4=C_i_cdr(t2);
/* support.scm:421: values */
C_values(4,0,t1,t3,t4);}

/* repeat */
static void C_fcall f_10715(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10715,NULL,3,t0,t1,t2);}
t3=t2;
t4=C_eqp(t3,lf[346]);
t5=(C_truep(t4)?t4:C_eqp(t3,lf[347]));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(*((C_word*)lf[348]+1))?((C_word*)t0)[2]:C_a_i_list(&a,2,lf[349],((C_word*)t0)[2])));}
else{
t6=C_eqp(t3,lf[350]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10739,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t6)){
t8=t7;
f_10739(t8,t6);}
else{
t8=C_eqp(t3,lf[421]);
if(C_truep(t8)){
t9=t7;
f_10739(t9,t8);}
else{
t9=C_eqp(t3,lf[422]);
if(C_truep(t9)){
t10=t7;
f_10739(t10,t9);}
else{
t10=C_eqp(t3,lf[423]);
if(C_truep(t10)){
t11=t7;
f_10739(t11,t10);}
else{
t11=C_eqp(t3,lf[424]);
if(C_truep(t11)){
t12=t7;
f_10739(t12,t11);}
else{
t12=C_eqp(t3,lf[425]);
if(C_truep(t12)){
t13=t7;
f_10739(t13,t12);}
else{
t13=C_eqp(t3,lf[426]);
t14=t7;
f_10739(t14,(C_truep(t13)?t13:C_eqp(t3,lf[427])));}}}}}}}}

/* f_10710 in foreign-type-check in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_10710(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10710,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10715,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_10715(t7,t1,t2);}

/* f_9207 in k9254 in k9248 in k9194 in k9191 */
static void C_ccall f_9207(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9207,3,t0,t1,t2);}
/* support.scm:751: g2036 */
t3=((C_word*)((C_word*)t0)[2])[1];
f_9040(t3,t1,t2,((C_word*)t0)[3]);}

/* ##compiler#with-debugging-output in k4697 in k4664 in k4662 */
static void C_ccall f_4802(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4802,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4806,a[2]=t2,tmp=(C_word)a,a+=3,tmp));
t9=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4853,tmp=(C_word)a,a+=2,tmp));
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4875,a[2]=t5,a[3]=t1,a[4]=t7,a[5]=t2,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* support.scm:94: test-mode */
f_4853(t10,t2,*((C_word*)lf[1]+1));}

/* f_4809 in collect in with-debugging-output in k4697 in k4664 in k4662 */
static void C_ccall f_4809(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4809,3,t0,t1,t2);}
t3=*((C_word*)lf[8]+1);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4812,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[2]))){
t5=((C_word*)t0)[2];
t6=C_u_i_car(t5);
/* support.scm:85: display */
t7=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,t6,*((C_word*)lf[8]+1));}
else{
t5=((C_word*)t0)[2];
/* support.scm:85: display */
t6=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,t3);}}

/* collect in with-debugging-output in k4697 in k4664 in k4662 */
static void C_fcall f_4806(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4806,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4809,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4828,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm:89: string-split */
t5=*((C_word*)lf[22]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[23]);}

/* k4799 in debugging in k4697 in k4664 in k4662 */
static void C_ccall f_4800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:79: dump */
t2=((C_word*)((C_word*)t0)[2])[1];
f_4760(t2,((C_word*)t0)[3],t1);}

/* k8649 in k8146 in k8138 in k8131 in k8124 in walk in build-expression-tree in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_8651(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8651,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8657,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_i_car(((C_word*)t0)[2]);
/* support.scm:669: walk */
t4=((C_word*)((C_word*)t0)[6])[1];
f_8117(t4,t2,t3);}
else{
t2=C_eqp(((C_word*)t0)[4],lf[246]);
t3=(C_truep(t2)?t2:C_eqp(((C_word*)t0)[4],lf[268]));
if(C_truep(t3)){
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_i_check_list_2(((C_word*)t0)[2],lf[160]);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8714,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8716,a[2]=t7,a[3]=t11,a[4]=t5,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_8716(t13,t9,((C_word*)t0)[2]);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8750,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_i_check_list_2(((C_word*)t0)[2],lf[160]);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8756,a[2]=t4,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8758,a[2]=t8,a[3]=t12,a[4]=t6,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t14=((C_word*)t12)[1];
f_8758(t14,t10,((C_word*)t0)[2]);}}}

/* k8656 in k8649 in k8146 in k8138 in k8131 in k8124 in walk in build-expression-tree in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_8657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8657,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_u_i_cdr(((C_word*)t0)[2]);
t7=C_i_check_list_2(t6,lf[160]);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8664,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8666,a[2]=t5,a[3]=t10,a[4]=t3,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_8666(t12,t8,t6);}

/* k10737 in repeat */
static void C_fcall f_10739(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10739,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(*((C_word*)lf[348]+1))){
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,2,lf[351],((C_word*)t0)[2]));}}
else{
t2=C_eqp(((C_word*)t0)[4],lf[352]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10753,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_10753(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[4],lf[419]);
t5=t3;
f_10753(t5,(C_truep(t4)?t4:C_eqp(((C_word*)t0)[4],lf[420])));}}}

/* f_5385 in k5364 in valid-c-identifier? in k4697 in k4664 in k4662 */
static void C_ccall f_5385(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5385,3,t0,t1,t2);}
t3=C_u_i_char_alphabeticp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=C_u_i_char_numericp(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?t4:C_i_char_equalp(C_make_character(95),t2)));}}

/* k8640 in loop in k8146 in k8138 in k8131 in k8124 in walk in build-expression-tree in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_8641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8641,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[2]);
/* support.scm:667: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8607(t3,((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6],t2);}

/* ##compiler#foreign-type-check in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_10704(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10704,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10710,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11539,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm:1015: follow-without-loop */
t6=*((C_word*)lf[90]+1);
f_5527(5,t6,t1,t3,t4,t5);}

/* k4827 in collect in with-debugging-output in k4697 in k4664 in k4662 */
static void C_ccall f_4828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4828,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4833,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_4833(t5,((C_word*)t0)[3],t1);}

/* k6647 in loop in k6486 */
static void C_fcall f_6649(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6649,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[13]+1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6651,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* write-char/port */
t4=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_make_character(9),*((C_word*)lf[13]+1));}
else{
t2=C_eqp(((C_word*)t0)[4],lf[168]);
if(C_truep(t2)){
t3=C_mutate(((C_word *)((C_word*)t0)[5])+1,lf[168]);
t4=((C_word*)t0)[2];
t5=C_u_i_cdr(t4);
/* support.scm:490: loop */
t6=((C_word*)((C_word*)t0)[6])[1];
f_6627(t6,((C_word*)t0)[7],t5);}
else{
t3=C_eqp(((C_word*)t0)[4],lf[171]);
if(C_truep(t3)){
t4=C_eqp(((C_word*)((C_word*)t0)[5])[1],lf[168]);
if(C_truep(t4)){
t5=((C_word*)t0)[2];
t6=C_u_i_cdr(t5);
/* support.scm:490: loop */
t7=((C_word*)((C_word*)t0)[6])[1];
f_6627(t7,((C_word*)t0)[7],t6);}
else{
t5=C_i_cdar(((C_word*)t0)[2]);
t6=C_mutate(((C_word *)((C_word*)t0)[5])+1,t5);
t7=((C_word*)t0)[2];
t8=C_u_i_cdr(t7);
/* support.scm:490: loop */
t9=((C_word*)((C_word*)t0)[6])[1];
f_6627(t9,((C_word*)t0)[7],t8);}}
else{
t4=C_eqp(((C_word*)t0)[4],lf[172]);
if(C_truep(t4)){
t5=C_eqp(((C_word*)((C_word*)t0)[5])[1],lf[168]);
if(C_truep(t5)){
t6=((C_word*)t0)[2];
t7=C_u_i_cdr(t6);
/* support.scm:490: loop */
t8=((C_word*)((C_word*)t0)[6])[1];
f_6627(t8,((C_word*)t0)[7],t7);}
else{
t6=C_i_cdar(((C_word*)t0)[2]);
t7=C_mutate(((C_word *)((C_word*)t0)[8])+1,t6);
t8=((C_word*)t0)[2];
t9=C_u_i_cdr(t8);
/* support.scm:490: loop */
t10=((C_word*)((C_word*)t0)[6])[1];
f_6627(t10,((C_word*)t0)[7],t9);}}
else{
t5=C_eqp(((C_word*)t0)[4],lf[173]);
if(C_truep(t5)){
t6=C_i_cdar(((C_word*)t0)[2]);
t7=C_mutate(((C_word *)((C_word*)t0)[9])+1,t6);
t8=((C_word*)t0)[2];
t9=C_u_i_cdr(t8);
/* support.scm:490: loop */
t10=((C_word*)((C_word*)t0)[6])[1];
f_6627(t10,((C_word*)t0)[7],t9);}
else{
t6=C_eqp(((C_word*)t0)[4],lf[174]);
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6720,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t6)){
t8=t7;
f_6720(t8,t6);}
else{
t8=C_eqp(((C_word*)t0)[4],lf[178]);
if(C_truep(t8)){
t9=t7;
f_6720(t9,t8);}
else{
t9=C_eqp(((C_word*)t0)[4],lf[179]);
if(C_truep(t9)){
t10=t7;
f_6720(t10,t9);}
else{
t10=C_eqp(((C_word*)t0)[4],lf[157]);
if(C_truep(t10)){
t11=t7;
f_6720(t11,t10);}
else{
t11=C_eqp(((C_word*)t0)[4],lf[180]);
if(C_truep(t11)){
t12=t7;
f_6720(t12,t11);}
else{
t12=C_eqp(((C_word*)t0)[4],lf[181]);
if(C_truep(t12)){
t13=t7;
f_6720(t13,t12);}
else{
t13=C_eqp(((C_word*)t0)[4],lf[182]);
if(C_truep(t13)){
t14=t7;
f_6720(t14,t13);}
else{
t14=C_eqp(((C_word*)t0)[4],lf[183]);
t15=t7;
f_6720(t15,(C_truep(t14)?t14:C_eqp(((C_word*)t0)[4],lf[184])));}}}}}}}}}}}}}

/* k4811 */
static void C_ccall f_4812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4812,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4814,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* write-char/port */
t3=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(124),((C_word*)t0)[3]);}

/* k4813 in k4811 */
static void C_ccall f_4814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4814,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4816,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:85: display */
t3=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[4],((C_word*)t0)[3]);}

/* k4815 in k4813 in k4811 */
static void C_ccall f_4816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(10),((C_word*)t0)[3]);}

/* k5730 in k5694 in basic-literal? in k4697 in k4664 in k4662 */
static void C_ccall f_5731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:277: every */
t2=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[99]+1),t1);}

/* loop in canonicalize-begin-body in k4697 in k4664 in k4662 */
static void C_fcall f_5739(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5739,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[103]);}
else{
t3=C_i_cdr(t2);
if(C_truep(C_i_nullp(t3))){
t4=t2;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_u_i_car(t4));}
else{
t4=t2;
t5=C_u_i_car(t4);
t6=C_i_equalp(t5,lf[104]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5762,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t6)){
t8=t7;
f_5762(t8,t6);}
else{
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5788,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* support.scm:291: constant? */
t9=*((C_word*)lf[94]+1);
f_5573(3,t9,t8,t5);}}}}

/* ##compiler#canonicalize-begin-body in k4697 in k4664 in k4662 */
static void C_ccall f_5733(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5733,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5739,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_5739(t6,t1,t2);}

/* k7770 in k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_7771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7771,2,t0,t1);}
t2=C_i_cadr(t1);
t3=C_a_i_list4(&a,4,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7756,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7759,a[2]=((C_word*)t0)[7],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* support.scm:597: sixth */
t6=*((C_word*)lf[244]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[8]);}

/* k10891 in k10857 in k10751 in k10737 in repeat */
static void C_fcall f_10893(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10893,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(*((C_word*)lf[348]+1))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[4];
t3=C_u_i_assq(t2,lf[364]);
t4=C_slot(t3,C_fix(1));
t5=C_a_i_list(&a,2,lf[95],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_list(&a,3,lf[360],t5,((C_word*)t0)[3]));}}
else{
t2=C_eqp(((C_word*)t0)[5],lf[365]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10916,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_10916(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[5],lf[402]);
if(C_truep(t4)){
t5=t3;
f_10916(t5,t4);}
else{
t5=C_eqp(((C_word*)t0)[5],lf[403]);
t6=t3;
f_10916(t6,(C_truep(t5)?t5:C_eqp(((C_word*)t0)[5],lf[404])));}}}}

/* k5760 in loop in canonicalize-begin-body in k4697 in k4664 in k4662 */
static void C_fcall f_5762(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5762,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
/* support.scm:293: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_5739(t4,((C_word*)t0)[4],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5784,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm:294: gensym */
t3=*((C_word*)lf[106]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[107]);}}

/* k5345 in k5308 in loop in k5288 in c-ify-string in k4697 in k4664 in k4662 */
static void C_ccall f_5346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5346,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* k6637 in loop in k6486 */
static void C_ccall f_6639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
/* support.scm:490: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6627(t4,((C_word*)t0)[4],t3);}

/* k10966 in k10940 in k10914 in k10891 in k10857 in k10751 in k10737 in repeat */
static void C_fcall f_10968(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10968,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10970,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1076: gensym */
t3=*((C_word*)lf[106]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=C_eqp(((C_word*)t0)[4],lf[375]);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_list(&a,2,lf[374],((C_word*)t0)[2]));}
else{
t3=C_eqp(((C_word*)t0)[4],lf[376]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11005,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t3)){
t5=t4;
f_11005(t5,t3);}
else{
t5=C_eqp(((C_word*)t0)[4],lf[396]);
if(C_truep(t5)){
t6=t4;
f_11005(t6,t5);}
else{
t6=C_eqp(((C_word*)t0)[4],lf[397]);
t7=t4;
f_11005(t7,(C_truep(t6)?t6:C_eqp(((C_word*)t0)[4],lf[398])));}}}}}

/* k7332 in map-loop1116 in k7248 in k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_7333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7333,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7308(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7308(t6,((C_word*)t0)[5],t5);}}

/* k10969 in k10966 in k10940 in k10914 in k10891 in k10857 in k10751 in k10737 in repeat */
static void C_ccall f_10970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10970,2,t0,t1);}
t2=C_a_i_list(&a,2,t1,((C_word*)t0)[2]);
t3=C_a_i_list(&a,1,t2);
t4=C_a_i_list(&a,2,lf[374],t1);
t5=C_a_i_list(&a,2,lf[95],C_SCHEME_FALSE);
t6=C_a_i_list(&a,4,lf[222],t1,t4,t5);
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_list(&a,3,lf[105],t3,t6));}

/* walk in k9030 in copy-node-tree-and-rename in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_9040(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9040,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9043,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9049,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* support.scm:712: g1904 */
t6=t4;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k9047 in walk in k9030 in copy-node-tree-and-rename in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_9049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9049,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9050,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9056,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* support.scm:713: g1907 */
t4=t2;
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[7]);}

/* f_9043 in walk in k9030 in copy-node-tree-and-rename in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_9043(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9043,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_slot(t2,C_fix(3)));}

/* k9030 in copy-node-tree-and-rename in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_9032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9032,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9040,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp));
/* support.scm:753: walk */
t5=((C_word*)t3)[1];
f_9040(t5,((C_word*)t0)[4],((C_word*)t0)[5],t1);}

/* f_6039 in k6036 in initialize-analysis-database in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_6039(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6039,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6041,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6057,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm:360: g586 */
t5=t3;
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,t2,lf[137],lf[140]);}

/* k6036 in initialize-analysis-database in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_6038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6038,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6039,tmp=(C_word)a,a+=2,tmp);
t3=*((C_word*)lf[141]+1);
t4=C_i_check_list_2(*((C_word*)lf[141]+1),lf[33]);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6085,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6131,a[2]=t7,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_6131(t9,t5,*((C_word*)lf[141]+1));}

/* ##compiler#copy-node-tree-and-rename in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_9023(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_9023,7,t0,t1,t2,t3,t4,t5,t6);}
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=*((C_word*)lf[282]+1);
t12=C_i_check_list_2(t3,lf[160]);
t13=C_i_check_list_2(t4,lf[160]);
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9032,a[2]=t6,a[3]=t5,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t15=C_SCHEME_UNDEFINED;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_set_block_item(t16,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9408,a[2]=t10,a[3]=t16,a[4]=t8,tmp=(C_word)a,a+=5,tmp));
t18=((C_word*)t16)[1];
f_9408(t18,t14,t3,t4);}

/* f_6041 */
static void C_ccall f_6041(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr4r,(void*)f_6041r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6041r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6041r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
if(C_truep(C_i_nullp(t4))){
/* tweaks.scm:54: ##sys#put! */
t5=*((C_word*)lf[134]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,t3,C_SCHEME_TRUE);}
else{
t5=C_i_car(t4);
/* tweaks.scm:54: ##sys#put! */
t6=*((C_word*)lf[134]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,t2,t3,t5);}}

/* f_7373 in k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_7373(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7373,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_record4(&a,4,lf[208],t2,t3,t4));}

/* k9017 in map-loop1814 */
static void C_ccall f_9018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9018,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8993(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8993(t6,((C_word*)t0)[5],t5);}}

/* map-loop1708 in k8656 in k8649 in k8146 in k8138 in k8131 in k8124 in walk in build-expression-tree in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_8666(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8666,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8691,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:669: g1714 */
t5=((C_word*)((C_word*)t0)[5])[1];
f_8117(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8662 in k8656 in k8649 in k8146 in k8138 in k8131 in k8124 in walk in build-expression-tree in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_8664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:669: cons* */
t2=*((C_word*)lf[265]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],t1);}

/* f_7345 in k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_7345(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7345,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_record4(&a,4,lf[208],t2,t3,t4));}

/* k9085 in k9061 in k9054 in k9047 in walk in k9030 in copy-node-tree-and-rename in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_9086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9086,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9092,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=((C_word*)t0)[3];
/* support.scm:710: alist-ref */
t4=*((C_word*)lf[283]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t2,((C_word*)t0)[4],t3,*((C_word*)lf[25]+1),((C_word*)t0)[4]);}

/* k8690 in map-loop1708 in k8656 in k8649 in k8146 in k8138 in k8131 in k8124 in walk in build-expression-tree in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_8691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8691,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8666(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8666(t6,((C_word*)t0)[5],t5);}}

/* k10940 in k10914 in k10891 in k10857 in k10751 in k10737 in repeat */
static void C_fcall f_10942(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10942,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(*((C_word*)lf[348]+1))){
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,2,lf[370],((C_word*)t0)[2]));}}
else{
t2=C_eqp(((C_word*)t0)[4],lf[371]);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(*((C_word*)lf[348]+1))?((C_word*)t0)[2]:C_a_i_list(&a,2,lf[372],((C_word*)t0)[2])));}
else{
t3=C_eqp(((C_word*)t0)[4],lf[373]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10968,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t3)){
t5=t4;
f_10968(t5,t3);}
else{
t5=C_eqp(((C_word*)t0)[4],lf[399]);
t6=t4;
f_10968(t6,(C_truep(t5)?t5:C_eqp(((C_word*)t0)[4],lf[400])));}}}}

/* f_9070 in k9061 in k9054 in k9047 in walk in k9030 in copy-node-tree-and-rename in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_9070(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9070,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_record4(&a,4,lf[208],t2,t3,t4));}

/* map-loop3643 in k13886 in constant-form-eval in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_13982(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13982,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14007,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:1474: g3649 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k13978 in k13886 in constant-form-eval in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13980,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13892,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13897,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* support.scm:1472: call-with-current-continuation */
t5=*((C_word*)lf[119]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k9061 in k9054 in k9047 in walk in k9030 in copy-node-tree-and-rename in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_9063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9063,2,t0,t1);}
t2=C_eqp(t1,lf[95]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9070,tmp=(C_word)a,a+=2,tmp);
/* support.scm:717: g1918 */
t4=t3;
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[2],t1,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);}
else{
t3=C_eqp(t1,lf[218]);
if(C_truep(t3)){
t4=C_i_car(((C_word*)t0)[3]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9086,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9095,a[2]=((C_word*)t0)[5],a[3]=t5,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* support.scm:720: get */
t7=*((C_word*)lf[144]+1);
f_6171(5,t7,t6,((C_word*)t0)[6],t4,lf[188]);}
else{
t4=C_eqp(t1,lf[241]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9105,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9126,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t7=C_i_car(((C_word*)t0)[3]);
t8=((C_word*)t0)[4];
/* support.scm:710: alist-ref */
t9=*((C_word*)lf[283]+1);
((C_proc6)(void*)(*((C_word*)t9+1)))(6,t9,t6,t7,t8,*((C_word*)lf[25]+1),t7);}
else{
t5=C_eqp(t1,lf[105]);
if(C_truep(t5)){
t6=C_i_car(((C_word*)t0)[3]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9139,a[2]=t6,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t8=C_i_car(((C_word*)t0)[7]);
/* support.scm:729: walk */
t9=((C_word*)((C_word*)t0)[8])[1];
f_9040(t9,t7,t8,((C_word*)t0)[4]);}
else{
t6=C_eqp(t1,lf[129]);
if(C_truep(t6)){
t7=C_i_caddr(((C_word*)t0)[3]);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9181,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* support.scm:737: decompose-lambda-list */
t9=*((C_word*)lf[120]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,((C_word*)t0)[2],t7,t8);}
else{
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9343,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9352,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=t7,a[6]=((C_word*)t0)[2],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* support.scm:752: tree-copy */
t9=*((C_word*)lf[286]+1);
f_9450(3,t9,t8,((C_word*)t0)[3]);}}}}}}

/* k7359 in k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_7360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7360,2,t0,t1);}
t2=C_a_i_list1(&a,1,t1);
/* support.scm:556: g1171 */
t3=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[231],((C_word*)t0)[4],t2);}

/* k5783 in k5760 in loop in canonicalize-begin-body in k4697 in k4664 in k4662 */
static void C_ccall f_5784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5784,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_u_i_car(t2);
t4=C_a_i_list(&a,2,t1,t3);
t5=C_a_i_list(&a,1,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5776,a[2]=((C_word*)t0)[3],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=((C_word*)t0)[2];
t8=C_u_i_cdr(t7);
/* support.scm:295: loop */
t9=((C_word*)((C_word*)t0)[4])[1];
f_5739(t9,t6,t8);}

/* k5787 in loop in canonicalize-begin-body in k4697 in k4664 in k4662 */
static void C_ccall f_5788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];
f_5762(t3,t2);}
else{
t2=((C_word*)t0)[2];
f_5762(t2,C_i_equalp(((C_word*)t0)[3],lf[108]));}}

/* f_12043 in estimate-foreign-result-location-size in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_12043(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_12043,4,t0,t1,t2,t3);}
t4=t2;
t5=C_eqp(t4,lf[346]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12052,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=t6;
f_12052(t7,t5);}
else{
t7=C_eqp(t4,lf[350]);
if(C_truep(t7)){
t8=t6;
f_12052(t8,t7);}
else{
t8=C_eqp(t4,lf[422]);
if(C_truep(t8)){
t9=t6;
f_12052(t9,t8);}
else{
t9=C_eqp(t4,lf[435]);
if(C_truep(t9)){
t10=t6;
f_12052(t10,t9);}
else{
t10=C_eqp(t4,lf[423]);
if(C_truep(t10)){
t11=t6;
f_12052(t11,t10);}
else{
t11=C_eqp(t4,lf[347]);
if(C_truep(t11)){
t12=t6;
f_12052(t12,t11);}
else{
t12=C_eqp(t4,lf[421]);
if(C_truep(t12)){
t13=t6;
f_12052(t13,t12);}
else{
t13=C_eqp(t4,lf[402]);
if(C_truep(t13)){
t14=t6;
f_12052(t14,t13);}
else{
t14=C_eqp(t4,lf[401]);
if(C_truep(t14)){
t15=t6;
f_12052(t15,t14);}
else{
t15=C_eqp(t4,lf[424]);
if(C_truep(t15)){
t16=t6;
f_12052(t16,t15);}
else{
t16=C_eqp(t4,lf[425]);
if(C_truep(t16)){
t17=t6;
f_12052(t17,t16);}
else{
t17=C_eqp(t4,lf[373]);
if(C_truep(t17)){
t18=t6;
f_12052(t18,t17);}
else{
t18=C_eqp(t4,lf[375]);
if(C_truep(t18)){
t19=t6;
f_12052(t19,t18);}
else{
t19=C_eqp(t4,lf[369]);
if(C_truep(t19)){
t20=t6;
f_12052(t20,t19);}
else{
t20=C_eqp(t4,lf[365]);
if(C_truep(t20)){
t21=t6;
f_12052(t21,t20);}
else{
t21=C_eqp(t4,lf[352]);
if(C_truep(t21)){
t22=t6;
f_12052(t22,t21);}
else{
t22=C_eqp(t4,lf[376]);
if(C_truep(t22)){
t23=t6;
f_12052(t23,t22);}
else{
t23=C_eqp(t4,lf[380]);
if(C_truep(t23)){
t24=t6;
f_12052(t24,t23);}
else{
t24=C_eqp(t4,lf[355]);
if(C_truep(t24)){
t25=t6;
f_12052(t25,t24);}
else{
t25=C_eqp(t4,lf[357]);
if(C_truep(t25)){
t26=t6;
f_12052(t26,t25);}
else{
t26=C_eqp(t4,lf[426]);
if(C_truep(t26)){
t27=t6;
f_12052(t27,t26);}
else{
t27=C_eqp(t4,lf[427]);
if(C_truep(t27)){
t28=t6;
f_12052(t28,t27);}
else{
t28=C_eqp(t4,lf[404]);
if(C_truep(t28)){
t29=t6;
f_12052(t29,t28);}
else{
t29=C_eqp(t4,lf[371]);
if(C_truep(t29)){
t30=t6;
f_12052(t30,t29);}
else{
t30=C_eqp(t4,lf[397]);
if(C_truep(t30)){
t31=t6;
f_12052(t31,t30);}
else{
t31=C_eqp(t4,lf[398]);
if(C_truep(t31)){
t32=t6;
f_12052(t32,t31);}
else{
t32=C_eqp(t4,lf[395]);
if(C_truep(t32)){
t33=t6;
f_12052(t33,t32);}
else{
t33=C_eqp(t4,lf[403]);
if(C_truep(t33)){
t34=t6;
f_12052(t34,t33);}
else{
t34=C_eqp(t4,lf[379]);
if(C_truep(t34)){
t35=t6;
f_12052(t35,t34);}
else{
t35=C_eqp(t4,lf[396]);
if(C_truep(t35)){
t36=t6;
f_12052(t36,t35);}
else{
t36=C_eqp(t4,lf[394]);
if(C_truep(t36)){
t37=t6;
f_12052(t37,t36);}
else{
t37=C_eqp(t4,lf[399]);
t38=t6;
f_12052(t38,(C_truep(t37)?t37:C_eqp(t4,lf[400])));}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* f_9050 in k9047 in walk in k9030 in copy-node-tree-and-rename in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_9050(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9050,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_slot(t2,C_fix(2)));}

/* k9054 in k9047 in walk in k9030 in copy-node-tree-and-rename in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_9056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9056,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9057,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9063,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* support.scm:714: g1910 */
t4=t2;
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[8]);}

/* f_9057 in k9054 in k9047 in walk in k9030 in copy-node-tree-and-rename in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_9057(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9057,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_slot(t2,C_fix(1)));}

/* k5775 in k5783 in k5760 in loop in canonicalize-begin-body in k4697 in k4664 in k4662 */
static void C_ccall f_5776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5776,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,3,lf[105],((C_word*)t0)[3],t1));}

/* k8622 in k8619 in loop in k8146 in k8138 in k8131 in k8124 in walk in build-expression-tree in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_8623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8623,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,3,lf[266],((C_word*)t0)[3],t1));}

/* k8619 in loop in k8146 in k8138 in k8131 in k8124 in walk in build-expression-tree in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_8620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8620,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8623,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=C_i_car(((C_word*)t0)[3]);
/* support.scm:666: walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_8117(t4,t2,t3);}

/* f_13962 */
static void C_ccall f_13962(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_13962r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_13962r(t0,t1,t2);}}

static void C_ccall f_13962r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13967,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm:1472: k3671 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* f_13967 */
static void C_ccall f_13967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13967,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* k6650 in k6647 in loop in k6486 */
static void C_ccall f_6651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_i_caar(((C_word*)t0)[2]);
t3=C_i_assq(t2,lf[170]);
t4=C_i_cdr(t3);
/* support.scm:473: display */
t5=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[3],t4,((C_word*)t0)[4]);}

/* ##compiler#estimate-foreign-result-location-size in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_12030(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12030,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12043,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12399,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm:1189: follow-without-loop */
t5=*((C_word*)lf[90]+1);
f_5527(5,t5,t1,t2,t3,t4);}

/* k7387 in k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_7388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7388,2,t0,t1);}
t2=C_a_i_list1(&a,1,t1);
/* support.scm:558: g1176 */
t3=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[232],((C_word*)t0)[4],t2);}

/* k10268 in rec in k10242 in simple-lambda-node? in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_10270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10270,2,t0,t1);}
t2=C_eqp(t1,lf[248]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10277,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10283,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:890: g2402 */
t5=t3;
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[5]);}
else{
t3=C_eqp(t1,lf[239]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10332,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10338,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm:896: g2414 */
t6=t4;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[5]);}}}

/* k5713 in k5699 in k5694 in basic-literal? in k4697 in k4664 in k4662 */
static void C_ccall f_5715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
/* support.scm:280: basic-literal? */
t4=*((C_word*)lf[99]+1);
f_5681(3,t4,((C_word*)t0)[3],t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* f_13954 */
static void C_ccall f_13954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13954,2,t0,t1);}
C_apply(4,0,t1,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k10281 in k10268 in rec in k10242 in simple-lambda-node? in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_10283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10283,2,t0,t1);}
t2=C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10315,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10321,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* support.scm:892: g2407 */
t5=t3;
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* f_10277 in k10268 in rec in k10242 in simple-lambda-node? in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_10277(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10277,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_slot(t2,C_fix(3)));}

/* k10914 in k10891 in k10857 in k10751 in k10737 in repeat */
static void C_fcall f_10916(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10916,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(*((C_word*)lf[348]+1))){
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,2,lf[366],((C_word*)t0)[2]));}}
else{
t2=C_eqp(((C_word*)t0)[4],lf[367]);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(*((C_word*)lf[348]+1))?((C_word*)t0)[2]:C_a_i_list(&a,2,lf[368],((C_word*)t0)[2])));}
else{
t3=C_eqp(((C_word*)t0)[4],lf[369]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10942,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t3)){
t5=t4;
f_10942(t5,t3);}
else{
t5=C_eqp(((C_word*)t0)[4],lf[371]);
t6=t4;
f_10942(t6,(C_truep(t5)?t5:C_eqp(((C_word*)t0)[4],lf[401])));}}}}

/* k12050 */
static void C_fcall f_12052(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12052,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_i_foreign_fixnum_argumentp(C_fix(1));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,stub351(C_SCHEME_UNDEFINED,t3));}
else{
t2=C_eqp(((C_word*)t0)[3],lf[419]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12063,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=t3;
f_12063(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[3],lf[420]);
if(C_truep(t4)){
t5=t3;
f_12063(t5,t4);}
else{
t5=C_eqp(((C_word*)t0)[3],lf[367]);
t6=t3;
f_12063(t6,(C_truep(t5)?t5:C_eqp(((C_word*)t0)[3],lf[434])));}}}}

/* k11143 in k11112 in k11079 in k11040 in k11003 in k10966 in k10940 in k10914 in k10891 in k10857 in k10751 in k10737 in repeat */
static void C_ccall f_11144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[51],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11144,2,t0,t1);}
t2=C_a_i_list(&a,2,t1,((C_word*)t0)[2]);
t3=C_a_i_list(&a,1,t2);
t4=C_a_i_list(&a,2,lf[95],lf[385]);
t5=C_a_i_list(&a,3,lf[386],((C_word*)t0)[2],t4);
t6=C_a_i_list(&a,2,lf[95],C_SCHEME_FALSE);
t7=C_a_i_list(&a,4,lf[222],t1,t5,t6);
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_a_i_list(&a,3,lf[105],t3,t7));}

/* k9093 in k9061 in k9054 in k9047 in walk in k9030 in copy-node-tree-and-rename in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_9095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm:721: cfk */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
f_9086(2,t2,C_SCHEME_UNDEFINED);}}

/* k9091 in k9085 in k9061 in k9054 in k9047 in walk in k9030 in copy-node-tree-and-rename in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_9092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:722: varnode */
t2=*((C_word*)lf[217]+1);
f_7048(3,t2,((C_word*)t0)[2],t1);}

/* f_13920 */
static void C_ccall f_13920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13920,2,t0,t1);}
t2=C_slot(((C_word*)t0)[2],C_fix(0));
if(C_truep(C_i_closurep(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13931,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13954,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1481: ##sys#call-with-values */
C_call_with_values(4,0,t3,t4,*((C_word*)lf[517]+1));}
else{
/* support.scm:1487: bomb */
t3=*((C_word*)lf[3]+1);
f_4675(4,t3,t1,lf[518],((C_word*)t0)[4]);}}

/* f_12025 in estimate-foreign-result-size in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_12025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12025,2,t0,t1);}
/* support.scm:1184: quit */
t2=*((C_word*)lf[26]+1);
f_4904(4,t2,t1,lf[438],((C_word*)t0)[2]);}

/* f_13915 */
static void C_ccall f_13915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13915,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13920,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13962,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* support.scm:1472: ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* k13912 */
static void C_ccall f_13913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1477: k */
t2=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[4],C_SCHEME_FALSE,t1);}

/* k5699 in k5694 in basic-literal? in k4697 in k4664 in k4662 */
static void C_ccall f_5700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5700,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[3]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5715,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[3];
t4=C_u_i_car(t3);
/* support.scm:279: basic-literal? */
t5=*((C_word*)lf[99]+1);
f_5681(3,t5,t2,t4);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* f_13902 */
static void C_ccall f_13902(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_13902,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13907,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm:1472: k3671 */
t4=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* f_13907 */
static void C_ccall f_13907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13907,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13913,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm:1477: get-condition-property */
t3=*((C_word*)lf[512]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[4],lf[513],lf[514]);}

/* f_13972 in k13886 in constant-form-eval in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13972(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_13972,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_list(&a,2,lf[95],t2));}

/* ##compiler#initialize-analysis-database in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_5986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5986,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5990,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5992,tmp=(C_word)a,a+=2,tmp);
t4=*((C_word*)lf[139]+1);
t5=C_i_check_list_2(*((C_word*)lf[139]+1),lf[33]);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6038,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6151,a[2]=t8,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t10=((C_word*)t8)[1];
f_6151(t10,t6,*((C_word*)lf[139]+1));}
else{
t3=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k11115 in k11112 in k11079 in k11040 in k11003 in k10966 in k10940 in k10914 in k10891 in k10857 in k10751 in k10737 in repeat */
static void C_ccall f_11116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11116,2,t0,t1);}
t2=C_a_i_list(&a,2,t1,((C_word*)t0)[2]);
t3=C_a_i_list(&a,1,t2);
t4=C_a_i_list(&a,2,lf[374],t1);
t5=C_a_i_list(&a,2,lf[95],C_SCHEME_FALSE);
t6=C_a_i_list(&a,4,lf[222],t1,t4,t5);
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_list(&a,3,lf[105],t3,t6));}

/* k11112 in k11079 in k11040 in k11003 in k10966 in k10940 in k10914 in k10891 in k10857 in k10751 in k10737 in repeat */
static void C_fcall f_11114(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11114,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11116,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1106: gensym */
t3=*((C_word*)lf[106]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=C_eqp(((C_word*)t0)[4],lf[383]);
t3=(C_truep(t2)?t2:C_eqp(((C_word*)t0)[4],lf[384]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11144,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1112: gensym */
t5=*((C_word*)lf[106]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=C_eqp(((C_word*)t0)[4],lf[387]);
if(C_truep(t4)){
t5=C_a_i_list(&a,2,lf[95],lf[385]);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_list(&a,3,lf[386],((C_word*)t0)[2],t5));}
else{
t5=C_eqp(((C_word*)t0)[4],lf[388]);
if(C_truep(t5)){
t6=C_i_cadr(((C_word*)t0)[5]);
/* support.scm:1119: repeat */
t7=((C_word*)((C_word*)t0)[6])[1];
f_10715(t7,((C_word*)t0)[3],t6);}
else{
t6=C_eqp(((C_word*)t0)[4],lf[389]);
if(C_truep(t6)){
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_truep(*((C_word*)lf[348]+1))?((C_word*)t0)[2]:C_a_i_list(&a,2,lf[366],((C_word*)t0)[2])));}
else{
t7=C_eqp(((C_word*)t0)[4],lf[390]);
if(C_truep(t7)){
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_truep(t7)?C_a_i_list(&a,2,lf[374],((C_word*)t0)[2]):((C_word*)t0)[2]));}
else{
t8=C_eqp(((C_word*)t0)[4],lf[375]);
t9=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_truep(t8)?C_a_i_list(&a,2,lf[374],((C_word*)t0)[2]):((C_word*)t0)[2]));}}}}}}}

/* map-loop1569 in k8291 in k8289 in k8146 in k8138 in k8131 in k8124 in walk in build-expression-tree in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_8308(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8308,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_a_i_list2(&a,2,t6,t7);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8319,a[2]=((C_word*)t0)[2],a[3]=t9,a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t11=t10;
f_8319(t11,C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t9));}
else{
t11=C_mutate(((C_word *)((C_word*)t0)[4])+1,t9);
t12=t10;
f_8319(t12,t11);}}
else{
t6=((C_word*)((C_word*)t0)[4])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k8305 in k8298 in k8291 in k8289 in k8146 in k8138 in k8131 in k8124 in walk in build-expression-tree in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_8306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:640: walk */
t2=((C_word*)((C_word*)t0)[2])[1];
f_8117(t2,((C_word*)t0)[3],t1);}

/* k8302 in k8298 in k8291 in k8289 in k8146 in k8138 in k8131 in k8124 in walk in build-expression-tree in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_8303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8303,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,3,lf[105],((C_word*)t0)[3],t1));}

/* k8298 in k8291 in k8289 in k8146 in k8138 in k8131 in k8124 in walk in build-expression-tree in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_8300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8300,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8303,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8306,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:640: last */
t4=*((C_word*)lf[261]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* ##compiler#big-fixnum? in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14302(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_14302,3,t0,t1,t2);}
if(C_truep(C_fixnump(t2))){
if(C_truep(C_fudge(C_fix(3)))){
t3=C_fixnum_greaterp(t2,C_fix(1073741823));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t3:C_fixnum_lessp(t2,C_fix(-1073741824))));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* ##compiler#c-ify-string in k4697 in k4664 in k4662 */
static void C_ccall f_5276(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5276,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5286,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5289,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* string->list */
t5=*((C_word*)lf[70]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k5264 in loop in build-lambda-list in k4697 in k4664 in k4662 */
static void C_ccall f_5265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5265,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* ##compiler#hide-variable in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14325(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_14325,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14328,tmp=(C_word)a,a+=2,tmp);
/* support.scm:1573: g3816 */
t4=t3;
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,t2,lf[532],lf[533]);}

/* k8318 in map-loop1569 in k8291 in k8289 in k8146 in k8138 in k8131 in k8124 in walk in build-expression-tree in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_8319(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[3]);
t3=C_slot(((C_word*)t0)[4],C_fix(1));
t4=C_slot(((C_word*)t0)[5],C_fix(1));
t5=((C_word*)((C_word*)t0)[6])[1];
f_8308(t5,((C_word*)t0)[7],t3,t4);}

/* f_14328 in hide-variable in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14328(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr4r,(void*)f_14328r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_14328r(t0,t1,t2,t3,t4);}}

static void C_ccall f_14328r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
if(C_truep(C_i_nullp(t4))){
/* tweaks.scm:54: ##sys#put! */
t5=*((C_word*)lf[134]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,t3,C_SCHEME_TRUE);}
else{
t5=C_i_car(t4);
/* tweaks.scm:54: ##sys#put! */
t6=*((C_word*)lf[134]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,t2,t3,t5);}}

/* k9351 in k9061 in k9054 in k9047 in walk in k9030 in copy-node-tree-and-rename in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_9352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9352,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9354,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t7=C_i_check_list_2(((C_word*)t0)[4],lf[160]);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9363,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9365,a[2]=t5,a[3]=t10,a[4]=t3,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_9365(t12,t8,((C_word*)t0)[4]);}

/* f_9354 in k9351 in k9061 in k9054 in k9047 in walk in k9030 in copy-node-tree-and-rename in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_9354(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9354,3,t0,t1,t2);}
/* support.scm:752: g2075 */
t3=((C_word*)((C_word*)t0)[2])[1];
f_9040(t3,t1,t2,((C_word*)t0)[3]);}

/* f_9343 in k9061 in k9054 in k9047 in walk in k9030 in copy-node-tree-and-rename in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_9343(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9343,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_record4(&a,4,lf[208],t2,t3,t4));}

/* k9338 in map-loop1946 */
static void C_ccall f_9339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9339,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_9314(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_9314(t6,((C_word*)t0)[5],t5);}}

/* k9389 in map-loop2052 in k9351 in k9061 in k9054 in k9047 in walk in k9030 in copy-node-tree-and-rename in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_9390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9390,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_9365(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_9365(t6,((C_word*)t0)[5],t5);}}

/* f_7051 in varnode in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_7051(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7051,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_record4(&a,4,lf[208],t2,t3,t4));}

/* f_7065 in qnode in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_7065(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7065,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_record4(&a,4,lf[208],t2,t3,t4));}

/* map-loop2052 in k9351 in k9061 in k9054 in k9047 in walk in k9030 in copy-node-tree-and-rename in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_9365(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9365,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9390,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:752: g2058 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k9361 in k9351 in k9061 in k9054 in k9047 in walk in k9030 in copy-node-tree-and-rename in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_9363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:752: g2045 */
t2=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],t1);}

/* ##compiler#qnode in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_7062(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7062,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7065,tmp=(C_word)a,a+=2,tmp);
t4=C_a_i_list1(&a,1,t2);
/* support.scm:521: g1048 */
t5=t3;
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,lf[95],t4,C_SCHEME_END_OF_LIST);}

/* ##compiler#scan-used-variables in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13173(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_13173,4,t0,t1,t2,t3);}
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13177,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13179,a[2]=t8,a[3]=t5,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_13179(t10,t6,t2);}

/* walk in scan-used-variables in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_13179(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13179,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13182,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13188,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* support.scm:1314: g3364 */
t5=t3;
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k13176 in scan-used-variables in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[3])[1]);}

/* k7974 */
static void C_ccall f_7976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7976,2,t0,t1);}
if(C_truep(t1)){
t2=C_a_i_plus(&a,2,((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=((C_word*)t0)[3];
f_7951(t4,C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[3];
f_7951(t2,C_SCHEME_FALSE);}}

/* f_7970 */
static void C_ccall f_7970(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7970,4,t0,t1,t2,t3);}
/* tweaks.scm:57: ##sys#get */
t4=*((C_word*)lf[250]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,t3);}

/* k10094 in k10105 in matchn in match-node in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_10096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_cadr(((C_word*)t0)[2]);
/* support.scm:850: match1 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_9969(t3,((C_word*)t0)[4],t1,t2);}

/* f_10090 in k10105 in matchn in match-node in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_10090(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10090,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_slot(t2,C_fix(2)));}

/* f_7094 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_7094(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7094,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_structurep(t2,lf[208]));}

/* k13193 in k13186 in walk in scan-used-variables in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13195,2,t0,t1);}
t2=C_eqp(t1,lf[218]);
t3=(C_truep(t2)?t2:C_eqp(t1,lf[241]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13250,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13256,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* support.scm:1317: g3379 */
t6=t4;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[7]);}
else{
t4=C_eqp(t1,lf[95]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13264,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_13264(t6,t4);}
else{
t6=C_eqp(t1,lf[223]);
t7=t5;
f_13264(t7,(C_truep(t6)?t6:C_eqp(t1,lf[237])));}}}

/* k10319 in k10281 in k10268 in rec in k10242 in simple-lambda-node? in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_10321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10321,2,t0,t1);}
t2=C_eqp(lf[218],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10307,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10313,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* support.scm:893: g2411 */
t5=t3;
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[6]);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* f_13182 in walk in scan-used-variables in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13182(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_13182,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_slot(t2,C_fix(3)));}

/* f_13189 in k13186 in walk in scan-used-variables in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13189(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_13189,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_slot(t2,C_fix(1)));}

/* k13186 in walk in scan-used-variables in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13188,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13189,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13195,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* support.scm:1315: g3372 */
t4=t2;
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[6]);}

/* f_10332 in k10268 in rec in k10242 in simple-lambda-node? in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_10332(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10332,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_slot(t2,C_fix(3)));}

/* k10336 in k10268 in rec in k10242 in simple-lambda-node? in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_10338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:896: every */
t2=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1],t1);}

/* loop in k8146 in k8138 in k8131 in k8124 in walk in build-expression-tree in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_8607(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8607,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep(C_i_zerop(t2))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8620,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* support.scm:666: reverse */
t6=*((C_word*)lf[89]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}
else{
t5=C_a_i_minus(&a,2,t2,C_fix(1));
t6=C_i_cdr(t3);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8641,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t5,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
t8=t3;
t9=C_u_i_car(t8);
/* support.scm:667: walk */
t10=((C_word*)((C_word*)t0)[2])[1];
f_8117(t10,t7,t9);}}

/* k5216 in k5213 in k5211 in symbolify in k4697 in k4664 in k4662 */
static void C_ccall f_5218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:169: string->symbol */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5213 in k5211 in symbolify in k4697 in k4664 in k4662 */
static void C_ccall f_5215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5215,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5218,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:169: get-output-string */
t3=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k10073 in loop in k10037 in k10026 in k10105 in matchn in match-node in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_10075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=((C_word*)t0)[3];
t5=C_u_i_cdr(t4);
/* support.scm:857: loop */
t6=((C_word*)((C_word*)t0)[4])[1];
f_10044(t6,((C_word*)t0)[5],t3,t5);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#dump-undefined-globals in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_10348(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10348,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10354,tmp=(C_word)a,a+=2,tmp);
/* support.scm:902: ##sys#hash-table-for-each */
t4=*((C_word*)lf[161]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* node-subexpressions-set! in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_7031(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7031,4,t0,t1,t2,t3);}
t4=C_i_check_structure_2(t2,lf[208],C_SCHEME_FALSE);
/* support.scm:507: ##sys#block-set! */
t5=*((C_word*)lf[212]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(3),t3);}

/* for-each-loop575 in k6036 in initialize-analysis-database in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_6131(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6131,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6140,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:358: g576 */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* f_14349 in export-variable in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14349(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr4r,(void*)f_14349r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_14349r(t0,t1,t2,t3,t4);}}

static void C_ccall f_14349r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
if(C_truep(C_i_nullp(t4))){
/* tweaks.scm:54: ##sys#put! */
t5=*((C_word*)lf[134]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,t3,C_SCHEME_TRUE);}
else{
t5=C_i_car(t4);
/* tweaks.scm:54: ##sys#put! */
t6=*((C_word*)lf[134]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,t2,t3,t5);}}

/* ##compiler#export-variable in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14346(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_14346,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14349,tmp=(C_word)a,a+=2,tmp);
/* support.scm:1576: g3833 */
t4=t3;
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,t2,lf[532],lf[535]);}

/* ##compiler#varnode in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_7048(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7048,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7051,tmp=(C_word)a,a+=2,tmp);
t4=C_a_i_list1(&a,1,t2);
/* support.scm:520: g1041 */
t5=t3;
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,lf[218],t4,C_SCHEME_END_OF_LIST);}

/* match1 in match-node in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_9969(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_9969,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_not_pair_p(t3))){
/* support.scm:841: resolve */
t4=((C_word*)((C_word*)t0)[2])[1];
f_9937(t4,t1,t3,t2);}
else{
if(C_truep(C_i_not_pair_p(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9991,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=C_i_car(t2);
t6=C_i_car(t3);
/* support.scm:843: match1 */
t8=t4;
t9=t5;
t10=t6;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}}

/* ##compiler#pprint-expressions-to-file in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_10652(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10652,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10656,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
/* support.scm:996: open-output-file */
t5=*((C_word*)lf[344]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}
else{
t5=t4;
f_10656(2,t5,*((C_word*)lf[13]+1));}}

/* f_10354 in dump-undefined-globals in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_10354(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10354,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10360,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10368,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* support.scm:904: keyword? */
t6=*((C_word*)lf[321]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k10655 in pprint-expressions-to-file in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_10656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10656,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10658,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10666,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* support.scm:997: with-output-to-port */
t4=*((C_word*)lf[343]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t1,t3);}

/* make-node in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_7042(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7042,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_record4(&a,4,lf[208],t2,t3,t4));}

/* k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_7040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word ab[131],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7040,2,t0,t1);}
t2=C_mutate((C_word*)lf[207]+1 /* (set! make-node ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7042,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate((C_word*)lf[217]+1 /* (set! ##compiler#varnode ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7048,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[219]+1 /* (set! ##compiler#qnode ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7062,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[220]+1 /* (set! ##compiler#build-node-graph ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7076,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[258]+1 /* (set! ##compiler#build-expression-tree ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8111,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[274]+1 /* (set! ##compiler#fold-boolean ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8852,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[276]+1 /* (set! ##compiler#inline-lambda-bindings ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8896,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[281]+1 /* (set! ##compiler#copy-node-tree-and-rename ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9023,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[286]+1 /* (set! ##compiler#tree-copy ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9450,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[287]+1 /* (set! ##compiler#copy-node! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9478,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[288]+1 /* (set! ##compiler#node->sexpr ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9512,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[289]+1 /* (set! ##compiler#sexpr->node ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9586,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[290]+1 /* (set! ##compiler#emit-global-inline-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9647,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[310]+1 /* (set! ##compiler#load-inline-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9881,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[312]+1 /* (set! ##compiler#match-node ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9933,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[315]+1 /* (set! ##compiler#expression-has-side-effects? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10135,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[319]+1 /* (set! ##compiler#simple-lambda-node? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10235,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate((C_word*)lf[320]+1 /* (set! ##compiler#dump-undefined-globals ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10348,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate((C_word*)lf[322]+1 /* (set! ##compiler#dump-defined-globals ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10385,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate((C_word*)lf[323]+1 /* (set! ##compiler#dump-global-refs ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10419,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate((C_word*)lf[324]+1 /* (set! ##sys#toplevel-definition-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10461,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate((C_word*)lf[327]+1 /* (set! ##compiler#compute-database-statistics ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10481,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate((C_word*)lf[330]+1 /* (set! ##compiler#print-program-statistics ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10587,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate((C_word*)lf[340]+1 /* (set! ##compiler#pprint-expressions-to-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10652,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate((C_word*)lf[345]+1 /* (set! ##compiler#foreign-type-check ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10704,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[429]+1 /* (set! ##compiler#foreign-type-convert-result ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11544,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate((C_word*)lf[430]+1 /* (set! ##compiler#foreign-type-convert-argument ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11573,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate((C_word*)lf[431]+1 /* (set! ##compiler#final-foreign-type ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11602,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate((C_word*)lf[433]+1 /* (set! ##compiler#estimate-foreign-result-size ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11643,tmp=(C_word)a,a+=2,tmp));
t31=C_mutate((C_word*)lf[439]+1 /* (set! ##compiler#estimate-foreign-result-location-size ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12030,tmp=(C_word)a,a+=2,tmp));
t32=C_mutate((C_word*)lf[442]+1 /* (set! ##compiler#finish-foreign-result ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12404,tmp=(C_word)a,a+=2,tmp));
t33=C_mutate((C_word*)lf[456]+1 /* (set! ##compiler#foreign-type->scrutiny-type ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12643,tmp=(C_word)a,a+=2,tmp));
t34=C_mutate((C_word*)lf[476]+1 /* (set! ##compiler#scan-used-variables ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13173,tmp=(C_word)a,a+=2,tmp));
t35=C_mutate((C_word*)lf[477]+1 /* (set! ##compiler#scan-free-variables ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13312,tmp=(C_word)a,a+=2,tmp));
t36=C_mutate((C_word*)lf[479]+1 /* (set! ##compiler#chop-separator ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13520,tmp=(C_word)a,a+=2,tmp));
t37=C_mutate((C_word*)lf[482]+1 /* (set! ##compiler#chop-extension ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13545,tmp=(C_word)a,a+=2,tmp));
t38=C_mutate((C_word*)lf[483]+1 /* (set! ##compiler#make-block-variable-literal ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13584,tmp=(C_word)a,a+=2,tmp));
t39=C_mutate((C_word*)lf[485]+1 /* (set! ##compiler#block-variable-literal? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13590,tmp=(C_word)a,a+=2,tmp));
t40=C_mutate((C_word*)lf[486]+1 /* (set! ##compiler#block-variable-literal-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13596,tmp=(C_word)a,a+=2,tmp));
t41=C_mutate((C_word*)lf[488]+1 /* (set! ##compiler#make-random-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13605,tmp=(C_word)a,a+=2,tmp));
t42=C_mutate((C_word*)lf[491]+1 /* (set! ##compiler#set-real-name! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13645,tmp=(C_word)a,a+=2,tmp));
t43=C_set_block_item(lf[493] /* real-name-max-depth */,0,C_fix(20));
t44=C_mutate((C_word*)lf[45]+1 /* (set! ##compiler#real-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13652,tmp=(C_word)a,a+=2,tmp));
t45=C_mutate((C_word*)lf[499]+1 /* (set! ##compiler#real-name2 ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13759,tmp=(C_word)a,a+=2,tmp));
t46=C_mutate((C_word*)lf[500]+1 /* (set! ##compiler#display-real-name-table ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13771,tmp=(C_word)a,a+=2,tmp));
t47=C_mutate((C_word*)lf[501]+1 /* (set! ##compiler#source-info->string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13789,tmp=(C_word)a,a+=2,tmp));
t48=C_mutate((C_word*)lf[507]+1 /* (set! ##compiler#source-info->line ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13817,tmp=(C_word)a,a+=2,tmp));
t49=C_mutate((C_word*)lf[508]+1 /* (set! ##compiler#call-info ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13835,tmp=(C_word)a,a+=2,tmp));
t50=C_mutate((C_word*)lf[511]+1 /* (set! ##compiler#constant-form-eval ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13869,tmp=(C_word)a,a+=2,tmp));
t51=C_mutate((C_word*)lf[519]+1 /* (set! ##compiler#dump-nodes ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14042,tmp=(C_word)a,a+=2,tmp));
t52=C_mutate((C_word*)lf[520]+1 /* (set! ##compiler#read-info-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14170,tmp=(C_word)a,a+=2,tmp));
t53=C_mutate((C_word*)lf[524]+1 /* (set! ##compiler#read/source-info ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14208,tmp=(C_word)a,a+=2,tmp));
t54=*((C_word*)lf[526]+1);
t55=C_mutate((C_word*)lf[526]+1 /* (set! ##sys#user-read-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_14214,a[2]=t54,tmp=(C_word)a,a+=3,tmp));
t56=C_mutate((C_word*)lf[529]+1 /* (set! ##compiler#scan-sharp-greater-string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14236,tmp=(C_word)a,a+=2,tmp));
t57=C_mutate((C_word*)lf[98]+1 /* (set! ##compiler#big-fixnum? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14302,tmp=(C_word)a,a+=2,tmp));
t58=C_mutate((C_word*)lf[325]+1 /* (set! ##compiler#hide-variable ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14325,tmp=(C_word)a,a+=2,tmp));
t59=C_mutate((C_word*)lf[534]+1 /* (set! ##compiler#export-variable ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14346,tmp=(C_word)a,a+=2,tmp));
t60=C_mutate((C_word*)lf[309]+1 /* (set! ##compiler#variable-visible? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14367,tmp=(C_word)a,a+=2,tmp));
t61=C_mutate((C_word*)lf[537]+1 /* (set! ##compiler#mark-variable ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14392,tmp=(C_word)a,a+=2,tmp));
t62=C_mutate((C_word*)lf[538]+1 /* (set! ##compiler#variable-mark ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14408,tmp=(C_word)a,a+=2,tmp));
t63=C_mutate((C_word*)lf[539]+1 /* (set! ##compiler#intrinsic? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14414,tmp=(C_word)a,a+=2,tmp));
t64=C_mutate((C_word*)lf[540]+1 /* (set! foldable? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14425,tmp=(C_word)a,a+=2,tmp));
t65=C_mutate((C_word*)lf[541]+1 /* (set! ##compiler#load-identifier-database ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14436,tmp=(C_word)a,a+=2,tmp));
t66=C_mutate((C_word*)lf[549]+1 /* (set! ##compiler#print-version ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14516,tmp=(C_word)a,a+=2,tmp));
t67=C_mutate((C_word*)lf[552]+1 /* (set! ##compiler#print-usage ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14540,tmp=(C_word)a,a+=2,tmp));
t68=C_mutate((C_word*)lf[554]+1 /* (set! ##compiler#print-debug-options ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14551,tmp=(C_word)a,a+=2,tmp));
t69=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t69+1)))(2,t69,C_SCHEME_UNDEFINED);}

/* f_12399 in estimate-foreign-result-location-size in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_12399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12399,2,t0,t1);}
/* support.scm:1210: quit */
t2=*((C_word*)lf[26]+1);
f_4904(4,t2,t1,lf[441],((C_word*)t0)[2]);}

/* map-loop1116 in k7248 in k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_7308(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7308,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7333,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:549: g1122 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7302 in map-loop1143 in k7250 in k7248 in k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_7303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7303,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7278(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7278(t6,((C_word*)t0)[5],t5);}}

/* node-parameters-set! in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_7013(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7013,4,t0,t1,t2,t3);}
t4=C_i_check_structure_2(t2,lf[208],C_SCHEME_FALSE);
/* support.scm:507: ##sys#block-set! */
t5=*((C_word*)lf[212]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(2),t3);}

/* ##compiler#match-node in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_9933(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9933,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9937,a[2]=t6,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t14=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9969,a[2]=t8,a[3]=t10,tmp=(C_word)a,a+=4,tmp));
t15=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10006,a[2]=t8,a[3]=t12,a[4]=t10,tmp=(C_word)a,a+=5,tmp));
t16=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10112,a[2]=t6,a[3]=t1,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* support.scm:859: matchn */
t17=((C_word*)t12)[1];
f_10006(t17,t16,t2,t3);}

/* k10123 in k10111 in match-node in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_10125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10125,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10127,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10133,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm:862: g2338 */
t4=t2;
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* resolve in match-node in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_9937(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9937,NULL,4,t0,t1,t2,t3);}
t4=C_i_assq(t2,((C_word*)((C_word*)t0)[2])[1]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9945,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm:830: g2303 */
t6=t5;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t1,t4);}
else{
if(C_truep(C_i_memq(t2,((C_word*)t0)[3]))){
t5=C_a_i_cons(&a,2,C_a_i_cons(&a,2,t2,t3),((C_word*)((C_word*)t0)[2])[1]);
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_TRUE);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_eqp(t2,t3));}}}

/* f_10127 in k10123 in k10111 in match-node in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_10127(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10127,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_slot(t2,C_fix(2)));}

/* f_10666 in k10655 in pprint-expressions-to-file in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_10666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10666,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10668,tmp=(C_word)a,a+=2,tmp);
t3=((C_word*)t0)[2];
t4=C_i_check_list_2(t3,lf[33]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10681,a[2]=t6,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_10681(t8,t1,t3);}

/* k10657 in k10655 in pprint-expressions-to-file in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_10658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(((C_word*)t0)[2])){
/* support.scm:1004: close-output-port */
t2=*((C_word*)lf[341]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[4]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* ##compiler#variable-visible? in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14367(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_14367,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_14371,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm:1579: ##sys#get */
t4=*((C_word*)lf[250]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[532]);}

/* ##compiler#expression-has-side-effects? in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_10135(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10135,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10141,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_10141(3,t7,t1,t2);}

/* k10131 in k10123 in k10111 in match-node in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_10133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:862: debugging */
t2=*((C_word*)lf[11]+1);
f_4702(7,t2,((C_word*)t0)[2],lf[313],lf[314],((C_word*)t0)[3],t1,((C_word*)t0)[4]);}

/* f_9903 in k9895 in loop */
static void C_ccall f_9903(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr4r,(void*)f_9903r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_9903r(t0,t1,t2,t3,t4);}}

static void C_ccall f_9903r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
if(C_truep(C_i_nullp(t4))){
/* tweaks.scm:54: ##sys#put! */
t5=*((C_word*)lf[134]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,t3,C_SCHEME_TRUE);}
else{
t5=C_i_car(t4);
/* tweaks.scm:54: ##sys#put! */
t6=*((C_word*)lf[134]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,t2,t3,t5);}}

/* k10670 */
static void C_ccall f_10671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1002: newline */
t2=*((C_word*)lf[12]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* f_10668 */
static void C_ccall f_10668(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10668,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10671,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm:1001: pretty-print */
t4=*((C_word*)lf[342]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* node-subexpressions in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_7022(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7022,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[208],lf[215]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_i_block_ref(t2,C_fix(3)));}

/* ##compiler#build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_7076(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7076,3,t0,t1,t2);}
t3=C_fix(0);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7080,a[2]=t6,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8101,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* support.scm:618: walk */
t9=((C_word*)t6)[1];
f_7080(t9,t8,t2);}

/* f_10144 in walk in expression-has-side-effects? in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_10144(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10144,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_slot(t2,C_fix(3)));}

/* for-each-loop2565 */
static void C_fcall f_10681(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10681,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10690,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:998: g2566 */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* walk in expression-has-side-effects? in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_10141(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10141,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10144,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10150,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* support.scm:870: g2351 */
t5=t3;
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k9927 in k9895 in loop */
static void C_ccall f_9928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:821: g2271 */
t2=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[4],lf[308],t1);}

/* ##compiler#slashify in k4697 in k4664 in k4662 */
static void C_ccall f_5220(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5220,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5227,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm:171: ->string */
t4=*((C_word*)lf[58]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k10613 in k10611 in k10609 in k10607 in k10605 in k10602 */
static void C_ccall f_10615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10615,2,t0,t1);}
t2=*((C_word*)lf[13]+1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10617,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* support.scm:986: display */
t4=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[335],*((C_word*)lf[13]+1));}

/* k10155 in k10148 in walk in expression-has-side-effects? in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_10157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10157,2,t0,t1);}
t2=C_eqp(t1,lf[218]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10165,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_10165(t4,t2);}
else{
t4=C_eqp(t1,lf[95]);
if(C_truep(t4)){
t5=t3;
f_10165(t5,t4);}
else{
t5=C_eqp(t1,lf[223]);
t6=t3;
f_10165(t6,(C_truep(t5)?t5:C_eqp(t1,lf[240])));}}}

/* k10609 in k10607 in k10605 in k10602 */
static void C_ccall f_10610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10610,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10612,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* support.scm:985: write */
t3=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[9],((C_word*)t0)[8]);}

/* k14370 in variable-visible? in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_eqp(t1,lf[533]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=C_eqp(t1,lf[535]);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?C_SCHEME_TRUE:C_i_not(*((C_word*)lf[536]+1))));}}

/* k10611 in k10609 in k10607 in k10605 in k10602 */
static void C_ccall f_10612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10612,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10615,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* write-char/port */
t3=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[8]);}

/* f_10151 in k10148 in walk in expression-has-side-effects? in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_10151(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10151,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_slot(t2,C_fix(1)));}

/* k10148 in walk in expression-has-side-effects? in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_10150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10150,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10151,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10157,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* support.scm:871: g2359 */
t4=t2;
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}

/* walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_7080(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7080,NULL,3,t0,t1,t2);}
if(C_truep(C_i_symbolp(t2))){
/* support.scm:526: varnode */
t3=*((C_word*)lf[217]+1);
f_7048(3,t3,t1,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7094,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7100,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* support.scm:527: g1061 */
t5=t3;
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}}

/* k5235 in uncommentify in k4697 in k4664 in k4662 */
static void C_ccall f_5236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:173: string-translate* */
t2=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,lf[61]);}

/* ##compiler#build-lambda-list in k4697 in k4664 in k4662 */
static void C_ccall f_5238(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5238,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5244,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_5244(t8,t1,t2,t3);}

/* map-loop1946 */
static void C_fcall f_9314(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9314,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9339,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:740: g1952 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5211 in symbolify in k4697 in k4664 in k4662 */
static void C_ccall f_5212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5212,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5215,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm:169: display */
t4=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],t2);}

/* k10623 in k10620 in k10618 in k10616 in k10613 in k10611 in k10609 in k10607 in k10605 in k10602 */
static void C_ccall f_10624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10624,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10626,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* support.scm:987: write */
t3=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[7],((C_word*)t0)[6]);}

/* k10625 in k10623 in k10620 in k10618 in k10616 in k10613 in k10611 in k10609 in k10607 in k10605 in k10602 */
static void C_ccall f_10626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10626,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10629,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* write-char/port */
t3=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[6]);}

/* k10620 in k10618 in k10616 in k10613 in k10611 in k10609 in k10607 in k10605 in k10602 */
static void C_ccall f_10622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10622,2,t0,t1);}
t2=*((C_word*)lf[13]+1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10624,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* support.scm:987: display */
t4=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[334],*((C_word*)lf[13]+1));}

/* k10616 in k10613 in k10611 in k10609 in k10607 in k10605 in k10602 */
static void C_ccall f_10617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10617,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10619,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* support.scm:986: write */
t3=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[8],((C_word*)t0)[7]);}

/* k10618 in k10616 in k10613 in k10611 in k10609 in k10607 in k10605 in k10602 */
static void C_ccall f_10619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10619,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10622,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* write-char/port */
t3=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[7]);}

/* ##compiler#uncommentify in k4697 in k4664 in k4662 */
static void C_ccall f_5229(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5229,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5236,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm:173: ->string */
t4=*((C_word*)lf[58]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k5226 in slashify in k4697 in k4664 in k4662 */
static void C_ccall f_5227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:171: string-translate */
t2=*((C_word*)lf[55]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,lf[56],lf[57]);}

/* ##compiler#chop-separator in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13520(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_13520,3,t0,t1,t2);}
t3=C_i_string_length(t2);
t4=C_a_i_minus(&a,2,t3,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13530,a[2]=t1,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_greaterp(t4,C_fix(0)))){
t6=C_i_string_ref(t2,t4);
t7=t5;
f_13530(t7,C_u_i_memq(t6,lf[481]));}
else{
t6=t5;
f_13530(t6,C_SCHEME_FALSE);}}

/* k10634 in k10632 in k10630 in k10627 in k10625 in k10623 in k10620 in k10618 in k10616 in k10613 in k10611 in k10609 in k10607 in k10605 in k10602 */
static void C_ccall f_10636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10636,2,t0,t1);}
t2=*((C_word*)lf[13]+1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10638,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* support.scm:989: display */
t4=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[332],*((C_word*)lf[13]+1));}

/* k10632 in k10630 in k10627 in k10625 in k10623 in k10620 in k10618 in k10616 in k10613 in k10611 in k10609 in k10607 in k10605 in k10602 */
static void C_ccall f_10633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10633,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10636,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* write-char/port */
t3=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[5]);}

/* k10630 in k10627 in k10625 in k10623 in k10620 in k10618 in k10616 in k10613 in k10611 in k10609 in k10607 in k10605 in k10602 */
static void C_ccall f_10631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10631,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10633,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* support.scm:988: write */
t3=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[6],((C_word*)t0)[5]);}

/* ##compiler#mark-variable in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14392(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr4r,(void*)f_14392r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_14392r(t0,t1,t2,t3,t4);}}

static void C_ccall f_14392r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
if(C_truep(C_i_nullp(t4))){
/* support.scm:1586: ##sys#put! */
t5=*((C_word*)lf[134]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,t3,C_SCHEME_TRUE);}
else{
t5=C_i_car(t4);
/* support.scm:1586: ##sys#put! */
t6=*((C_word*)lf[134]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,t2,t3,t5);}}

/* k10627 in k10625 in k10623 in k10620 in k10618 in k10616 in k10613 in k10611 in k10609 in k10607 in k10605 in k10602 */
static void C_ccall f_10629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10629,2,t0,t1);}
t2=*((C_word*)lf[13]+1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10631,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* support.scm:988: display */
t4=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[333],*((C_word*)lf[13]+1));}

/* k5288 in c-ify-string in k4697 in k4664 in k4662 */
static void C_ccall f_5289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5289,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5291,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_5291(t5,((C_word*)t0)[2],t1);}

/* k5285 in c-ify-string in k4697 in k4664 in k4662 */
static void C_ccall f_5286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5286,2,t0,t1);}
t2=C_a_i_cons(&a,2,C_make_character(34),t1);
/* list->string */
t3=*((C_word*)lf[66]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* k13514 in scan-free-variables in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1361: values */
C_values(4,0,((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[4])[1]);}

/* k9917 in k9895 in loop */
static void C_ccall f_9919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:825: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_9892(t2,((C_word*)t0)[3]);}

/* k10105 in matchn in match-node in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_10107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10107,2,t0,t1);}
t2=C_i_car(((C_word*)t0)[2]);
t3=C_eqp(t1,t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10028,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10090,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10096,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* support.scm:850: g2319 */
t7=t5;
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[6]);}
else{
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k10644 in k10641 in k10639 in k10637 in k10634 in k10632 in k10630 in k10627 in k10625 in k10623 in k10620 in k10618 in k10616 in k10613 in k10611 in k10609 in k10607 in k10605 in k10602 */
static void C_ccall f_10645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10645,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10647,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:990: write */
t3=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[4],((C_word*)t0)[3]);}

/* k10641 in k10639 in k10637 in k10634 in k10632 in k10630 in k10627 in k10625 in k10623 in k10620 in k10618 in k10616 in k10613 in k10611 in k10609 in k10607 in k10605 in k10602 */
static void C_ccall f_10643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10643,2,t0,t1);}
t2=*((C_word*)lf[13]+1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10645,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm:990: display */
t4=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[331],*((C_word*)lf[13]+1));}

/* f_10101 in matchn in match-node in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_10101(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10101,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_slot(t2,C_fix(1)));}

/* k10639 in k10637 in k10634 in k10632 in k10630 in k10627 in k10625 in k10623 in k10620 in k10618 in k10616 in k10613 in k10611 in k10609 in k10607 in k10605 in k10602 */
static void C_ccall f_10640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10640,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10643,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[4]);}

/* k10637 in k10634 in k10632 in k10630 in k10627 in k10625 in k10623 in k10620 in k10618 in k10616 in k10613 in k10611 in k10609 in k10607 in k10605 in k10602 */
static void C_ccall f_10638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10638,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10640,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:989: write */
t3=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[5],((C_word*)t0)[4]);}

/* k13503 in for-each-loop3474 in walkeach in scan-free-variables in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_13495(t3,((C_word*)t0)[4],t2);}

/* f_10119 in k10111 in match-node in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_10119(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10119,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_slot(t2,C_fix(1)));}

/* k10116 in k10111 in match-node in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_10117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)((C_word*)t0)[2])[1];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k10111 in match-node in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_10112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10112,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10117,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10119,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10125,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* support.scm:862: g2335 */
t5=t3;
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[5]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k10646 in k10644 in k10641 in k10639 in k10637 in k10634 in k10632 in k10630 in k10627 in k10625 in k10623 in k10620 in k10618 in k10616 in k10613 in k10611 in k10609 in k10607 in k10605 in k10602 */
static void C_ccall f_10647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(10),((C_word*)t0)[3]);}

/* ##compiler#quit in k4697 in k4664 in k4662 */
static void C_ccall f_4904(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3r,(void*)f_4904r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4904r(t0,t1,t2,t3);}}

static void C_ccall f_4904r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(9);
t4=*((C_word*)lf[27]+1);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4908,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4916,a[2]=t5,a[3]=t4,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* support.scm:105: string-append */
t7=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,lf[30],t2);}

/* k4901 in k4894 in k4873 in with-debugging-output in k4697 in k4664 in k4662 */
static void C_ccall f_4902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:101: collect */
t2=((C_word*)((C_word*)t0)[2])[1];
f_4806(t2,((C_word*)t0)[3],t1);}

/* k4907 in quit in k4697 in k4664 in k4662 */
static void C_ccall f_4908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4908,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4910,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:106: newline */
t3=*((C_word*)lf[12]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* loop in build-lambda-list in k4697 in k4664 in k4662 */
static void C_fcall f_5244(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5244,NULL,4,t0,t1,t2,t3);}
t4=C_i_zerop(t3);
t5=(C_truep(t4)?t4:C_i_nullp(t2));
if(C_truep(t5)){
t6=((C_word*)t0)[2];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_truep(t6)?t6:C_SCHEME_END_OF_LIST));}
else{
t6=C_i_car(t2);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5265,a[2]=t1,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=t2;
t9=C_u_i_cdr(t8);
t10=C_a_i_minus(&a,2,t3,C_fix(1));
/* support.scm:178: loop */
t13=t7;
t14=t9;
t15=t10;
t1=t13;
t2=t14;
t3=t15;
goto loop;}}

/* k4921 in syntax-error-hook in k4697 in k4664 in k4662 */
static void C_fcall f_4922(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4922,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4924,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4961,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* support.scm:118: display */
t4=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[38],((C_word*)t0)[2]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4974,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* support.scm:119: display */
t4=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[39],((C_word*)t0)[2]);}}

/* k7887 in map-loop1366 in k7786 in k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_7888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7888,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7863(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7863(t6,((C_word*)t0)[5],t5);}}

/* k4923 in k4921 in syntax-error-hook in k4697 in k4664 in k4662 */
static void C_ccall f_4924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4924,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4925,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=((C_word*)((C_word*)t0)[3])[1];
t4=C_i_check_list_2(t3,lf[33]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4934,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4941,a[2]=t7,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_4941(t9,t5,t3);}

/* f_4925 in k4923 in k4921 in syntax-error-hook in k4697 in k4664 in k4662 */
static void C_ccall f_4925(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4925,3,t0,t1,t2);}
t3=*((C_word*)lf[29]+1);
/* support.scm:120: g193 */
t4=*((C_word*)lf[29]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,((C_word*)t0)[2],lf[32],t2);}

/* k8183 in map-loop1498 in k8146 in k8138 in k8131 in k8124 in walk in build-expression-tree in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_8184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8184,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8159(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8159(t6,((C_word*)t0)[5],t5);}}

/* k10602 */
static void C_ccall f_10604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10604,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[13]+1);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_10606,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* support.scm:985: display */
t4=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[337],*((C_word*)lf[13]+1));}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k4915 in quit in k4697 in k4664 in k4662 */
static void C_ccall f_4916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(6,0,((C_word*)t0)[2],*((C_word*)lf[29]+1),((C_word*)t0)[3],t1,((C_word*)t0)[4]);}

/* ##sys#syntax-error-hook in k4697 in k4664 in k4662 */
static void C_ccall f_4918(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3r,(void*)f_4918r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4918r(t0,t1,t2,t3);}}

static void C_ccall f_4918r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(10);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t6=*((C_word*)lf[27]+1);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4922,a[2]=t6,a[3]=t5,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_symbolp(((C_word*)t4)[1]))){
t8=((C_word*)t4)[1];
t9=C_i_car(((C_word*)t5)[1]);
t10=C_set_block_item(t4,0,t9);
t11=C_i_cdr(((C_word*)t5)[1]);
t12=C_set_block_item(t5,0,t11);
t13=t7;
f_4922(t13,t8);}
else{
t8=t7;
f_4922(t8,C_SCHEME_FALSE);}}

/* k4909 in k4907 in quit in k4697 in k4664 in k4662 */
static void C_ccall f_4910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:107: exit */
t2=*((C_word*)lf[28]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_fix(1));}

/* f_7896 in k7786 in k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_7896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7896,2,t0,t1);}
/* support.scm:604: get-line-2 */
t2=*((C_word*)lf[155]+1);
f_6355(3,t2,t1,((C_word*)t0)[2]);}

/* k7758 in k7770 in k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_7759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:597: walk */
t2=((C_word*)((C_word*)t0)[2])[1];
f_7080(t2,((C_word*)t0)[3],t1);}

/* k7755 in k7770 in k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_7756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7756,2,t0,t1);}
t2=C_a_i_list1(&a,1,t1);
/* support.scm:594: g1311 */
t3=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[243],((C_word*)t0)[4],t2);}

/* k10163 in k10155 in k10148 in walk in expression-has-side-effects? in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_10165(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10165,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=C_eqp(((C_word*)t0)[3],lf[129]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10186,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10192,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:874: g2372 */
t5=t3;
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[4]);}
else{
t3=C_eqp(((C_word*)t0)[3],lf[222]);
if(C_truep(t3)){
if(C_truep(t3)){
/* support.scm:878: any */
t4=*((C_word*)lf[75]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[6]);}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_TRUE);}}
else{
t4=C_eqp(((C_word*)t0)[3],lf[105]);
if(C_truep(t4)){
/* support.scm:878: any */
t5=*((C_word*)lf[75]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[2],((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[6]);}
else{
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_TRUE);}}}}}

/* loop in k5288 in c-ify-string in k4697 in k4664 in k4662 */
static void C_fcall f_5291(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5291,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[67]);}
else{
t3=C_i_car(t2);
t4=C_fix(C_character_code(t3));
t5=C_fixnum_lessp(t4,C_fix(32));
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5310,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_5310(t7,t5);}
else{
t7=C_fixnum_greater_or_equal_p(t4,C_fix(127));
if(C_truep(t7)){
t8=t6;
f_5310(t8,t7);}
else{
t8=C_u_i_memq(t3,lf[73]);
t9=t6;
f_5310(t9,t8);}}}}

/* map-loop1286 in k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_7701(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7701,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7726,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:591: g1292 */
t5=((C_word*)((C_word*)t0)[5])[1];
f_7080(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* f_9945 in resolve in match-node in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_9945(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9945,3,t0,t1,t2);}
t3=C_i_cdr(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_i_equalp(((C_word*)t0)[2],t3));}

/* k12739 in k12667 in k12646 in foreign-type->scrutiny-type in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_12741(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12741,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_eqp(t2,lf[457]);
if(C_truep(t3)){
t4=C_a_i_list(&a,2,lf[460],((C_word*)t0)[3]);
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_list(&a,3,lf[461],lf[462],t4));}
else{
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_list(&a,2,lf[460],((C_word*)t0)[3]));}}
else{
t2=C_eqp(((C_word*)t0)[5],lf[363]);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[463]);}
else{
t3=C_eqp(((C_word*)t0)[5],lf[406]);
if(C_truep(t3)){
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[464]);}
else{
t4=C_eqp(((C_word*)t0)[5],lf[405]);
if(C_truep(t4)){
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[465]);}
else{
t5=C_eqp(((C_word*)t0)[5],lf[407]);
if(C_truep(t5)){
t6=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[466]);}
else{
t6=C_eqp(((C_word*)t0)[5],lf[408]);
if(C_truep(t6)){
t7=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,lf[467]);}
else{
t7=C_eqp(((C_word*)t0)[5],lf[409]);
if(C_truep(t7)){
t8=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[468]);}
else{
t8=C_eqp(((C_word*)t0)[5],lf[410]);
if(C_truep(t8)){
t9=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,lf[469]);}
else{
t9=C_eqp(((C_word*)t0)[5],lf[411]);
if(C_truep(t9)){
t10=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,lf[470]);}
else{
t10=C_eqp(((C_word*)t0)[5],lf[365]);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12814,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t10)){
t12=t11;
f_12814(t12,t10);}
else{
t12=C_eqp(((C_word*)t0)[5],lf[402]);
if(C_truep(t12)){
t13=t11;
f_12814(t13,t12);}
else{
t13=C_eqp(((C_word*)t0)[5],lf[403]);
if(C_truep(t13)){
t14=t11;
f_12814(t14,t13);}
else{
t14=C_eqp(((C_word*)t0)[5],lf[404]);
if(C_truep(t14)){
t15=t11;
f_12814(t15,t14);}
else{
t15=C_eqp(((C_word*)t0)[5],lf[371]);
if(C_truep(t15)){
t16=t11;
f_12814(t16,t15);}
else{
t16=C_eqp(((C_word*)t0)[5],lf[367]);
if(C_truep(t16)){
t17=t11;
f_12814(t17,t16);}
else{
t17=C_eqp(((C_word*)t0)[5],lf[434]);
t18=t11;
f_12814(t18,(C_truep(t17)?t17:C_eqp(((C_word*)t0)[5],lf[401])));}}}}}}}}}}}}}}}}

/* k7433 in k7450 in loop in k7513 in k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_7434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:565: g1188 */
t2=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[233],((C_word*)t0)[4],t1);}

/* f_7439 in k7450 in loop in k7513 in k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_7439(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7439,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_record4(&a,4,lf[208],t2,t3,t4));}

/* k7443 in k7450 in loop in k7513 in k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_7445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7445,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[2]);
/* support.scm:568: reverse */
t3=*((C_word*)lf[89]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[3],t2);}

/* k10857 in k10751 in k10737 in repeat */
static void C_fcall f_10859(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10859,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10861,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:1049: gensym */
t3=*((C_word*)lf[106]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=C_eqp(((C_word*)t0)[5],lf[363]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10893,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_10893(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[5],lf[405]);
if(C_truep(t4)){
t5=t3;
f_10893(t5,t4);}
else{
t5=C_eqp(((C_word*)t0)[5],lf[406]);
if(C_truep(t5)){
t6=t3;
f_10893(t6,t5);}
else{
t6=C_eqp(((C_word*)t0)[5],lf[407]);
if(C_truep(t6)){
t7=t3;
f_10893(t7,t6);}
else{
t7=C_eqp(((C_word*)t0)[5],lf[408]);
if(C_truep(t7)){
t8=t3;
f_10893(t8,t7);}
else{
t8=C_eqp(((C_word*)t0)[5],lf[409]);
if(C_truep(t8)){
t9=t3;
f_10893(t9,t8);}
else{
t9=C_eqp(((C_word*)t0)[5],lf[410]);
t10=t3;
f_10893(t10,(C_truep(t9)?t9:C_eqp(((C_word*)t0)[5],lf[411])));}}}}}}}}

/* k6524 in k6521 in k6488 in k6486 */
static void C_ccall f_6525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6525,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6533,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6539,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:492: g914 */
t4=t2;
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)((C_word*)t0)[4])[1]);}

/* k6521 in k6488 in k6486 */
static void C_fcall f_6523(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6523,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[13]+1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6525,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm:492: display */
t4=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[165],*((C_word*)lf[13]+1));}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6553,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t3=C_eqp(((C_word*)((C_word*)t0)[3])[1],lf[168]);
t4=t2;
f_6553(t4,C_i_not(t3));}
else{
t3=t2;
f_6553(t3,C_SCHEME_FALSE);}}}

/* k8092 in map-loop1442 in k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_8093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8093,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8068(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8068(t6,((C_word*)t0)[5],t5);}}

/* k8124 in walk in build-expression-tree in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_8126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8126,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8127,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8133,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* support.scm:626: g1479 */
t4=t2;
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* f_8120 in walk in build-expression-tree in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_8120(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8120,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_slot(t2,C_fix(3)));}

/* f_8127 in k8124 in walk in build-expression-tree in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_8127(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8127,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_slot(t2,C_fix(2)));}

/* k6537 in k6524 in k6521 in k6488 in k6486 */
static void C_ccall f_6539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6539,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6541,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6547,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm:492: g917 */
t4=t2;
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)((C_word*)t0)[4])[1]);}

/* f_6533 in k6524 in k6521 in k6488 in k6486 */
static void C_ccall f_6533(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6533,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_slot(t2,C_fix(1)));}

/* ##compiler#build-expression-tree in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_8111(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8111,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8117,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_8117(t6,t1,t2);}

/* walk in build-expression-tree in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_8117(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8117,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8120,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8126,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm:625: g1476 */
t5=t3;
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* f_7422 in loop in k7513 in k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_7422(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7422,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_record4(&a,4,lf[208],t2,t3,t4));}

/* k6502 in k6492 in k6490 in k6488 in k6486 */
static void C_ccall f_6503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_length(((C_word*)((C_word*)t0)[2])[1]);
/* support.scm:498: write */
t3=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[4]);}

/* k8100 in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_8101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8101,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8103,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_positivep(((C_word*)((C_word*)t0)[3])[1]))){
/* support.scm:620: debugging */
t3=*((C_word*)lf[11]+1);
f_4702(5,t3,t2,lf[256],lf[257],((C_word*)((C_word*)t0)[3])[1]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}}

/* k8102 in k8100 in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_8103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}

/* k10872 in k10860 in k10857 in k10751 in k10737 in repeat */
static void C_fcall f_10873(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10873,NULL,2,t0,t1);}
t2=C_a_i_list(&a,2,lf[95],C_SCHEME_FALSE);
t3=C_a_i_list(&a,4,lf[222],((C_word*)t0)[2],t1,t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_list(&a,3,lf[105],((C_word*)t0)[4],t3));}

/* f_10307 in k10319 in k10281 in k10268 in rec in k10242 in simple-lambda-node? in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_10307(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10307,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_slot(t2,C_fix(2)));}

/* k7478 in k7484 in loop in k7513 in k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_7479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:574: walk */
t2=((C_word*)((C_word*)t0)[2])[1];
f_7080(t2,((C_word*)t0)[3],t1);}

/* k7475 in k7484 in loop in k7513 in k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_7476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7476,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[2]);
/* support.scm:574: reverse */
t3=*((C_word*)lf[89]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[3],t2);}

/* k4734 */
static void C_ccall f_4735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:65: write */
t2=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,((C_word*)t0)[3]);}

/* k4748 in for-each-loop46 in k4724 in k4714 */
static void C_ccall f_4749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4740(t3,((C_word*)t0)[4],t2);}

/* ##compiler#chop-extension in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13545(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_13545,3,t0,t1,t2);}
t3=C_i_string_length(t2);
t4=C_a_i_minus(&a,2,t3,C_fix(1));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13554,a[2]=t2,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_13554(t8,t1,t4);}

/* k7469 in k7484 in loop in k7513 in k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_7470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:571: g1198 */
t2=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[233],((C_word*)t0)[4],t1);}

/* k10311 in k10319 in k10281 in k10268 in rec in k10242 in simple-lambda-node? in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_10313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_i_car(t1);
t3=C_eqp(((C_word*)t0)[2],t2);
if(C_truep(t3)){
t4=C_u_i_cdr(((C_word*)t0)[3]);
/* support.scm:894: every */
t5=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[4],((C_word*)((C_word*)t0)[5])[1],t4);}
else{
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k7725 in map-loop1286 in k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_7726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7726,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7701(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7701(t6,((C_word*)t0)[5],t5);}}

/* k6513 in k6490 in k6488 in k6486 */
static void C_ccall f_6514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_length(((C_word*)((C_word*)t0)[2])[1]);
/* support.scm:497: write */
t3=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[4]);}

/* f_10315 in k10281 in k10268 in rec in k10242 in simple-lambda-node? in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_10315(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10315,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_slot(t2,C_fix(1)));}

/* k7484 in loop in k7513 in k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_7485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7485,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7470,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7476,a[2]=((C_word*)t0)[5],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7479,a[2]=((C_word*)t0)[6],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* support.scm:574: cadar */
t6=*((C_word*)lf[235]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[7]);}

/* k4765 in k4763 in dump in debugging in k4697 in k4664 in k4662 */
static void C_ccall f_4766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:57: display */
t2=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4]);}

/* k4763 in dump in debugging in k4697 in k4664 in k4662 */
static void C_ccall f_4764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4764,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4766,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* write-char/port */
t3=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(124),((C_word*)t0)[4]);}

/* dump in debugging in k4697 in k4664 in k4662 */
static void C_fcall f_4760(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4760,NULL,3,t0,t1,t2);}
t3=*((C_word*)lf[8]+1);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4764,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* support.scm:57: display */
t5=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],*((C_word*)lf[8]+1));}

/* k13528 in chop-separator in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_13530(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* support.scm:1370: substring */
t2=*((C_word*)lf[480]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k10811 in k10751 in k10737 in repeat */
static void C_ccall f_10812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10812,2,t0,t1);}
t2=C_a_i_list(&a,2,t1,((C_word*)t0)[2]);
t3=C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10824,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(*((C_word*)lf[348]+1))){
t5=t4;
f_10824(t5,t1);}
else{
t5=C_a_i_list(&a,2,lf[95],lf[359]);
t6=t4;
f_10824(t6,C_a_i_list(&a,3,lf[360],t5,t1));}}

/* f_7458 in loop in k7513 in k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_7458(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7458,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_record4(&a,4,lf[208],t2,t3,t4));}

/* k7450 in loop in k7513 in k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_7451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7451,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7434,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7439,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7445,a[2]=((C_word*)t0)[5],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* support.scm:569: g1193 */
t6=t4;
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[223],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* k8155 in k8146 in k8138 in k8131 in k8124 in walk in build-expression-tree in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_8157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8157,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* map-loop1498 in k8146 in k8138 in k8131 in k8124 in walk in build-expression-tree in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_8159(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8159,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8184,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:629: g1504 */
t5=((C_word*)((C_word*)t0)[5])[1];
f_8117(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k10860 in k10857 in k10751 in k10737 in repeat */
static void C_ccall f_10861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10861,2,t0,t1);}
t2=C_a_i_list(&a,2,t1,((C_word*)t0)[2]);
t3=C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10873,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(*((C_word*)lf[348]+1))){
t5=t4;
f_10873(t5,t1);}
else{
t5=C_a_i_list(&a,2,lf[95],((C_word*)t0)[4]);
t6=t4;
f_10873(t6,C_a_i_list(&a,3,lf[360],t5,t1));}}

/* k8138 in k8131 in k8124 in walk in build-expression-tree in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_8140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8140,2,t0,t1);}
t2=C_eqp(t1,lf[222]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8148,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_8148(t4,t2);}
else{
t4=C_eqp(t1,lf[272]);
t5=t3;
f_8148(t5,(C_truep(t4)?t4:C_eqp(t1,lf[273])));}}

/* k8146 in k8138 in k8131 in k8124 in walk in build-expression-tree in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_8148(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8148,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_i_check_list_2(((C_word*)t0)[2],lf[160]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8157,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8159,a[2]=t5,a[3]=t9,a[4]=t3,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_8159(t11,t7,((C_word*)t0)[2]);}
else{
t2=C_eqp(((C_word*)t0)[4],lf[259]);
if(C_truep(t2)){
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_i_check_list_2(((C_word*)t0)[2],lf[160]);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8205,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8207,a[2]=t6,a[3]=t10,a[4]=t4,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_8207(t12,t8,((C_word*)t0)[2]);}
else{
t3=C_eqp(((C_word*)t0)[4],lf[218]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_i_car(((C_word*)t0)[6]));}
else{
t4=C_eqp(((C_word*)t0)[4],lf[95]);
if(C_truep(t4)){
t5=C_i_car(((C_word*)t0)[6]);
t6=C_booleanp(t5);
if(C_truep(t6)){
if(C_truep(t6)){
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t5);}
else{
t7=C_u_i_car(((C_word*)t0)[6]);
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_a_i_list(&a,2,lf[95],t7));}}
else{
t7=C_i_stringp(t5);
if(C_truep(t7)){
if(C_truep(t7)){
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t5);}
else{
t8=C_u_i_car(((C_word*)t0)[6]);
t9=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_a_i_list(&a,2,lf[95],t8));}}
else{
t8=C_i_numberp(t5);
t9=(C_truep(t8)?t8:C_charp(t5));
if(C_truep(t9)){
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t5);}
else{
t10=C_u_i_car(((C_word*)t0)[6]);
t11=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_a_i_list(&a,2,lf[95],t10));}}}}
else{
t5=C_eqp(((C_word*)t0)[4],lf[105]);
if(C_truep(t5)){
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=*((C_word*)lf[260]+1);
t11=C_SCHEME_END_OF_LIST;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_SCHEME_FALSE;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8290,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],a[6]=t9,a[7]=t7,a[8]=t14,a[9]=t12,tmp=(C_word)a,a+=10,tmp);
/* support.scm:639: butlast */
t16=*((C_word*)lf[262]+1);
((C_proc3)(void*)(*((C_word*)t16+1)))(3,t16,t15,((C_word*)t0)[2]);}
else{
t6=C_eqp(((C_word*)t0)[4],lf[129]);
if(C_truep(t6)){
t7=C_i_cadr(((C_word*)t0)[6]);
t8=(C_truep(t7)?lf[231]:lf[129]);
t9=C_i_caddr(((C_word*)t0)[6]);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8396,a[2]=((C_word*)t0)[3],a[3]=t8,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
t11=C_i_car(((C_word*)t0)[2]);
/* support.scm:646: walk */
t12=((C_word*)((C_word*)t0)[5])[1];
f_8117(t12,t10,t11);}
else{
t7=C_eqp(((C_word*)t0)[4],lf[232]);
if(C_truep(t7)){
t8=C_i_car(((C_word*)t0)[6]);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8417,a[2]=((C_word*)t0)[3],a[3]=t8,tmp=(C_word)a,a+=4,tmp);
t10=C_i_car(((C_word*)t0)[2]);
/* support.scm:648: walk */
t11=((C_word*)((C_word*)t0)[5])[1];
f_8117(t11,t9,t10);}
else{
t8=C_eqp(((C_word*)t0)[4],lf[233]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8435,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t10=C_i_car(((C_word*)t0)[2]);
/* support.scm:651: walk */
t11=((C_word*)((C_word*)t0)[5])[1];
f_8117(t11,t9,t10);}
else{
t9=C_eqp(((C_word*)t0)[4],lf[248]);
if(C_truep(t9)){
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_FALSE;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_i_check_list_2(((C_word*)t0)[2],lf[160]);
t15=C_SCHEME_UNDEFINED;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_set_block_item(t16,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8508,a[2]=t13,a[3]=t16,a[4]=t11,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t18=((C_word*)t16)[1];
f_8508(t18,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t10=C_eqp(((C_word*)t0)[4],lf[239]);
if(C_truep(t10)){
t11=C_i_car(((C_word*)t0)[6]);
t12=C_SCHEME_END_OF_LIST;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_FALSE;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_i_check_list_2(((C_word*)t0)[2],lf[160]);
t17=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8554,a[2]=((C_word*)t0)[3],a[3]=t11,tmp=(C_word)a,a+=4,tmp);
t18=C_SCHEME_UNDEFINED;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_set_block_item(t19,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8556,a[2]=t15,a[3]=t19,a[4]=t13,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t21=((C_word*)t19)[1];
f_8556(t21,t17,((C_word*)t0)[2]);}
else{
t11=C_eqp(((C_word*)t0)[4],lf[223]);
if(C_truep(t11)){
t12=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_a_i_list1(&a,1,((C_word*)t0)[4]));}
else{
t12=C_eqp(((C_word*)t0)[4],lf[266]);
if(C_truep(t12)){
t13=C_i_car(((C_word*)t0)[6]);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8607,a[2]=((C_word*)t0)[5],a[3]=t15,tmp=(C_word)a,a+=4,tmp));
t17=((C_word*)t15)[1];
f_8607(t17,((C_word*)t0)[3],t13,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}
else{
t13=C_eqp(((C_word*)t0)[4],lf[267]);
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8651,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t13)){
t15=t14;
f_8651(t15,t13);}
else{
t15=C_eqp(((C_word*)t0)[4],lf[269]);
if(C_truep(t15)){
t16=t14;
f_8651(t16,t15);}
else{
t16=C_eqp(((C_word*)t0)[4],lf[270]);
t17=t14;
f_8651(t17,(C_truep(t16)?t16:C_eqp(((C_word*)t0)[4],lf[271])));}}}}}}}}}}}}}}}

/* k4776 in debugging in k4697 in k4664 in k4662 */
static void C_ccall f_4777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4777,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4779,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* support.scm:72: display */
t3=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k8131 in k8124 in walk in build-expression-tree in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_8133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8133,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8134,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8140,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* support.scm:627: g1482 */
t4=t2;
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[5]);}

/* f_8134 in k8131 in k8124 in walk in build-expression-tree in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_8134(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8134,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_slot(t2,C_fix(1)));}

/* k13414 in k13405 in k13345 in k13337 in k13330 in k13323 in walk in scan-free-variables in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1349: walk */
t2=((C_word*)((C_word*)t0)[2])[1];
f_13316(t2,((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* k4778 in k4776 in debugging in k4697 in k4664 in k4662 */
static void C_ccall f_4779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4779,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4781,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* support.scm:73: flush-output */
t3=*((C_word*)lf[20]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k10358 */
static void C_fcall f_10360(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10360,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10362,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:907: write */
t3=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k10361 in k10358 */
static void C_ccall f_10362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:908: newline */
t2=*((C_word*)lf[12]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k13405 in k13345 in k13337 in k13330 in k13323 in walk in scan-free-variables in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13406,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13415,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm:1349: append */
t4=*((C_word*)lf[68]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[5],((C_word*)t0)[6]);}

/* k10366 */
static void C_ccall f_10368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_10360(t2,C_SCHEME_FALSE);}
else{
if(C_truep(C_i_assq(lf[187],((C_word*)t0)[3]))){
t2=C_i_assq(lf[185],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_10360(t3,C_i_not(t2));}
else{
t2=((C_word*)t0)[2];
f_10360(t2,C_SCHEME_FALSE);}}}

/* k4790 in debugging in k4697 in k4664 in k4662 */
static void C_ccall f_4791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* f_7741 in k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_7741(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7741,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_record4(&a,4,lf[208],t2,t3,t4));}

/* k10823 in k10811 in k10751 in k10737 in repeat */
static void C_fcall f_10824(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10824,NULL,2,t0,t1);}
t2=C_a_i_list(&a,2,lf[95],C_SCHEME_FALSE);
t3=C_a_i_list(&a,4,lf[222],((C_word*)t0)[2],t1,t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_list(&a,3,lf[105],((C_word*)t0)[4],t3));}

/* for-each-loop46 in k4724 in k4714 */
static void C_fcall f_4740(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4740,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4749,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:64: g47 */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6581 in k6551 in k6521 in k6488 in k6486 */
static void C_fcall f_6583(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6583,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[13]+1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6585,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm:496: display */
t4=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[167],*((C_word*)lf[13]+1));}
else{
t2=((C_word*)t0)[2];
f_6491(2,t2,C_SCHEME_UNDEFINED);}}

/* k6584 in k6581 in k6551 in k6521 in k6488 in k6486 */
static void C_ccall f_6585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6585,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6593,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6599,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:496: g946 */
t4=t2;
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)((C_word*)t0)[4])[1]);}

/* ##compiler#dump-defined-globals in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_10385(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10385,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10391,tmp=(C_word)a,a+=2,tmp);
/* support.scm:912: ##sys#hash-table-for-each */
t4=*((C_word*)lf[161]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* ##compiler#tree-copy in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_9450(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9450,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9456,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_9456(t6,t1,t2);}

/* rec in tree-copy in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_9456(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_9456,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9469,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=t2;
t5=C_u_i_car(t4);
/* support.scm:758: rec */
t8=t3;
t9=t5;
t1=t8;
t2=t9;
goto loop;}
else{
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* f_6593 in k6584 in k6581 in k6551 in k6521 in k6488 in k6486 */
static void C_ccall f_6593(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6593,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_slot(t2,C_fix(1)));}

/* k6597 in k6584 in k6581 in k6551 in k6521 in k6488 in k6486 */
static void C_ccall f_6599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6599,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6601,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6607,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm:496: g949 */
t4=t2;
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)((C_word*)t0)[4])[1]);}

/* f_10391 in dump-defined-globals in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_10391(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10391,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10397,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10405,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* support.scm:914: keyword? */
t6=*((C_word*)lf[321]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k9481 in copy-node! in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_9482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9482,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9484,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9496,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9502,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:763: g2097 */
t5=t3;
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[4]);}

/* k10398 in k10395 */
static void C_ccall f_10399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:918: newline */
t2=*((C_word*)lf[12]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k10395 */
static void C_fcall f_10397(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10397,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10399,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:917: write */
t3=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* f_9488 in k9483 in k9481 in copy-node! in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_9488(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9488,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_slot(t2,C_fix(3)));}

/* k9483 in k9481 in copy-node! in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_9484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9484,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9486,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9488,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9494,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:764: g2100 */
t5=t3;
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[4]);}

/* k9485 in k9483 in k9481 in copy-node! in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_9486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}

/* ##compiler#collapsable-literal? in k4697 in k4664 in k4662 */
static void C_ccall f_5613(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5613,3,t0,t1,t2);}
t3=C_booleanp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=C_charp(t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=C_eofp(t2);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=C_i_numberp(t2);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_truep(t6)?t6:C_i_symbolp(t2)));}}}}

/* f_6563 in k6554 in k6551 in k6521 in k6488 in k6486 */
static void C_ccall f_6563(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6563,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_slot(t2,C_fix(1)));}

/* k6567 in k6554 in k6551 in k6521 in k6488 in k6486 */
static void C_ccall f_6569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6569,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6571,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6577,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm:494: g933 */
t4=t2;
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)((C_word*)t0)[4])[1]);}

/* f_6571 in k6567 in k6554 in k6551 in k6521 in k6488 in k6486 */
static void C_ccall f_6571(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6571,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_slot(t2,C_fix(2)));}

/* k6575 in k6567 in k6554 in k6551 in k6521 in k6488 in k6486 */
static void C_ccall f_6577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6577,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
/* support.scm:494: write */
t3=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[4]);}

/* k9468 in rec in tree-copy in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_9469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9469,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9472,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[3];
t4=C_u_i_cdr(t3);
/* support.scm:758: rec */
t5=((C_word*)((C_word*)t0)[4])[1];
f_9456(t5,t2,t4);}

/* k4780 in k4778 in k4776 in debugging in k4697 in k4664 in k4662 */
static void C_ccall f_4781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4781,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4783,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_memq(((C_word*)t0)[3],*((C_word*)lf[9]+1)))){
/* support.scm:75: dump */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4760(t3,t2,((C_word*)t0)[5]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}}

/* k4782 in k4780 in k4778 in k4776 in debugging in k4697 in k4664 in k4662 */
static void C_ccall f_4783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* k7138 in k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_7140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:531: g1072 */
t2=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[4],C_SCHEME_END_OF_LIST,t1);}

/* map-loop1079 in k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_7142(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7142,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7167,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:531: g1085 */
t5=((C_word*)((C_word*)t0)[5])[1];
f_7080(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* ##compiler#block-variable-literal-name in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13596(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_13596,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[484],lf[487]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_i_block_ref(t2,C_fix(1)));}

/* k5445 in k5434 in check-and-open-input-file in k4697 in k4664 in k4662 */
static void C_fcall f_5447(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* support.scm:222: quit */
t2=*((C_word*)lf[26]+1);
f_4904(4,t2,((C_word*)t0)[2],lf[82],((C_word*)t0)[3]);}
else{
t2=C_i_car(((C_word*)t0)[4]);
/* support.scm:223: quit */
t3=*((C_word*)lf[26]+1);
f_4904(5,t3,((C_word*)t0)[2],lf[83],t2,((C_word*)t0)[3]);}}

/* ##compiler#block-variable-literal? in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13590(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_13590,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_structurep(t2,lf[484]));}

/* k9492 in k9483 in k9481 in copy-node! in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_9494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[2];
t3=C_i_check_structure_2(t2,lf[208],C_SCHEME_FALSE);
/* support.scm:507: ##sys#block-set! */
t4=*((C_word*)lf[212]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],t2,C_fix(3),t1);}

/* f_9496 in k9481 in copy-node! in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_9496(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9496,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_slot(t2,C_fix(2)));}

/* ##compiler#make-block-variable-literal in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13584(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_13584,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record2(&a,2,lf[484],t2));}

/* ##compiler#immediate? in k4697 in k4664 in k4662 */
static void C_ccall f_5640(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5640,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5644,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_fixnump(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5679,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm:266: big-fixnum? */
t5=*((C_word*)lf[98]+1);
f_14302(3,t5,t4,t2);}
else{
t4=t3;
f_5644(t4,C_SCHEME_FALSE);}}

/* k7166 in map-loop1079 in k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_7167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7167,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7142(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7142(t6,((C_word*)t0)[5],t5);}}

/* k5643 in immediate? in k4697 in k4664 in k4662 */
static void C_fcall f_5644(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=C_eqp(C_SCHEME_UNDEFINED,((C_word*)t0)[3]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=C_i_nullp(((C_word*)t0)[3]);
if(C_truep(t3)){
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=C_eofp(((C_word*)t0)[3]);
if(C_truep(t4)){
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=C_charp(((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?t5:C_booleanp(((C_word*)t0)[3])));}}}}}

/* k13254 in k13193 in k13186 in walk in scan-used-variables in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13256,2,t0,t1);}
t2=C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13207,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13235,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_memq(t2,((C_word*)t0)[6]))){
t5=C_i_memq(t2,((C_word*)((C_word*)t0)[5])[1]);
t6=t4;
f_13235(t6,C_i_not(t5));}
else{
t5=t4;
f_13235(t5,C_SCHEME_FALSE);}}

/* f_13250 in k13193 in k13186 in walk in scan-used-variables in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13250(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_13250,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_slot(t2,C_fix(2)));}

/* k9471 in k9468 in rec in tree-copy in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_9472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9472,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* ##compiler#copy-node! in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_9478(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9478,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9482,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9504,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9510,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* support.scm:762: g2094 */
t7=t5;
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}

/* k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_7100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word t124;
C_word t125;
C_word t126;
C_word t127;
C_word t128;
C_word t129;
C_word t130;
C_word t131;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7100,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
if(C_truep(C_i_not_pair_p(((C_word*)t0)[3]))){
/* support.scm:528: bomb */
t2=*((C_word*)lf[3]+1);
f_4675(4,t2,((C_word*)t0)[2],lf[221],((C_word*)t0)[3]);}
else{
t2=C_i_car(((C_word*)t0)[3]);
if(C_truep(C_i_symbolp(t2))){
t3=((C_word*)t0)[3];
t4=C_u_i_car(t3);
t5=C_eqp(t4,lf[222]);
t6=(C_truep(t5)?t5:C_eqp(t4,lf[223]));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7125,tmp=(C_word)a,a+=2,tmp);
t8=((C_word*)t0)[3];
t9=C_u_i_car(t8);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_FALSE;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=((C_word*)t0)[3];
t15=C_u_i_cdr(t14);
t16=C_i_check_list_2(t15,lf[160]);
t17=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7140,a[2]=t7,a[3]=((C_word*)t0)[2],a[4]=t9,tmp=(C_word)a,a+=5,tmp);
t18=C_SCHEME_UNDEFINED;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_set_block_item(t19,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7142,a[2]=t13,a[3]=t19,a[4]=t11,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t21=((C_word*)t19)[1];
f_7142(t21,t17,t15);}
else{
t7=C_eqp(t4,lf[95]);
if(C_truep(t7)){
t8=C_i_cadr(((C_word*)t0)[3]);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7187,a[2]=((C_word*)t0)[2],a[3]=t8,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_numberp(t8))){
t10=C_eqp(lf[227],*((C_word*)lf[228]+1));
if(C_truep(t10)){
t11=C_i_integerp(t8);
t12=t9;
f_7187(t12,C_i_not(t11));}
else{
t11=t9;
f_7187(t11,C_SCHEME_FALSE);}}
else{
t10=t9;
f_7187(t10,C_SCHEME_FALSE);}}
else{
t8=C_eqp(t4,lf[105]);
if(C_truep(t8)){
t9=C_i_cadr(((C_word*)t0)[3]);
t10=C_i_caddr(((C_word*)t0)[3]);
if(C_truep(C_i_nullp(t9))){
/* support.scm:546: walk */
t11=((C_word*)((C_word*)t0)[4])[1];
f_7080(t11,((C_word*)t0)[2],t10);}
else{
t11=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7230,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_END_OF_LIST;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_FALSE;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7238,tmp=(C_word)a,a+=2,tmp);
t17=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7249,a[2]=t11,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],a[6]=t10,a[7]=t15,a[8]=t13,a[9]=t16,tmp=(C_word)a,a+=10,tmp);
/* support.scm:552: unzip1 */
t18=*((C_word*)lf[230]+1);
((C_proc3)(void*)(*((C_word*)t18+1)))(3,t18,t17,t9);}}
else{
t9=C_eqp(t4,lf[231]);
t10=(C_truep(t9)?t9:C_eqp(t4,lf[129]));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7345,tmp=(C_word)a,a+=2,tmp);
t12=C_i_cadr(((C_word*)t0)[3]);
t13=C_a_i_list1(&a,1,t12);
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7360,a[2]=t11,a[3]=((C_word*)t0)[2],a[4]=t13,tmp=(C_word)a,a+=5,tmp);
t15=C_i_caddr(((C_word*)t0)[3]);
/* support.scm:556: walk */
t16=((C_word*)((C_word*)t0)[4])[1];
f_7080(t16,t14,t15);}
else{
t11=C_eqp(t4,lf[232]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7373,tmp=(C_word)a,a+=2,tmp);
t13=C_i_cadr(((C_word*)t0)[3]);
t14=C_i_caddr(((C_word*)t0)[3]);
t15=C_a_i_list2(&a,2,t13,t14);
t16=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7388,a[2]=t12,a[3]=((C_word*)t0)[2],a[4]=t15,tmp=(C_word)a,a+=5,tmp);
t17=C_i_cadddr(((C_word*)t0)[3]);
/* support.scm:560: walk */
t18=((C_word*)((C_word*)t0)[4])[1];
f_7080(t18,t16,t17);}
else{
t12=C_eqp(t4,lf[233]);
if(C_truep(t12)){
t13=C_i_cdddr(((C_word*)t0)[3]);
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7514,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=t13,tmp=(C_word)a,a+=6,tmp);
t15=((C_word*)t0)[3];
t16=C_u_i_cdr(t15);
t17=C_u_i_cdr(t16);
t18=C_u_i_car(t17);
/* support.scm:563: walk */
t19=((C_word*)((C_word*)t0)[4])[1];
f_7080(t19,t14,t18);}
else{
t13=C_eqp(t4,lf[237]);
if(C_truep(t13)){
t14=C_i_cadr(((C_word*)t0)[3]);
t15=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7527,tmp=(C_word)a,a+=2,tmp);
t16=((C_word*)t0)[3];
t17=C_u_i_car(t16);
t18=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7538,a[2]=((C_word*)t0)[3],a[3]=t15,a[4]=((C_word*)t0)[2],a[5]=t17,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_pairp(t14))){
t19=C_u_i_car(t14);
t20=C_eqp(lf[95],t19);
if(C_truep(t20)){
t21=C_i_cadr(t14);
t22=t18;
f_7538(t22,C_a_i_list1(&a,1,t21));}
else{
t21=t18;
f_7538(t21,C_a_i_list1(&a,1,t14));}}
else{
t19=t18;
f_7538(t19,C_a_i_list1(&a,1,t14));}}
else{
t14=C_eqp(t4,lf[238]);
t15=(C_truep(t14)?t14:C_eqp(t4,lf[239]));
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7602,tmp=(C_word)a,a+=2,tmp);
t17=((C_word*)t0)[3];
t18=C_u_i_car(t17);
t19=C_i_cadr(((C_word*)t0)[3]);
t20=C_a_i_list1(&a,1,t19);
t21=C_SCHEME_END_OF_LIST;
t22=(*a=C_VECTOR_TYPE|1,a[1]=t21,tmp=(C_word)a,a+=2,tmp);
t23=C_SCHEME_FALSE;
t24=(*a=C_VECTOR_TYPE|1,a[1]=t23,tmp=(C_word)a,a+=2,tmp);
t25=((C_word*)t0)[3];
t26=C_u_i_cdr(t25);
t27=C_u_i_cdr(t26);
t28=C_i_check_list_2(t27,lf[160]);
t29=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7621,a[2]=t16,a[3]=((C_word*)t0)[2],a[4]=t18,a[5]=t20,tmp=(C_word)a,a+=6,tmp);
t30=C_SCHEME_UNDEFINED;
t31=(*a=C_VECTOR_TYPE|1,a[1]=t30,tmp=(C_word)a,a+=2,tmp);
t32=C_set_block_item(t31,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7623,a[2]=t24,a[3]=t31,a[4]=t22,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t33=((C_word*)t31)[1];
f_7623(t33,t29,t27);}
else{
t16=C_eqp(t4,lf[240]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7661,tmp=(C_word)a,a+=2,tmp);
t18=C_i_cadr(((C_word*)t0)[3]);
t19=C_a_i_list2(&a,2,t18,C_SCHEME_TRUE);
/* support.scm:587: g1271 */
t20=t17;
((C_proc5)(void*)(*((C_word*)t20+1)))(5,t20,((C_word*)t0)[2],lf[240],t19,C_SCHEME_END_OF_LIST);}
else{
t17=C_eqp(t4,lf[241]);
t18=(C_truep(t17)?t17:C_eqp(t4,lf[242]));
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7682,tmp=(C_word)a,a+=2,tmp);
t20=C_i_cadr(((C_word*)t0)[3]);
t21=C_a_i_list1(&a,1,t20);
t22=C_SCHEME_END_OF_LIST;
t23=(*a=C_VECTOR_TYPE|1,a[1]=t22,tmp=(C_word)a,a+=2,tmp);
t24=C_SCHEME_FALSE;
t25=(*a=C_VECTOR_TYPE|1,a[1]=t24,tmp=(C_word)a,a+=2,tmp);
t26=((C_word*)t0)[3];
t27=C_u_i_cdr(t26);
t28=C_u_i_cdr(t27);
t29=C_i_check_list_2(t28,lf[160]);
t30=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7699,a[2]=t19,a[3]=((C_word*)t0)[2],a[4]=t21,tmp=(C_word)a,a+=5,tmp);
t31=C_SCHEME_UNDEFINED;
t32=(*a=C_VECTOR_TYPE|1,a[1]=t31,tmp=(C_word)a,a+=2,tmp);
t33=C_set_block_item(t32,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7701,a[2]=t25,a[3]=t32,a[4]=t23,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t34=((C_word*)t32)[1];
f_7701(t34,t30,t28);}
else{
t19=C_eqp(t4,lf[243]);
if(C_truep(t19)){
t20=C_i_cadr(((C_word*)t0)[3]);
t21=C_i_cadr(t20);
t22=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7741,tmp=(C_word)a,a+=2,tmp);
t23=C_i_caddr(((C_word*)t0)[3]);
t24=C_i_cadr(t23);
t25=C_i_cadddr(((C_word*)t0)[3]);
t26=C_i_cadr(t25);
t27=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7771,a[2]=t21,a[3]=t24,a[4]=t26,a[5]=t22,a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[3],tmp=(C_word)a,a+=9,tmp);
/* support.scm:596: fifth */
t28=*((C_word*)lf[245]+1);
((C_proc3)(void*)(*((C_word*)t28+1)))(3,t28,t27,((C_word*)t0)[3]);}
else{
t20=C_eqp(t4,lf[246]);
t21=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7788,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t20)){
t22=t21;
f_7788(t22,t20);}
else{
t22=C_eqp(t4,lf[252]);
if(C_truep(t22)){
t23=t21;
f_7788(t23,t22);}
else{
t23=C_eqp(t4,lf[253]);
if(C_truep(t23)){
t24=t21;
f_7788(t24,t23);}
else{
t24=C_eqp(t4,lf[254]);
t25=t21;
f_7788(t25,(C_truep(t24)?t24:C_eqp(t4,lf[255])));}}}}}}}}}}}}}}}
else{
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8053,tmp=(C_word)a,a+=2,tmp);
t4=C_a_i_list1(&a,1,C_SCHEME_FALSE);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=((C_word*)t0)[3];
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8066,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8068,a[2]=t8,a[3]=t12,a[4]=t6,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t14=((C_word*)t12)[1];
f_8068(t14,t10,t9);}}}}

/* loop in chop-extension in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_13554(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_13554,NULL,3,t0,t1,t2);}
if(C_truep(C_i_zerop(t2))){
t3=((C_word*)t0)[2];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=C_i_string_ref(((C_word*)t0)[2],t2);
if(C_truep(C_i_char_equalp(C_make_character(46),t3))){
/* support.scm:1377: substring */
t4=*((C_word*)lf[480]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,((C_word*)t0)[2],C_fix(0),t2);}
else{
t4=C_a_i_minus(&a,2,t2,C_fix(1));
/* support.scm:1378: loop */
t7=t1;
t8=t4;
t1=t7;
t2=t8;
goto loop;}}}

/* f_7125 in k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_7125(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7125,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_record4(&a,4,lf[208],t2,t3,t4));}

/* for-each-loop3385 in k13206 in k13254 in k13193 in k13186 in walk in scan-used-variables in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_13214(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13214,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13223,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:1320: g3386 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_13179(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k9895 in loop */
static void C_ccall f_9896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9896,2,t0,t1);}
if(C_truep(C_eofp(t1))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9903,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9919,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=C_i_car(t1);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9928,a[2]=t2,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=C_i_cadr(t1);
/* support.scm:824: sexpr->node */
t7=*((C_word*)lf[289]+1);
f_9586(3,t7,t5,t6);}}

/* loop */
static void C_fcall f_9892(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9892,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9896,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm:819: read */
t3=*((C_word*)lf[113]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k13206 in k13254 in k13193 in k13186 in walk in scan-used-variables in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_13207(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13207,NULL,2,t0,t1);}
t2=C_i_check_list_2(((C_word*)t0)[2],lf[33]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13214,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_13214(t6,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k8552 in k8146 in k8138 in k8131 in k8124 in walk in build-expression-tree in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_8554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:661: cons* */
t2=*((C_word*)lf[265]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[239],((C_word*)t0)[3],t1);}

/* map-loop1665 in k8146 in k8138 in k8131 in k8124 in walk in build-expression-tree in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_8556(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8556,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8581,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:661: g1671 */
t5=((C_word*)((C_word*)t0)[5])[1];
f_8117(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* f_10425 in dump-global-refs in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_10425(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10425,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10453,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm:924: keyword? */
t5=*((C_word*)lf[321]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k8580 in map-loop1665 in k8146 in k8138 in k8131 in k8124 in walk in build-expression-tree in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_8581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8581,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8556(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8556(t6,((C_word*)t0)[5],t5);}}

/* k10434 in k10451 */
static void C_ccall f_10435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:927: newline */
t2=*((C_word*)lf[12]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k9989 in match1 in match-node in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_9991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_u_i_cdr(t2);
t4=((C_word*)t0)[3];
t5=C_u_i_cdr(t4);
/* support.scm:843: match1 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_9969(t6,((C_word*)t0)[5],t3,t5);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k8532 in map-loop1639 in k8146 in k8138 in k8131 in k8124 in walk in build-expression-tree in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_8533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8533,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8508(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8508(t6,((C_word*)t0)[5],t5);}}

/* k10451 */
static void C_ccall f_10453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10453,2,t0,t1);}
t2=(C_truep(t1)?C_SCHEME_FALSE:C_i_assq(lf[187],((C_word*)t0)[2]));
if(C_truep(t2)){
t3=C_i_assq(lf[175],((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10435,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t3)){
t5=C_i_cdr(t3);
t6=C_i_length(t5);
t7=C_a_i_list2(&a,2,((C_word*)t0)[4],t6);
/* support.scm:926: write */
t8=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t4,t7);}
else{
t5=C_a_i_list2(&a,2,((C_word*)t0)[4],C_fix(0));
/* support.scm:926: write */
t6=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7185 in k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_7187(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7187,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7189,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:538: warning */
t3=*((C_word*)lf[225]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[226],((C_word*)t0)[3]);}
else{
/* support.scm:534: qnode */
t2=*((C_word*)lf[219]+1);
f_7062(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* k7188 in k7185 in k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_7189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7189,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7195,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:540: truncate */
t3=*((C_word*)lf[224]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k13233 in k13254 in k13193 in k13186 in walk in scan-used-variables in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_13235(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13235,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[4];
f_13207(t4,t3);}
else{
t2=((C_word*)t0)[4];
f_13207(t2,C_SCHEME_UNDEFINED);}}

/* f_14428 in foldable? in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14428(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_14428,4,t0,t1,t2,t3);}
/* tweaks.scm:57: ##sys#get */
t4=*((C_word*)lf[250]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,t3);}

/* k5694 in basic-literal? in k4697 in k4664 in k4662 */
static void C_ccall f_5695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5695,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5700,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_vectorp(((C_word*)t0)[3]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5731,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm:277: vector->list */
t4=*((C_word*)lf[101]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}
else{
t3=t2;
f_5700(2,t3,C_SCHEME_FALSE);}}}

/* k13222 in for-each-loop3385 in k13206 in k13254 in k13193 in k13186 in walk in scan-used-variables in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_13214(t3,((C_word*)t0)[4],t2);}

/* k7194 in k7188 in k7185 in k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_7195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_inexact_to_exact(t1);
/* support.scm:534: qnode */
t3=*((C_word*)lf[219]+1);
f_7062(3,t3,((C_word*)t0)[2],t2);}

/* foldable? in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14425(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_14425,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14428,tmp=(C_word)a,a+=2,tmp);
/* support.scm:1592: g3891 */
t4=t3;
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,lf[136]);}

/* k12832 in k12812 in k12739 in k12667 in k12646 in foreign-type->scrutiny-type in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_12834(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12834,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[472]);}
else{
t2=C_eqp(((C_word*)t0)[3],lf[399]);
t3=(C_truep(t2)?t2:C_eqp(((C_word*)t0)[3],lf[400]));
if(C_truep(t3)){
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[473]);}
else{
t4=C_eqp(((C_word*)t0)[3],lf[379]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12850,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t4)){
t6=t5;
f_12850(t6,t4);}
else{
t6=C_eqp(((C_word*)t0)[3],lf[394]);
t7=t5;
f_12850(t7,(C_truep(t6)?t6:C_eqp(((C_word*)t0)[3],lf[395])));}}}}

/* node-parameters in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_7004(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7004,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[208],lf[213]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_i_block_ref(t2,C_fix(2)));}

/* ##compiler#basic-literal? in k4697 in k4664 in k4662 */
static void C_ccall f_5681(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5681,3,t0,t1,t2);}
t3=C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=C_i_symbolp(t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5695,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:276: constant? */
t6=*((C_word*)lf[94]+1);
f_5573(3,t6,t5,t2);}}}

/* k10607 in k10605 in k10602 */
static void C_ccall f_10608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10608,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10610,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* support.scm:985: display */
t3=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[336],((C_word*)t0)[8]);}

/* k10605 in k10602 */
static void C_ccall f_10606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10606,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10608,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* support.scm:985: write */
t3=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[10],((C_word*)t0)[8]);}

/* f_14417 in intrinsic? in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14417(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_14417,4,t0,t1,t2,t3);}
/* tweaks.scm:57: ##sys#get */
t4=*((C_word*)lf[250]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,t3);}

/* ##compiler#intrinsic? in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14414(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_14414,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14417,tmp=(C_word)a,a+=2,tmp);
/* support.scm:1591: g3880 */
t4=t3;
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,lf[137]);}

/* ##compiler#variable-mark in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14408(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_14408,4,t0,t1,t2,t3);}
/* support.scm:1589: ##sys#get */
t4=*((C_word*)lf[250]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,t3);}

/* k13440 */
static void C_ccall f_13441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1354: walk */
t2=((C_word*)((C_word*)t0)[2])[1];
f_13316(t2,((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* k5678 in immediate? in k4697 in k4664 in k4662 */
static void C_ccall f_5679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5644(t2,C_i_not(t1));}

/* f_13432 in k13345 in k13337 in k13330 in k13323 in walk in scan-free-variables in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13432(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_13432,5,t0,t1,t2,t3,t4);}
t5=C_i_car(((C_word*)t0)[2]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13441,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* support.scm:1354: append */
t7=*((C_word*)lf[68]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t2,((C_word*)t0)[4]);}

/* f_5548 in loop in follow-without-loop in k4697 in k4664 in k4662 */
static void C_ccall f_5548(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5548,3,t0,t1,t2);}
t3=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
/* support.scm:242: loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_5533(t4,t1,t2,t3);}

/* f_6541 in k6537 in k6524 in k6521 in k6488 in k6486 */
static void C_ccall f_6541(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6541,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_slot(t2,C_fix(2)));}

/* k6545 in k6537 in k6524 in k6521 in k6488 in k6486 */
static void C_ccall f_6547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6547,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
/* support.scm:492: write */
t3=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[4]);}

/* k6551 in k6521 in k6488 in k6486 */
static void C_fcall f_6553(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6553,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[13]+1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6555,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm:494: display */
t4=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[166],*((C_word*)lf[13]+1));}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6583,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t3=C_eqp(((C_word*)((C_word*)t0)[5])[1],lf[168]);
t4=t2;
f_6583(t4,C_i_not(t3));}
else{
t3=t2;
f_6583(t3,C_SCHEME_FALSE);}}}

/* k6554 in k6551 in k6521 in k6488 in k6486 */
static void C_ccall f_6555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6555,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6563,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6569,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:494: g930 */
t4=t2;
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)((C_word*)t0)[4])[1]);}

/* for-each-loop3474 in walkeach in scan-free-variables in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_13495(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13495,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13504,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:1328: g3475 */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* f_5562 in sort-symbols in k4697 in k4664 in k4662 */
static void C_ccall f_5562(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5562,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5568,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* support.scm:245: symbol->string */
t5=*((C_word*)lf[49]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k5567 */
static void C_ccall f_5568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5568,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5571,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm:245: symbol->string */
t3=*((C_word*)lf[49]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* walkeach in scan-free-variables in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_13482(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13482,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13485,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=C_i_check_list_2(t2,lf[33]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13495,a[2]=t7,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_13495(t9,t1,t2);}

/* f_13485 in walkeach in scan-free-variables in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13485(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_13485,3,t0,t1,t2);}
/* support.scm:1358: walk */
t3=((C_word*)((C_word*)t0)[2])[1];
f_13316(t3,t1,t2,((C_word*)t0)[3]);}

/* k6404 in loop in find-lambda-container in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_6405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm:428: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_6396(t2,((C_word*)t0)[3],t1);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#sort-symbols in k4697 in k4664 in k4662 */
static void C_ccall f_5556(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5556,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5562,tmp=(C_word)a,a+=2,tmp);
/* support.scm:245: sort */
t4=*((C_word*)lf[93]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,t3);}

/* ##compiler#display-line-number-database in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_6413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6413,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6419,tmp=(C_word)a,a+=2,tmp);
/* support.scm:431: ##sys#hash-table-for-each */
t3=*((C_word*)lf[161]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,*((C_word*)lf[154]+1));}

/* f_9873 in k9755 */
static void C_ccall f_9873(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9873,4,t0,t1,t2,t3);}
/* tweaks.scm:57: ##sys#get */
t4=*((C_word*)lf[250]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,t3);}

/* k9869 in k9755 */
static void C_ccall f_9871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9871,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=C_i_assq(lf[171],((C_word*)t0)[3]);
t3=C_i_not(t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9778,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t3)){
t5=t4;
f_9778(t5,t3);}
else{
t5=C_i_cdr(t2);
t6=C_eqp(lf[168],t5);
t7=t4;
f_9778(t7,C_i_not(t6));}}}

/* k9877 in k9755 */
static void C_ccall f_9879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:784: g2193 */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],t1);}

/* ##compiler#stringify in k4697 in k4664 in k4662 */
static void C_ccall f_5164(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5164,3,t0,t1,t2);}
if(C_truep(C_i_stringp(t2))){
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep(C_i_symbolp(t2))){
/* support.scm:163: symbol->string */
t3=*((C_word*)lf[49]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5182,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:164: open-output-string */
t4=*((C_word*)lf[51]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}}

/* f_6419 in display-line-number-database in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_6419(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6419,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=*((C_word*)lf[13]+1);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6424,a[2]=t1,a[3]=t4,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* support.scm:433: write */
t6=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,*((C_word*)lf[13]+1));}
else{
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k6427 in k6425 in k6423 */
static void C_ccall f_6428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(10),((C_word*)t0)[3]);}

/* k6425 in k6423 */
static void C_ccall f_6426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6426,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6428,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=*((C_word*)lf[159]+1);
t8=((C_word*)t0)[4];
t9=C_i_check_list_2(t8,lf[160]);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6437,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6439,a[2]=t6,a[3]=t12,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t14=((C_word*)t12)[1];
f_6439(t14,t10,t8);}

/* k6423 */
static void C_ccall f_6424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6424,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6426,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* write-char/port */
t3=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(32),((C_word*)t0)[3]);}

/* ##compiler#load-inline-file in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_9881(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9881,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9887,tmp=(C_word)a,a+=2,tmp);
/* support.scm:816: with-input-from-file */
t4=*((C_word*)lf[311]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,t3);}

/* f_9887 in load-inline-file in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_9887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9887,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9892,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_9892(t5,t1);}

/* k6435 in k6425 in k6423 */
static void C_ccall f_6437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:433: write */
t2=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,((C_word*)t0)[3]);}

/* k7544 in k7537 in k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_7546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:580: g1205 */
t2=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],t1);}

/* map-loop1213 in k7537 in k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_7548(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7548,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7573,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:583: g1219 */
t5=((C_word*)((C_word*)t0)[5])[1];
f_7080(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5183 in k5181 in stringify in k4697 in k4664 in k4662 */
static void C_ccall f_5185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:164: get-output-string */
t2=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k5181 in stringify in k4697 in k4664 in k4662 */
static void C_ccall f_5182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5182,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5185,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm:164: display */
t4=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],t2);}

/* map-loop751 in k6425 in k6423 */
static void C_fcall f_6439(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6439,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_cdr(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t6=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t5);
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}
else{
t6=C_mutate(((C_word *)((C_word*)t0)[4])+1,t5);
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t8=C_slot(t2,C_fix(1));
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* f_6064 in k6055 */
static void C_ccall f_6064(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr4r,(void*)f_6064r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6064r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6064r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
if(C_truep(C_i_nullp(t4))){
/* tweaks.scm:54: ##sys#put! */
t5=*((C_word*)lf[134]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,t3,C_SCHEME_TRUE);}
else{
t5=C_i_car(t4);
/* tweaks.scm:54: ##sys#put! */
t6=*((C_word*)lf[134]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,t2,t3,t5);}}

/* for-each-loop3409 in k13262 in k13193 in k13186 in walk in scan-used-variables in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_13271(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13271,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13280,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:1322: g3410 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_13179(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k13262 in k13193 in k13186 in walk in scan-used-variables in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_13264(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13264,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=C_i_check_list_2(((C_word*)t0)[3],lf[33]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13271,a[2]=t4,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_13271(t6,((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* f_6088 */
static void C_ccall f_6088(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr4r,(void*)f_6088r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6088r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6088r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
if(C_truep(C_i_nullp(t4))){
/* tweaks.scm:54: ##sys#put! */
t5=*((C_word*)lf[134]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,t3,C_SCHEME_TRUE);}
else{
t5=C_i_car(t4);
/* tweaks.scm:54: ##sys#put! */
t6=*((C_word*)lf[134]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,t2,t3,t5);}}

/* f_6086 in k6083 in k6036 in initialize-analysis-database in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_6086(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6086,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6088,tmp=(C_word)a,a+=2,tmp);
/* support.scm:366: g635 */
t4=t3;
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,t2,lf[137],lf[142]);}

/* k6083 in k6036 in initialize-analysis-database in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_6085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6085,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6086,tmp=(C_word)a,a+=2,tmp);
t3=*((C_word*)lf[143]+1);
t4=C_i_check_list_2(*((C_word*)lf[143]+1),lf[33]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6111,a[2]=t6,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_6111(t8,((C_word*)t0)[2],*((C_word*)lf[143]+1));}

/* ##compiler#symbolify in k4697 in k4664 in k4662 */
static void C_ccall f_5190(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5190,3,t0,t1,t2);}
if(C_truep(C_i_symbolp(t2))){
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep(C_i_stringp(t2))){
/* support.scm:168: string->symbol */
t3=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5212,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:169: open-output-string */
t4=*((C_word*)lf[51]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}}

/* loop in llist-match? in k5801 in k5799 in k4697 in k4664 in k4662 */
static C_word C_fcall f_5904(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_stack_overflow_check;
loop:
if(C_truep(C_i_nullp(t1))){
return(C_i_nullp(t2));}
else{
t3=C_i_symbolp(t1);
if(C_truep(t3)){
return(t3);}
else{
if(C_truep(C_i_nullp(t2))){
return(C_i_not_pair_p(t1));}
else{
t4=C_i_cdr(t1);
t5=C_i_cdr(t2);
t7=t4;
t8=t5;
t1=t7;
t2=t8;
goto loop;}}}}

/* f_6017 in k6008 */
static void C_ccall f_6017(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr4r,(void*)f_6017r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6017r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6017r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
if(C_truep(C_i_nullp(t4))){
/* tweaks.scm:54: ##sys#put! */
t5=*((C_word*)lf[134]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,t3,C_SCHEME_TRUE);}
else{
t5=C_i_car(t4);
/* tweaks.scm:54: ##sys#put! */
t6=*((C_word*)lf[134]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,t2,t3,t5);}}

/* k6008 */
static void C_ccall f_6010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6010,2,t0,t1);}
if(C_truep(C_i_memq(((C_word*)t0)[2],*((C_word*)lf[135]+1)))){
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6017,tmp=(C_word)a,a+=2,tmp);
/* support.scm:356: g552 */
t3=t2;
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],((C_word*)t0)[2],lf[136],C_SCHEME_TRUE);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k6486 */
static void C_ccall f_6487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6487,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6489,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6627,a[2]=t4,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_6627(t6,t2,((C_word*)t0)[8]);}

/* k6488 in k6486 */
static void C_ccall f_6489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6489,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6491,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6523,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)((C_word*)t0)[5])[1])){
t4=C_eqp(((C_word*)((C_word*)t0)[5])[1],lf[168]);
t5=t3;
f_6523(t5,C_i_not(t4));}
else{
t4=t3;
f_6523(t4,C_SCHEME_FALSE);}}

/* k6492 in k6490 in k6488 in k6486 */
static void C_ccall f_6493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6493,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6495,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_pairp(((C_word*)((C_word*)t0)[3])[1]))){
t3=*((C_word*)lf[13]+1);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6503,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* support.scm:498: display */
t5=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,lf[163],*((C_word*)lf[13]+1));}
else{
/* support.scm:499: newline */
t3=*((C_word*)lf[12]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}}

/* ##compiler#source-info->line in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13817(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_13817,3,t0,t1,t2);}
if(C_truep(C_i_listp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_car(t2));}
else{
if(C_truep(t2)){
/* support.scm:1459: ->string */
t3=*((C_word*)lf[58]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}}

/* k6494 in k6492 in k6490 in k6488 in k6486 */
static void C_ccall f_6495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:499: newline */
t2=*((C_word*)lf[12]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k6490 in k6488 in k6486 */
static void C_ccall f_6491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6491,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6493,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_pairp(((C_word*)((C_word*)t0)[4])[1]))){
t3=*((C_word*)lf[13]+1);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6514,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* support.scm:497: display */
t5=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,lf[164],*((C_word*)lf[13]+1));}
else{
t3=t2;
f_6493(2,t3,C_SCHEME_UNDEFINED);}}

/* k13808 in source-info->string in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1453: make-string */
t2=*((C_word*)lf[505]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_make_character(32));}

/* k13805 in source-info->string in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1453: conc */
t2=*((C_word*)lf[502]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[2],((C_word*)t0)[3],lf[503],t1,lf[504],((C_word*)t0)[4]);}

/* k10403 */
static void C_ccall f_10405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_10397(t2,C_SCHEME_FALSE);}
else{
t2=C_i_assq(lf[187],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_10397(t3,(C_truep(t2)?C_i_assq(lf[185],((C_word*)t0)[3]):C_SCHEME_FALSE));}}

/* k6055 */
static void C_ccall f_6057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6057,2,t0,t1);}
if(C_truep(C_i_memq(((C_word*)t0)[2],*((C_word*)lf[135]+1)))){
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6064,tmp=(C_word)a,a+=2,tmp);
/* support.scm:362: g601 */
t3=t2;
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],((C_word*)t0)[2],lf[136],C_SCHEME_TRUE);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k4841 in for-each-loop103 in k4827 in collect in with-debugging-output in k4697 in k4664 in k4662 */
static void C_ccall f_4842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4833(t3,((C_word*)t0)[4],t2);}

/* ##compiler#dump-global-refs in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_10419(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10419,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10425,tmp=(C_word)a,a+=2,tmp);
/* support.scm:922: ##sys#hash-table-for-each */
t4=*((C_word*)lf[161]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* k9528 in walk in node->sexpr in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_9530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9530,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9535,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9541,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* support.scm:770: g2116 */
t4=t2;
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* ##compiler#constant-form-eval in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13869(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_13869,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13872,tmp=(C_word)a,a+=2,tmp);
t10=C_i_check_list_2(t3,lf[160]);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13888,a[2]=t2,a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14012,a[2]=t8,a[3]=t13,a[4]=t6,a[5]=t9,tmp=(C_word)a,a+=6,tmp));
t15=((C_word*)t13)[1];
f_14012(t15,t11,t3);}

/* f_9535 in k9528 in walk in node->sexpr in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_9535(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9535,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_slot(t2,C_fix(2)));}

/* k13279 in for-each-loop3409 in k13262 in k13193 in k13186 in walk in scan-used-variables in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_13271(t3,((C_word*)t0)[4],t2);}

/* for-each-loop103 in k4827 in collect in with-debugging-output in k4697 in k4664 in k4662 */
static void C_fcall f_4833(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4833,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4842,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:82: g104 */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k14072 in k14065 in k14058 in loop in dump-nodes in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14074,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_14076,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* support.scm:1497: make-string */
t3=*((C_word*)lf[505]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_make_character(32));}

/* k14075 in k14072 in k14065 in k14058 in loop in dump-nodes in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14076,2,t0,t1);}
t2=C_a_i_plus(&a,2,((C_word*)t0)[2],C_fix(2));
t3=*((C_word*)lf[13]+1);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_14080,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t3,a[9]=((C_word*)t0)[8],a[10]=t1,tmp=(C_word)a,a+=11,tmp);
/* write-char/port */
t5=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_make_character(10),*((C_word*)lf[13]+1));}

/* f_9524 in walk in node->sexpr in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_9524(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9524,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_slot(t2,C_fix(1)));}

/* k4868 in test-mode in with-debugging-output in k4697 in k4664 in k4662 */
static void C_ccall f_4869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_i_pairp(t1));}

/* k14462 */
static void C_ccall f_14463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14463,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[2];
t4=C_u_i_cdr(t3);
t5=C_a_i_list1(&a,1,t4);
/* support.scm:1606: append */
t6=*((C_word*)lf[68]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,((C_word*)t0)[3],t2,t5);}

/* k13840 in call-info in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k14459 */
static void C_ccall f_14460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1604: ##sys#put! */
t2=*((C_word*)lf[134]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],((C_word*)t0)[3],lf[542],t1);}

/* test-mode in with-debugging-output in k4697 in k4664 in k4662 */
static void C_fcall f_4853(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4853,NULL,3,t1,t2,t3);}
if(C_truep(C_i_symbolp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_i_memq(t2,t3));}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4869,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm:93: lset-intersection */
t5=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,*((C_word*)lf[25]+1),t2,t3);}}

/* k7572 in map-loop1213 in k7537 in k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_7573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7573,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7548(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7548(t6,((C_word*)t0)[5],t5);}}

/* k12869 in k12848 in k12832 in k12812 in k12739 in k12667 in k12646 in foreign-type->scrutiny-type in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_12871(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[475]);}
else{
t2=C_eqp(((C_word*)t0)[3],lf[388]);
if(C_truep(t2)){
t3=C_i_cadr(((C_word*)t0)[4]);
/* support.scm:1302: foreign-type->scrutiny-type */
t4=*((C_word*)lf[456]+1);
f_12643(4,t4,((C_word*)t0)[2],t3,((C_word*)t0)[5]);}
else{
t3=C_eqp(((C_word*)t0)[3],lf[389]);
if(C_truep(t3)){
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[420]);}
else{
t4=C_eqp(((C_word*)t0)[3],lf[390]);
if(C_truep(t4)){
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?lf[391]:lf[236]));}
else{
t5=C_eqp(((C_word*)t0)[3],lf[375]);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?lf[391]:lf[236]));}}}}}

/* loop in k10037 in k10026 in k10105 in matchn in match-node in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_10044(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10044,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_i_nullp(t2));}
else{
if(C_truep(C_i_not_pair_p(t3))){
/* support.scm:854: resolve */
t4=((C_word*)((C_word*)t0)[2])[1];
f_9937(t4,t1,t3,t2);}
else{
if(C_truep(C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10075,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=C_i_car(t2);
t6=C_i_car(t3);
/* support.scm:856: matchn */
t7=((C_word*)((C_word*)t0)[4])[1];
f_10006(t7,t4,t5,t6);}}}}

/* f_14451 in k14449 in k14444 in k14439 in load-identifier-database in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14451(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_14451,3,t0,t1,t2);}
t3=C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14460,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14463,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1606: ##sys#get */
t6=*((C_word*)lf[250]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,lf[542]);}

/* k14449 in k14444 in k14439 in load-identifier-database in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14450,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14451,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14473,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1607: read-file */
t4=*((C_word*)lf[543]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}

/* ##compiler#call-info in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13835(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_13835,4,t0,t1,t2,t3);}
t4=C_i_cdr(t2);
t5=C_i_pairp(t4);
t6=(C_truep(t5)?C_i_cadr(t2):C_SCHEME_FALSE);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13842,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t6)){
if(C_truep(C_i_listp(t6))){
t8=C_i_car(t6);
t9=C_i_cadr(t6);
/* support.scm:1466: conc */
t10=*((C_word*)lf[502]+1);
((C_proc6)(void*)(*((C_word*)t10+1)))(6,t10,t7,lf[509],t8,lf[510],t3);}
else{
t8=t3;
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}}
else{
t8=t3;
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}}

/* k4880 in k4878 in k4876 in k4873 in with-debugging-output in k4697 in k4664 in k4662 */
static void C_ccall f_4881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4881,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4887,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:98: test-mode */
f_4853(t2,((C_word*)t0)[6],*((C_word*)lf[9]+1));}

/* k4885 in k4880 in k4878 in k4876 in k4873 in with-debugging-output in k4697 in k4664 in k4662 */
static void C_ccall f_4887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm:99: collect */
t2=((C_word*)((C_word*)t0)[2])[1];
f_4806(t2,((C_word*)t0)[3],((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k14444 in k14439 in load-identifier-database in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14445,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14450,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14499,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1600: open-output-string */
t4=*((C_word*)lf[51]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k8982 in k8916 in k8914 */
static void C_ccall f_8983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8983,2,t0,t1);}
t2=C_a_i_list1(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8958,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_nullp(((C_word*)t0)[5]))){
/* support.scm:698: qnode */
t4=*((C_word*)lf[219]+1);
f_7062(3,t4,t3,C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8965,tmp=(C_word)a,a+=2,tmp);
t5=C_i_length(((C_word*)t0)[5]);
t6=C_a_i_times(&a,2,C_fix(3),t5);
t7=C_a_i_list2(&a,2,lf[280],t6);
/* support.scm:699: g1852 */
t8=t4;
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t3,lf[246],t7,((C_word*)t0)[5]);}}

/* k14439 in load-identifier-database in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14440,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_14445,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_14514,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm:1599: make-pathname */
t4=*((C_word*)lf[547]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t1,((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* loop in k7513 in k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_7414(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7414,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep(C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7422,tmp=(C_word)a,a+=2,tmp);
t6=C_i_cadr(((C_word*)t0)[2]);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7451,a[2]=t6,a[3]=t5,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* support.scm:567: reverse */
t8=*((C_word*)lf[89]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t3);}
else{
t5=C_i_caar(t2);
t6=C_eqp(lf[234],t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7458,tmp=(C_word)a,a+=2,tmp);
t8=C_i_cadr(((C_word*)t0)[2]);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7485,a[2]=t8,a[3]=t7,a[4]=t1,a[5]=t4,a[6]=((C_word*)t0)[3],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t10=C_a_i_cons(&a,2,lf[236],t3);
/* support.scm:573: reverse */
t11=*((C_word*)lf[89]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t9,t10);}
else{
t7=t2;
t8=C_u_i_cdr(t7);
t9=C_i_caar(t2);
t10=C_a_i_cons(&a,2,t9,t3);
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7502,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t8,a[6]=t10,tmp=(C_word)a,a+=7,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7505,a[2]=((C_word*)t0)[3],a[3]=t11,tmp=(C_word)a,a+=4,tmp);
/* support.scm:577: cadar */
t13=*((C_word*)lf[235]+1);
((C_proc3)(void*)(*((C_word*)t13+1)))(3,t13,t12,t2);}}}

/* k4876 in k4873 in with-debugging-output in k4697 in k4664 in k4662 */
static void C_ccall f_4877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4877,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4879,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* support.scm:96: display */
t3=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k4873 in with-debugging-output in k4697 in k4664 in k4662 */
static void C_ccall f_4875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4875,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4877,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* support.scm:95: with-output-to-string */
t3=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4896,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* support.scm:100: test-mode */
f_4853(t2,((C_word*)t0)[5],*((C_word*)lf[9]+1));}}

/* ##compiler#load-identifier-database in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14436(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_14436,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14440,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1598: repository-path */
t4=*((C_word*)lf[548]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k4878 in k4876 in k4873 in with-debugging-output in k4697 in k4664 in k4662 */
static void C_ccall f_4879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4879,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4881,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* support.scm:97: flush-output */
t3=*((C_word*)lf[20]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k12812 in k12739 in k12667 in k12646 in foreign-type->scrutiny-type in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_12814(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12814,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[420]);}
else{
t2=C_eqp(((C_word*)t0)[3],lf[373]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[471]);}
else{
t3=C_eqp(((C_word*)t0)[3],lf[375]);
if(C_truep(t3)){
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[391]);}
else{
t4=C_eqp(((C_word*)t0)[3],lf[376]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12834,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t4)){
t6=t5;
f_12834(t6,t4);}
else{
t6=C_eqp(((C_word*)t0)[3],lf[396]);
if(C_truep(t6)){
t7=t5;
f_12834(t7,t6);}
else{
t7=C_eqp(((C_word*)t0)[3],lf[397]);
t8=t5;
f_12834(t8,(C_truep(t7)?t7:C_eqp(((C_word*)t0)[3],lf[398])));}}}}}}

/* f_13897 in k13978 in k13886 in constant-form-eval in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13897(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_13897,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13902,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13915,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* support.scm:1472: with-exception-handler */
t5=*((C_word*)lf[118]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* k13891 in k13978 in k13886 in constant-form-eval in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1472: g3675 */
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* f_7527 in k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_7527(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7527,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_record4(&a,4,lf[208],t2,t3,t4));}

/* ##sys#toplevel-definition-hook in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_10461(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_10461,6,t0,t1,t2,t3,t4,t5);}
t6=(C_truep(t5)?C_SCHEME_FALSE:C_i_not(t4));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10470,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:936: debugging */
t8=*((C_word*)lf[11]+1);
f_4702(5,t8,t7,lf[256],lf[326],t2);}
else{
t7=C_SCHEME_UNDEFINED;
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}}

/* f_10033 in k10026 in k10105 in matchn in match-node in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_10033(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10033,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_slot(t2,C_fix(3)));}

/* k10037 in k10026 in k10105 in matchn in match-node in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_10039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10039,2,t0,t1);}
t2=C_i_cddr(((C_word*)t0)[2]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10044,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_10044(t6,((C_word*)t0)[5],t1,t2);}

/* k13886 in constant-form-eval in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13888,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13972,tmp=(C_word)a,a+=2,tmp);
t7=C_i_check_list_2(t1,lf[160]);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13980,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13982,a[2]=t5,a[3]=t10,a[4]=t3,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_13982(t12,t8,t1);}

/* k13881 */
static void C_ccall f_13883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_i_car(t1));}

/* k7537 in k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_7538(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7538,NULL,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t0)[2];
t7=C_u_i_cdr(t6);
t8=C_u_i_cdr(t7);
t9=C_i_check_list_2(t8,lf[160]);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7546,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7548,a[2]=t5,a[3]=t12,a[4]=t3,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t14=((C_word*)t12)[1];
f_7548(t14,t10,t8);}

/* k4894 in k4873 in with-debugging-output in k4697 in k4664 in k4662 */
static void C_ccall f_4896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4896,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4902,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:101: with-output-to-string */
t3=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k14498 in k14444 in k14439 in load-identifier-database in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14499,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14501,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* support.scm:1600: display */
t4=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[546],t2);}

/* k10469 in toplevel-definition-hook in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_10470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:937: hide-variable */
t2=*((C_word*)lf[325]+1);
f_14325(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* map-loop1866 in copy-node-tree-and-rename in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_9408(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9408,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_a_i_cons(&a,2,t6,t7);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9419,a[2]=((C_word*)t0)[2],a[3]=t9,a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t11=t10;
f_9419(t11,C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t9));}
else{
t11=C_mutate(((C_word *)((C_word*)t0)[4])+1,t9);
t12=t10;
f_9419(t12,t11);}}
else{
t6=((C_word*)((C_word*)t0)[4])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* matchn in match-node in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_10006(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10006,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_not_pair_p(t3))){
/* support.scm:848: resolve */
t4=((C_word*)((C_word*)t0)[2])[1];
f_9937(t4,t1,t3,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10101,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10107,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t2,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* support.scm:849: g2315 */
t6=t4;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}}

/* f_13872 in constant-form-eval in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13872(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_13872,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13877,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13883,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm:1473: g3630 */
t5=t3;
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* f_13877 */
static void C_ccall f_13877(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_13877,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_slot(t2,C_fix(2)));}

/* k14486 in for-each-loop3917 in k14472 in k14449 in k14444 in k14439 in load-identifier-database in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_14478(t3,((C_word*)t0)[4],t2);}

/* k10484 in compute-database-statistics in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_10485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:973: values */
C_values(9,0,((C_word*)t0)[2],*((C_word*)lf[328]+1),*((C_word*)lf[329]+1),((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[7])[1]);}

/* ##compiler#compute-database-statistics in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_10481(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10481,3,t0,t1,t2);}
t3=C_fix(0);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_fix(0);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_fix(0);
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_fix(0);
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_fix(0);
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_10485,a[2]=t1,a[3]=t6,a[4]=t4,a[5]=t8,a[6]=t12,a[7]=t10,tmp=(C_word)a,a+=8,tmp);
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10490,a[2]=t10,a[3]=t8,a[4]=t6,a[5]=t4,a[6]=t12,tmp=(C_word)a,a+=7,tmp);
/* support.scm:959: ##sys#hash-table-for-each */
t15=*((C_word*)lf[161]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t13,t14,t2);}

/* for-each-loop3917 in k14472 in k14449 in k14444 in k14439 in load-identifier-database in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_14478(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14478,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14487,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:1601: g3918 */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* map-loop1814 */
static void C_fcall f_8993(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8993,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9018,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:688: g1820 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* f_10490 in compute-database-statistics in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_10490(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10490,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10492,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t5=C_i_check_list_2(t3,lf[33]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10567,a[2]=t7,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_10567(t9,t1,t3);}

/* f_10492 */
static void C_ccall f_10492(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10492,3,t0,t1,t2);}
t3=C_a_i_plus(&a,2,((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=C_i_car(t2);
t6=C_eqp(t5,lf[187]);
if(C_truep(t6)){
t7=C_a_i_plus(&a,2,((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t8=C_mutate(((C_word *)((C_word*)t0)[3])+1,t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t7=C_eqp(t5,lf[171]);
if(C_truep(t7)){
t8=C_a_i_plus(&a,2,((C_word*)((C_word*)t0)[4])[1],C_fix(1));
t9=C_mutate(((C_word *)((C_word*)t0)[4])+1,t8);
t10=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10531,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10537,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t12=t2;
t13=C_u_i_cdr(t12);
/* support.scm:968: g2472 */
t14=t10;
((C_proc3)(void*)(*((C_word*)t14+1)))(3,t14,t11,t13);}
else{
t8=C_eqp(t5,lf[176]);
if(C_truep(t8)){
t9=t2;
t10=C_u_i_cdr(t9);
t11=C_i_length(t10);
t12=C_a_i_plus(&a,2,((C_word*)((C_word*)t0)[6])[1],t11);
t13=C_mutate(((C_word *)((C_word*)t0)[6])+1,t12);
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,t13);}
else{
t9=C_SCHEME_UNDEFINED;
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}}}}

/* k12848 in k12832 in k12812 in k12739 in k12667 in k12646 in foreign-type->scrutiny-type in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_12850(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12850,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[474]);}
else{
t2=C_eqp(((C_word*)t0)[3],lf[380]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[380]);}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[4]))){
t3=((C_word*)t0)[4];
t4=C_u_i_car(t3);
t5=C_eqp(t4,lf[382]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12871,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=t6;
f_12871(t7,t5);}
else{
t7=C_eqp(t4,lf[391]);
if(C_truep(t7)){
t8=t6;
f_12871(t8,t7);}
else{
t8=C_eqp(t4,lf[392]);
t9=t6;
f_12871(t9,(C_truep(t8)?t8:C_eqp(t4,lf[373])));}}}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[236]);}}}}

/* k10026 in k10105 in matchn in match-node in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_10028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10028,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10033,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10039,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* support.scm:851: g2330 */
t4=t2;
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[6]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k14472 in k14449 in k14444 in k14439 in load-identifier-database in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14473,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14478,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_14478(t5,((C_word*)t0)[3],t1);}

/* f_8922 in k8916 in k8914 */
static void C_ccall f_8922(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8922,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8924,tmp=(C_word)a,a+=2,tmp);
t6=C_a_i_list1(&a,1,t2);
t7=C_a_i_list2(&a,2,t3,t4);
/* support.scm:693: g1842 */
t8=t5;
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t1,lf[105],t6,t7);}

/* f_8924 */
static void C_ccall f_8924(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8924,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_record4(&a,4,lf[208],t2,t3,t4));}

/* k9418 in map-loop1866 in copy-node-tree-and-rename in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_9419(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[3]);
t3=C_slot(((C_word*)t0)[4],C_fix(1));
t4=C_slot(((C_word*)t0)[5],C_fix(1));
t5=((C_word*)((C_word*)t0)[6])[1];
f_9408(t5,((C_word*)t0)[7],t3,t4);}

/* walk in sexpr->node in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_9592(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9592,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9595,tmp=(C_word)a,a+=2,tmp);
t4=C_i_car(t2);
t5=C_i_cadr(t2);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=t2;
t11=C_u_i_cdr(t10);
t12=C_u_i_cdr(t11);
t13=C_i_check_list_2(t12,lf[160]);
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9615,a[2]=t3,a[3]=t1,a[4]=t4,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t15=C_SCHEME_UNDEFINED;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_set_block_item(t16,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9617,a[2]=t9,a[3]=t16,a[4]=t7,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp));
t18=((C_word*)t16)[1];
f_9617(t18,t14,t12);}

/* f_9595 in walk in sexpr->node in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_9595(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9595,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_record4(&a,4,lf[208],t2,t3,t4));}

/* k9580 in map-loop2121 in k9547 in k9539 in k9528 in walk in node->sexpr in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_9581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9581,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_9556(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_9556(t6,((C_word*)t0)[5],t5);}}

/* ##compiler#sexpr->node in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_9586(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9586,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9592,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_9592(t6,t1,t2);}

/* k6605 in k6597 in k6584 in k6581 in k6551 in k6521 in k6488 in k6486 */
static void C_ccall f_6607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6607,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
/* support.scm:496: write */
t3=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[4]);}

/* f_6601 in k6597 in k6584 in k6581 in k6551 in k6521 in k6488 in k6486 */
static void C_ccall f_6601(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6601,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_slot(t2,C_fix(2)));}

/* f_8907 */
static void C_ccall f_8907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8907,2,t0,t1);}
/* support.scm:687: split-at */
t2=*((C_word*)lf[277]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* f_8902 in inline-lambda-bindings in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_8902(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8902,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8907,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8912,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* support.scm:686: ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* ##compiler#valid-c-identifier? in k4697 in k4664 in k4662 */
static void C_ccall f_5361(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5361,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5365,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5407,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm:201: ->string */
t5=*((C_word*)lf[58]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k5364 in valid-c-identifier? in k4697 in k4664 in k4662 */
static void C_ccall f_5365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5365,2,t0,t1);}
if(C_truep(C_i_pairp(t1))){
t2=t1;
t3=C_u_i_car(t2);
t4=C_u_i_char_alphabeticp(t3);
t5=(C_truep(t4)?t4:C_i_char_equalp(C_make_character(95),t3));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5385,tmp=(C_word)a,a+=2,tmp);
t7=t1;
t8=C_u_i_cdr(t7);
/* support.scm:205: any */
t9=*((C_word*)lf[75]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,((C_word*)t0)[2],t6,t8);}
else{
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* loop in k6486 */
static void C_fcall f_6627(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6627,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_i_caar(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6639,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=C_eqp(t3,lf[169]);
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6649,a[2]=t2,a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[2],a[7]=t1,a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],tmp=(C_word)a,a+=12,tmp);
if(C_truep(t5)){
t7=t6;
f_6649(t7,t5);}
else{
t7=C_eqp(t3,lf[185]);
if(C_truep(t7)){
t8=t6;
f_6649(t8,t7);}
else{
t8=C_eqp(t3,lf[186]);
if(C_truep(t8)){
t9=t6;
f_6649(t9,t8);}
else{
t9=C_eqp(t3,lf[187]);
if(C_truep(t9)){
t10=t6;
f_6649(t10,t9);}
else{
t10=C_eqp(t3,lf[188]);
if(C_truep(t10)){
t11=t6;
f_6649(t11,t10);}
else{
t11=C_eqp(t3,lf[189]);
if(C_truep(t11)){
t12=t6;
f_6649(t12,t11);}
else{
t12=C_eqp(t3,lf[190]);
if(C_truep(t12)){
t13=t6;
f_6649(t13,t12);}
else{
t13=C_eqp(t3,lf[191]);
if(C_truep(t13)){
t14=t6;
f_6649(t14,t13);}
else{
t14=C_eqp(t3,lf[192]);
if(C_truep(t14)){
t15=t6;
f_6649(t15,t14);}
else{
t15=C_eqp(t3,lf[193]);
if(C_truep(t15)){
t16=t6;
f_6649(t16,t15);}
else{
t16=C_eqp(t3,lf[194]);
if(C_truep(t16)){
t17=t6;
f_6649(t17,t16);}
else{
t17=C_eqp(t3,lf[195]);
if(C_truep(t17)){
t18=t6;
f_6649(t18,t17);}
else{
t18=C_eqp(t3,lf[196]);
if(C_truep(t18)){
t19=t6;
f_6649(t19,t18);}
else{
t19=C_eqp(t3,lf[197]);
if(C_truep(t19)){
t20=t6;
f_6649(t20,t19);}
else{
t20=C_eqp(t3,lf[198]);
if(C_truep(t20)){
t21=t6;
f_6649(t21,t20);}
else{
t21=C_eqp(t3,lf[199]);
if(C_truep(t21)){
t22=t6;
f_6649(t22,t21);}
else{
t22=C_eqp(t3,lf[200]);
if(C_truep(t22)){
t23=t6;
f_6649(t23,t22);}
else{
t23=C_eqp(t3,lf[201]);
if(C_truep(t23)){
t24=t6;
f_6649(t24,t23);}
else{
t24=C_eqp(t3,lf[202]);
if(C_truep(t24)){
t25=t6;
f_6649(t25,t24);}
else{
t25=C_eqp(t3,lf[203]);
t26=t6;
f_6649(t26,(C_truep(t25)?t25:C_eqp(t3,lf[204])));}}}}}}}}}}}}}}}}}}}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* f_5992 in initialize-analysis-database in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_5992(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5992,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5994,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6010,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm:354: g537 */
t5=t3;
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,t2,lf[137],lf[138]);}

/* k5989 in initialize-analysis-database in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_5990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_FALSE);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* f_8965 in k8982 in k8916 in k8914 */
static void C_ccall f_8965(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8965,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_record4(&a,4,lf[208],t2,t3,t4));}

/* f_5994 */
static void C_ccall f_5994(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr4r,(void*)f_5994r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5994r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5994r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
if(C_truep(C_i_nullp(t4))){
/* tweaks.scm:54: ##sys#put! */
t5=*((C_word*)lf[134]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,t3,C_SCHEME_TRUE);}
else{
t5=C_i_car(t4);
/* tweaks.scm:54: ##sys#put! */
t6=*((C_word*)lf[134]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,t2,t3,t5);}}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_support_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_support_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("support_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(6134)){
C_save(t1);
C_rereclaim2(6134*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,560);
lf[0]=C_h_intern(&lf[0],30,"\010compilercompiler-cleanup-hook");
lf[1]=C_h_intern(&lf[1],26,"\010compilerdebugging-chicken");
lf[2]=C_h_intern(&lf[2],26,"\010compilerdisabled-warnings");
lf[3]=C_h_intern(&lf[3],13,"\010compilerbomb");
lf[4]=C_h_intern(&lf[4],5,"error");
lf[5]=C_h_intern(&lf[5],13,"string-append");
lf[6]=C_decode_literal(C_heaptop,"\376B\000\000\032[internal compiler error] ");
lf[7]=C_decode_literal(C_heaptop,"\376B\000\000\031[internal compiler error]");
lf[8]=C_h_intern(&lf[8],35,"\010compilercollected-debugging-output");
lf[9]=C_h_intern(&lf[9],24,"+logged-debugging-modes+");
lf[10]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001o\376\003\000\000\002\376\001\000\000\001x\376\003\000\000\002\376\001\000\000\001S\376\377\016");
lf[11]=C_h_intern(&lf[11],18,"\010compilerdebugging");
lf[12]=C_h_intern(&lf[12],7,"newline");
lf[13]=C_h_intern(&lf[13],19,"\003sysstandard-output");
lf[14]=C_h_intern(&lf[14],19,"\003syswrite-char/port");
lf[15]=C_h_intern(&lf[15],5,"write");
lf[16]=C_h_intern(&lf[16],5,"force");
lf[17]=C_h_intern(&lf[17],7,"display");
lf[18]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[19]=C_h_intern(&lf[19],21,"with-output-to-string");
lf[20]=C_h_intern(&lf[20],12,"flush-output");
lf[21]=C_h_intern(&lf[21],30,"\010compilerwith-debugging-output");
lf[22]=C_h_intern(&lf[22],12,"string-split");
lf[23]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[24]=C_h_intern(&lf[24],17,"lset-intersection");
lf[25]=C_h_intern(&lf[25],3,"eq\077");
lf[26]=C_h_intern(&lf[26],13,"\010compilerquit");
lf[27]=C_h_intern(&lf[27],18,"\003sysstandard-error");
lf[28]=C_h_intern(&lf[28],4,"exit");
lf[29]=C_h_intern(&lf[29],7,"fprintf");
lf[30]=C_decode_literal(C_heaptop,"\376B\000\000\010\012Error: ");
lf[31]=C_h_intern(&lf[31],21,"\003syssyntax-error-hook");
lf[32]=C_decode_literal(C_heaptop,"\376B\000\000\005\011~s~%");
lf[33]=C_h_intern(&lf[33],8,"for-each");
lf[34]=C_h_intern(&lf[34],16,"print-call-chain");
lf[35]=C_h_intern(&lf[35],18,"\003syscurrent-thread");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\025\012\011Expansion history:\012");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\003): ");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\017\012Syntax error (");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\017\012Syntax error: ");
lf[40]=C_h_intern(&lf[40],12,"syntax-error");
lf[41]=C_h_intern(&lf[41],31,"\010compileremit-syntax-trace-info");
lf[42]=C_h_intern(&lf[42],9,"map-llist");
lf[43]=C_h_intern(&lf[43],24,"\010compilercheck-signature");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000@Arguments to inlined call of `~A\047 do not match parameter-list ~A");
lf[45]=C_h_intern(&lf[45],18,"\010compilerreal-name");
lf[46]=C_h_intern(&lf[46],13,"\010compilerposq");
lf[47]=C_h_intern(&lf[47],13,"\010compilerposv");
lf[48]=C_h_intern(&lf[48],18,"\010compilerstringify");
lf[49]=C_h_intern(&lf[49],14,"symbol->string");
lf[50]=C_h_intern(&lf[50],17,"get-output-string");
lf[51]=C_h_intern(&lf[51],18,"open-output-string");
lf[52]=C_h_intern(&lf[52],18,"\010compilersymbolify");
lf[53]=C_h_intern(&lf[53],14,"string->symbol");
lf[54]=C_h_intern(&lf[54],17,"\010compilerslashify");
lf[55]=C_h_intern(&lf[55],16,"string-translate");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[58]=C_h_intern(&lf[58],8,"->string");
lf[59]=C_h_intern(&lf[59],21,"\010compileruncommentify");
lf[60]=C_h_intern(&lf[60],17,"string-translate\052");
lf[61]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376B\000\000\002\052/\376B\000\000\003\052_/\376\377\016");
lf[62]=C_h_intern(&lf[62],26,"\010compilerbuild-lambda-list");
lf[63]=C_h_intern(&lf[63],29,"\010compilerstring->c-identifier");
lf[64]=C_h_intern(&lf[64],24,"\003sysstring->c-identifier");
lf[65]=C_h_intern(&lf[65],21,"\010compilerc-ify-string");
lf[66]=C_h_intern(&lf[66],16,"\003syslist->string");
lf[67]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\042\376\377\016");
lf[68]=C_h_intern(&lf[68],6,"append");
lf[69]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\377\016");
lf[70]=C_h_intern(&lf[70],16,"\003sysstring->list");
lf[71]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\0000\376\003\000\000\002\376\377\012\000\0000\376\377\016");
lf[72]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\0000\376\377\016");
lf[73]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\042\376\003\000\000\002\376\377\012\000\000\047\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000\077\376\003\000\000\002\376\377\012\000\000\052\376\377\016");
lf[74]=C_h_intern(&lf[74],28,"\010compilervalid-c-identifier\077");
lf[75]=C_h_intern(&lf[75],3,"any");
lf[76]=C_h_intern(&lf[76],14,"\010compilerwords");
lf[77]=C_h_intern(&lf[77],21,"\010compilerwords->bytes");
lf[78]=C_h_intern(&lf[78],34,"\010compilercheck-and-open-input-file");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[80]=C_h_intern(&lf[80],18,"\003sysstandard-input");
lf[81]=C_h_intern(&lf[81],15,"open-input-file");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000\024Can not open file ~s");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000\031(~a) can not open file ~s");
lf[84]=C_h_intern(&lf[84],12,"file-exists\077");
lf[85]=C_h_intern(&lf[85],33,"\010compilerclose-checked-input-file");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[87]=C_h_intern(&lf[87],16,"close-input-port");
lf[88]=C_h_intern(&lf[88],19,"\010compilerfold-inner");
lf[89]=C_h_intern(&lf[89],7,"reverse");
lf[90]=C_h_intern(&lf[90],28,"\010compilerfollow-without-loop");
lf[91]=C_h_intern(&lf[91],21,"\010compilersort-symbols");
lf[92]=C_h_intern(&lf[92],8,"string<\077");
lf[93]=C_h_intern(&lf[93],4,"sort");
lf[94]=C_h_intern(&lf[94],18,"\010compilerconstant\077");
lf[95]=C_h_intern(&lf[95],5,"quote");
lf[96]=C_h_intern(&lf[96],29,"\010compilercollapsable-literal\077");
lf[97]=C_h_intern(&lf[97],19,"\010compilerimmediate\077");
lf[98]=C_h_intern(&lf[98],20,"\010compilerbig-fixnum\077");
lf[99]=C_h_intern(&lf[99],23,"\010compilerbasic-literal\077");
lf[100]=C_h_intern(&lf[100],5,"every");
lf[101]=C_h_intern(&lf[101],12,"vector->list");
lf[102]=C_h_intern(&lf[102],32,"\010compilercanonicalize-begin-body");
lf[103]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[104]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[105]=C_h_intern(&lf[105],3,"let");
lf[106]=C_h_intern(&lf[106],6,"gensym");
lf[107]=C_h_intern(&lf[107],1,"t");
lf[108]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\377\016");
lf[109]=C_h_intern(&lf[109],21,"\010compilerstring->expr");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000\042cannot parse expression: ~s [~a]~%");
lf[111]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[112]=C_h_intern(&lf[112],5,"begin");
lf[113]=C_h_intern(&lf[113],4,"read");
lf[114]=C_h_intern(&lf[114],6,"unfold");
lf[115]=C_h_intern(&lf[115],11,"eof-object\077");
lf[116]=C_h_intern(&lf[116],6,"values");
lf[117]=C_h_intern(&lf[117],22,"with-input-from-string");
lf[118]=C_h_intern(&lf[118],22,"with-exception-handler");
lf[119]=C_h_intern(&lf[119],30,"call-with-current-continuation");
lf[120]=C_h_intern(&lf[120],30,"\010compilerdecompose-lambda-list");
lf[121]=C_h_intern(&lf[121],25,"\003sysdecompose-lambda-list");
lf[122]=C_h_intern(&lf[122],21,"\010compilerllist-length");
lf[123]=C_h_intern(&lf[123],21,"\010compilerllist-match\077");
lf[124]=C_h_intern(&lf[124],30,"\010compilerexpand-profile-lambda");
lf[125]=C_h_intern(&lf[125],29,"\010compilerprofile-lambda-index");
lf[126]=C_h_intern(&lf[126],28,"\010compilerprofile-lambda-list");
lf[127]=C_h_intern(&lf[127],17,"\003sysprofile-entry");
lf[128]=C_h_intern(&lf[128],33,"\010compilerprofile-info-vector-name");
lf[129]=C_h_intern(&lf[129],11,"\004corelambda");
lf[130]=C_h_intern(&lf[130],9,"\003sysapply");
lf[131]=C_h_intern(&lf[131],16,"\003sysprofile-exit");
lf[132]=C_h_intern(&lf[132],16,"\003sysdynamic-wind");
lf[133]=C_h_intern(&lf[133],37,"\010compilerinitialize-analysis-database");
lf[134]=C_h_intern(&lf[134],8,"\003sysput!");
lf[135]=C_h_intern(&lf[135],26,"\010compilerfoldable-bindings");
lf[136]=C_h_intern(&lf[136],17,"\010compilerfoldable");
lf[137]=C_h_intern(&lf[137],18,"\010compilerintrinsic");
lf[138]=C_h_intern(&lf[138],8,"standard");
lf[139]=C_h_intern(&lf[139],17,"standard-bindings");
lf[140]=C_h_intern(&lf[140],8,"extended");
lf[141]=C_h_intern(&lf[141],17,"extended-bindings");
lf[142]=C_h_intern(&lf[142],8,"internal");
lf[143]=C_h_intern(&lf[143],26,"\010compilerinternal-bindings");
lf[144]=C_h_intern(&lf[144],12,"\010compilerget");
lf[145]=C_h_intern(&lf[145],18,"\003syshash-table-ref");
lf[146]=C_h_intern(&lf[146],16,"\010compilerget-all");
lf[147]=C_h_intern(&lf[147],10,"filter-map");
lf[148]=C_h_intern(&lf[148],13,"\010compilerput!");
lf[149]=C_h_intern(&lf[149],19,"\003syshash-table-set!");
lf[150]=C_h_intern(&lf[150],17,"\010compilercollect!");
lf[151]=C_h_intern(&lf[151],15,"\010compilercount!");
lf[152]=C_h_intern(&lf[152],17,"\010compilerget-list");
lf[153]=C_h_intern(&lf[153],17,"\010compilerget-line");
lf[154]=C_h_intern(&lf[154],24,"\003sysline-number-database");
lf[155]=C_h_intern(&lf[155],19,"\010compilerget-line-2");
lf[156]=C_h_intern(&lf[156],30,"\010compilerfind-lambda-container");
lf[157]=C_h_intern(&lf[157],12,"contained-in");
lf[158]=C_h_intern(&lf[158],37,"\010compilerdisplay-line-number-database");
lf[159]=C_h_intern(&lf[159],3,"cdr");
lf[160]=C_h_intern(&lf[160],3,"map");
lf[161]=C_h_intern(&lf[161],23,"\003syshash-table-for-each");
lf[162]=C_h_intern(&lf[162],34,"\010compilerdisplay-analysis-database");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000\005\011css=");
lf[164]=C_decode_literal(C_heaptop,"\376B\000\000\006\011refs=");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000\005\011val=");
lf[166]=C_decode_literal(C_heaptop,"\376B\000\000\006\011lval=");
lf[167]=C_decode_literal(C_heaptop,"\376B\000\000\006\011pval=");
lf[168]=C_h_intern(&lf[168],7,"unknown");
lf[169]=C_h_intern(&lf[169],8,"captured");
lf[170]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010captured\376\001\000\000\003cpt\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010assigned\376\001\000\000\003set\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005box"
"ed\376\001\000\000\003box\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006global\376\001\000\000\003glo\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020assigned-locally\376\001\000\000\003stl\376\003"
"\000\000\002\376\003\000\000\002\376\001\000\000\014contractable\376\001\000\000\003con\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020standard-binding\376\001\000\000\003stb\376\003\000\000\002\376\003\000"
"\000\002\376\001\000\000\006simple\376\001\000\000\003sim\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011inlinable\376\001\000\000\003inl\376\003\000\000\002\376\003\000\000\002\376\001\000\000\013collapsable\376"
"\001\000\000\003col\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011removable\376\001\000\000\003rem\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010constant\376\001\000\000\003con\376\003\000\000\002\376\003\000\000\002"
"\376\001\000\000\015inline-target\376\001\000\000\003ilt\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020inline-transient\376\001\000\000\003itr\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011"
"undefined\376\001\000\000\003und\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011replacing\376\001\000\000\003rpg\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006unused\376\001\000\000\003uud\376\003"
"\000\000\002\376\003\000\000\002\376\001\000\000\020extended-binding\376\001\000\000\003xtb\376\003\000\000\002\376\003\000\000\002\376\001\000\000\015inline-export\376\001\000\000\003ilx\376\003\000\000\002\376\003"
"\000\000\002\376\001\000\000\013hidden-refs\376\001\000\000\003hrf\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011value-ref\376\001\000\000\003vvf\376\003\000\000\002\376\003\000\000\002\376\001\000\000\014custom"
"izable\376\001\000\000\003cst\376\003\000\000\002\376\003\000\000\002\376\001\000\000\025has-unused-parameters\376\001\000\000\003hup\376\003\000\000\002\376\003\000\000\002\376\001\000\000\012boxed-r"
"est\376\001\000\000\003bxr\376\377\016");
lf[171]=C_h_intern(&lf[171],5,"value");
lf[172]=C_h_intern(&lf[172],11,"local-value");
lf[173]=C_h_intern(&lf[173],15,"potential-value");
lf[174]=C_h_intern(&lf[174],10,"replacable");
lf[175]=C_h_intern(&lf[175],10,"references");
lf[176]=C_h_intern(&lf[176],10,"call-sites");
lf[177]=C_decode_literal(C_heaptop,"\376B\000\000\020Illegal property");
lf[178]=C_h_intern(&lf[178],4,"home");
lf[179]=C_h_intern(&lf[179],8,"contains");
lf[180]=C_h_intern(&lf[180],8,"use-expr");
lf[181]=C_h_intern(&lf[181],12,"closure-size");
lf[182]=C_h_intern(&lf[182],14,"rest-parameter");
lf[183]=C_h_intern(&lf[183],18,"captured-variables");
lf[184]=C_h_intern(&lf[184],13,"explicit-rest");
lf[185]=C_h_intern(&lf[185],8,"assigned");
lf[186]=C_h_intern(&lf[186],5,"boxed");
lf[187]=C_h_intern(&lf[187],6,"global");
lf[188]=C_h_intern(&lf[188],12,"contractable");
lf[189]=C_h_intern(&lf[189],16,"standard-binding");
lf[190]=C_h_intern(&lf[190],16,"assigned-locally");
lf[191]=C_h_intern(&lf[191],11,"collapsable");
lf[192]=C_h_intern(&lf[192],9,"removable");
lf[193]=C_h_intern(&lf[193],9,"undefined");
lf[194]=C_h_intern(&lf[194],9,"replacing");
lf[195]=C_h_intern(&lf[195],6,"unused");
lf[196]=C_h_intern(&lf[196],6,"simple");
lf[197]=C_h_intern(&lf[197],9,"inlinable");
lf[198]=C_h_intern(&lf[198],13,"inline-export");
lf[199]=C_h_intern(&lf[199],21,"has-unused-parameters");
lf[200]=C_h_intern(&lf[200],16,"extended-binding");
lf[201]=C_h_intern(&lf[201],12,"customizable");
lf[202]=C_h_intern(&lf[202],8,"constant");
lf[203]=C_h_intern(&lf[203],10,"boxed-rest");
lf[204]=C_h_intern(&lf[204],11,"hidden-refs");
lf[205]=C_h_intern(&lf[205],34,"\010compilerdefault-standard-bindings");
lf[206]=C_h_intern(&lf[206],34,"\010compilerdefault-extended-bindings");
lf[207]=C_h_intern(&lf[207],9,"make-node");
lf[208]=C_h_intern(&lf[208],4,"node");
lf[209]=C_h_intern(&lf[209],5,"node\077");
lf[210]=C_h_intern(&lf[210],10,"node-class");
lf[211]=C_h_intern(&lf[211],15,"node-class-set!");
lf[212]=C_h_intern(&lf[212],14,"\003sysblock-set!");
lf[213]=C_h_intern(&lf[213],15,"node-parameters");
lf[214]=C_h_intern(&lf[214],20,"node-parameters-set!");
lf[215]=C_h_intern(&lf[215],19,"node-subexpressions");
lf[216]=C_h_intern(&lf[216],24,"node-subexpressions-set!");
lf[217]=C_h_intern(&lf[217],16,"\010compilervarnode");
lf[218]=C_h_intern(&lf[218],13,"\004corevariable");
lf[219]=C_h_intern(&lf[219],14,"\010compilerqnode");
lf[220]=C_h_intern(&lf[220],25,"\010compilerbuild-node-graph");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\016bad expression");
lf[222]=C_h_intern(&lf[222],2,"if");
lf[223]=C_h_intern(&lf[223],14,"\004coreundefined");
lf[224]=C_h_intern(&lf[224],8,"truncate");
lf[225]=C_h_intern(&lf[225],7,"warning");
lf[226]=C_decode_literal(C_heaptop,"\376B\000\0006literal is out of range - will be truncated to integer");
lf[227]=C_h_intern(&lf[227],6,"fixnum");
lf[228]=C_h_intern(&lf[228],11,"number-type");
lf[229]=C_h_intern(&lf[229],4,"\000tmp");
lf[230]=C_h_intern(&lf[230],6,"unzip1");
lf[231]=C_h_intern(&lf[231],6,"lambda");
lf[232]=C_h_intern(&lf[232],8,"\004corethe");
lf[233]=C_h_intern(&lf[233],13,"\004coretypecase");
lf[234]=C_h_intern(&lf[234],4,"else");
lf[235]=C_h_intern(&lf[235],5,"cadar");
lf[236]=C_h_intern(&lf[236],1,"\052");
lf[237]=C_h_intern(&lf[237],14,"\004coreprimitive");
lf[238]=C_h_intern(&lf[238],11,"\004coreinline");
lf[239]=C_h_intern(&lf[239],13,"\004corecallunit");
lf[240]=C_h_intern(&lf[240],9,"\004coreproc");
lf[241]=C_h_intern(&lf[241],4,"set!");
lf[242]=C_h_intern(&lf[242],9,"\004coreset!");
lf[243]=C_h_intern(&lf[243],29,"\004coreforeign-callback-wrapper");
lf[244]=C_h_intern(&lf[244],5,"sixth");
lf[245]=C_h_intern(&lf[245],5,"fifth");
lf[246]=C_h_intern(&lf[246],20,"\004coreinline_allocate");
lf[247]=C_h_intern(&lf[247],8,"\004coreapp");
lf[248]=C_h_intern(&lf[248],9,"\004corecall");
lf[249]=C_h_intern(&lf[249],28,"\003syssymbol->qualified-string");
lf[250]=C_h_intern(&lf[250],7,"\003sysget");
lf[251]=C_h_intern(&lf[251],34,"\010compileralways-bound-to-procedure");
lf[252]=C_h_intern(&lf[252],15,"\004coreinline_ref");
lf[253]=C_h_intern(&lf[253],18,"\004coreinline_update");
lf[254]=C_h_intern(&lf[254],19,"\004coreinline_loc_ref");
lf[255]=C_h_intern(&lf[255],22,"\004coreinline_loc_update");
lf[256]=C_h_intern(&lf[256],1,"o");
lf[257]=C_decode_literal(C_heaptop,"\376B\000\000\033eliminated procedure checks");
lf[258]=C_h_intern(&lf[258],30,"\010compilerbuild-expression-tree");
lf[259]=C_h_intern(&lf[259],12,"\004coreclosure");
lf[260]=C_h_intern(&lf[260],4,"list");
lf[261]=C_h_intern(&lf[261],4,"last");
lf[262]=C_h_intern(&lf[262],7,"butlast");
lf[263]=C_h_intern(&lf[263],3,"the");
lf[264]=C_h_intern(&lf[264],17,"compiler-typecase");
lf[265]=C_h_intern(&lf[265],5,"cons\052");
lf[266]=C_h_intern(&lf[266],9,"\004corebind");
lf[267]=C_h_intern(&lf[267],10,"\004coreunbox");
lf[268]=C_h_intern(&lf[268],16,"\004corelet_unboxed");
lf[269]=C_h_intern(&lf[269],8,"\004coreref");
lf[270]=C_h_intern(&lf[270],11,"\004coreupdate");
lf[271]=C_h_intern(&lf[271],13,"\004coreupdate_i");
lf[272]=C_h_intern(&lf[272],8,"\004corebox");
lf[273]=C_h_intern(&lf[273],9,"\004corecond");
lf[274]=C_h_intern(&lf[274],21,"\010compilerfold-boolean");
lf[275]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\005C_and\376\377\016");
lf[276]=C_h_intern(&lf[276],31,"\010compilerinline-lambda-bindings");
lf[277]=C_h_intern(&lf[277],8,"split-at");
lf[278]=C_h_intern(&lf[278],10,"fold-right");
lf[279]=C_h_intern(&lf[279],4,"take");
lf[280]=C_decode_literal(C_heaptop,"\376B\000\000\012C_a_i_list");
lf[281]=C_h_intern(&lf[281],34,"\010compilercopy-node-tree-and-rename");
lf[282]=C_h_intern(&lf[282],4,"cons");
lf[283]=C_h_intern(&lf[283],9,"alist-ref");
lf[284]=C_h_intern(&lf[284],16,"inline-transient");
lf[285]=C_h_intern(&lf[285],1,"f");
lf[286]=C_h_intern(&lf[286],18,"\010compilertree-copy");
lf[287]=C_h_intern(&lf[287],19,"\010compilercopy-node!");
lf[288]=C_h_intern(&lf[288],20,"\010compilernode->sexpr");
lf[289]=C_h_intern(&lf[289],20,"\010compilersexpr->node");
lf[290]=C_h_intern(&lf[290],32,"\010compileremit-global-inline-file");
lf[291]=C_h_intern(&lf[291],5,"print");
lf[292]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[293]=C_h_intern(&lf[293],1,"i");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\0001the following procedures can be globally inlined:");
lf[295]=C_h_intern(&lf[295],12,"delete-file\052");
lf[296]=C_h_intern(&lf[296],2,"pp");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\015; END OF FILE");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000\027; GENERATED BY CHICKEN ");
lf[299]=C_decode_literal(C_heaptop,"\376B\000\000\006 FROM ");
lf[300]=C_h_intern(&lf[300],24,"\010compilersource-filename");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[302]=C_h_intern(&lf[302],15,"chicken-version");
lf[303]=C_h_intern(&lf[303],19,"with-output-to-file");
lf[304]=C_h_intern(&lf[304],3,"yes");
lf[305]=C_h_intern(&lf[305],2,"no");
lf[306]=C_h_intern(&lf[306],24,"\010compilerinline-max-size");
lf[307]=C_h_intern(&lf[307],15,"\010compilerinline");
lf[308]=C_h_intern(&lf[308],22,"\010compilerinline-global");
lf[309]=C_h_intern(&lf[309],26,"\010compilervariable-visible\077");
lf[310]=C_h_intern(&lf[310],25,"\010compilerload-inline-file");
lf[311]=C_h_intern(&lf[311],20,"with-input-from-file");
lf[312]=C_h_intern(&lf[312],19,"\010compilermatch-node");
lf[313]=C_h_intern(&lf[313],1,"a");
lf[314]=C_decode_literal(C_heaptop,"\376B\000\000\007matched");
lf[315]=C_h_intern(&lf[315],37,"\010compilerexpression-has-side-effects\077");
lf[316]=C_h_intern(&lf[316],24,"foreign-callback-stub-id");
lf[317]=C_h_intern(&lf[317],4,"find");
lf[318]=C_h_intern(&lf[318],22,"foreign-callback-stubs");
lf[319]=C_h_intern(&lf[319],28,"\010compilersimple-lambda-node\077");
lf[320]=C_h_intern(&lf[320],31,"\010compilerdump-undefined-globals");
lf[321]=C_h_intern(&lf[321],8,"keyword\077");
lf[322]=C_h_intern(&lf[322],29,"\010compilerdump-defined-globals");
lf[323]=C_h_intern(&lf[323],25,"\010compilerdump-global-refs");
lf[324]=C_h_intern(&lf[324],28,"\003systoplevel-definition-hook");
lf[325]=C_h_intern(&lf[325],22,"\010compilerhide-variable");
lf[326]=C_decode_literal(C_heaptop,"\376B\000\000\042hiding nonexported module bindings");
lf[327]=C_h_intern(&lf[327],36,"\010compilercompute-database-statistics");
lf[328]=C_h_intern(&lf[328],29,"\010compilercurrent-program-size");
lf[329]=C_h_intern(&lf[329],30,"\010compileroriginal-program-size");
lf[330]=C_h_intern(&lf[330],33,"\010compilerprint-program-statistics");
lf[331]=C_decode_literal(C_heaptop,"\376B\000\000\027;   database entries: \011");
lf[332]=C_decode_literal(C_heaptop,"\376B\000\000\027;   known call sites: \011");
lf[333]=C_decode_literal(C_heaptop,"\376B\000\000\027;   global variables: \011");
lf[334]=C_decode_literal(C_heaptop,"\376B\000\000\027;   known procedures: \011");
lf[335]=C_decode_literal(C_heaptop,"\376B\000\000\042;   variables with known values: \011");
lf[336]=C_decode_literal(C_heaptop,"\376B\000\000\032 \011original program size: \011");
lf[337]=C_decode_literal(C_heaptop,"\376B\000\000\023;   program size: \011");
lf[338]=C_h_intern(&lf[338],1,"s");
lf[339]=C_decode_literal(C_heaptop,"\376B\000\000\023program statistics:");
lf[340]=C_h_intern(&lf[340],35,"\010compilerpprint-expressions-to-file");
lf[341]=C_h_intern(&lf[341],17,"close-output-port");
lf[342]=C_h_intern(&lf[342],12,"pretty-print");
lf[343]=C_h_intern(&lf[343],19,"with-output-to-port");
lf[344]=C_h_intern(&lf[344],16,"open-output-file");
lf[345]=C_h_intern(&lf[345],27,"\010compilerforeign-type-check");
lf[346]=C_h_intern(&lf[346],4,"char");
lf[347]=C_h_intern(&lf[347],13,"unsigned-char");
lf[348]=C_h_intern(&lf[348],6,"unsafe");
lf[349]=C_h_intern(&lf[349],25,"\003sysforeign-char-argument");
lf[350]=C_h_intern(&lf[350],3,"int");
lf[351]=C_h_intern(&lf[351],27,"\003sysforeign-fixnum-argument");
lf[352]=C_h_intern(&lf[352],5,"float");
lf[353]=C_h_intern(&lf[353],27,"\003sysforeign-flonum-argument");
lf[354]=C_h_intern(&lf[354],4,"blob");
lf[355]=C_h_intern(&lf[355],14,"scheme-pointer");
lf[356]=C_h_intern(&lf[356],26,"\003sysforeign-block-argument");
lf[357]=C_h_intern(&lf[357],22,"nonnull-scheme-pointer");
lf[358]=C_h_intern(&lf[358],12,"nonnull-blob");
lf[359]=C_h_intern(&lf[359],14,"pointer-vector");
lf[360]=C_h_intern(&lf[360],35,"\003sysforeign-struct-wrapper-argument");
lf[361]=C_h_intern(&lf[361],22,"nonnull-pointer-vector");
lf[362]=C_h_intern(&lf[362],8,"u8vector");
lf[363]=C_h_intern(&lf[363],16,"nonnull-u8vector");
lf[364]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020nonnull-u8vector\376\001\000\000\010u8vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-u16vector\376\001\000\000"
"\011u16vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020nonnull-s8vector\376\001\000\000\010s8vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-s16"
"vector\376\001\000\000\011s16vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-u32vector\376\001\000\000\011u32vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000"
"\021nonnull-s32vector\376\001\000\000\011s32vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-f32vector\376\001\000\000\011f32vector\376\003"
"\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-f64vector\376\001\000\000\011f64vector\376\377\016");
lf[365]=C_h_intern(&lf[365],7,"integer");
lf[366]=C_h_intern(&lf[366],28,"\003sysforeign-integer-argument");
lf[367]=C_h_intern(&lf[367],9,"integer64");
lf[368]=C_h_intern(&lf[368],30,"\003sysforeign-integer64-argument");
lf[369]=C_h_intern(&lf[369],16,"unsigned-integer");
lf[370]=C_h_intern(&lf[370],37,"\003sysforeign-unsigned-integer-argument");
lf[371]=C_h_intern(&lf[371],18,"unsigned-integer32");
lf[372]=C_h_intern(&lf[372],39,"\003sysforeign-unsigned-integer64-argument");
lf[373]=C_h_intern(&lf[373],9,"c-pointer");
lf[374]=C_h_intern(&lf[374],28,"\003sysforeign-pointer-argument");
lf[375]=C_h_intern(&lf[375],17,"nonnull-c-pointer");
lf[376]=C_h_intern(&lf[376],8,"c-string");
lf[377]=C_h_intern(&lf[377],17,"\003sysmake-c-string");
lf[378]=C_h_intern(&lf[378],27,"\003sysforeign-string-argument");
lf[379]=C_h_intern(&lf[379],16,"nonnull-c-string");
lf[380]=C_h_intern(&lf[380],6,"symbol");
lf[381]=C_h_intern(&lf[381],18,"\003syssymbol->string");
lf[382]=C_h_intern(&lf[382],3,"ref");
lf[383]=C_h_intern(&lf[383],8,"instance");
lf[384]=C_h_intern(&lf[384],12,"instance-ref");
lf[385]=C_h_intern(&lf[385],4,"this");
lf[386]=C_h_intern(&lf[386],8,"slot-ref");
lf[387]=C_h_intern(&lf[387],16,"nonnull-instance");
lf[388]=C_h_intern(&lf[388],5,"const");
lf[389]=C_h_intern(&lf[389],4,"enum");
lf[390]=C_h_intern(&lf[390],15,"nonnull-pointer");
lf[391]=C_h_intern(&lf[391],7,"pointer");
lf[392]=C_h_intern(&lf[392],8,"function");
lf[393]=C_h_intern(&lf[393],27,"\010compilerforeign-type-table");
lf[394]=C_h_intern(&lf[394],17,"nonnull-c-string\052");
lf[395]=C_h_intern(&lf[395],26,"nonnull-unsigned-c-string\052");
lf[396]=C_h_intern(&lf[396],9,"c-string\052");
lf[397]=C_h_intern(&lf[397],17,"unsigned-c-string");
lf[398]=C_h_intern(&lf[398],18,"unsigned-c-string\052");
lf[399]=C_h_intern(&lf[399],13,"c-string-list");
lf[400]=C_h_intern(&lf[400],14,"c-string-list\052");
lf[401]=C_h_intern(&lf[401],13,"unsigned-long");
lf[402]=C_h_intern(&lf[402],4,"long");
lf[403]=C_h_intern(&lf[403],6,"size_t");
lf[404]=C_h_intern(&lf[404],9,"integer32");
lf[405]=C_h_intern(&lf[405],17,"nonnull-u16vector");
lf[406]=C_h_intern(&lf[406],16,"nonnull-s8vector");
lf[407]=C_h_intern(&lf[407],17,"nonnull-s16vector");
lf[408]=C_h_intern(&lf[408],17,"nonnull-u32vector");
lf[409]=C_h_intern(&lf[409],17,"nonnull-s32vector");
lf[410]=C_h_intern(&lf[410],17,"nonnull-f32vector");
lf[411]=C_h_intern(&lf[411],17,"nonnull-f64vector");
lf[412]=C_h_intern(&lf[412],9,"u16vector");
lf[413]=C_h_intern(&lf[413],8,"s8vector");
lf[414]=C_h_intern(&lf[414],9,"s16vector");
lf[415]=C_h_intern(&lf[415],9,"u32vector");
lf[416]=C_h_intern(&lf[416],9,"s32vector");
lf[417]=C_h_intern(&lf[417],9,"f32vector");
lf[418]=C_h_intern(&lf[418],9,"f64vector");
lf[419]=C_h_intern(&lf[419],6,"double");
lf[420]=C_h_intern(&lf[420],6,"number");
lf[421]=C_h_intern(&lf[421],12,"unsigned-int");
lf[422]=C_h_intern(&lf[422],5,"short");
lf[423]=C_h_intern(&lf[423],14,"unsigned-short");
lf[424]=C_h_intern(&lf[424],4,"byte");
lf[425]=C_h_intern(&lf[425],13,"unsigned-byte");
lf[426]=C_h_intern(&lf[426],5,"int32");
lf[427]=C_h_intern(&lf[427],14,"unsigned-int32");
lf[428]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[429]=C_h_intern(&lf[429],36,"\010compilerforeign-type-convert-result");
lf[430]=C_h_intern(&lf[430],38,"\010compilerforeign-type-convert-argument");
lf[431]=C_h_intern(&lf[431],27,"\010compilerfinal-foreign-type");
lf[432]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[433]=C_h_intern(&lf[433],37,"\010compilerestimate-foreign-result-size");
lf[434]=C_h_intern(&lf[434],18,"unsigned-integer64");
lf[435]=C_h_intern(&lf[435],4,"bool");
lf[436]=C_h_intern(&lf[436],4,"void");
lf[437]=C_h_intern(&lf[437],13,"scheme-object");
lf[438]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[439]=C_h_intern(&lf[439],46,"\010compilerestimate-foreign-result-location-size");
lf[440]=C_decode_literal(C_heaptop,"\376B\000\0005cannot compute size of location for foreign type `~S\047");
lf[441]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[442]=C_h_intern(&lf[442],30,"\010compilerfinish-foreign-result");
lf[443]=C_h_intern(&lf[443],17,"\003syspeek-c-string");
lf[444]=C_h_intern(&lf[444],25,"\003syspeek-nonnull-c-string");
lf[445]=C_h_intern(&lf[445],26,"\003syspeek-and-free-c-string");
lf[446]=C_h_intern(&lf[446],34,"\003syspeek-and-free-nonnull-c-string");
lf[447]=C_h_intern(&lf[447],17,"\003sysintern-symbol");
lf[448]=C_h_intern(&lf[448],22,"\003syspeek-c-string-list");
lf[449]=C_h_intern(&lf[449],31,"\003syspeek-and-free-c-string-list");
lf[450]=C_h_intern(&lf[450],17,"\003sysnull-pointer\077");
lf[451]=C_h_intern(&lf[451],3,"not");
lf[452]=C_h_intern(&lf[452],4,"make");
lf[453]=C_h_intern(&lf[453],3,"and");
lf[454]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010c-string\376\003\000\000\002\376\001\000\000\011c-string\052\376\003\000\000\002\376\001\000\000\021unsigned-c-string\376\003\000\000\002\376\001\000\000\022unsign"
"ed-c-string\052\376\003\000\000\002\376\001\000\000\020nonnull-c-string\376\003\000\000\002\376\001\000\000\021nonnull-c-string\052\376\003\000\000\002\376\001\000\000\030nonnu"
"ll-unsigned-string\052\376\377\016");
lf[455]=C_h_intern(&lf[455],16,"\003sysstrip-syntax");
lf[456]=C_h_intern(&lf[456],36,"\010compilerforeign-type->scrutiny-type");
lf[457]=C_h_intern(&lf[457],3,"arg");
lf[458]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\002or\376\003\000\000\002\376\001\000\000\007boolean\376\003\000\000\002\376\001\000\000\004blob\376\377\016");
lf[459]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\002or\376\003\000\000\002\376\001\000\000\007boolean\376\003\000\000\002\376\001\000\000\016pointer-vector\376\377\016");
lf[460]=C_h_intern(&lf[460],6,"struct");
lf[461]=C_h_intern(&lf[461],2,"or");
lf[462]=C_h_intern(&lf[462],7,"boolean");
lf[463]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006struct\376\003\000\000\002\376\001\000\000\010u8vector\376\377\016");
lf[464]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006struct\376\003\000\000\002\376\001\000\000\010s8vector\376\377\016");
lf[465]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006struct\376\003\000\000\002\376\001\000\000\011u16vector\376\377\016");
lf[466]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006struct\376\003\000\000\002\376\001\000\000\011s16vector\376\377\016");
lf[467]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006struct\376\003\000\000\002\376\001\000\000\011u32vector\376\377\016");
lf[468]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006struct\376\003\000\000\002\376\001\000\000\011s32vector\376\377\016");
lf[469]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006struct\376\003\000\000\002\376\001\000\000\011f32vector\376\377\016");
lf[470]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006struct\376\003\000\000\002\376\001\000\000\011f64vector\376\377\016");
lf[471]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\002or\376\003\000\000\002\376\001\000\000\007boolean\376\003\000\000\002\376\001\000\000\007pointer\376\003\000\000\002\376\001\000\000\010locative\376\377\016");
lf[472]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\002or\376\003\000\000\002\376\001\000\000\007boolean\376\003\000\000\002\376\001\000\000\006string\376\377\016");
lf[473]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007list-of\376\003\000\000\002\376\001\000\000\006string\376\377\016");
lf[474]=C_h_intern(&lf[474],6,"string");
lf[475]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\002or\376\003\000\000\002\376\001\000\000\007boolean\376\003\000\000\002\376\001\000\000\007pointer\376\003\000\000\002\376\001\000\000\010locative\376\377\016");
lf[476]=C_h_intern(&lf[476],28,"\010compilerscan-used-variables");
lf[477]=C_h_intern(&lf[477],28,"\010compilerscan-free-variables");
lf[478]=C_h_intern(&lf[478],11,"lset-adjoin");
lf[479]=C_h_intern(&lf[479],23,"\010compilerchop-separator");
lf[480]=C_h_intern(&lf[480],9,"substring");
lf[481]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000/\376\377\016");
lf[482]=C_h_intern(&lf[482],23,"\010compilerchop-extension");
lf[483]=C_h_intern(&lf[483],36,"\010compilermake-block-variable-literal");
lf[484]=C_h_intern(&lf[484],22,"block-variable-literal");
lf[485]=C_h_intern(&lf[485],32,"\010compilerblock-variable-literal\077");
lf[486]=C_h_intern(&lf[486],36,"\010compilerblock-variable-literal-name");
lf[487]=C_h_intern(&lf[487],27,"block-variable-literal-name");
lf[488]=C_h_intern(&lf[488],25,"\010compilermake-random-name");
lf[489]=C_h_intern(&lf[489],6,"random");
lf[490]=C_h_intern(&lf[490],15,"current-seconds");
lf[491]=C_h_intern(&lf[491],23,"\010compilerset-real-name!");
lf[492]=C_h_intern(&lf[492],24,"\010compilerreal-name-table");
lf[493]=C_h_intern(&lf[493],19,"real-name-max-depth");
lf[494]=C_h_intern(&lf[494],18,"string-intersperse");
lf[495]=C_decode_literal(C_heaptop,"\376B\000\000\004 in ");
lf[496]=C_decode_literal(C_heaptop,"\376B\000\000\003...");
lf[497]=C_decode_literal(C_heaptop,"\376B\000\000\004 in ");
lf[498]=C_decode_literal(C_heaptop,"\376B\000\000\004 in ");
lf[499]=C_h_intern(&lf[499],19,"\010compilerreal-name2");
lf[500]=C_h_intern(&lf[500],32,"\010compilerdisplay-real-name-table");
lf[501]=C_h_intern(&lf[501],28,"\010compilersource-info->string");
lf[502]=C_h_intern(&lf[502],4,"conc");
lf[503]=C_decode_literal(C_heaptop,"\376B\000\000\001:");
lf[504]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[505]=C_h_intern(&lf[505],11,"make-string");
lf[506]=C_h_intern(&lf[506],3,"max");
lf[507]=C_h_intern(&lf[507],26,"\010compilersource-info->line");
lf[508]=C_h_intern(&lf[508],18,"\010compilercall-info");
lf[509]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[510]=C_decode_literal(C_heaptop,"\376B\000\000\002) ");
lf[511]=C_h_intern(&lf[511],27,"\010compilerconstant-form-eval");
lf[512]=C_h_intern(&lf[512],22,"get-condition-property");
lf[513]=C_h_intern(&lf[513],3,"exn");
lf[514]=C_h_intern(&lf[514],7,"message");
lf[515]=C_decode_literal(C_heaptop,"\376B\000\000\032folded constant expression");
lf[516]=C_decode_literal(C_heaptop,"\376B\000\000Dattempt to constant-fold call to procedure that has multiple results");
lf[517]=C_h_intern(&lf[517],8,"\003syslist");
lf[518]=C_decode_literal(C_heaptop,"\376B\000\000.attempt to constant-fold call to non-procedure");
lf[519]=C_h_intern(&lf[519],19,"\010compilerdump-nodes");
lf[520]=C_h_intern(&lf[520],23,"\010compilerread-info-hook");
lf[521]=C_h_intern(&lf[521],27,"\003syscurrent-source-filename");
lf[522]=C_decode_literal(C_heaptop,"\376B\000\000\001:");
lf[523]=C_h_intern(&lf[523],9,"list-info");
lf[524]=C_h_intern(&lf[524],25,"\010compilerread/source-info");
lf[525]=C_h_intern(&lf[525],8,"\003sysread");
lf[526]=C_h_intern(&lf[526],18,"\003sysuser-read-hook");
lf[527]=C_h_intern(&lf[527],15,"foreign-declare");
lf[528]=C_h_intern(&lf[528],7,"declare");
lf[529]=C_h_intern(&lf[529],34,"\010compilerscan-sharp-greater-string");
lf[530]=C_h_intern(&lf[530],18,"\003sysread-char/port");
lf[531]=C_decode_literal(C_heaptop,"\376B\000\000&unexpected end of `#> ... <#\047 sequence");
lf[532]=C_h_intern(&lf[532],19,"\010compilervisibility");
lf[533]=C_h_intern(&lf[533],6,"hidden");
lf[534]=C_h_intern(&lf[534],24,"\010compilerexport-variable");
lf[535]=C_h_intern(&lf[535],8,"exported");
lf[536]=C_h_intern(&lf[536],26,"\010compilerblock-compilation");
lf[537]=C_h_intern(&lf[537],22,"\010compilermark-variable");
lf[538]=C_h_intern(&lf[538],22,"\010compilervariable-mark");
lf[539]=C_h_intern(&lf[539],19,"\010compilerintrinsic\077");
lf[540]=C_h_intern(&lf[540],9,"foldable\077");
lf[541]=C_h_intern(&lf[541],33,"\010compilerload-identifier-database");
lf[542]=C_h_intern(&lf[542],7,"\004coredb");
lf[543]=C_h_intern(&lf[543],9,"read-file");
lf[544]=C_h_intern(&lf[544],1,"p");
lf[545]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[546]=C_decode_literal(C_heaptop,"\376B\000\000\034loading identifier database ");
lf[547]=C_h_intern(&lf[547],13,"make-pathname");
lf[548]=C_h_intern(&lf[548],15,"repository-path");
lf[549]=C_h_intern(&lf[549],22,"\010compilerprint-version");
lf[550]=C_h_intern(&lf[550],6,"print\052");
lf[551]=C_decode_literal(C_heaptop,"\376B\000\000\077(c)2008-2012 The Chicken Team\012(c)2000-2007 Felix L. Winkelmann\012");
lf[552]=C_h_intern(&lf[552],20,"\010compilerprint-usage");
lf[553]=C_decode_literal(C_heaptop,"\376B\000\030\027Usage: chicken FILENAME OPTION ...\012\012  `chicken\047 is the CHICKEN compiler.\012  "
"\012  FILENAME should be a complete source file name with extension, or \042-\042 for\012  s"
"tandard input. OPTION may be one of the following:\012\012  General options:\012\012    -hel"
"p                        display this text and exit\012    -version                "
"     display compiler version and exit\012    -release                     print re"
"lease number and exit\012    -verbose                     display information on co"
"mpilation progress\012\012  File and pathname options:\012\012    -output-file FILENAME     "
"   specifies output-filename, default is \047out.c\047\012    -include-path PATHNAME     "
"  specifies alternative path for included files\012    -to-stdout                  "
" write compiled file to stdout instead of file\012\012  Language options:\012\012    -featur"
"e SYMBOL              register feature identifier\012    -no-feature SYMBOL        "
"   disable built-in feature identifier\012\012  Syntax related options:\012\012    -case-ins"
"ensitive            don\047t preserve case of read symbols\012    -keyword-style STYLE"
"         allow alternative keyword syntax\012                                  (pre"
"fix, suffix or none)\012    -no-parentheses-synonyms     disables list delimiter sy"
"nonyms\012    -no-symbol-escape            disables support for escaped symbols\012   "
" -r5rs-syntax                 disables the Chicken extensions to\012               "
"                   R5RS syntax\012    -compile-syntax              macros are made "
"available at run-time\012    -emit-import-library MODULE  write compile-time module"
" information into\012                                  separate file\012    -emit-all-"
"import-libraries   emit import-libraries for all defined modules\012    -no-module-"
"registration      do not generate module registration code\012    -no-compiler-synt"
"ax          disable expansion of compiler-macros\012    -module                    "
"  wrap compiled code into implicit module\012\012  Translation options:\012\012    -explicit"
"-use                do not use units \047library\047 and \047eval\047 by\012                   "
"               default\012    -check-syntax                stop compilation after m"
"acro-expansion\012    -analyze-only                stop compilation after first ana"
"lysis pass\012\012  Debugging options:\012\012    -no-warnings                 disable warni"
"ngs\012    -debug-level NUMBER          set level of available debugging informatio"
"n\012    -no-trace                    disable tracing information\012    -profile     "
"                executable emits profiling information \012    -profile-name FILENA"
"ME       name of the generated profile information file\012    -accumulate-profile "
"         executable emits profiling information in\012                             "
"     append mode\012    -no-lambda-info              omit additional procedure-info"
"rmation\012    -scrutinize                  perform local flow analysis for static "
"checks\012    -types FILENAME              load additional type database\012    -emit-"
"type-file FILENAME     write type-declaration information into file\012\012  Optimizat"
"ion options:\012\012    -optimize-level NUMBER       enable certain sets of optimizati"
"on options\012    -optimize-leaf-routines      enable leaf routine optimization\012   "
" -no-usual-integrations       standard procedures may be redefined\012    -unsafe  "
"                    disable all safety checks\012    -local                       a"
"ssume globals are only modified in current\012                                  fil"
"e\012    -block                       enable block-compilation\012    -disable-interru"
"pts          disable interrupts in compiled code\012    -fixnum-arithmetic         "
"  assume all numbers are fixnums\012    -disable-stack-overflow-checks  disables de"
"tection of stack-overflows\012    -inline                      enable inlining\012    "
"-inline-limit LIMIT          set inlining threshold\012    -inline-global          "
"     enable cross-module inlining\012    -specialize                  perform type-"
"based specialization of primitive calls\012    -emit-inline-file FILENAME   generat"
"e file with globally inlinable\012                                  procedures (imp"
"lies -inline -local)\012    -consult-inline-file FILENAME  explicitly load inline f"
"ile\012    -no-argc-checks              disable argument count checks\012    -no-bound"
"-checks             disable bound variable checks\012    -no-procedure-checks      "
"   disable procedure call checks\012    -no-procedure-checks-for-usual-bindings\012   "
"                                disable procedure call checks only for usual\012   "
"                                bindings\012    -no-procedure-checks-for-toplevel-b"
"indings\012                                   disable procedure call checks for top"
"level\012                                   bindings\012    -strict-types             "
"   assume variable do not change their type\012    -clustering                  com"
"bine groups of local procedures into dispatch\012                                  "
" loop\012\012  Configuration options:\012\012    -unit NAME                   compile file a"
"s a library unit\012    -uses NAME                   declare library unit as used.\012"
"    -heap-size NUMBER            specifies heap-size of compiled executable\012    "
"-nursery NUMBER  -stack-size NUMBER\012                                 specifies n"
"ursery size of compiled executable\012    -extend FILENAME             load file be"
"fore compilation commences\012    -prelude EXPRESSION          add expression to fr"
"ont of source file\012    -postlude EXPRESSION         add expression to end of sou"
"rce file\012    -prologue FILENAME           include file before main source file\012 "
"   -epilogue FILENAME           include file after main source file\012    -dynamic"
"                     compile as dynamically loadable code\012    -require-extension"
" NAME      require and import extension NAME\012\012  Obscure options:\012\012    -debug MOD"
"ES                 display debugging output for the given modes\012    -raw        "
"                 do not generate implicit init- and exit code                   "
"        \012    -emit-external-prototypes-first\012                                 em"
"it prototypes for callbacks before foreign\012                                  dec"
"larations\012    -ignore-repository           do not refer to repository for extens"
"ions\012    -setup-mode                  prefer the current directory when locating"
" extensions\012");
lf[554]=C_h_intern(&lf[554],28,"\010compilerprint-debug-options");
lf[555]=C_decode_literal(C_heaptop,"\376B\000\007\026\012Available debugging options:\012\012     a          show node-matching during si"
"mplification\012     b          show breakdown of time needed for each compiler pas"
"s\012     c          print every expression before macro-expansion\012     d          "
"lists all assigned global variables\012     e          show information about speci"
"alizations\012     h          you already figured that out\012     i          show inf"
"ormation about inlining\012     m          show GC statistics during compilation\012  "
"   n          print the line-number database \012     o          show performed opt"
"imizations\012     p          display information about what the compiler is curren"
"tly doing\012     r          show invocation parameters\012     s          show progra"
"m-size information and other statistics\012     t          show time needed for com"
"pilation\012     u          lists all unassigned global variable references\012     x "
"         display information about experimental features\012     D          when pr"
"inting nodes, use node-tree output\012     I          show inferred type informatio"
"n for unexported globals\012     M          show syntax-/runtime-requirements\012     "
"N          show the real-name mapping table\012     P          show expressions aft"
"er specialization\012     S          show applications of compiler syntax\012     T   "
"       show expressions after converting to node tree\012     1          show sourc"
"e expressions\012     2          show canonicalized expressions\012     3          sho"
"w expressions converted into CPS\012     4          show database after each analys"
"is pass\012     5          show expressions after each optimization pass\012     6    "
"      show expressions after each inlining pass\012     7          show expressions"
" after complete optimization\012     8          show database after final analysis\012"
"     9          show expressions after closure conversion\012\012");
lf[556]=C_decode_literal(C_heaptop,"\376B\000\000\007#<node ");
lf[557]=C_h_intern(&lf[557],27,"\003sysregister-record-printer");
lf[558]=C_h_intern(&lf[558],27,"condition-property-accessor");
lf[559]=C_h_intern(&lf[559],19,"condition-predicate");
C_register_lf2(lf,560,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4663,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* map-loop2121 in k9547 in k9539 in k9528 in walk in node->sexpr in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_9556(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9556,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9581,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:771: g2127 */
t5=((C_word*)((C_word*)t0)[5])[1];
f_9518(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k9552 in k9547 in k9539 in k9528 in walk in node->sexpr in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_9554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9554,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,((C_word*)t0)[4],t2));}

/* k8938 in k8916 in k8914 */
static void C_ccall f_8939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8939,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8942,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* support.scm:705: take */
t3=*((C_word*)lf[279]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[5],((C_word*)t0)[6]);}

/* k5942 in expand-profile-lambda in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_5943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[106],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5943,2,t0,t1);}
t2=C_a_i_cons(&a,2,C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]),*((C_word*)lf[126]+1));
t3=C_mutate((C_word*)lf[126]+1 /* (set! ##compiler#profile-lambda-list ...) */,t2);
t4=C_a_i_plus(&a,2,((C_word*)t0)[2],C_fix(1));
t5=C_mutate((C_word*)lf[125]+1 /* (set! ##compiler#profile-lambda-index ...) */,t4);
t6=C_a_i_list(&a,2,lf[95],((C_word*)t0)[2]);
t7=C_a_i_list(&a,3,lf[127],t6,*((C_word*)lf[128]+1));
t8=C_a_i_list(&a,3,lf[129],C_SCHEME_END_OF_LIST,t7);
t9=C_a_i_list(&a,3,lf[129],((C_word*)t0)[4],((C_word*)t0)[5]);
t10=C_a_i_list(&a,3,lf[130],t9,t1);
t11=C_a_i_list(&a,3,lf[129],C_SCHEME_END_OF_LIST,t10);
t12=C_a_i_list(&a,2,lf[95],((C_word*)t0)[2]);
t13=C_a_i_list(&a,3,lf[131],t12,*((C_word*)lf[128]+1));
t14=C_a_i_list(&a,3,lf[129],C_SCHEME_END_OF_LIST,t13);
t15=C_a_i_list(&a,4,lf[132],t8,t11,t14);
t16=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_a_i_list(&a,3,lf[129],t1,t15));}

/* f_9543 in k9539 in k9528 in walk in node->sexpr in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_9543(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9543,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_slot(t2,C_fix(3)));}

/* k9539 in k9528 in walk in node->sexpr in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_9541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9541,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9543,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9549,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t5,a[6]=t3,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* support.scm:771: g2138 */
t8=t6;
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,((C_word*)t0)[5]);}

/* k9547 in k9539 in k9528 in walk in node->sexpr in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_9549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9549,2,t0,t1);}
t2=C_i_check_list_2(t1,lf[160]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9554,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9556,a[2]=((C_word*)t0)[5],a[3]=t5,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_9556(t7,t3,t1);}

/* f_8943 in k8916 in k8914 */
static void C_ccall f_8943(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8943,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_record4(&a,4,lf[208],t2,t3,t4));}

/* ##compiler#expand-profile-lambda in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_5939(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5939,5,t0,t1,t2,t3,t4);}
t5=*((C_word*)lf[125]+1);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5943,a[2]=t5,a[3]=t2,a[4]=t3,a[5]=t4,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* support.scm:331: gensym */
t7=*((C_word*)lf[106]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k8941 in k8938 in k8916 in k8914 */
static void C_ccall f_8942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:692: fold-right */
t2=*((C_word*)lf[278]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],t1,((C_word*)t0)[5]);}

/* ##compiler#posq in k4697 in k4664 in k4662 */
static void C_ccall f_5100(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5100,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5106,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_5106(t7,t1,t3,C_fix(0));}

/* loop in posq in k4697 in k4664 in k4662 */
static void C_fcall f_5106(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5106,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=C_i_car(t2);
t5=C_eqp(((C_word*)t0)[2],t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
t6=t2;
t7=C_u_i_cdr(t6);
t8=C_a_i_plus(&a,2,t3,C_fix(1));
/* support.scm:153: loop */
t10=t1;
t11=t7;
t12=t8;
t1=t10;
t2=t11;
t3=t12;
goto loop;}}}

/* k14113 in k14099 in k14089 in k14087 in k14085 in k14083 in k14081 in k14079 in k14075 in k14072 in k14065 in k14058 in loop in dump-nodes in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14114,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14117,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_slot(((C_word*)t0)[4],C_fix(4));
/* support.scm:1503: write */
t4=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[5]);}

/* k14115 in k14113 in k14099 in k14089 in k14087 in k14085 in k14083 in k14081 in k14079 in k14075 in k14072 in k14065 in k14058 in loop in dump-nodes in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14117,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_14119,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14124,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_14124(t6,t2,C_fix(5));}

/* k14118 in k14115 in k14113 in k14099 in k14089 in k14087 in k14085 in k14083 in k14081 in k14079 in k14075 in k14072 in k14065 in k14058 in loop in dump-nodes in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 in ... */
static void C_ccall f_14119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(93),*((C_word*)lf[13]+1));}

/* k8914 */
static void C_ccall f_8915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8915,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8917,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[7])){
/* support.scm:690: copy-node-tree-and-rename */
t3=*((C_word*)lf[281]+1);
f_9023(7,t3,t2,((C_word*)t0)[8],((C_word*)t0)[9],t1,((C_word*)t0)[10],((C_word*)t0)[11]);}
else{
t3=t2;
f_8917(2,t3,((C_word*)t0)[8]);}}

/* k8916 in k8914 */
static void C_ccall f_8917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8917,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8922,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8939,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[6])){
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8943,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8983,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* support.scm:696: last */
t6=*((C_word*)lf[261]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[4]);}
else{
t4=t3;
f_8939(2,t4,t1);}}

/* f_8912 */
static void C_ccall f_8912(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8912,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8915,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t3,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
if(C_truep(((C_word*)t0)[4])){
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=*((C_word*)lf[106]+1);
t10=((C_word*)t0)[6];
t11=C_i_check_list_2(t10,lf[160]);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8993,a[2]=t8,a[3]=t13,a[4]=t6,a[5]=t9,tmp=(C_word)a,a+=6,tmp));
t15=((C_word*)t13)[1];
f_8993(t15,t4,t10);}
else{
t5=t4;
f_8915(2,t5,((C_word*)t0)[6]);}}

/* f_7845 in k7786 in k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_7845(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7845,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_record4(&a,4,lf[208],t2,t3,t4));}

/* k12100 in k12067 in k12061 in k12050 */
static void C_fcall f_12102(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_i_foreign_fixnum_argumentp(C_fix(1));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,stub351(C_SCHEME_UNDEFINED,t3));}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
/* support.scm:1188: quit */
t4=*((C_word*)lf[26]+1);
f_4904(4,t4,t2,lf[440],t3);}}

/* map-loop1639 in k8146 in k8138 in k8131 in k8124 in walk in build-expression-tree in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_8508(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8508,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8533,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:660: g1645 */
t5=((C_word*)((C_word*)t0)[5])[1];
f_8117(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k14134 in k14132 in doloop3753 in k14115 in k14113 in k14099 in k14089 in k14087 in k14085 in k14083 in k14081 in k14079 in k14075 in k14072 in k14065 in k14058 in loop in dump-nodes in k7039 in k5801 in k5799 in k4697 in ... */
static void C_ccall f_14136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_14124(t3,((C_word*)t0)[4],t2);}

/* k14132 in doloop3753 in k14115 in k14113 in k14099 in k14089 in k14087 in k14085 in k14083 in k14081 in k14079 in k14075 in k14072 in k14065 in k14058 in loop in dump-nodes in k7039 in k5801 in k5799 in k4697 in k4664 in ... */
static void C_ccall f_14133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14133,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14136,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_slot(((C_word*)t0)[5],((C_word*)t0)[2]);
/* support.scm:1504: write */
t4=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[6]);}

/* ##compiler#put! in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_6205(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_6205,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6209,a[2]=t4,a[3]=t1,a[4]=t5,a[5]=t2,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* support.scm:383: ##sys#hash-table-ref */
t7=*((C_word*)lf[145]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t2,t3);}

/* map-loop1366 in k7786 in k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_7863(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7863,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7888,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:602: g1372 */
t5=((C_word*)((C_word*)t0)[5])[1];
f_7080(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* f_6200 in k6191 in get-all in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_6200(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6200,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_assq(t2,((C_word*)t0)[2]));}

/* k7859 in k7786 in k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_7861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:602: g1359 */
t2=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[248],((C_word*)t0)[4],t1);}

/* doloop3753 in k14115 in k14113 in k14099 in k14089 in k14087 in k14085 in k14083 in k14081 in k14079 in k14075 in k14072 in k14065 in k14058 in loop in dump-nodes in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 in ... */
static void C_fcall f_14124(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14124,NULL,3,t0,t1,t2);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=*((C_word*)lf[13]+1);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14133,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* write-char/port */
t5=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_make_character(32),*((C_word*)lf[13]+1));}}

/* k6208 in put! in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_6209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6209,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_assq(((C_word*)t0)[2],t1);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_setslot(t2,C_fix(1),((C_word*)t0)[4]));}
else{
if(C_truep(((C_word*)t0)[4])){
t3=C_slot(t1,C_fix(1));
t4=C_a_i_cons(&a,2,C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[4]),t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_i_setslot(t1,C_fix(1),t4));}
else{
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}}
else{
if(C_truep(((C_word*)t0)[4])){
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[4]);
t3=C_a_i_list1(&a,1,t2);
/* support.scm:388: ##sys#hash-table-set! */
t4=*((C_word*)lf[149]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],((C_word*)t0)[5],((C_word*)t0)[6],t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}}

/* map-loop1335 in k7786 in k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_7810(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7810,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7835,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:600: g1341 */
t5=((C_word*)((C_word*)t0)[5])[1];
f_7080(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* for-each-loop3720 in k14089 in k14087 in k14085 in k14083 in k14081 in k14079 in k14075 in k14072 in k14065 in k14058 in loop in dump-nodes in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_14150(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14150,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14159,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:1500: g3721 */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k14158 in for-each-loop3720 in k14089 in k14087 in k14085 in k14083 in k14081 in k14079 in k14075 in k14072 in k14065 in k14058 in loop in dump-nodes in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_14150(t3,((C_word*)t0)[4],t2);}

/* loop in posv in k4697 in k4664 in k4662 */
static void C_fcall f_5138(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5138,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=C_i_car(t2);
if(C_truep(C_i_eqvp(((C_word*)t0)[2],t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=t2;
t6=C_u_i_cdr(t5);
t7=C_a_i_plus(&a,2,t3,C_fix(1));
/* support.scm:159: loop */
t9=t1;
t10=t6;
t11=t7;
t1=t9;
t2=t10;
t3=t11;
goto loop;}}}

/* k8957 in k8982 in k8916 in k8914 */
static void C_ccall f_8958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8958,2,t0,t1);}
t2=C_a_i_list2(&a,2,t1,((C_word*)t0)[2]);
/* support.scm:695: g1847 */
t3=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[4],lf[105],((C_word*)t0)[5],t2);}

/* ##compiler#posv in k4697 in k4664 in k4662 */
static void C_ccall f_5132(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5132,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5138,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_5138(t7,t1,t3,C_fix(0));}

/* k7806 in k7786 in k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_7808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:600: g1328 */
t2=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],t1);}

/* k8880 in fold in fold-boolean in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_8881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8881,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8884,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[4];
t4=C_u_i_cdr(t3);
/* support.scm:681: fold */
t5=((C_word*)((C_word*)t0)[5])[1];
f_8858(t5,t2,t4);}

/* k8883 in k8880 in fold in fold-boolean in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_8884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8884,2,t0,t1);}
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
/* support.scm:678: g1793 */
t3=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[4],lf[238],lf[275],t2);}

/* ##compiler#inline-lambda-bindings in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_8896(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr8,(void*)f_8896,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8902,a[2]=t3,a[3]=t5,a[4]=t4,a[5]=t6,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* support.scm:684: decompose-lambda-list */
t9=*((C_word*)lf[120]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t1,t2,t8);}

/* f_9196 in k9194 in k9191 */
static void C_ccall f_9196(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9196,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_record4(&a,4,lf[208],t2,t3,t4));}

/* k9194 in k9191 */
static void C_ccall f_9195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9195,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9196,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9249,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
/* support.scm:748: gensym */
t4=*((C_word*)lf[106]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[285]);}

/* k9191 */
static void C_ccall f_9193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9193,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9195,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=*((C_word*)lf[282]+1);
t8=((C_word*)t0)[8];
t9=C_i_check_list_2(t1,lf[160]);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9270,a[2]=t2,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9272,a[2]=t6,a[3]=t12,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t14=((C_word*)t12)[1];
f_9272(t14,t10,t8,t1);}

/* k14502 in k14500 in k14498 in k14444 in k14439 in load-identifier-database in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14503,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14505,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:1600: display */
t3=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[545],((C_word*)t0)[4]);}

/* k14500 in k14498 in k14444 in k14439 in load-identifier-database in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14501,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14503,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:1600: display */
t3=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[5],((C_word*)t0)[4]);}

/* k14504 in k14502 in k14500 in k14498 in k14444 in k14439 in load-identifier-database in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14505,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14508,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[4]);}

/* k14506 in k14504 in k14502 in k14500 in k14498 in k14444 in k14439 in load-identifier-database in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14508,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_14511,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:1600: get-output-string */
t3=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k14522 in print-version in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14523,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_14529,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:1614: chicken-version */
t3=*((C_word*)lf[302]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_SCHEME_TRUE);}

/* f_13326 in k13323 in walk in scan-free-variables in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13326(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_13326,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_slot(t2,C_fix(2)));}

/* k13323 in walk in scan-free-variables in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13325,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13326,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_13332,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* support.scm:1334: g3439 */
t4=t2;
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[8]);}

/* k14528 in k14522 in print-version in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1614: print */
t2=*((C_word*)lf[291]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k14099 in k14089 in k14087 in k14085 in k14083 in k14081 in k14079 in k14075 in k14072 in k14065 in k14058 in loop in dump-nodes in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14101,2,t0,t1);}
t2=C_block_size(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_14106,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_fixnum_greaterp(t2,C_fix(4)))){
t4=*((C_word*)lf[13]+1);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14114,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* write-char/port */
t6=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_make_character(91),*((C_word*)lf[13]+1));}
else{
/* write-char/port */
t4=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[3],C_make_character(62),*((C_word*)lf[13]+1));}}

/* k14104 in k14099 in k14089 in k14087 in k14085 in k14083 in k14081 in k14079 in k14075 in k14072 in k14065 in k14058 in loop in dump-nodes in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(62),*((C_word*)lf[13]+1));}

/* ##compiler#scan-free-variables in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13312(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_13312,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13316,a[2]=t4,a[3]=t6,a[4]=t8,a[5]=t10,tmp=(C_word)a,a+=6,tmp));
t12=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13482,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13515,a[2]=t1,a[3]=t4,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* support.scm:1360: walk */
t14=((C_word*)t8)[1];
f_13316(t14,t13,t2,C_SCHEME_END_OF_LIST);}

/* k14509 in k14506 in k14504 in k14502 in k14500 in k14498 in k14444 in k14439 in load-identifier-database in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1600: debugging */
t2=*((C_word*)lf[11]+1);
f_4702(4,t2,((C_word*)t0)[2],lf[544],t1);}

/* walk in scan-free-variables in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_13316(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13316,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13319,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_13325,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* support.scm:1333: g3436 */
t6=t4;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k14513 in k14439 in load-identifier-database in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1599: file-exists? */
t2=*((C_word*)lf[84]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* ##compiler#print-version in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14516(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2r,(void*)f_14516r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_14516r(t0,t1,t2);}}

static void C_ccall f_14516r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t3=C_i_nullp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:C_i_car(t2));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_14523,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t4)){
/* support.scm:1613: print* */
t6=*((C_word*)lf[550]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[551]);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f15836,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm:1614: chicken-version */
t7=*((C_word*)lf[302]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,C_SCHEME_TRUE);}}

/* f_13319 in walk in scan-free-variables in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13319(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_13319,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_slot(t2,C_fix(3)));}

/* ##compiler#display-analysis-database in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_6469(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6469,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6473,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t4=t3;
f_6473(t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6972,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* support.scm:454: append */
t5=*((C_word*)lf[68]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,*((C_word*)lf[205]+1),*((C_word*)lf[206]+1),*((C_word*)lf[143]+1));}}

/* k6472 in display-analysis-database in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_6473(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6473,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6478,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:457: ##sys#hash-table-for-each */
t3=*((C_word*)lf[161]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[4]);}

/* f_6478 in k6472 in display-analysis-database in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_6478(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6478,4,t0,t1,t2,t3);}
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_END_OF_LIST;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
if(C_truep(C_i_memq(t2,((C_word*)((C_word*)t0)[2])[1]))){
t14=C_SCHEME_UNDEFINED;
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,t14);}
else{
t14=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6487,a[2]=t1,a[3]=t11,a[4]=t13,a[5]=t5,a[6]=t7,a[7]=t9,a[8]=t3,tmp=(C_word)a,a+=9,tmp);
/* support.scm:465: write */
t15=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t15+1)))(3,t15,t14,t2);}}

/* walk in node->sexpr in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_9518(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9518,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9524,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9530,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm:769: g2113 */
t5=t3;
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* f_9183 */
static void C_ccall f_9183(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9183,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9186,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm:741: gensym */
t4=*((C_word*)lf[106]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* f_9181 in k9061 in k9054 in k9047 in walk in k9030 in copy-node-tree-and-rename in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_9181(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9181,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9183,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t10=t2;
t11=C_i_check_list_2(t10,lf[160]);
t12=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9193,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t3,a[7]=t4,a[8]=t2,a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9314,a[2]=t8,a[3]=t14,a[4]=t6,a[5]=t9,tmp=(C_word)a,a+=6,tmp));
t16=((C_word*)t14)[1];
f_9314(t16,t12,t10);}

/* k9185 */
static void C_ccall f_9186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9186,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9188,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm:742: put! */
t3=*((C_word*)lf[148]+1);
f_6205(6,t3,t2,((C_word*)t0)[3],((C_word*)t0)[4],lf[284],C_SCHEME_TRUE);}

/* ##compiler#node->sexpr in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_9512(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9512,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9518,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_9518(t6,t1,t2);}

/* k9508 in copy-node! in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_9510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[2];
t3=C_i_check_structure_2(t2,lf[208],C_SCHEME_FALSE);
/* support.scm:507: ##sys#block-set! */
t4=*((C_word*)lf[212]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],t2,C_fix(1),t1);}

/* k9187 in k9185 */
static void C_ccall f_9188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}

/* k6295 in k6293 in count! in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_6296(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6296,NULL,2,t0,t1);}
if(C_truep(((C_word*)t0)[2])){
t2=C_i_assq(((C_word*)t0)[3],((C_word*)t0)[2]);
if(C_truep(t2)){
t3=C_slot(t2,C_fix(1));
t4=C_a_i_plus(&a,2,t3,t1);
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_i_setslot(t2,C_fix(1),t4));}
else{
t3=C_slot(((C_word*)t0)[2],C_fix(1));
t4=C_a_i_cons(&a,2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1),t3);
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_i_setslot(((C_word*)t0)[2],C_fix(1),t4));}}
else{
t2=C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[5]);
t3=C_a_i_list1(&a,1,t2);
/* support.scm:405: ##sys#hash-table-set! */
t4=*((C_word*)lf[149]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[4],((C_word*)t0)[6],((C_word*)t0)[7],t3);}}

/* k6293 in count! in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_6294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6294,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6296,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[4]))){
t3=((C_word*)t0)[4];
t4=t2;
f_6296(t4,C_u_i_car(t3));}
else{
t3=t2;
f_6296(t3,C_fix(1));}}

/* ##compiler#count! in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_6290(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr5r,(void*)f_6290r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_6290r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_6290r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6294,a[2]=t4,a[3]=t1,a[4]=t5,a[5]=t2,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* support.scm:399: ##sys#hash-table-ref */
t7=*((C_word*)lf[145]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t2,t3);}

/* f_9504 in copy-node! in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_9504(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9504,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_slot(t2,C_fix(1)));}

/* k9500 in k9481 in copy-node! in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_9502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[2];
t3=C_i_check_structure_2(t2,lf[208],C_SCHEME_FALSE);
/* support.scm:507: ##sys#block-set! */
t4=*((C_word*)lf[212]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],t2,C_fix(2),t1);}

/* k9160 in k9144 in k9140 in k9138 in k9061 in k9054 in k9047 in walk in k9030 in copy-node-tree-and-rename in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_9161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9161,2,t0,t1);}
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
/* support.scm:733: g1934 */
t3=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[4],lf[105],((C_word*)t0)[5],t2);}

/* k7834 in map-loop1335 in k7786 in k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_7835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7835,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7810(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7810(t6,((C_word*)t0)[5],t5);}}

/* f_11608 in final-foreign-type in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_11608(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11608,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11611,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_symbolp(t2))){
/* support.scm:1149: ##sys#hash-table-ref */
t5=*((C_word*)lf[145]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[393]+1),t2);}
else{
t5=t4;
f_11611(2,t5,C_SCHEME_FALSE);}}

/* ##compiler#final-foreign-type in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_11602(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11602,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11608,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11638,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm:1146: follow-without-loop */
t5=*((C_word*)lf[90]+1);
f_5527(5,t5,t1,t2,t3,t4);}

/* ##compiler#collect! in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_6246(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_6246,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6250,a[2]=t4,a[3]=t5,a[4]=t1,a[5]=t2,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* support.scm:391: ##sys#hash-table-ref */
t7=*((C_word*)lf[145]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t2,t3);}

/* k9811 in k9808 in k9798 in k9789 in k9776 in k9869 in k9755 */
static void C_fcall f_9813(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9813,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9827,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=C_u_i_cdr(((C_word*)t0)[6]);
/* support.scm:797: node->sexpr */
t6=*((C_word*)lf[288]+1);
f_9512(3,t6,t4,t5);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k9808 in k9798 in k9789 in k9776 in k9869 in k9755 */
static void C_ccall f_9810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9810,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9813,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_eqp(t1,lf[304]);
if(C_truep(t3)){
t4=t2;
f_9813(t4,C_SCHEME_TRUE);}
else{
t4=C_eqp(t1,lf[305]);
if(C_truep(t4)){
t5=t2;
f_9813(t5,C_SCHEME_FALSE);}
else{
t5=C_i_cadddr(((C_word*)t0)[7]);
t6=t2;
f_9813(t6,C_i_lessp(t5,*((C_word*)lf[306]+1)));}}}

/* f_11615 in k11610 */
static void C_ccall f_11615(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11615,3,t0,t1,t2);}
if(C_truep(C_i_vectorp(t2))){
t3=C_i_vector_ref(t2,C_fix(0));
/* support.scm:1151: next */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t3=t2;
/* support.scm:1151: next */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}}

/* k9140 in k9138 in k9061 in k9054 in k9047 in walk in k9030 in copy-node-tree-and-rename in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_9141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9141,2,t0,t1);}
t2=C_a_i_cons(&a,2,C_a_i_cons(&a,2,((C_word*)t0)[2],t1),((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9145,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* support.scm:732: put! */
t4=*((C_word*)lf[148]+1);
f_6205(6,t4,t3,((C_word*)t0)[8],t1,lf[284],C_SCHEME_TRUE);}

/* k9144 in k9140 in k9138 in k9061 in k9054 in k9047 in walk in k9030 in copy-node-tree-and-rename in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_9145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9145,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9146,tmp=(C_word)a,a+=2,tmp);
t3=C_a_i_list1(&a,1,((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9161,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t5=C_i_cadr(((C_word*)t0)[5]);
/* support.scm:735: walk */
t6=((C_word*)((C_word*)t0)[6])[1];
f_9040(t6,t4,t5,((C_word*)t0)[7]);}

/* f_9146 in k9144 in k9140 in k9138 in k9061 in k9054 in k9047 in walk in k9030 in copy-node-tree-and-rename in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_9146(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9146,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_record4(&a,4,lf[208],t2,t3,t4));}

/* k11610 */
static void C_ccall f_11611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11611,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11615,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:1148: g2861 */
t3=t2;
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[3],t1);}
else{
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k6249 in collect! in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_6250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6250,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_assq(((C_word*)t0)[2],t1);
if(C_truep(t2)){
t3=C_slot(t2,C_fix(1));
t4=C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_i_setslot(t2,C_fix(1),t4));}
else{
t3=C_a_i_list1(&a,1,((C_word*)t0)[3]);
t4=C_slot(t1,C_fix(1));
t5=C_a_i_cons(&a,2,C_a_i_cons(&a,2,((C_word*)t0)[2],t3),t4);
t6=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_i_setslot(t1,C_fix(1),t5));}}
else{
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t3=C_a_i_list1(&a,1,t2);
/* support.scm:396: ##sys#hash-table-set! */
t4=*((C_word*)lf[149]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6],t3);}}

/* k9826 in k9811 in k9808 in k9798 in k9789 in k9776 in k9869 in k9755 */
static void C_ccall f_9827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9827,2,t0,t1);}
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k9119 in k9125 in k9061 in k9054 in k9047 in walk in k9030 in copy-node-tree-and-rename in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_9120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9120,2,t0,t1);}
t2=C_a_i_list1(&a,1,t1);
/* support.scm:724: g1925 */
t3=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[241],((C_word*)t0)[4],t2);}

/* k9125 in k9061 in k9054 in k9047 in walk in k9030 in copy-node-tree-and-rename in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_9126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9126,2,t0,t1);}
t2=C_a_i_list1(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9120,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_i_car(((C_word*)t0)[4]);
/* support.scm:726: walk */
t5=((C_word*)((C_word*)t0)[5])[1];
f_9040(t5,t3,t4,((C_word*)t0)[6]);}

/* fold in fold-boolean in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_8858(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8858,NULL,3,t0,t1,t2);}
t3=C_i_cddr(t2);
if(C_truep(C_i_nullp(t3))){
C_apply(4,0,t1,((C_word*)t0)[2],t2);}
else{
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8869,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8881,a[2]=t4,a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t6=t2;
t7=C_u_i_car(t6);
t8=C_i_cadr(t2);
/* support.scm:680: proc */
t9=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t5,t7,t8);}}

/* ##compiler#fold-boolean in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_8852(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8852,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8858,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_8858(t7,t1,t3);}

/* f_8869 in fold in fold-boolean in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_8869(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8869,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_record4(&a,4,lf[208],t2,t3,t4));}

/* f_9105 in k9061 in k9054 in k9047 in walk in k9030 in copy-node-tree-and-rename in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_9105(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9105,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_record4(&a,4,lf[208],t2,t3,t4));}

/* k8064 in k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_8066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:617: g1435 */
t2=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[248],((C_word*)t0)[4],t1);}

/* map-loop1442 in k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_8068(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8068,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8093,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:617: g1448 */
t5=((C_word*)((C_word*)t0)[5])[1];
f_7080(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* f_9865 in k9755 */
static void C_ccall f_9865(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9865,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_structurep(t2,lf[208]));}

/* k9138 in k9061 in k9054 in k9047 in walk in k9030 in copy-node-tree-and-rename in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_9139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9139,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9141,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* support.scm:730: gensym */
t3=*((C_word*)lf[106]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* f_8053 in k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_8053(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8053,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_record4(&a,4,lf[208],t2,t3,t4));}

/* f_11539 in foreign-type-check in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_11539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11539,2,t0,t1);}
/* support.scm:1126: quit */
t2=*((C_word*)lf[26]+1);
f_4904(4,t2,t1,lf[428],((C_word*)t0)[2]);}

/* k9789 in k9776 in k9869 in k9755 */
static void C_ccall f_9791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9791,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9800,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* support.scm:790: get */
t3=*((C_word*)lf[144]+1);
f_6171(5,t3,t2,((C_word*)t0)[7],((C_word*)t0)[3],lf[204]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k11555 in foreign-type-convert-result in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_11556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11556,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_i_vectorp(t1))){
t2=C_i_vector_ref(t1,C_fix(2));
t3=C_a_i_list2(&a,2,t2,((C_word*)t0)[2]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=((C_word*)t0)[2];
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k11664 in k11656 */
static void C_fcall f_11666(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11666,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_i_foreign_fixnum_argumentp(C_fix(3));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,stub351(C_SCHEME_UNDEFINED,t3));}
else{
t2=C_eqp(((C_word*)t0)[3],lf[369]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11677,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_11677(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[3],lf[402]);
if(C_truep(t4)){
t5=t3;
f_11677(t5,t4);}
else{
t5=C_eqp(((C_word*)t0)[3],lf[365]);
if(C_truep(t5)){
t6=t3;
f_11677(t6,t5);}
else{
t6=C_eqp(((C_word*)t0)[3],lf[403]);
if(C_truep(t6)){
t7=t3;
f_11677(t7,t6);}
else{
t7=C_eqp(((C_word*)t0)[3],lf[401]);
if(C_truep(t7)){
t8=t3;
f_11677(t8,t7);}
else{
t8=C_eqp(((C_word*)t0)[3],lf[404]);
t9=t3;
f_11677(t9,(C_truep(t8)?t8:C_eqp(((C_word*)t0)[3],lf[371])));}}}}}}}

/* for-each-loop177 in k4923 in k4921 in syntax-error-hook in k4697 in k4664 in k4662 */
static void C_fcall f_4941(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4941,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4950,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:120: g178 */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* f_10531 */
static void C_ccall f_10531(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10531,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_slot(t2,C_fix(1)));}

/* k10535 */
static void C_ccall f_10537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10537,2,t0,t1);}
t2=C_eqp(lf[129],t1);
if(C_truep(t2)){
t3=C_a_i_plus(&a,2,((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* f_11649 in estimate-foreign-result-size in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_11649(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11649,4,t0,t1,t2,t3);}
t4=t2;
t5=C_eqp(t4,lf[346]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11658,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=t6;
f_11658(t7,t5);}
else{
t7=C_eqp(t4,lf[350]);
if(C_truep(t7)){
t8=t6;
f_11658(t8,t7);}
else{
t8=C_eqp(t4,lf[422]);
if(C_truep(t8)){
t9=t6;
f_11658(t9,t8);}
else{
t9=C_eqp(t4,lf[435]);
if(C_truep(t9)){
t10=t6;
f_11658(t10,t9);}
else{
t10=C_eqp(t4,lf[436]);
if(C_truep(t10)){
t11=t6;
f_11658(t11,t10);}
else{
t11=C_eqp(t4,lf[423]);
if(C_truep(t11)){
t12=t6;
f_11658(t12,t11);}
else{
t12=C_eqp(t4,lf[437]);
if(C_truep(t12)){
t13=t6;
f_11658(t13,t12);}
else{
t13=C_eqp(t4,lf[347]);
if(C_truep(t13)){
t14=t6;
f_11658(t14,t13);}
else{
t14=C_eqp(t4,lf[421]);
if(C_truep(t14)){
t15=t6;
f_11658(t15,t14);}
else{
t15=C_eqp(t4,lf[424]);
if(C_truep(t15)){
t16=t6;
f_11658(t16,t15);}
else{
t16=C_eqp(t4,lf[425]);
if(C_truep(t16)){
t17=t6;
f_11658(t17,t16);}
else{
t17=C_eqp(t4,lf[426]);
t18=t6;
f_11658(t18,(C_truep(t17)?t17:C_eqp(t4,lf[427])));}}}}}}}}}}}}

/* k4935 in k4932 in k4923 in k4921 in syntax-error-hook in k4697 in k4664 in k4662 */
static void C_ccall f_4936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:122: exit */
t2=*((C_word*)lf[28]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_fix(70));}

/* k4932 in k4923 in k4921 in syntax-error-hook in k4697 in k4664 in k4662 */
static void C_ccall f_4934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4934,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4936,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:121: print-call-chain */
t3=*((C_word*)lf[34]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[3],C_fix(0),*((C_word*)lf[35]+1),lf[36]);}

/* ##compiler#estimate-foreign-result-size in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_11643(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11643,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11649,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12025,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm:1159: follow-without-loop */
t5=*((C_word*)lf[90]+1);
f_5527(5,t5,t1,t2,t3,t4);}

/* k4966 in k4964 in k4962 in k4960 in k4921 in syntax-error-hook in k4697 in k4664 in k4662 */
static void C_ccall f_4967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4967,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4969,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[3]);}

/* k4968 in k4966 in k4964 in k4962 in k4960 in k4921 in syntax-error-hook in k4697 in k4664 in k4662 */
static void C_ccall f_4969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(10),((C_word*)t0)[3]);}

/* k14543 in print-usage in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14544,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_14546,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:1618: newline */
t3=*((C_word*)lf[12]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* ##compiler#print-usage in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14540,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_14544,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm:1617: print-version */
t3=*((C_word*)lf[549]+1);
f_14516(2,t3,t2);}

/* k14545 in k14543 in print-usage in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1619: display */
t2=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[553]);}

/* k7504 in loop in k7513 in k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_7505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:577: walk */
t2=((C_word*)((C_word*)t0)[2])[1];
f_7080(t2,((C_word*)t0)[3],t1);}

/* k7501 in loop in k7513 in k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_7502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7502,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[2]);
/* support.scm:575: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7414(t3,((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6],t2);}

/* k11656 */
static void C_fcall f_11658(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11658,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
t2=C_eqp(((C_word*)t0)[3],lf[376]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11666,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_11666(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[3],lf[379]);
if(C_truep(t4)){
t5=t3;
f_11666(t5,t4);}
else{
t5=C_eqp(((C_word*)t0)[3],lf[373]);
if(C_truep(t5)){
t6=t3;
f_11666(t6,t5);}
else{
t6=C_eqp(((C_word*)t0)[3],lf[375]);
if(C_truep(t6)){
t7=t3;
f_11666(t7,t6);}
else{
t7=C_eqp(((C_word*)t0)[3],lf[380]);
if(C_truep(t7)){
t8=t3;
f_11666(t8,t7);}
else{
t8=C_eqp(((C_word*)t0)[3],lf[396]);
if(C_truep(t8)){
t9=t3;
f_11666(t9,t8);}
else{
t9=C_eqp(((C_word*)t0)[3],lf[394]);
if(C_truep(t9)){
t10=t3;
f_11666(t10,t9);}
else{
t10=C_eqp(((C_word*)t0)[3],lf[397]);
if(C_truep(t10)){
t11=t3;
f_11666(t11,t10);}
else{
t11=C_eqp(((C_word*)t0)[3],lf[398]);
if(C_truep(t11)){
t12=t3;
f_11666(t12,t11);}
else{
t12=C_eqp(((C_word*)t0)[3],lf[395]);
if(C_truep(t12)){
t13=t3;
f_11666(t13,t12);}
else{
t13=C_eqp(((C_word*)t0)[3],lf[399]);
t14=t3;
f_11666(t14,(C_truep(t13)?t13:C_eqp(((C_word*)t0)[3],lf[400])));}}}}}}}}}}}}

/* k4962 in k4960 in k4921 in syntax-error-hook in k4697 in k4664 in k4662 */
static void C_ccall f_4963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4963,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4965,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:118: display */
t3=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[37],((C_word*)t0)[3]);}

/* k4964 in k4962 in k4960 in k4921 in syntax-error-hook in k4697 in k4664 in k4662 */
static void C_ccall f_4965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4965,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4967,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:118: display */
t3=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}

/* k4960 in k4921 in syntax-error-hook in k4697 in k4664 in k4662 */
static void C_ccall f_4961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4961,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4963,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:118: display */
t3=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[5],((C_word*)t0)[3]);}

/* k5434 in check-and-open-input-file in k4697 in k4664 in k4662 */
static void C_ccall f_5436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5436,2,t0,t1);}
if(C_truep(t1)){
/* support.scm:221: open-input-file */
t2=*((C_word*)lf[81]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
t2=C_i_nullp(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5447,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=t3;
f_5447(t4,t2);}
else{
t4=C_i_car(((C_word*)t0)[4]);
t5=t3;
f_5447(t5,C_i_not(t4));}}}

/* k7513 in k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_7514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7514,2,t0,t1);}
t2=C_a_i_list1(&a,1,t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7414,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_7414(t6,((C_word*)t0)[4],((C_word*)t0)[5],C_SCHEME_END_OF_LIST,t2);}

/* k4949 in for-each-loop177 in k4923 in k4921 in syntax-error-hook in k4697 in k4664 in k4662 */
static void C_ccall f_4950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4941(t3,((C_word*)t0)[4],t2);}

/* k14561 in k14559 */
static void C_ccall f_14562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14562,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14564,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* write-char/port */
t3=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(32),((C_word*)t0)[3]);}

/* k14563 in k14561 in k14559 */
static void C_ccall f_14564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14564,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14566,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14571,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14577,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:515: g1028 */
t5=t3;
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[4]);}

/* k13363 in k13345 in k13337 in k13330 in k13323 in walk in scan-free-variables in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13365,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13371,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* support.scm:1341: variable-visible? */
t4=*((C_word*)lf[309]+1);
f_14367(3,t4,t3,((C_word*)t0)[5]);}

/* k14559 */
static void C_ccall f_14560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14560,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14562,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14579,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14585,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:515: g1025 */
t5=t3;
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[4]);}

/* ##compiler#finish-foreign-result in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_12404(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_12404,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12408,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1216: ##sys#strip-syntax */
t5=*((C_word*)lf[455]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k12407 in finish-foreign-result in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_12408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12408,2,t0,t1);}
t2=t1;
t3=C_eqp(t2,lf[376]);
t4=(C_truep(t3)?t3:C_eqp(t2,lf[397]));
if(C_truep(t4)){
t5=C_a_i_list(&a,2,lf[95],C_fix(0));
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_list(&a,3,lf[443],((C_word*)t0)[3],t5));}
else{
t5=C_eqp(t2,lf[379]);
if(C_truep(t5)){
t6=C_a_i_list(&a,2,lf[95],C_fix(0));
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_list(&a,3,lf[444],((C_word*)t0)[3],t6));}
else{
t6=C_eqp(t2,lf[396]);
t7=(C_truep(t6)?t6:C_eqp(t2,lf[398]));
if(C_truep(t7)){
t8=C_a_i_list(&a,2,lf[95],C_fix(0));
t9=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_a_i_list(&a,3,lf[445],((C_word*)t0)[3],t8));}
else{
t8=C_eqp(t2,lf[394]);
t9=(C_truep(t8)?t8:C_eqp(t2,lf[395]));
if(C_truep(t9)){
t10=C_a_i_list(&a,2,lf[95],C_fix(0));
t11=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_a_i_list(&a,3,lf[446],((C_word*)t0)[3],t10));}
else{
t10=C_eqp(t2,lf[380]);
if(C_truep(t10)){
t11=C_a_i_list(&a,2,lf[95],C_fix(0));
t12=C_a_i_list(&a,3,lf[443],((C_word*)t0)[3],t11);
t13=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_a_i_list(&a,2,lf[447],t12));}
else{
t11=C_eqp(t2,lf[399]);
if(C_truep(t11)){
t12=C_a_i_list(&a,2,lf[95],C_SCHEME_FALSE);
t13=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_a_i_list(&a,3,lf[448],((C_word*)t0)[3],t12));}
else{
t12=C_eqp(t2,lf[400]);
if(C_truep(t12)){
t13=C_a_i_list(&a,2,lf[95],C_SCHEME_FALSE);
t14=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_a_i_list(&a,3,lf[449],((C_word*)t0)[3],t13));}
else{
if(C_truep(C_i_listp(t1))){
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12513,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t14=C_i_car(t1);
t15=C_eqp(t14,lf[388]);
if(C_truep(t15)){
t16=C_i_length(t1);
t17=C_eqp(C_fix(2),t16);
if(C_truep(t17)){
t18=C_i_cadr(t1);
t19=C_u_i_memq(t18,lf[454]);
t20=t13;
f_12513(t20,t19);}
else{
t18=t13;
f_12513(t18,C_SCHEME_FALSE);}}
else{
t16=t13;
f_12513(t16,C_SCHEME_FALSE);}}
else{
t13=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,((C_word*)t0)[3]);}}}}}}}}}

/* k14565 in k14563 in k14561 in k14559 */
static void C_ccall f_14566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(62),((C_word*)t0)[3]);}

/* ##compiler#check-and-open-input-file in k4697 in k4664 in k4662 */
static void C_ccall f_5423(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_5423r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5423r(t0,t1,t2,t3);}}

static void C_ccall f_5423r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
if(C_truep(C_i_string_equal_p(t2,lf[79]))){
t4=*((C_word*)lf[80]+1);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,*((C_word*)lf[80]+1));}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5436,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* support.scm:221: file-exists? */
t5=*((C_word*)lf[84]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}}

/* k4977 in k4975 in k4973 in k4921 in syntax-error-hook in k4697 in k4664 in k4662 */
static void C_ccall f_4978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(10),((C_word*)t0)[3]);}

/* ##compiler#print-debug-options in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14551,2,t0,t1);}
/* support.scm:1744: display */
t2=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,lf[555]);}

/* ##compiler#words->bytes in k4697 in k4664 in k4662 */
static void C_ccall f_5416(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5416,3,t0,t1,t2);}
t3=C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,stub351(C_SCHEME_UNDEFINED,t3));}

/* f_14557 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14557(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_14557,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14560,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm:514: display */
t5=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,lf[556],t3);}

/* f_9804 in k9798 in k9789 in k9776 in k9869 in k9755 */
static void C_ccall f_9804(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9804,4,t0,t1,t2,t3);}
/* tweaks.scm:57: ##sys#get */
t4=*((C_word*)lf[250]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,t3);}

/* k9798 in k9789 in k9776 in k9869 in k9755 */
static void C_ccall f_9800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9800,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9804,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9810,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* support.scm:791: g2213 */
t4=t2;
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],lf[307]);}}

/* k4975 in k4973 in k4921 in syntax-error-hook in k4697 in k4664 in k4662 */
static void C_ccall f_4976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4976,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4978,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[3]);}

/* k4973 in k4921 in syntax-error-hook in k4697 in k4664 in k4662 */
static void C_ccall f_4974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4974,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4976,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:119: display */
t3=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3]);}

/* k14583 in k14559 */
static void C_ccall f_14585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:514: display */
t2=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,((C_word*)t0)[3]);}

/* k13345 in k13337 in k13330 in k13323 in walk in scan-free-variables in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_13347(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13347,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=C_eqp(((C_word*)t0)[3],lf[218]);
if(C_truep(t2)){
t3=C_i_car(((C_word*)t0)[4]);
if(C_truep(C_i_memq(t3,((C_word*)t0)[5]))){
t4=C_SCHEME_UNDEFINED;
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13365,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[7],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* support.scm:1340: lset-adjoin */
t5=*((C_word*)lf[478]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,*((C_word*)lf[25]+1),((C_word*)((C_word*)t0)[6])[1],t3);}}
else{
t3=C_eqp(((C_word*)t0)[3],lf[241]);
if(C_truep(t3)){
t4=C_i_car(((C_word*)t0)[4]);
if(C_truep(C_i_memq(t4,((C_word*)t0)[5]))){
t5=C_i_car(((C_word*)t0)[8]);
/* support.scm:1346: walk */
t6=((C_word*)((C_word*)t0)[9])[1];
f_13316(t6,((C_word*)t0)[2],t5,((C_word*)t0)[5]);}
else{
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13398,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* support.scm:1345: lset-adjoin */
t6=*((C_word*)lf[478]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,*((C_word*)lf[25]+1),((C_word*)((C_word*)t0)[6])[1],t4);}}
else{
t4=C_eqp(((C_word*)t0)[3],lf[105]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13406,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t6=C_i_car(((C_word*)t0)[8]);
/* support.scm:1348: walk */
t7=((C_word*)((C_word*)t0)[9])[1];
f_13316(t7,t5,t6,((C_word*)t0)[5]);}
else{
t5=C_eqp(((C_word*)t0)[3],lf[129]);
if(C_truep(t5)){
t6=C_i_caddr(((C_word*)t0)[4]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13432,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* support.scm:1351: decompose-lambda-list */
t8=*((C_word*)lf[120]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,((C_word*)t0)[2],t6,t7);}
else{
/* support.scm:1355: walkeach */
t6=((C_word*)((C_word*)t0)[10])[1];
f_13482(t6,((C_word*)t0)[2],((C_word*)t0)[8],((C_word*)t0)[5]);}}}}}}

/* ##compiler#words in k4697 in k4664 in k4662 */
static void C_ccall f_5409(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5409,3,t0,t1,t2);}
t3=C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,stub346(C_SCHEME_UNDEFINED,t3));}

/* k5406 in valid-c-identifier? in k4697 in k4664 in k4662 */
static void C_ccall f_5407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->list */
t2=*((C_word*)lf[70]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k11584 in foreign-type-convert-argument in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_11585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11585,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_i_vectorp(t1))){
t2=C_i_vector_ref(t1,C_fix(1));
t3=C_a_i_list2(&a,2,t2,((C_word*)t0)[2]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=((C_word*)t0)[2];
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* map-llist in k4697 in k4664 in k4662 */
static void C_ccall f_4999(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4999,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5005,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_5005(t7,t1,t3);}

/* f_14571 in k14563 in k14561 in k14559 */
static void C_ccall f_14571(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_14571,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_slot(t2,C_fix(2)));}

/* k13330 in k13323 in walk in scan-free-variables in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13332,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13333,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_13339,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* support.scm:1335: g3447 */
t4=t2;
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[9]);}

/* f_13333 in k13330 in k13323 in walk in scan-free-variables in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13333(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_13333,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_slot(t2,C_fix(1)));}

/* f_14579 in k14559 */
static void C_ccall f_14579(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_14579,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_slot(t2,C_fix(1)));}

/* k14575 in k14563 in k14561 in k14559 */
static void C_ccall f_14577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:514: display */
t2=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,((C_word*)t0)[3]);}

/* ##compiler#emit-syntax-trace-info in k4697 in k4664 in k4662 */
static void C_ccall f_4995(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4995,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_emit_syntax_trace_info(t2,t3,*((C_word*)lf[35]+1)));}

/* k13337 in k13330 in k13323 in walk in scan-free-variables in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13339,2,t0,t1);}
t2=C_eqp(t1,lf[95]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_13347,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
if(C_truep(t2)){
t4=t3;
f_13347(t4,t2);}
else{
t4=C_eqp(t1,lf[223]);
if(C_truep(t4)){
t5=t3;
f_13347(t5,t4);}
else{
t5=C_eqp(t1,lf[237]);
if(C_truep(t5)){
t6=t3;
f_13347(t6,t5);}
else{
t6=C_eqp(t1,lf[240]);
t7=t3;
f_13347(t7,(C_truep(t6)?t6:C_eqp(t1,lf[252])));}}}}

/* k11675 in k11664 in k11656 */
static void C_fcall f_11677(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11677,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_i_foreign_fixnum_argumentp(C_fix(4));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,stub351(C_SCHEME_UNDEFINED,t3));}
else{
t2=C_eqp(((C_word*)t0)[3],lf[352]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11688,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=t3;
f_11688(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[3],lf[419]);
if(C_truep(t4)){
t5=t3;
f_11688(t5,t4);}
else{
t5=C_eqp(((C_word*)t0)[3],lf[420]);
if(C_truep(t5)){
t6=t3;
f_11688(t6,t5);}
else{
t6=C_eqp(((C_word*)t0)[3],lf[367]);
t7=t3;
f_11688(t7,(C_truep(t6)?t6:C_eqp(((C_word*)t0)[3],lf[434])));}}}}}

/* k13396 in k13345 in k13337 in k13330 in k13323 in walk in scan-free-variables in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
t3=C_i_car(((C_word*)t0)[3]);
/* support.scm:1346: walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_13316(t4,((C_word*)t0)[5],t3,((C_word*)t0)[6]);}

/* ##compiler#foreign-type-convert-argument in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_11573(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11573,4,t0,t1,t2,t3);}
if(C_truep(C_i_symbolp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11585,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1140: ##sys#hash-table-ref */
t5=*((C_word*)lf[145]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[393]+1),t3);}
else{
t4=t2;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* ##compiler#foreign-type-convert-result in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_11544(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11544,4,t0,t1,t2,t3);}
if(C_truep(C_i_symbolp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11556,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1133: ##sys#hash-table-ref */
t5=*((C_word*)lf[145]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[393]+1),t3);}
else{
t4=t2;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k13373 in k13369 in k13363 in k13345 in k13337 in k13330 in k13323 in walk in scan-free-variables in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k6191 in get-all in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_6192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6192,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6200,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm:379: filter-map */
t3=*((C_word*)lf[147]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* k13369 in k13363 in k13345 in k13337 in k13330 in k13323 in walk in scan-free-variables in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13371,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13375,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1342: lset-adjoin */
t3=*((C_word*)lf[478]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[25]+1),((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[4]);}}

/* k14079 in k14075 in k14072 in k14065 in k14058 in loop in dump-nodes in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14080,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_14082,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* support.scm:1492: display */
t3=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[10],((C_word*)t0)[8]);}

/* k9681 in for-each-loop2242 in k9665 in k9657 in k9652 in k9650 in emit-global-inline-file in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_9682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_9673(t3,((C_word*)t0)[4],t2);}

/* k14083 in k14081 in k14079 in k14075 in k14072 in k14065 in k14058 in loop in dump-nodes in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14084,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_14086,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* support.scm:1492: display */
t3=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[9],((C_word*)t0)[8]);}

/* k14081 in k14079 in k14075 in k14072 in k14065 in k14058 in loop in dump-nodes in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14082,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_14084,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* write-char/port */
t3=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(60),((C_word*)t0)[8]);}

/* k9776 in k9869 in k9755 */
static void C_fcall f_9778(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9778,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_i_assq(lf[197],((C_word*)t0)[2]))){
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9785,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9791,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t4=C_i_cdr(((C_word*)t0)[7]);
/* support.scm:789: g2205 */
t5=t2;
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#debugging in k4697 in k4664 in k4662 */
static void C_ccall f_4702(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+16)){
C_save_and_reclaim((void*)tr4r,(void*)f_4702r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4702r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4702r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(16);
t5=C_SCHEME_UNDEFINED;
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4706,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t9=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4760,a[2]=t2,tmp=(C_word)a,a+=3,tmp));
if(C_truep(C_i_memq(t2,*((C_word*)lf[1]+1)))){
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4777,a[2]=t1,a[3]=t2,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
/* support.scm:71: text */
t11=t5;
f_4706(t11,t10);}
else{
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4791,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_memq(t2,*((C_word*)lf[9]+1)))){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4800,a[2]=t7,a[3]=t10,tmp=(C_word)a,a+=4,tmp);
/* support.scm:79: text */
t12=t5;
f_4706(t12,t11);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}}

/* f_11638 in final-foreign-type in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_11638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11638,2,t0,t1);}
/* support.scm:1153: quit */
t2=*((C_word*)lf[26]+1);
f_4904(4,t2,t1,lf[432],((C_word*)t0)[2]);}

/* k14087 in k14085 in k14083 in k14081 in k14079 in k14075 in k14072 in k14065 in k14058 in loop in dump-nodes in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14088,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14091,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* support.scm:1492: write */
t3=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[7],((C_word*)t0)[8]);}

/* text in debugging in k4697 in k4664 in k4662 */
static void C_fcall f_4706(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4706,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4712,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:59: with-output-to-string */
t3=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* k14085 in k14083 in k14081 in k14079 in k14075 in k14072 in k14065 in k14058 in loop in dump-nodes in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14086,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_14088,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* write-char/port */
t3=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(32),((C_word*)t0)[8]);}

/* fold in k5488 in fold-inner in k4697 in k4664 in k4662 */
static void C_fcall f_5491(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5491,NULL,3,t0,t1,t2);}
t3=C_i_cddr(t2);
if(C_truep(C_i_nullp(t3))){
t4=t2;
t5=C_u_i_cdr(t4);
t6=C_u_i_car(t5);
t7=t2;
t8=C_u_i_car(t7);
t9=C_a_i_list2(&a,2,t6,t8);
C_apply(4,0,t1,((C_word*)t0)[2],t9);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5515,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t5=t2;
t6=C_u_i_cdr(t5);
/* support.scm:236: fold */
t14=t4;
t15=t6;
t1=t14;
t2=t15;
goto loop;}}

/* k14089 in k14087 in k14085 in k14083 in k14081 in k14079 in k14075 in k14072 in k14065 in k14058 in loop in dump-nodes in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14091,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14092,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_check_list_2(((C_word*)t0)[4],lf[33]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14101,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14150,a[2]=t6,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_14150(t8,t4,((C_word*)t0)[4]);}

/* f_14092 in k14089 in k14087 in k14085 in k14083 in k14081 in k14079 in k14075 in k14072 in k14065 in k14058 in loop in dump-nodes in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14092(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_14092,3,t0,t1,t2);}
/* support.scm:1500: g3736 */
t3=((C_word*)((C_word*)t0)[2])[1];
f_14051(t3,t1,((C_word*)t0)[3],t2);}

/* f_9785 in k9776 in k9869 in k9755 */
static void C_ccall f_9785(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9785,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_slot(t2,C_fix(2)));}

/* for-each-loop2242 in k9665 in k9657 in k9652 in k9650 in emit-global-inline-file in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_9673(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9673,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9682,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:813: g2243 */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k11686 in k11675 in k11664 in k11656 */
static void C_fcall f_11688(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11688,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_i_foreign_fixnum_argumentp(C_fix(4));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,stub351(C_SCHEME_UNDEFINED,t3));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11693,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_symbolp(((C_word*)t0)[4]))){
/* support.scm:1175: ##sys#hash-table-ref */
t3=*((C_word*)lf[145]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[393]+1),((C_word*)t0)[4]);}
else{
t3=t2;
f_11693(2,t3,C_SCHEME_FALSE);}}}

/* ##compiler#get-all in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_6188(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4r,(void*)f_6188r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6188r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6188r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6192,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* support.scm:377: ##sys#hash-table-ref */
t6=*((C_word*)lf[145]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,t3);}

/* k5488 in fold-inner in k4697 in k4664 in k4662 */
static void C_ccall f_5489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5489,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5491,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_5491(t5,((C_word*)t0)[3],t1);}

/* f_14061 in k14058 in loop in dump-nodes in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14061(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_14061,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_slot(t2,C_fix(2)));}

/* k14058 in loop in dump-nodes in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14060,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14061,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14067,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* support.scm:1495: g3699 */
t4=t2;
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* f_9660 in k9657 in k9652 in k9650 in emit-global-inline-file in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_9660(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9660,3,t0,t1,t2);}
t3=*((C_word*)lf[291]+1);
/* support.scm:813: g2258 */
t4=*((C_word*)lf[291]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,lf[292],t2);}

/* k9665 in k9657 in k9652 in k9650 in emit-global-inline-file in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_9666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9666,2,t0,t1);}
t2=C_i_check_list_2(t1,lf[33]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9673,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_9673(t6,((C_word*)t0)[3],t1);}

/* k4724 in k4714 */
static void C_ccall f_4725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4725,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4726,tmp=(C_word)a,a+=2,tmp);
t3=((C_word*)t0)[2];
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4740,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_4740(t7,((C_word*)t0)[3],t3);}

/* k11692 in k11686 in k11675 in k11664 in k11656 */
static void C_ccall f_11693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11693,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11697,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:1175: g2978 */
t3=t2;
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[3],t1);}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[4];
t3=C_u_i_car(t2);
t4=C_eqp(t3,lf[382]);
if(C_truep(t4)){
if(C_truep(t4)){
t5=((C_word*)t0)[3];
t6=C_i_foreign_fixnum_argumentp(C_fix(3));
t7=t5;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,stub351(C_SCHEME_UNDEFINED,t6));}
else{
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_fix(0));}}
else{
t5=C_eqp(t3,lf[390]);
if(C_truep(t5)){
if(C_truep(t5)){
t6=((C_word*)t0)[3];
t7=C_i_foreign_fixnum_argumentp(C_fix(3));
t8=t6;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,stub351(C_SCHEME_UNDEFINED,t7));}
else{
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_fix(0));}}
else{
t6=C_eqp(t3,lf[391]);
if(C_truep(t6)){
if(C_truep(t6)){
t7=((C_word*)t0)[3];
t8=C_i_foreign_fixnum_argumentp(C_fix(3));
t9=t7;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,stub351(C_SCHEME_UNDEFINED,t8));}
else{
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_fix(0));}}
else{
t7=C_eqp(t3,lf[373]);
if(C_truep(t7)){
if(C_truep(t7)){
t8=((C_word*)t0)[3];
t9=C_i_foreign_fixnum_argumentp(C_fix(3));
t10=t8;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,stub351(C_SCHEME_UNDEFINED,t9));}
else{
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_fix(0));}}
else{
t8=C_eqp(t3,lf[375]);
if(C_truep(t8)){
if(C_truep(t8)){
t9=((C_word*)t0)[3];
t10=C_i_foreign_fixnum_argumentp(C_fix(3));
t11=t9;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,stub351(C_SCHEME_UNDEFINED,t10));}
else{
t9=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_fix(0));}}
else{
t9=C_eqp(t3,lf[392]);
if(C_truep(t9)){
if(C_truep(t9)){
t10=((C_word*)t0)[3];
t11=C_i_foreign_fixnum_argumentp(C_fix(3));
t12=t10;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,stub351(C_SCHEME_UNDEFINED,t11));}
else{
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_fix(0));}}
else{
t10=C_eqp(t3,lf[383]);
if(C_truep(t10)){
if(C_truep(t10)){
t11=((C_word*)t0)[3];
t12=C_i_foreign_fixnum_argumentp(C_fix(3));
t13=t11;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,stub351(C_SCHEME_UNDEFINED,t12));}
else{
t11=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_fix(0));}}
else{
t11=C_eqp(t3,lf[384]);
if(C_truep(t11)){
if(C_truep(t11)){
t12=((C_word*)t0)[3];
t13=C_i_foreign_fixnum_argumentp(C_fix(3));
t14=t12;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,stub351(C_SCHEME_UNDEFINED,t13));}
else{
t12=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_fix(0));}}
else{
t12=C_eqp(t3,lf[387]);
if(C_truep(t12)){
t13=((C_word*)t0)[3];
t14=C_i_foreign_fixnum_argumentp(C_fix(3));
t15=t13;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,stub351(C_SCHEME_UNDEFINED,t14));}
else{
t13=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_fix(0));}}}}}}}}}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}}}

/* k14065 in k14058 in loop in dump-nodes in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14067,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14068,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_14074,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* support.scm:1496: g3702 */
t4=t2;
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* k4728 */
static void C_ccall f_4729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(32),((C_word*)t0)[3]);}

/* f_14068 in k14065 in k14058 in loop in dump-nodes in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14068(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_14068,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_slot(t2,C_fix(3)));}

/* f_11697 in k11692 in k11686 in k11675 in k11664 in k11656 */
static void C_ccall f_11697(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11697,3,t0,t1,t2);}
if(C_truep(C_i_vectorp(t2))){
t3=C_i_vector_ref(t2,C_fix(0));
/* support.scm:1177: next */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t3=t2;
/* support.scm:1177: next */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}}

/* f_4726 in k4724 in k4714 */
static void C_ccall f_4726(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4726,3,t0,t1,t2);}
t3=*((C_word*)lf[13]+1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4729,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4735,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* support.scm:65: force */
t6=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* ##compiler#fold-inner in k4697 in k4664 in k4662 */
static void C_ccall f_5476(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5476,4,t0,t1,t2,t3);}
t4=C_i_cdr(t3);
if(C_truep(C_i_nullp(t4))){
t5=t3;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5489,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm:231: reverse */
t6=*((C_word*)lf[89]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}}

/* for-each-loop526 in initialize-analysis-database in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_6151(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6151,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6160,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:352: g527 */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k9652 in k9650 in emit-global-inline-file in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_9653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9653,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9659,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_pairp(((C_word*)((C_word*)t0)[3])[1]))){
/* support.scm:812: debugging */
t3=*((C_word*)lf[11]+1);
f_4702(4,t3,t2,lf[293],lf[294]);}
else{
t3=t2;
f_9659(2,t3,C_SCHEME_FALSE);}}

/* k9650 in emit-global-inline-file in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_9651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9651,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9653,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(((C_word*)((C_word*)t0)[4])[1]))){
/* support.scm:800: delete-file* */
t3=*((C_word*)lf[295]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9708,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* support.scm:801: with-output-to-file */
t4=*((C_word*)lf[303]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[5],t3);}}

/* k9657 in k9652 in k9650 in emit-global-inline-file in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_9659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9659,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9660,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9666,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm:813: sort-symbols */
t4=*((C_word*)lf[91]+1);
f_5556(3,t4,t3,((C_word*)((C_word*)t0)[3])[1]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k4714 */
static void C_ccall f_4715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4715,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4717,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[3]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4725,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:63: display */
t4=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[18]);}
else{
/* support.scm:67: newline */
t3=*((C_word*)lf[12]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}}

/* f_4712 in text in debugging in k4697 in k4664 in k4662 */
static void C_ccall f_4712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4712,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4715,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm:61: display */
t3=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k4716 in k4714 */
static void C_ccall f_4717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:67: newline */
t2=*((C_word*)lf[12]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* f_11084 in k11079 in k11040 in k11003 in k10966 in k10940 in k10914 in k10891 in k10857 in k10751 in k10737 in repeat */
static void C_ccall f_11084(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11084,3,t0,t1,t2);}
if(C_truep(C_i_vectorp(t2))){
t3=C_i_vector_ref(t2,C_fix(0));
/* support.scm:1102: next */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t3=t2;
/* support.scm:1102: next */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}}

/* ##compiler#close-checked-input-file in k4697 in k4664 in k4662 */
static void C_ccall f_5464(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5464,4,t0,t1,t2,t3);}
if(C_truep(C_i_string_equal_p(t3,lf[86]))){
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
/* support.scm:226: close-input-port */
t4=*((C_word*)lf[87]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t2);}}

/* k6159 in for-each-loop526 in initialize-analysis-database in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_6160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6151(t3,((C_word*)t0)[4],t2);}

/* k11079 in k11040 in k11003 in k10966 in k10940 in k10914 in k10891 in k10857 in k10751 in k10737 in repeat */
static void C_ccall f_11080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11080,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11084,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:1100: g2796 */
t3=t2;
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[3],t1);}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[4];
t3=C_u_i_car(t2);
t4=C_eqp(t3,lf[382]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11114,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t4)){
t6=t5;
f_11114(t6,t4);}
else{
t6=C_eqp(t3,lf[391]);
if(C_truep(t6)){
t7=t5;
f_11114(t7,t6);}
else{
t7=C_eqp(t3,lf[392]);
t8=t5;
f_11114(t8,(C_truep(t7)?t7:C_eqp(t3,lf[373])));}}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}}}

/* k9641 in map-loop2160 in walk in sexpr->node in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_9642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9642,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_9617(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_9617(t6,((C_word*)t0)[5],t5);}}

/* ##compiler#emit-global-inline-file in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_9647(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9647,4,t0,t1,t2,t3);}
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9651,a[2]=t1,a[3]=t5,a[4]=t7,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9751,a[2]=t5,a[3]=t7,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* support.scm:780: ##sys#hash-table-for-each */
t10=*((C_word*)lf[161]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t8,t9,t3);}

/* k6139 in for-each-loop575 in k6036 in initialize-analysis-database in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_6140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6131(t3,((C_word*)t0)[4],t2);}

/* for-each-loop624 in k6083 in k6036 in initialize-analysis-database in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_6111(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6111,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6120,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:364: g625 */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k13729 in k13717 in loop in k13694 in k13753 in k13669 in real-name in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1432: string-intersperse */
t2=*((C_word*)lf[494]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,lf[497]);}

/* k6119 in for-each-loop624 in k6083 in k6036 in initialize-analysis-database in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_6120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6111(t3,((C_word*)t0)[4],t2);}

/* k8434 in k8146 in k8138 in k8131 in k8124 in walk in build-expression-tree in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_8435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8435,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8438,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cdr(((C_word*)t0)[3]);
t4=C_u_i_cdr(((C_word*)t0)[4]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8445,a[2]=((C_word*)t0)[5],a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_8445(t8,t2,t3,t4);}

/* k8437 in k8434 in k8146 in k8138 in k8131 in k8124 in walk in build-expression-tree in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_8438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8438,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,lf[264],t2));}

/* ##compiler#get in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_6171(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6171,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6175,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm:371: ##sys#hash-table-ref */
t6=*((C_word*)lf[145]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,t3);}

/* k6174 in get in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_6175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=C_i_assq(((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?C_slot(t2,C_fix(1)):C_SCHEME_FALSE));}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k13709 in loop in k13694 in k13753 in k13669 in real-name in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1428: string-intersperse */
t2=*((C_word*)lf[494]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,lf[495]);}

/* loop in map-llist in k4697 in k4664 in k4662 */
static void C_fcall f_5005(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5005,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
if(C_truep(C_i_symbolp(t2))){
/* support.scm:132: proc */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5027,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=C_i_car(t2);
/* support.scm:133: proc */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}}}

/* ##compiler#check-signature in k4697 in k4664 in k4662 */
static void C_ccall f_5037(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5037,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5041,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5059,a[2]=t5,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_5059(t9,t1,t3,t4);}

/* k13717 in loop in k13694 in k13753 in k13669 in real-name in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13718,2,t0,t1);}
t2=C_eqp(t1,((C_word*)t0)[2]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13730,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm:1432: reverse */
t4=*((C_word*)lf[89]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13745,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
/* support.scm:1433: symbol->string */
t4=*((C_word*)lf[49]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t1);}}

/* k5029 in k5026 in loop in map-llist in k4697 in k4664 in k4662 */
static void C_ccall f_5030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5030,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* k13741 in k13744 in k13717 in loop in k13694 in k13753 in k13669 in real-name in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1433: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_13697(t2,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],t1);}

/* k13744 in k13717 in loop in k13694 in k13753 in k13669 in real-name in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13745,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[2]);
t3=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13742,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* support.scm:1435: get */
t5=*((C_word*)lf[144]+1);
f_6171(5,t5,t4,((C_word*)t0)[6],((C_word*)t0)[7],lf[157]);}

/* node? in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_6980(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6980,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_structurep(t2,lf[208]));}

/* node-class in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_6986(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6986,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[208],lf[210]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_i_block_ref(t2,C_fix(1)));}

/* loop in k8434 in k8146 in k8138 in k8131 in k8124 in walk in build-expression-tree in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_8445(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8445,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
if(C_truep(C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8467,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=C_i_car(t3);
/* support.scm:656: walk */
t6=((C_word*)((C_word*)t0)[2])[1];
f_8117(t6,t4,t5);}}
else{
t4=C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8489,a[2]=t4,a[3]=t1,a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t6=C_i_car(t3);
/* support.scm:657: walk */
t7=((C_word*)((C_word*)t0)[2])[1];
f_8117(t7,t5,t6);}}

/* f_13777 in display-real-name-table in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13777(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_13777,4,t0,t1,t2,t3);}
t4=*((C_word*)lf[13]+1);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13780,a[2]=t1,a[3]=t4,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* support.scm:1445: write */
t6=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,*((C_word*)lf[13]+1));}

/* ##compiler#display-real-name-table in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13771,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13777,tmp=(C_word)a,a+=2,tmp);
/* support.scm:1444: ##sys#hash-table-for-each */
t3=*((C_word*)lf[161]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,*((C_word*)lf[492]+1));}

/* k8478 in k8488 in loop in k8434 in k8146 in k8138 in k8131 in k8124 in walk in build-expression-tree in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_8479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8479,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* k8291 in k8289 in k8146 in k8138 in k8131 in k8124 in walk in build-expression-tree in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_8293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8293,2,t0,t1);}
t2=C_i_check_list_2(((C_word*)t0)[2],lf[160]);
t3=C_i_check_list_2(t1,lf[160]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8300,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8308,a[2]=((C_word*)t0)[6],a[3]=t6,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_8308(t8,t4,((C_word*)t0)[2],t1);}

/* k8289 in k8146 in k8138 in k8131 in k8124 in walk in build-expression-tree in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_8290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8290,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8293,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8350,a[2]=((C_word*)t0)[8],a[3]=t4,a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_8350(t6,t2,t1);}

/* k13753 in k13669 in real-name in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13754,2,t0,t1);}
t2=C_a_i_list1(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13695,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* support.scm:1425: get */
t4=*((C_word*)lf[144]+1);
f_6171(5,t4,t3,((C_word*)t0)[2],((C_word*)t0)[5],lf[157]);}

/* ##compiler#real-name2 in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13759(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_13759,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13763,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1440: ##sys#hash-table-ref */
t5=*((C_word*)lf[145]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[492]+1),t2);}

/* k8466 in loop in k8434 in k8146 in k8138 in k8131 in k8124 in walk in build-expression-tree in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_8467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8467,2,t0,t1);}
t2=C_a_i_list(&a,2,lf[234],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_list(&a,1,t2));}

/* k13750 in loop in k13694 in k13753 in k13669 in real-name in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1436: string-intersperse */
t2=*((C_word*)lf[494]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,lf[498]);}

/* k13781 in k13779 */
static void C_ccall f_13782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13782,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13784,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1445: write */
t3=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[4],((C_word*)t0)[3]);}

/* k13783 in k13781 in k13779 */
static void C_ccall f_13784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(10),((C_word*)t0)[3]);}

/* k13779 */
static void C_ccall f_13780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13780,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13782,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* write-char/port */
t3=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(9),((C_word*)t0)[3]);}

/* ##compiler#source-info->string in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13789(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_13789,3,t0,t1,t2);}
if(C_truep(C_i_listp(t2))){
t3=C_i_car(t2);
t4=C_i_cadr(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13806,a[2]=t1,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13809,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=C_i_string_length(t3);
t8=C_a_i_minus(&a,2,C_fix(4),t7);
/* support.scm:1453: max */
t9=*((C_word*)lf[506]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t6,C_fix(0),t8);}
else{
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8488 in loop in k8434 in k8146 in k8138 in k8131 in k8124 in walk in build-expression-tree in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_8489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8489,2,t0,t1);}
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8479,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[4];
t5=C_u_i_cdr(t4);
t6=((C_word*)t0)[5];
t7=C_u_i_cdr(t6);
/* support.scm:658: loop */
t8=((C_word*)((C_word*)t0)[6])[1];
f_8445(t8,t3,t5,t7);}

/* k13611 in make-random-name in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13612,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13614,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[3];
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13634,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t4))){
/* support.scm:1394: gensym */
t6=*((C_word*)lf[106]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=C_i_car(t4);
/* support.scm:1393: display */
t7=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t3,t6,t2);}}

/* k13613 in k13611 in make-random-name in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13614,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13616,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* write-char/port */
t3=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(45),((C_word*)t0)[4]);}

/* k13615 in k13613 in k13611 in make-random-name in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13616,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13618,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13630,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1395: current-seconds */
t4=*((C_word*)lf[490]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k13617 in k13615 in k13613 in k13611 in make-random-name in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13618,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13621,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13627,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1396: random */
t4=*((C_word*)lf[489]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,C_fix(1000));}

/* map-loop1976 in k9191 */
static void C_fcall f_9272(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9272,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_a_i_cons(&a,2,t6,t7);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9283,a[2]=((C_word*)t0)[2],a[3]=t9,a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t11=t10;
f_9283(t11,C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t9));}
else{
t11=C_mutate(((C_word *)((C_word*)t0)[4])+1,t9);
t12=t10;
f_9283(t12,t11);}}
else{
t6=((C_word*)((C_word*)t0)[4])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k9268 in k9191 */
static void C_ccall f_9270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:745: append */
t2=*((C_word*)lf[68]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,((C_word*)t0)[3]);}

/* node-class-set! in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_6995(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6995,4,t0,t1,t2,t3);}
t4=C_i_check_structure_2(t2,lf[208],C_SCHEME_FALSE);
/* support.scm:507: ##sys#block-set! */
t5=*((C_word*)lf[212]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(1),t3);}

/* for-each-loop2456 */
static void C_fcall f_10567(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10567,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10576,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:960: g2457 */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k13762 in real-name2 in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm:1441: real-name */
t2=*((C_word*)lf[45]+1);
f_13652(4,t2,((C_word*)t0)[2],t1,((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k14239 in scan-sharp-greater-string in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14240,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14245,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_14245(t5,((C_word*)t0)[3]);}

/* k10575 in for-each-loop2456 */
static void C_ccall f_10576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_10567(t3,((C_word*)t0)[4],t2);}

/* k14248 in loop in k14239 in scan-sharp-greater-string in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14249,2,t0,t1);}
if(C_truep(C_eofp(t1))){
/* support.scm:1544: quit */
t2=*((C_word*)lf[26]+1);
f_4904(3,t2,((C_word*)t0)[2],lf[531]);}
else{
if(C_truep(C_i_char_equalp(t1,C_make_character(10)))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14266,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1546: newline */
t3=*((C_word*)lf[12]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}
else{
if(C_truep(C_i_char_equalp(t1,C_make_character(60)))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14277,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* read-char/port */
t3=*((C_word*)lf[530]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14297,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,((C_word*)t0)[4]);}}}}

/* loop in k14239 in scan-sharp-greater-string in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_14245(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14245,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14249,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* read-char/port */
t3=*((C_word*)lf[530]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k9260 in k9248 in k9194 in k9191 */
static void C_ccall f_9261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:749: build-lambda-list */
t2=*((C_word*)lf[62]+1);
f_5238(5,t2,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* k5806 in string->expr in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_5807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:298: g482 */
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* ##compiler#scan-sharp-greater-string in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14236(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_14236,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14240,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1541: open-output-string */
t4=*((C_word*)lf[51]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6970 in display-analysis-database in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_6972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
t3=((C_word*)t0)[3];
f_6473(t3,t2);}

/* f_6974 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_6974(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6974,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_record4(&a,4,lf[208],t2,t3,t4));}

/* ##compiler#print-program-statistics in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_10587(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10587,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10593,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10598,tmp=(C_word)a,a+=2,tmp);
/* support.scm:981: ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* k9254 in k9248 in k9194 in k9191 */
static void C_ccall f_9255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9255,2,t0,t1);}
t2=C_i_cadddr(((C_word*)t0)[2]);
t3=C_a_i_list4(&a,4,((C_word*)t0)[3],((C_word*)t0)[4],t1,t2);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9207,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t9=C_i_check_list_2(((C_word*)t0)[7],lf[160]);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9216,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9218,a[2]=t7,a[3]=t12,a[4]=t5,a[5]=t8,tmp=(C_word)a,a+=6,tmp));
t14=((C_word*)t12)[1];
f_9218(t14,t10,((C_word*)t0)[7]);}

/* k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_5800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5800,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5802,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm:299: condition-property-accessor */
t3=*((C_word*)lf[558]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[513],lf[514]);}

/* k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_5802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word ab[61],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5802,2,t0,t1);}
t2=C_mutate((C_word*)lf[109]+1 /* (set! ##compiler#string->expr ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5803,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));
t3=C_mutate((C_word*)lf[120]+1 /* (set! ##compiler#decompose-lambda-list ...) */,*((C_word*)lf[121]+1));
t4=C_mutate((C_word*)lf[122]+1 /* (set! ##compiler#llist-length ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5894,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[123]+1 /* (set! ##compiler#llist-match? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5898,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[124]+1 /* (set! ##compiler#expand-profile-lambda ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5939,tmp=(C_word)a,a+=2,tmp));
t7=C_SCHEME_TRUE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_mutate((C_word*)lf[133]+1 /* (set! ##compiler#initialize-analysis-database ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5986,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[144]+1 /* (set! ##compiler#get ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6171,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[146]+1 /* (set! ##compiler#get-all ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6188,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[148]+1 /* (set! ##compiler#put! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6205,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[150]+1 /* (set! ##compiler#collect! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6246,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[151]+1 /* (set! ##compiler#count! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6290,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[152]+1 /* (set! ##compiler#get-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6337,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[153]+1 /* (set! ##compiler#get-line ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6346,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[155]+1 /* (set! ##compiler#get-line-2 ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6355,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[156]+1 /* (set! ##compiler#find-lambda-container ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6390,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate((C_word*)lf[158]+1 /* (set! ##compiler#display-line-number-database ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6413,tmp=(C_word)a,a+=2,tmp));
t20=C_SCHEME_FALSE;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_mutate((C_word*)lf[162]+1 /* (set! ##compiler#display-analysis-database ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6469,a[2]=t21,tmp=(C_word)a,a+=3,tmp));
t23=C_mutate((C_word*)lf[207]+1 /* (set! make-node ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6974,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate((C_word*)lf[209]+1 /* (set! node? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6980,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate((C_word*)lf[210]+1 /* (set! node-class ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6986,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate((C_word*)lf[211]+1 /* (set! node-class-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6995,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[213]+1 /* (set! node-parameters ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7004,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate((C_word*)lf[214]+1 /* (set! node-parameters-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7013,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate((C_word*)lf[215]+1 /* (set! node-subexpressions ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7022,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate((C_word*)lf[216]+1 /* (set! node-subexpressions-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7031,tmp=(C_word)a,a+=2,tmp));
t31=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7040,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t32=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14557,tmp=(C_word)a,a+=2,tmp);
/* support.scm:514: ##sys#register-record-printer */
t33=*((C_word*)lf[557]+1);
((C_proc4)(void*)(*((C_word*)t33+1)))(4,t33,t31,lf[208],t32);}

/* ##compiler#string->expr in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_5803(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5803,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5807,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5812,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm:298: call-with-current-continuation */
t5=*((C_word*)lf[119]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k13619 in k13617 in k13615 in k13613 in k13611 in make-random-name in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13621,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13624,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:1393: get-output-string */
t3=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* f_10593 in print-program-statistics in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_10593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10593,2,t0,t1);}
/* support.scm:983: compute-database-statistics */
t2=*((C_word*)lf[327]+1);
f_10481(3,t2,t1,((C_word*)t0)[2]);}

/* k13622 in k13619 in k13617 in k13615 in k13613 in k13611 in make-random-name in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1392: string->symbol */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k13626 in k13617 in k13615 in k13613 in k13611 in make-random-name in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1393: display */
t2=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,((C_word*)t0)[3]);}

/* f_10598 in print-program-statistics in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_10598(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_10598,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_10604,a[2]=t1,a[3]=t8,a[4]=t7,a[5]=t6,a[6]=t5,a[7]=t4,a[8]=t3,a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* support.scm:984: debugging */
t10=*((C_word*)lf[11]+1);
f_4702(4,t10,t9,lf[338],lf[339]);}

/* ##sys#user-read-hook in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14214(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_14214,4,t0,t1,t2,t3);}
if(C_truep(C_i_char_equalp(C_make_character(62),t2))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14223,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* read-char/port */
t5=*((C_word*)lf[530]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}
else{
/* support.scm:1538: old-hook */
t4=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,t3);}}

/* k14265 in k14248 in loop in k14239 in scan-sharp-greater-string in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1547: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_14245(t2,((C_word*)t0)[3]);}

/* f_5817 */
static void C_ccall f_5817(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5817,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5822,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* support.scm:298: k478 */
t4=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* k6721 in k6718 in k6647 in loop in k6486 */
static void C_ccall f_6722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6722,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6724,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_i_caar(((C_word*)t0)[2]);
/* support.scm:484: display */
t4=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[4]);}

/* k6723 in k6721 in k6718 in k6647 in loop in k6486 */
static void C_ccall f_6724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6724,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6726,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* write-char/port */
t3=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(61),((C_word*)t0)[4]);}

/* k6725 in k6723 in k6721 in k6718 in k6647 in loop in k6486 */
static void C_ccall f_6726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_cdar(((C_word*)t0)[2]);
/* support.scm:484: write */
t3=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[4]);}

/* ##compiler#read/source-info in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14208(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_14208,3,t0,t1,t2);}
/* support.scm:1526: ##sys#read */
t3=*((C_word*)lf[525]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,*((C_word*)lf[520]+1));}

/* k6718 in k6647 in loop in k6486 */
static void C_fcall f_6720(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6720,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[13]+1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6722,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* write-char/port */
t4=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_make_character(9),*((C_word*)lf[13]+1));}
else{
t2=C_eqp(((C_word*)t0)[4],lf[175]);
if(C_truep(t2)){
t3=C_i_cdar(((C_word*)t0)[2]);
t4=C_mutate(((C_word *)((C_word*)t0)[5])+1,t3);
t5=((C_word*)t0)[2];
t6=C_u_i_cdr(t5);
/* support.scm:490: loop */
t7=((C_word*)((C_word*)t0)[6])[1];
f_6627(t7,((C_word*)t0)[7],t6);}
else{
t3=C_eqp(((C_word*)t0)[4],lf[176]);
if(C_truep(t3)){
t4=C_i_cdar(((C_word*)t0)[2]);
t5=C_mutate(((C_word *)((C_word*)t0)[8])+1,t4);
t6=((C_word*)t0)[2];
t7=C_u_i_cdr(t6);
/* support.scm:490: loop */
t8=((C_word*)((C_word*)t0)[6])[1];
f_6627(t8,((C_word*)t0)[7],t7);}
else{
t4=((C_word*)t0)[2];
t5=C_u_i_car(t4);
/* support.scm:489: bomb */
t6=*((C_word*)lf[3]+1);
f_4675(4,t6,((C_word*)t0)[3],lf[177],t5);}}}}

/* ##compiler#make-random-name in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13605(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_13605r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_13605r(t0,t1,t2);}}

static void C_ccall f_13605r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13612,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1393: open-output-string */
t4=*((C_word*)lf[51]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k14276 in k14248 in loop in k14239 in scan-sharp-greater-string in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14277,2,t0,t1);}
t2=t1;
t3=C_eqp(C_make_character(35),t2);
if(C_truep(t3)){
/* support.scm:1551: get-output-string */
t4=*((C_word*)lf[50]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14288,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* write-char/port */
t5=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_make_character(60),((C_word*)t0)[3]);}}

/* f_5812 in string->expr in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_5812(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5812,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5817,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5839,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:298: with-exception-handler */
t5=*((C_word*)lf[118]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* k11018 in k11006 in k11003 in k10966 in k10940 in k10914 in k10891 in k10857 in k10751 in k10737 in repeat */
static void C_fcall f_11019(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11019,NULL,2,t0,t1);}
t2=C_a_i_list(&a,2,lf[95],C_SCHEME_FALSE);
t3=C_a_i_list(&a,4,lf[222],((C_word*)t0)[2],t1,t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_list(&a,3,lf[105],((C_word*)t0)[4],t3));}

/* map-loop2013 in k9254 in k9248 in k9194 in k9191 */
static void C_fcall f_9218(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9218,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9243,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:751: g2019 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* loop in check-signature in k4697 in k4664 in k4662 */
static void C_fcall f_5059(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5059,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t3))){
if(C_truep(C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
/* support.scm:141: err */
t4=((C_word*)t0)[2];
f_5041(t4,t1);}}
else{
t4=C_i_symbolp(t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
if(C_truep(C_i_nullp(t2))){
/* support.scm:143: err */
t5=((C_word*)t0)[2];
f_5041(t5,t1);}
else{
t5=C_i_cdr(t2);
t6=C_i_cdr(t3);
/* support.scm:144: loop */
t8=t1;
t9=t5;
t10=t6;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}}}

/* k9214 in k9254 in k9248 in k9194 in k9191 */
static void C_ccall f_9216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:746: g2005 */
t2=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[129],((C_word*)t0)[4],t1);}

/* k5050 in k5047 in err in check-signature in k4697 in k4664 in k4662 */
static void C_ccall f_5051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:137: quit */
t2=*((C_word*)lf[26]+1);
f_4904(5,t2,((C_word*)t0)[2],lf[44],((C_word*)t0)[3],t1);}

/* k9282 in map-loop1976 in k9191 */
static void C_fcall f_9283(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[3]);
t3=C_slot(((C_word*)t0)[4],C_fix(1));
t4=C_slot(((C_word*)t0)[5],C_fix(1));
t5=((C_word*)((C_word*)t0)[6])[1];
f_9272(t5,((C_word*)t0)[7],t3,t4);}

/* k14006 in map-loop3643 in k13886 in constant-form-eval in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14007,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_13982(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_13982(t6,((C_word*)t0)[5],t5);}}

/* k5827 */
static void C_ccall f_5828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:302: quit */
t2=*((C_word*)lf[26]+1);
f_4904(5,t2,((C_word*)t0)[2],lf[110],((C_word*)t0)[3],t1);}

/* f_5822 */
static void C_ccall f_5822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5822,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5828,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5831,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:304: exn? */
t4=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* k11040 in k11003 in k10966 in k10940 in k10914 in k10891 in k10857 in k10751 in k10737 in repeat */
static void C_fcall f_11042(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11042,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(*((C_word*)lf[348]+1))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,2,lf[377],((C_word*)t0)[3]));}
else{
t2=C_a_i_list(&a,2,lf[378],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_list(&a,2,lf[377],t2));}}
else{
t2=C_eqp(((C_word*)t0)[4],lf[380]);
if(C_truep(t2)){
if(C_truep(*((C_word*)lf[348]+1))){
t3=C_a_i_list(&a,2,lf[381],((C_word*)t0)[3]);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_list(&a,2,lf[377],t3));}
else{
t3=C_a_i_list(&a,2,lf[381],((C_word*)t0)[3]);
t4=C_a_i_list(&a,2,lf[378],t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_list(&a,2,lf[377],t4));}}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11080,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_symbolp(((C_word*)t0)[6]))){
/* support.scm:1100: ##sys#hash-table-ref */
t4=*((C_word*)lf[145]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[393]+1),((C_word*)t0)[6]);}
else{
t4=t3;
f_11080(2,t4,C_SCHEME_FALSE);}}}}

/* k14036 in map-loop3612 in constant-form-eval in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14037,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_14012(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_14012(t6,((C_word*)t0)[5],t5);}}

/* k5829 */
static void C_ccall f_5831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm:305: exn-msg */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[4]);}
else{
/* support.scm:306: ->string */
t2=*((C_word*)lf[58]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[4]);}}

/* f_5839 */
static void C_ccall f_5839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5839,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5841,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5877,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5891,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* tmp14288 */
t5=t2;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k7268 in k7250 in k7248 in k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_7270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7270,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7276,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm:554: walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7080(t3,t2,((C_word*)t0)[4]);}

/* k14287 in k14276 in k14248 in loop in k14239 in scan-sharp-greater-string in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14288,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14290,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[4],((C_word*)t0)[5]);}

/* f_5865 */
static void C_ccall f_5865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5865,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5870,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5876,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:309: read */
t4=*((C_word*)lf[113]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* map-loop3612 in constant-form-eval in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_14012(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14012,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_14037,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:1473: g3618 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* ##compiler#follow-without-loop in k4697 in k4664 in k4662 */
static void C_ccall f_5527(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5527,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5533,a[2]=t4,a[3]=t6,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_5533(t8,t1,t2,C_SCHEME_END_OF_LIST);}

/* k14289 in k14287 in k14276 in k14248 in loop in k14239 in scan-sharp-greater-string in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1555: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_14245(t2,((C_word*)t0)[3]);}

/* k14224 in k14222 in user-read-hook in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14225,2,t0,t1);}
t2=C_a_i_list(&a,2,lf[527],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_list(&a,2,lf[528],t2));}

/* k14222 in user-read-hook in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14223,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_14225,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:1536: scan-sharp-greater-string */
t3=*((C_word*)lf[529]+1);
f_14236(3,t3,t2,((C_word*)t0)[3]);}

/* k14296 in k14248 in loop in k14239 in scan-sharp-greater-string in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1558: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_14245(t2,((C_word*)t0)[3]);}

/* k9248 in k9194 in k9191 */
static void C_ccall f_9249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9249,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9255,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9261,a[2]=t3,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[10])){
t5=((C_word*)t0)[10];
t6=((C_word*)t0)[4];
/* support.scm:710: alist-ref */
t7=*((C_word*)lf[283]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t4,t5,t6,*((C_word*)lf[25]+1),t5);}
else{
/* support.scm:749: build-lambda-list */
t5=*((C_word*)lf[62]+1);
f_5238(5,t5,t3,((C_word*)t0)[8],((C_word*)t0)[9],C_SCHEME_FALSE);}}

/* k5047 in err in check-signature in k4697 in k4664 in k4662 */
static void C_ccall f_5048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5048,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5051,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=C_i_cdr(((C_word*)t0)[3]);
/* support.scm:139: map-llist */
t4=*((C_word*)lf[42]+1);
f_4999(4,t4,t2,*((C_word*)lf[45]+1),t3);}

/* err in check-signature in k4697 in k4664 in k4662 */
static void C_fcall f_5041(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5041,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5048,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm:138: real-name */
t3=*((C_word*)lf[45]+1);
f_13652(3,t3,t2,((C_word*)t0)[3]);}

/* k9242 in map-loop2013 in k9254 in k9248 in k9194 in k9191 */
static void C_ccall f_9243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9243,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_9218(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_9218(t6,((C_word*)t0)[5],t5);}}

/* ##compiler#dump-nodes in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14042(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_14042,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_14046,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_14051,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_14051(t7,t3,C_fix(0),t2);}

/* k14045 in dump-nodes in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1509: newline */
t2=*((C_word*)lf[12]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k7275 in k7268 in k7250 in k7248 in k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_7276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7276,2,t0,t1);}
t2=C_a_i_list1(&a,1,t1);
/* support.scm:553: append */
t3=*((C_word*)lf[68]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],((C_word*)t0)[3],t2);}

/* map-loop1143 in k7250 in k7248 in k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_7278(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7278,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7303,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:553: g1149 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5514 in fold in k5488 in fold-inner in k4697 in k4664 in k4662 */
static void C_ccall f_5515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5515,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_u_i_car(t2);
t4=C_a_i_list2(&a,2,t1,t3);
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[4],t4);}

/* k7250 in k7248 in k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_7252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7252,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7255,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7257,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t8=C_i_cadr(((C_word*)t0)[5]);
t9=C_i_check_list_2(t8,lf[160]);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7270,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7278,a[2]=t6,a[3]=t12,a[4]=t4,a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t14=((C_word*)t12)[1];
f_7278(t14,t10,t8);}

/* k11003 in k10966 in k10940 in k10914 in k10891 in k10857 in k10751 in k10737 in repeat */
static void C_fcall f_11005(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11005,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11007,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1084: gensym */
t3=*((C_word*)lf[106]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=C_eqp(((C_word*)t0)[4],lf[379]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11042,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_11042(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[4],lf[394]);
t5=t3;
f_11042(t5,(C_truep(t4)?t4:C_eqp(((C_word*)t0)[4],lf[395])));}}}

/* k11006 in k11003 in k10966 in k10940 in k10914 in k10891 in k10857 in k10751 in k10737 in repeat */
static void C_ccall f_11007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11007,2,t0,t1);}
t2=C_a_i_list(&a,2,t1,((C_word*)t0)[2]);
t3=C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11019,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(*((C_word*)lf[348]+1))){
t5=t4;
f_11019(t5,C_a_i_list(&a,2,lf[377],t1));}
else{
t5=C_a_i_list(&a,2,lf[378],t1);
t6=t4;
f_11019(t6,C_a_i_list(&a,2,lf[377],t5));}}

/* map-loop1411 in k7953 in k7950 */
static void C_fcall f_7920(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7920,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7945,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:616: g1417 */
t5=((C_word*)((C_word*)t0)[5])[1];
f_7080(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5026 in loop in map-llist in k4697 in k4664 in k4662 */
static void C_ccall f_5027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5027,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5030,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[3];
t4=C_u_i_cdr(t3);
/* support.scm:133: loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_5005(t5,t2,t4);}

/* loop in follow-without-loop in k4697 in k4664 in k4662 */
static void C_fcall f_5533(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5533,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_member(t2,t3))){
/* support.scm:241: abort */
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t1);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5548,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm:242: proc */
t5=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t2,t4);}}

/* k7916 in k7953 in k7950 */
static void C_ccall f_7918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:605: g1392 */
t2=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[248],((C_word*)t0)[4],t1);}

/* k13632 in k13611 in make-random-name in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1393: display */
t2=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,((C_word*)t0)[3]);}

/* k13629 in k13615 in k13613 in k13611 in make-random-name in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1393: display */
t2=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,((C_word*)t0)[3]);}

/* f_7903 */
static void C_ccall f_7903(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7903,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_record4(&a,4,lf[208],t2,t3,t4));}

/* loop in dump-nodes in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_14051(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14051,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14054,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14060,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* support.scm:1494: g3696 */
t6=t4;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}

/* f_7901 in k7786 in k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_7901(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7901,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7903,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7951,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7970,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7976,a[2]=((C_word*)t0)[4],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* support.scm:607: g1400 */
t8=t6;
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,t2,lf[251]);}

/* f_14054 in loop in dump-nodes in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14054(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_14054,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_slot(t2,C_fix(1)));}

/* k13664 in k13659 in resolve in real-name in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[3]));}

/* k13659 in resolve in real-name in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13660,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13665,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1416: ##sys#hash-table-ref */
t3=*((C_word*)lf[145]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[492]+1),t1);}
else{
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* f_5882 */
static void C_ccall f_5882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5882,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* k7961 in k7955 in k7950 */
static void C_ccall f_7963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7963,2,t0,t1);}
t2=((C_word*)t0)[2];
f_7954(2,t2,C_a_i_list2(&a,2,((C_word*)t0)[3],t1));}

/* ##compiler#set-real-name! in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13645(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_13645,4,t0,t1,t2,t3);}
/* support.scm:1407: ##sys#hash-table-set! */
t4=*((C_word*)lf[149]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,*((C_word*)lf[492]+1),t2,t3);}

/* ##compiler#constant? in k4697 in k4664 in k4662 */
static void C_ccall f_5573(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5573,3,t0,t1,t2);}
t3=C_i_numberp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=C_charp(t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=C_i_stringp(t2);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=C_booleanp(t2);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t7=C_eofp(t2);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
if(C_truep(C_i_pairp(t2))){
t8=t2;
t9=C_u_i_car(t8);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_eqp(lf[95],t9));}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}}}}}}

/* k5570 in k5567 */
static void C_ccall f_5571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:245: string<? */
t2=*((C_word*)lf[92]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* k7953 in k7950 */
static void C_ccall f_7954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7954,2,t0,t1);}
t2=C_a_i_list2(&a,2,((C_word*)t0)[2],t1);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=((C_word*)t0)[3];
t8=C_i_check_list_2(t7,lf[160]);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7918,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7920,a[2]=t6,a[3]=t11,a[4]=t4,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_7920(t13,t9,t7);}

/* k7955 in k7950 */
static void C_ccall f_7956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7956,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7963,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t1;
t4=((C_word*)t0)[2];
f_7954(2,t4,C_a_i_list2(&a,2,((C_word*)t0)[3],t3));}
else{
/* support.scm:614: ##sys#symbol->qualified-string */
t3=*((C_word*)lf[249]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}}

/* k7950 */
static void C_fcall f_7951(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7951,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7954,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[6])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7956,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* support.scm:612: real-name */
t4=*((C_word*)lf[45]+1);
f_13652(3,t4,t3,((C_word*)t0)[7]);}
else{
/* support.scm:615: ##sys#symbol->qualified-string */
t3=*((C_word*)lf[249]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[7]);}}

/* k8782 in map-loop1763 in k8649 in k8146 in k8138 in k8131 in k8124 in walk in build-expression-tree in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_8783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8783,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8758(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8758(t6,((C_word*)t0)[5],t5);}}

/* k7944 in map-loop1411 in k7953 in k7950 */
static void C_ccall f_7945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7945,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7920(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7920(t6,((C_word*)t0)[5],t5);}}

/* k5890 */
static void C_ccall f_5891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tmp24289 */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],t1);}

/* ##compiler#llist-length in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_5894(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5894,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_u_i_length(t2));}

/* ##compiler#llist-match? in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_5898(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5898,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5904,tmp=(C_word)a,a+=2,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_5904(t2,t3));}

/* ##compiler#get-list in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_6337(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6337,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6341,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm:408: get */
t6=*((C_word*)lf[144]+1);
f_6171(5,t6,t5,t2,t3,t4);}

/* f_5841 */
static void C_ccall f_5841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5841,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5844,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5865,tmp=(C_word)a,a+=2,tmp);
/* support.scm:307: with-input-from-string */
t4=*((C_word*)lf[117]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}

/* f15836 in print-version in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f15836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1614: print */
t2=*((C_word*)lf[291]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5843 */
static void C_ccall f_5844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5844,2,t0,t1);}
if(C_truep(C_i_nullp(t1))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[111]);}
else{
t2=C_i_cdr(t1);
if(C_truep(C_i_nullp(t2))){
t3=t1;
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_u_i_car(t3));}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,lf[112],t1));}}}

/* loop in find-lambda-container in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_6396(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6396,NULL,3,t0,t1,t2);}
t3=C_eqp(t2,((C_word*)t0)[2]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6405,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm:427: get */
t5=*((C_word*)lf[144]+1);
f_6171(5,t5,t4,((C_word*)t0)[4],t2,lf[157]);}}

/* ##compiler#find-lambda-container in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_6390(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6390,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6396,a[2]=t3,a[3]=t6,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_6396(t8,t1,t2);}

/* f_5870 */
static void C_ccall f_5870(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5870,3,t0,t1,t2);}
/* support.scm:309: read */
t3=*((C_word*)lf[113]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* f_5877 */
static void C_ccall f_5877(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_5877r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5877r(t0,t1,t2);}}

static void C_ccall f_5877r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5882,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm:298: k478 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* k5875 */
static void C_ccall f_5876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:309: unfold */
t2=*((C_word*)lf[114]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],*((C_word*)lf[115]+1),*((C_word*)lf[116]+1),((C_word*)t0)[3],t1);}

/* f_7257 in k7250 in k7248 in k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_7257(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7257,3,t0,t1,t2);}
t3=C_i_cadr(t2);
/* support.scm:553: walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_7080(t4,t1,t3);}

/* k7254 in k7250 in k7248 in k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_7255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:547: g1109 */
t2=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[105],((C_word*)t0)[4],t1);}

/* f_7230 in k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_7230(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7230,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_record4(&a,4,lf[208],t2,t3,t4));}

/* ##compiler#read-info-hook in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14170(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_14170,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14174,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14177,a[2]=t3,a[3]=t5,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t7=C_eqp(lf[523],t2);
if(C_truep(t7)){
t8=C_i_car(t3);
t9=t6;
f_14177(t9,C_i_symbolp(t8));}
else{
t8=t6;
f_14177(t8,C_SCHEME_FALSE);}}

/* k14173 in read-info-hook in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}

/* map-loop1737 in k8649 in k8146 in k8138 in k8131 in k8124 in walk in build-expression-tree in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_8716(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8716,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8741,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:671: g1743 */
t5=((C_word*)((C_word*)t0)[5])[1];
f_8117(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8712 in k8649 in k8146 in k8138 in k8131 in k8124 in walk in build-expression-tree in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_8714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:671: cons* */
t2=*((C_word*)lf[265]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* map-loop2160 in walk in sexpr->node in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_9617(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9617,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9642,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:775: g2166 */
t5=((C_word*)((C_word*)t0)[5])[1];
f_9592(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k9613 in walk in sexpr->node in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_9615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:775: g2153 */
t2=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],t1);}

/* f_7238 in k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_7238(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7238,3,t0,t1,t2);}
t3=C_eqp(lf[229],t2);
if(C_truep(t3)){
/* support.scm:551: gensym */
t4=*((C_word*)lf[106]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t1);}
else{
t4=t2;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k13694 in k13753 in k13669 in real-name in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13695,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13697,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_13697(t5,((C_word*)t0)[4],((C_word*)t0)[5],C_fix(0),t1);}

/* k12511 in k12407 in finish-foreign-result in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_12513(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12513,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_cadr(((C_word*)t0)[2]);
/* support.scm:1233: finish-foreign-result */
t3=*((C_word*)lf[442]+1);
f_12404(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[4]);}
else{
t2=C_i_length(((C_word*)t0)[2]);
t3=C_eqp(C_fix(3),t2);
if(C_truep(t3)){
t4=C_i_car(((C_word*)t0)[2]);
t5=C_eqp(t4,lf[383]);
t6=(C_truep(t5)?t5:C_eqp(t4,lf[384]));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12537,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm:1237: gensym */
t8=*((C_word*)lf[106]+1);
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t7=C_eqp(t4,lf[387]);
if(C_truep(t7)){
t8=C_i_caddr(((C_word*)t0)[2]);
t9=C_a_i_list(&a,2,lf[95],lf[385]);
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_a_i_list(&a,4,lf[452],t8,t9,((C_word*)t0)[4]));}
else{
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,((C_word*)t0)[4]);}}}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[4]);}}}

/* loop in k13694 in k13753 in k13669 in real-name in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_13697(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13697,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep(C_i_greaterp(t3,*((C_word*)lf[493]+1)))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13710,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=C_a_i_cons(&a,2,lf[496],t2);
/* support.scm:1428: reverse */
t7=*((C_word*)lf[89]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}
else{
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13718,a[2]=t4,a[3]=t1,a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
/* support.scm:1430: resolve */
f_13656(t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_13751,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm:1436: reverse */
t6=*((C_word*)lf[89]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}}}

/* k14175 in read-info-hook in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_14177(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14177,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_14189,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm:1520: conc */
t4=*((C_word*)lf[502]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,*((C_word*)lf[521]+1),lf[522],((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k6340 in get-list in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_6341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* ##compiler#get-line in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_6346(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6346,3,t0,t1,t2);}
t3=C_i_car(t2);
/* support.scm:415: get */
t4=*((C_word*)lf[144]+1);
f_6171(5,t4,t1,*((C_word*)lf[154]+1),t3,t2);}

/* k7248 in k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_7249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7249,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7252,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7308,a[2]=((C_word*)t0)[7],a[3]=t4,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_7308(t6,t2,t1);}

/* ##compiler#get-line-2 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_6355(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6355,3,t0,t1,t2);}
t3=C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6361,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm:419: ##sys#hash-table-ref */
t5=*((C_word*)lf[145]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[154]+1),t3);}

/* k13669 in real-name in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13670,2,t0,t1);}
t2=t1;
if(C_truep(t2)){
if(C_truep(C_i_pairp(((C_word*)t0)[2]))){
t3=((C_word*)t0)[2];
t4=C_u_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13754,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* support.scm:1423: ##sys#symbol->qualified-string */
t6=*((C_word*)lf[249]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t1);}
else{
/* support.scm:1437: ##sys#symbol->qualified-string */
t3=*((C_word*)lf[249]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[4],t1);}}
else{
/* support.scm:1420: ##sys#symbol->qualified-string */
t3=*((C_word*)lf[249]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[4],((C_word*)t0)[5]);}}

/* k9714 */
static void C_ccall f_9715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:808: newline */
t2=*((C_word*)lf[12]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* f_9712 in k9710 */
static void C_ccall f_9712(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9712,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9715,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm:807: pp */
t4=*((C_word*)lf[296]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k9710 */
static void C_ccall f_9711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9711,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9712,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9720,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:809: reverse */
t4=*((C_word*)lf[89]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)((C_word*)t0)[3])[1]);}

/* f_12072 in k12067 in k12061 in k12050 */
static void C_ccall f_12072(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12072,3,t0,t1,t2);}
if(C_truep(C_i_vectorp(t2))){
t3=C_i_vector_ref(t2,C_fix(0));
/* support.scm:1204: next */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t3=t2;
/* support.scm:1204: next */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}}

/* for-each-loop2220 in k9719 in k9710 */
static void C_fcall f_9728(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9728,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9737,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:805: g2221 */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k9721 in k9719 in k9710 */
static void C_ccall f_9723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:810: print */
t2=*((C_word*)lf[291]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[297]);}

/* map-loop1763 in k8649 in k8146 in k8138 in k8131 in k8124 in walk in build-expression-tree in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_8758(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8758,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8783,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:672: g1769 */
t5=((C_word*)((C_word*)t0)[5])[1];
f_8117(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8754 in k8649 in k8146 in k8138 in k8131 in k8124 in walk in build-expression-tree in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_8756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:672: append */
t2=*((C_word*)lf[68]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* k9719 in k9710 */
static void C_ccall f_9720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9720,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9723,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9728,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_9728(t6,t2,t1);}

/* k8749 in k8649 in k8146 in k8138 in k8131 in k8124 in walk in build-expression-tree in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_8750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8750,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* resolve in real-name in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_13656(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13656,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13660,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1414: ##sys#hash-table-ref */
t4=*((C_word*)lf[145]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[492]+1),t2);}

/* ##compiler#real-name in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_13652(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_13652r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_13652r(t0,t1,t2,t3);}}

static void C_ccall f_13652r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13656,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13670,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* support.scm:1419: resolve */
f_13656(t5,t2);}

/* k9736 in for-each-loop2220 in k9719 in k9710 */
static void C_ccall f_9737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_9728(t3,((C_word*)t0)[4],t2);}

/* k14191 in k14188 in k14175 in read-info-hook in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14192,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=C_a_i_cons(&a,2,C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]),t2);
/* support.scm:1516: ##sys#hash-table-set! */
t4=*((C_word*)lf[149]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[4],*((C_word*)lf[154]+1),((C_word*)t0)[5],t3);}
else{
t2=C_a_i_cons(&a,2,C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]),C_SCHEME_END_OF_LIST);
/* support.scm:1516: ##sys#hash-table-set! */
t3=*((C_word*)lf[149]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[4],*((C_word*)lf[154]+1),((C_word*)t0)[5],t2);}}

/* k14188 in k14175 in read-info-hook in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_14189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14189,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14192,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[2];
t4=C_u_i_car(t3);
/* support.scm:1521: ##sys#hash-table-ref */
t5=*((C_word*)lf[145]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,*((C_word*)lf[154]+1),t4);}

/* k9748 */
static void C_ccall f_9749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:803: print */
t2=*((C_word*)lf[291]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[2],lf[298],t1,lf[299],*((C_word*)lf[300]+1),lf[301]);}

/* k9755 */
static void C_ccall f_9757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9757,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_assq(lf[172],((C_word*)t0)[2]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9865,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9871,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9873,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9879,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* support.scm:784: g2196 */
t7=t5;
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[4],lf[308]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* f_9751 in emit-global-inline-file in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_9751(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9751,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9757,a[2]=t3,a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* support.scm:782: variable-visible? */
t5=*((C_word*)lf[309]+1);
f_14367(3,t5,t4,t2);}

/* k8740 in map-loop1737 in k8649 in k8146 in k8138 in k8131 in k8124 in walk in build-expression-tree in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_8741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8741,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8716(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8716(t6,((C_word*)t0)[5],t5);}}

/* k12667 in k12646 in foreign-type->scrutiny-type in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_12669(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12669,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[227]);}
else{
t2=C_eqp(((C_word*)t0)[3],lf[352]);
t3=(C_truep(t2)?t2:C_eqp(((C_word*)t0)[3],lf[419]));
if(C_truep(t3)){
t4=((C_word*)t0)[4];
t5=C_eqp(t4,lf[457]);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?lf[420]:lf[352]));}
else{
t4=C_eqp(((C_word*)t0)[3],lf[355]);
t5=(C_truep(t4)?t4:C_eqp(((C_word*)t0)[3],lf[357]));
if(C_truep(t5)){
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[236]);}
else{
t6=C_eqp(((C_word*)t0)[3],lf[354]);
if(C_truep(t6)){
t7=((C_word*)t0)[4];
t8=C_eqp(t7,lf[457]);
t9=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_truep(t8)?lf[458]:lf[354]));}
else{
t7=C_eqp(((C_word*)t0)[3],lf[358]);
if(C_truep(t7)){
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[354]);}
else{
t8=C_eqp(((C_word*)t0)[3],lf[359]);
if(C_truep(t8)){
t9=((C_word*)t0)[4];
t10=C_eqp(t9,lf[457]);
t11=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_truep(t10)?lf[459]:lf[359]));}
else{
t9=C_eqp(((C_word*)t0)[3],lf[361]);
if(C_truep(t9)){
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,lf[359]);}
else{
t10=C_eqp(((C_word*)t0)[3],lf[362]);
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12741,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t10)){
t12=t11;
f_12741(t12,t10);}
else{
t12=C_eqp(((C_word*)t0)[3],lf[412]);
if(C_truep(t12)){
t13=t11;
f_12741(t13,t12);}
else{
t13=C_eqp(((C_word*)t0)[3],lf[413]);
if(C_truep(t13)){
t14=t11;
f_12741(t14,t13);}
else{
t14=C_eqp(((C_word*)t0)[3],lf[414]);
if(C_truep(t14)){
t15=t11;
f_12741(t15,t14);}
else{
t15=C_eqp(((C_word*)t0)[3],lf[415]);
if(C_truep(t15)){
t16=t11;
f_12741(t16,t15);}
else{
t16=C_eqp(((C_word*)t0)[3],lf[416]);
if(C_truep(t16)){
t17=t11;
f_12741(t17,t16);}
else{
t17=C_eqp(((C_word*)t0)[3],lf[417]);
t18=t11;
f_12741(t18,(C_truep(t17)?t17:C_eqp(((C_word*)t0)[3],lf[418])));}}}}}}}}}}}}}}

/* map-loop1527 in k8146 in k8138 in k8131 in k8124 in walk in build-expression-tree in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_8207(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8207,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8232,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:631: g1533 */
t5=((C_word*)((C_word*)t0)[5])[1];
f_8117(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k12067 in k12061 in k12050 */
static void C_ccall f_12068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12068,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12072,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:1202: g3132 */
t3=t2;
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[3],t1);}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[4];
t3=C_u_i_car(t2);
t4=C_eqp(t3,lf[382]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12102,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=t5;
f_12102(t6,t4);}
else{
t6=C_eqp(t3,lf[390]);
if(C_truep(t6)){
t7=t5;
f_12102(t7,t6);}
else{
t7=C_eqp(t3,lf[391]);
if(C_truep(t7)){
t8=t5;
f_12102(t8,t7);}
else{
t8=C_eqp(t3,lf[373]);
if(C_truep(t8)){
t9=t5;
f_12102(t9,t8);}
else{
t9=C_eqp(t3,lf[375]);
t10=t5;
f_12102(t10,(C_truep(t9)?t9:C_eqp(t3,lf[392])));}}}}}
else{
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[4];
/* support.scm:1188: quit */
t4=*((C_word*)lf[26]+1);
f_4904(4,t4,t2,lf[440],t3);}}}

/* k8203 in k8146 in k8138 in k8131 in k8124 in walk in build-expression-tree in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_8205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8205,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,lf[259],t2));}

/* k12061 in k12050 */
static void C_fcall f_12063(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12063,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=C_i_foreign_fixnum_argumentp(C_fix(2));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,stub351(C_SCHEME_UNDEFINED,t3));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12068,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_symbolp(((C_word*)t0)[4]))){
/* support.scm:1202: ##sys#hash-table-ref */
t3=*((C_word*)lf[145]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[393]+1),((C_word*)t0)[4]);}
else{
t3=t2;
f_12068(2,t3,C_SCHEME_FALSE);}}}

/* k10190 in k10163 in k10155 in k10148 in walk in expression-has-side-effects? in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_10192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10192,2,t0,t1);}
t2=C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10178,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm:875: find */
t4=*((C_word*)lf[317]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t3,*((C_word*)lf[318]+1));}

/* k8231 in map-loop1527 in k8146 in k8138 in k8131 in k8124 in walk in build-expression-tree in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_8232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8232,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8207(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8207(t6,((C_word*)t0)[5],t5);}}

/* f_10186 in k10163 in k10155 in k10148 in walk in expression-has-side-effects? in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_10186(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10186,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_slot(t2,C_fix(2)));}

/* k10183 */
static void C_ccall f_10184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_eqp(((C_word*)t0)[3],t1));}

/* f_10178 in k10190 in k10163 in k10155 in k10148 in walk in expression-has-side-effects? in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_10178(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10178,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10184,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm:876: foreign-callback-stub-id */
t4=*((C_word*)lf[316]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k10689 in for-each-loop2565 */
static void C_ccall f_10690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_10681(t3,((C_word*)t0)[4],t2);}

/* ##compiler#simple-lambda-node? in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_10235(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10235,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10238,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10244,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:882: g2383 */
t5=t3;
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* f_7602 in k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_7602(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7602,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_record4(&a,4,lf[208],t2,t3,t4));}

/* k7647 in map-loop1247 in k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_7648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7648,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7623(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_7623(t6,((C_word*)t0)[5],t5);}}

/* k10242 in simple-lambda-node? in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_10244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10244,2,t0,t1);}
t2=C_i_caddr(t1);
t3=(C_truep(C_i_pairp(t2))?C_u_i_car(t2):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=C_u_i_cdr(t1);
if(C_truep(C_u_i_car(t4))){
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10261,a[2]=t3,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_10261(3,t8,((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* f_10238 in simple-lambda-node? in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_10238(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10238,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_slot(t2,C_fix(2)));}

/* map-loop1247 in k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_fcall f_7623(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7623,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7648,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* support.scm:585: g1253 */
t5=((C_word*)((C_word*)t0)[5])[1];
f_7080(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7619 in k7098 in walk in build-node-graph in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_7621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:585: g1240 */
t2=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],t1);}

/* k8416 in k8146 in k8138 in k8131 in k8124 in walk in build-expression-tree in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_8417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8417,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,3,lf[263],((C_word*)t0)[3],t1));}

/* k4664 in k4662 */
static void C_ccall f_4665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4665,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1 /* (set! ##compiler#compiler-cleanup-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4669,tmp=(C_word)a,a+=2,tmp));
t3=C_set_block_item(lf[1] /* ##compiler#debugging-chicken */,0,C_SCHEME_END_OF_LIST);
t4=C_set_block_item(lf[2] /* ##compiler#disabled-warnings */,0,C_SCHEME_END_OF_LIST);
t5=C_mutate((C_word*)lf[3]+1 /* (set! ##compiler#bomb ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4675,tmp=(C_word)a,a+=2,tmp));
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4699,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:53: open-output-string */
t7=*((C_word*)lf[51]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k4662 */
static void C_ccall f_4663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4663,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4665,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* ##compiler#compiler-cleanup-hook in k4664 in k4662 */
static void C_ccall f_4669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4669,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k8374 in map-loop1590 in k8289 in k8146 in k8138 in k8131 in k8124 in walk in build-expression-tree in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_8375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8375,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8350(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_8350(t6,((C_word*)t0)[5],t5);}}

/* k5308 in loop in k5288 in c-ify-string in k4697 in k4664 in k4662 */
static void C_fcall f_5310(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5310,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5316,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_fixnum_lessp(((C_word*)t0)[5],C_fix(8)))){
t3=t2;
f_5316(t3,lf[71]);}
else{
t3=C_fixnum_lessp(((C_word*)t0)[5],C_fix(64));
t4=t2;
f_5316(t4,(C_truep(t3)?lf[72]:C_SCHEME_END_OF_LIST));}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5346,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[3];
t4=C_u_i_cdr(t3);
/* support.scm:198: loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_5291(t5,t2,t4);}}

/* f_10264 in rec in k10242 in simple-lambda-node? in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_10264(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10264,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_slot(t2,C_fix(1)));}

/* rec in k10242 in simple-lambda-node? in k7039 in k5801 in k5799 in k4697 in k4664 in k4662 */
static void C_ccall f_10261(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10261,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10264,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10270,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* support.scm:888: g2398 */
t5=t3;
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[904] = {
{"f_5319:support_2escm",(void*)f_5319},
{"f_5316:support_2escm",(void*)f_5316},
{"f_7682:support_2escm",(void*)f_7682},
{"f_10769:support_2escm",(void*)f_10769},
{"f_4688:support_2escm",(void*)f_4688},
{"f_8350:support_2escm",(void*)f_8350},
{"f_9708:support_2escm",(void*)f_9708},
{"f_7661:support_2escm",(void*)f_7661},
{"f_4675:support_2escm",(void*)f_4675},
{"f_5322:support_2escm",(void*)f_5322},
{"f_7699:support_2escm",(void*)f_7699},
{"f_5327:support_2escm",(void*)f_5327},
{"f_13931:support_2escm",(void*)f_13931},
{"f_10753:support_2escm",(void*)f_10753},
{"f_13939:support_2escm",(void*)f_13939},
{"f_4699:support_2escm",(void*)f_4699},
{"f_7788:support_2escm",(void*)f_7788},
{"f_7789:support_2escm",(void*)f_7789},
{"f_8396:support_2escm",(void*)f_8396},
{"f_12647:support_2escm",(void*)f_12647},
{"f_12643:support_2escm",(void*)f_12643},
{"f_6361:support_2escm",(void*)f_6361},
{"f_6363:support_2escm",(void*)f_6363},
{"f_12537:support_2escm",(void*)f_12537},
{"f_6367:support_2escm",(void*)f_6367},
{"f_10715:support_2escm",(void*)f_10715},
{"f_10710:support_2escm",(void*)f_10710},
{"f_9207:support_2escm",(void*)f_9207},
{"f_4802:support_2escm",(void*)f_4802},
{"f_4809:support_2escm",(void*)f_4809},
{"f_4806:support_2escm",(void*)f_4806},
{"f_4800:support_2escm",(void*)f_4800},
{"f_8651:support_2escm",(void*)f_8651},
{"f_8657:support_2escm",(void*)f_8657},
{"f_10739:support_2escm",(void*)f_10739},
{"f_5385:support_2escm",(void*)f_5385},
{"f_8641:support_2escm",(void*)f_8641},
{"f_10704:support_2escm",(void*)f_10704},
{"f_4828:support_2escm",(void*)f_4828},
{"f_6649:support_2escm",(void*)f_6649},
{"f_4812:support_2escm",(void*)f_4812},
{"f_4814:support_2escm",(void*)f_4814},
{"f_4816:support_2escm",(void*)f_4816},
{"f_5731:support_2escm",(void*)f_5731},
{"f_5739:support_2escm",(void*)f_5739},
{"f_5733:support_2escm",(void*)f_5733},
{"f_7771:support_2escm",(void*)f_7771},
{"f_10893:support_2escm",(void*)f_10893},
{"f_5762:support_2escm",(void*)f_5762},
{"f_5346:support_2escm",(void*)f_5346},
{"f_6639:support_2escm",(void*)f_6639},
{"f_10968:support_2escm",(void*)f_10968},
{"f_7333:support_2escm",(void*)f_7333},
{"f_10970:support_2escm",(void*)f_10970},
{"f_9040:support_2escm",(void*)f_9040},
{"f_9049:support_2escm",(void*)f_9049},
{"f_9043:support_2escm",(void*)f_9043},
{"f_9032:support_2escm",(void*)f_9032},
{"f_6039:support_2escm",(void*)f_6039},
{"f_6038:support_2escm",(void*)f_6038},
{"f_9023:support_2escm",(void*)f_9023},
{"f_6041:support_2escm",(void*)f_6041},
{"f_7373:support_2escm",(void*)f_7373},
{"f_9018:support_2escm",(void*)f_9018},
{"f_8666:support_2escm",(void*)f_8666},
{"f_8664:support_2escm",(void*)f_8664},
{"f_7345:support_2escm",(void*)f_7345},
{"f_9086:support_2escm",(void*)f_9086},
{"f_8691:support_2escm",(void*)f_8691},
{"f_10942:support_2escm",(void*)f_10942},
{"f_9070:support_2escm",(void*)f_9070},
{"f_13982:support_2escm",(void*)f_13982},
{"f_13980:support_2escm",(void*)f_13980},
{"f_9063:support_2escm",(void*)f_9063},
{"f_7360:support_2escm",(void*)f_7360},
{"f_5784:support_2escm",(void*)f_5784},
{"f_5788:support_2escm",(void*)f_5788},
{"f_12043:support_2escm",(void*)f_12043},
{"f_9050:support_2escm",(void*)f_9050},
{"f_9056:support_2escm",(void*)f_9056},
{"f_9057:support_2escm",(void*)f_9057},
{"f_5776:support_2escm",(void*)f_5776},
{"f_8623:support_2escm",(void*)f_8623},
{"f_8620:support_2escm",(void*)f_8620},
{"f_13962:support_2escm",(void*)f_13962},
{"f_13967:support_2escm",(void*)f_13967},
{"f_6651:support_2escm",(void*)f_6651},
{"f_12030:support_2escm",(void*)f_12030},
{"f_7388:support_2escm",(void*)f_7388},
{"f_10270:support_2escm",(void*)f_10270},
{"f_5715:support_2escm",(void*)f_5715},
{"f_13954:support_2escm",(void*)f_13954},
{"f_10283:support_2escm",(void*)f_10283},
{"f_10277:support_2escm",(void*)f_10277},
{"f_10916:support_2escm",(void*)f_10916},
{"f_12052:support_2escm",(void*)f_12052},
{"f_11144:support_2escm",(void*)f_11144},
{"f_9095:support_2escm",(void*)f_9095},
{"f_9092:support_2escm",(void*)f_9092},
{"f_13920:support_2escm",(void*)f_13920},
{"f_12025:support_2escm",(void*)f_12025},
{"f_13915:support_2escm",(void*)f_13915},
{"f_13913:support_2escm",(void*)f_13913},
{"f_5700:support_2escm",(void*)f_5700},
{"f_13902:support_2escm",(void*)f_13902},
{"f_13907:support_2escm",(void*)f_13907},
{"f_13972:support_2escm",(void*)f_13972},
{"f_5986:support_2escm",(void*)f_5986},
{"f_11116:support_2escm",(void*)f_11116},
{"f_11114:support_2escm",(void*)f_11114},
{"f_8308:support_2escm",(void*)f_8308},
{"f_8306:support_2escm",(void*)f_8306},
{"f_8303:support_2escm",(void*)f_8303},
{"f_8300:support_2escm",(void*)f_8300},
{"f_14302:support_2escm",(void*)f_14302},
{"f_5276:support_2escm",(void*)f_5276},
{"f_5265:support_2escm",(void*)f_5265},
{"f_14325:support_2escm",(void*)f_14325},
{"f_8319:support_2escm",(void*)f_8319},
{"f_14328:support_2escm",(void*)f_14328},
{"f_9352:support_2escm",(void*)f_9352},
{"f_9354:support_2escm",(void*)f_9354},
{"f_9343:support_2escm",(void*)f_9343},
{"f_9339:support_2escm",(void*)f_9339},
{"f_9390:support_2escm",(void*)f_9390},
{"f_7051:support_2escm",(void*)f_7051},
{"f_7065:support_2escm",(void*)f_7065},
{"f_9365:support_2escm",(void*)f_9365},
{"f_9363:support_2escm",(void*)f_9363},
{"f_7062:support_2escm",(void*)f_7062},
{"f_13173:support_2escm",(void*)f_13173},
{"f_13179:support_2escm",(void*)f_13179},
{"f_13177:support_2escm",(void*)f_13177},
{"f_7976:support_2escm",(void*)f_7976},
{"f_7970:support_2escm",(void*)f_7970},
{"f_10096:support_2escm",(void*)f_10096},
{"f_10090:support_2escm",(void*)f_10090},
{"f_7094:support_2escm",(void*)f_7094},
{"f_13195:support_2escm",(void*)f_13195},
{"f_10321:support_2escm",(void*)f_10321},
{"f_13182:support_2escm",(void*)f_13182},
{"f_13189:support_2escm",(void*)f_13189},
{"f_13188:support_2escm",(void*)f_13188},
{"f_10332:support_2escm",(void*)f_10332},
{"f_10338:support_2escm",(void*)f_10338},
{"f_8607:support_2escm",(void*)f_8607},
{"f_5218:support_2escm",(void*)f_5218},
{"f_5215:support_2escm",(void*)f_5215},
{"f_10075:support_2escm",(void*)f_10075},
{"f_10348:support_2escm",(void*)f_10348},
{"f_7031:support_2escm",(void*)f_7031},
{"f_6131:support_2escm",(void*)f_6131},
{"f_14349:support_2escm",(void*)f_14349},
{"f_14346:support_2escm",(void*)f_14346},
{"f_7048:support_2escm",(void*)f_7048},
{"f_9969:support_2escm",(void*)f_9969},
{"f_10652:support_2escm",(void*)f_10652},
{"f_10354:support_2escm",(void*)f_10354},
{"f_10656:support_2escm",(void*)f_10656},
{"f_7042:support_2escm",(void*)f_7042},
{"f_7040:support_2escm",(void*)f_7040},
{"f_12399:support_2escm",(void*)f_12399},
{"f_7308:support_2escm",(void*)f_7308},
{"f_7303:support_2escm",(void*)f_7303},
{"f_7013:support_2escm",(void*)f_7013},
{"f_9933:support_2escm",(void*)f_9933},
{"f_10125:support_2escm",(void*)f_10125},
{"f_9937:support_2escm",(void*)f_9937},
{"f_10127:support_2escm",(void*)f_10127},
{"f_10666:support_2escm",(void*)f_10666},
{"f_10658:support_2escm",(void*)f_10658},
{"f_14367:support_2escm",(void*)f_14367},
{"f_10135:support_2escm",(void*)f_10135},
{"f_10133:support_2escm",(void*)f_10133},
{"f_9903:support_2escm",(void*)f_9903},
{"f_10671:support_2escm",(void*)f_10671},
{"f_10668:support_2escm",(void*)f_10668},
{"f_7022:support_2escm",(void*)f_7022},
{"f_7076:support_2escm",(void*)f_7076},
{"f_10144:support_2escm",(void*)f_10144},
{"f_10681:support_2escm",(void*)f_10681},
{"f_10141:support_2escm",(void*)f_10141},
{"f_9928:support_2escm",(void*)f_9928},
{"f_5220:support_2escm",(void*)f_5220},
{"f_10615:support_2escm",(void*)f_10615},
{"f_10157:support_2escm",(void*)f_10157},
{"f_10610:support_2escm",(void*)f_10610},
{"f_14371:support_2escm",(void*)f_14371},
{"f_10612:support_2escm",(void*)f_10612},
{"f_10151:support_2escm",(void*)f_10151},
{"f_10150:support_2escm",(void*)f_10150},
{"f_7080:support_2escm",(void*)f_7080},
{"f_5236:support_2escm",(void*)f_5236},
{"f_5238:support_2escm",(void*)f_5238},
{"f_9314:support_2escm",(void*)f_9314},
{"f_5212:support_2escm",(void*)f_5212},
{"f_10624:support_2escm",(void*)f_10624},
{"f_10626:support_2escm",(void*)f_10626},
{"f_10622:support_2escm",(void*)f_10622},
{"f_10617:support_2escm",(void*)f_10617},
{"f_10619:support_2escm",(void*)f_10619},
{"f_5229:support_2escm",(void*)f_5229},
{"f_5227:support_2escm",(void*)f_5227},
{"f_13520:support_2escm",(void*)f_13520},
{"f_10636:support_2escm",(void*)f_10636},
{"f_10633:support_2escm",(void*)f_10633},
{"f_10631:support_2escm",(void*)f_10631},
{"f_14392:support_2escm",(void*)f_14392},
{"f_10629:support_2escm",(void*)f_10629},
{"f_5289:support_2escm",(void*)f_5289},
{"f_5286:support_2escm",(void*)f_5286},
{"f_13515:support_2escm",(void*)f_13515},
{"f_9919:support_2escm",(void*)f_9919},
{"f_10107:support_2escm",(void*)f_10107},
{"f_10645:support_2escm",(void*)f_10645},
{"f_10643:support_2escm",(void*)f_10643},
{"f_10101:support_2escm",(void*)f_10101},
{"f_10640:support_2escm",(void*)f_10640},
{"f_10638:support_2escm",(void*)f_10638},
{"f_13504:support_2escm",(void*)f_13504},
{"f_10119:support_2escm",(void*)f_10119},
{"f_10117:support_2escm",(void*)f_10117},
{"f_10112:support_2escm",(void*)f_10112},
{"f_10647:support_2escm",(void*)f_10647},
{"f_4904:support_2escm",(void*)f_4904},
{"f_4902:support_2escm",(void*)f_4902},
{"f_4908:support_2escm",(void*)f_4908},
{"f_5244:support_2escm",(void*)f_5244},
{"f_4922:support_2escm",(void*)f_4922},
{"f_7888:support_2escm",(void*)f_7888},
{"f_4924:support_2escm",(void*)f_4924},
{"f_4925:support_2escm",(void*)f_4925},
{"f_8184:support_2escm",(void*)f_8184},
{"f_10604:support_2escm",(void*)f_10604},
{"f_4916:support_2escm",(void*)f_4916},
{"f_4918:support_2escm",(void*)f_4918},
{"f_4910:support_2escm",(void*)f_4910},
{"f_7896:support_2escm",(void*)f_7896},
{"f_7759:support_2escm",(void*)f_7759},
{"f_7756:support_2escm",(void*)f_7756},
{"f_10165:support_2escm",(void*)f_10165},
{"f_5291:support_2escm",(void*)f_5291},
{"f_7701:support_2escm",(void*)f_7701},
{"f_9945:support_2escm",(void*)f_9945},
{"f_12741:support_2escm",(void*)f_12741},
{"f_7434:support_2escm",(void*)f_7434},
{"f_7439:support_2escm",(void*)f_7439},
{"f_7445:support_2escm",(void*)f_7445},
{"f_10859:support_2escm",(void*)f_10859},
{"f_6525:support_2escm",(void*)f_6525},
{"f_6523:support_2escm",(void*)f_6523},
{"f_8093:support_2escm",(void*)f_8093},
{"f_8126:support_2escm",(void*)f_8126},
{"f_8120:support_2escm",(void*)f_8120},
{"f_8127:support_2escm",(void*)f_8127},
{"f_6539:support_2escm",(void*)f_6539},
{"f_6533:support_2escm",(void*)f_6533},
{"f_8111:support_2escm",(void*)f_8111},
{"f_8117:support_2escm",(void*)f_8117},
{"f_7422:support_2escm",(void*)f_7422},
{"f_6503:support_2escm",(void*)f_6503},
{"f_8101:support_2escm",(void*)f_8101},
{"f_8103:support_2escm",(void*)f_8103},
{"f_10873:support_2escm",(void*)f_10873},
{"f_10307:support_2escm",(void*)f_10307},
{"f_7479:support_2escm",(void*)f_7479},
{"f_7476:support_2escm",(void*)f_7476},
{"f_4735:support_2escm",(void*)f_4735},
{"f_4749:support_2escm",(void*)f_4749},
{"f_13545:support_2escm",(void*)f_13545},
{"f_7470:support_2escm",(void*)f_7470},
{"f_10313:support_2escm",(void*)f_10313},
{"f_7726:support_2escm",(void*)f_7726},
{"f_6514:support_2escm",(void*)f_6514},
{"f_10315:support_2escm",(void*)f_10315},
{"f_7485:support_2escm",(void*)f_7485},
{"f_4766:support_2escm",(void*)f_4766},
{"f_4764:support_2escm",(void*)f_4764},
{"f_4760:support_2escm",(void*)f_4760},
{"f_13530:support_2escm",(void*)f_13530},
{"f_10812:support_2escm",(void*)f_10812},
{"f_7458:support_2escm",(void*)f_7458},
{"f_7451:support_2escm",(void*)f_7451},
{"f_8157:support_2escm",(void*)f_8157},
{"f_8159:support_2escm",(void*)f_8159},
{"f_10861:support_2escm",(void*)f_10861},
{"f_8140:support_2escm",(void*)f_8140},
{"f_8148:support_2escm",(void*)f_8148},
{"f_4777:support_2escm",(void*)f_4777},
{"f_8133:support_2escm",(void*)f_8133},
{"f_8134:support_2escm",(void*)f_8134},
{"f_13415:support_2escm",(void*)f_13415},
{"f_4779:support_2escm",(void*)f_4779},
{"f_10360:support_2escm",(void*)f_10360},
{"f_10362:support_2escm",(void*)f_10362},
{"f_13406:support_2escm",(void*)f_13406},
{"f_10368:support_2escm",(void*)f_10368},
{"f_4791:support_2escm",(void*)f_4791},
{"f_7741:support_2escm",(void*)f_7741},
{"f_10824:support_2escm",(void*)f_10824},
{"f_4740:support_2escm",(void*)f_4740},
{"f_6583:support_2escm",(void*)f_6583},
{"f_6585:support_2escm",(void*)f_6585},
{"f_10385:support_2escm",(void*)f_10385},
{"f_9450:support_2escm",(void*)f_9450},
{"f_9456:support_2escm",(void*)f_9456},
{"f_6593:support_2escm",(void*)f_6593},
{"f_6599:support_2escm",(void*)f_6599},
{"f_10391:support_2escm",(void*)f_10391},
{"f_9482:support_2escm",(void*)f_9482},
{"f_10399:support_2escm",(void*)f_10399},
{"f_10397:support_2escm",(void*)f_10397},
{"f_9488:support_2escm",(void*)f_9488},
{"f_9484:support_2escm",(void*)f_9484},
{"f_9486:support_2escm",(void*)f_9486},
{"f_5613:support_2escm",(void*)f_5613},
{"f_6563:support_2escm",(void*)f_6563},
{"f_6569:support_2escm",(void*)f_6569},
{"f_6571:support_2escm",(void*)f_6571},
{"f_6577:support_2escm",(void*)f_6577},
{"f_9469:support_2escm",(void*)f_9469},
{"f_4781:support_2escm",(void*)f_4781},
{"f_4783:support_2escm",(void*)f_4783},
{"f_7140:support_2escm",(void*)f_7140},
{"f_7142:support_2escm",(void*)f_7142},
{"f_13596:support_2escm",(void*)f_13596},
{"f_5447:support_2escm",(void*)f_5447},
{"f_13590:support_2escm",(void*)f_13590},
{"f_9494:support_2escm",(void*)f_9494},
{"f_9496:support_2escm",(void*)f_9496},
{"f_13584:support_2escm",(void*)f_13584},
{"f_5640:support_2escm",(void*)f_5640},
{"f_7167:support_2escm",(void*)f_7167},
{"f_5644:support_2escm",(void*)f_5644},
{"f_13256:support_2escm",(void*)f_13256},
{"f_13250:support_2escm",(void*)f_13250},
{"f_9472:support_2escm",(void*)f_9472},
{"f_9478:support_2escm",(void*)f_9478},
{"f_7100:support_2escm",(void*)f_7100},
{"f_13554:support_2escm",(void*)f_13554},
{"f_7125:support_2escm",(void*)f_7125},
{"f_13214:support_2escm",(void*)f_13214},
{"f_9896:support_2escm",(void*)f_9896},
{"f_9892:support_2escm",(void*)f_9892},
{"f_13207:support_2escm",(void*)f_13207},
{"f_8554:support_2escm",(void*)f_8554},
{"f_8556:support_2escm",(void*)f_8556},
{"f_10425:support_2escm",(void*)f_10425},
{"f_8581:support_2escm",(void*)f_8581},
{"f_10435:support_2escm",(void*)f_10435},
{"f_9991:support_2escm",(void*)f_9991},
{"f_8533:support_2escm",(void*)f_8533},
{"f_10453:support_2escm",(void*)f_10453},
{"f_7187:support_2escm",(void*)f_7187},
{"f_7189:support_2escm",(void*)f_7189},
{"f_13235:support_2escm",(void*)f_13235},
{"f_14428:support_2escm",(void*)f_14428},
{"f_5695:support_2escm",(void*)f_5695},
{"f_13223:support_2escm",(void*)f_13223},
{"f_7195:support_2escm",(void*)f_7195},
{"f_14425:support_2escm",(void*)f_14425},
{"f_12834:support_2escm",(void*)f_12834},
{"f_7004:support_2escm",(void*)f_7004},
{"f_5681:support_2escm",(void*)f_5681},
{"f_10608:support_2escm",(void*)f_10608},
{"f_10606:support_2escm",(void*)f_10606},
{"f_14417:support_2escm",(void*)f_14417},
{"f_14414:support_2escm",(void*)f_14414},
{"f_14408:support_2escm",(void*)f_14408},
{"f_13441:support_2escm",(void*)f_13441},
{"f_5679:support_2escm",(void*)f_5679},
{"f_13432:support_2escm",(void*)f_13432},
{"f_5548:support_2escm",(void*)f_5548},
{"f_6541:support_2escm",(void*)f_6541},
{"f_6547:support_2escm",(void*)f_6547},
{"f_6553:support_2escm",(void*)f_6553},
{"f_6555:support_2escm",(void*)f_6555},
{"f_13495:support_2escm",(void*)f_13495},
{"f_5562:support_2escm",(void*)f_5562},
{"f_5568:support_2escm",(void*)f_5568},
{"f_13482:support_2escm",(void*)f_13482},
{"f_13485:support_2escm",(void*)f_13485},
{"f_6405:support_2escm",(void*)f_6405},
{"f_5556:support_2escm",(void*)f_5556},
{"f_6413:support_2escm",(void*)f_6413},
{"f_9873:support_2escm",(void*)f_9873},
{"f_9871:support_2escm",(void*)f_9871},
{"f_9879:support_2escm",(void*)f_9879},
{"f_5164:support_2escm",(void*)f_5164},
{"f_6419:support_2escm",(void*)f_6419},
{"f_6428:support_2escm",(void*)f_6428},
{"f_6426:support_2escm",(void*)f_6426},
{"f_6424:support_2escm",(void*)f_6424},
{"f_9881:support_2escm",(void*)f_9881},
{"f_9887:support_2escm",(void*)f_9887},
{"f_6437:support_2escm",(void*)f_6437},
{"f_7546:support_2escm",(void*)f_7546},
{"f_7548:support_2escm",(void*)f_7548},
{"f_5185:support_2escm",(void*)f_5185},
{"f_5182:support_2escm",(void*)f_5182},
{"f_6439:support_2escm",(void*)f_6439},
{"f_6064:support_2escm",(void*)f_6064},
{"f_13271:support_2escm",(void*)f_13271},
{"f_13264:support_2escm",(void*)f_13264},
{"f_6088:support_2escm",(void*)f_6088},
{"f_6086:support_2escm",(void*)f_6086},
{"f_6085:support_2escm",(void*)f_6085},
{"f_5190:support_2escm",(void*)f_5190},
{"f_5904:support_2escm",(void*)f_5904},
{"f_6017:support_2escm",(void*)f_6017},
{"f_6010:support_2escm",(void*)f_6010},
{"f_6487:support_2escm",(void*)f_6487},
{"f_6489:support_2escm",(void*)f_6489},
{"f_6493:support_2escm",(void*)f_6493},
{"f_13817:support_2escm",(void*)f_13817},
{"f_6495:support_2escm",(void*)f_6495},
{"f_6491:support_2escm",(void*)f_6491},
{"f_13809:support_2escm",(void*)f_13809},
{"f_13806:support_2escm",(void*)f_13806},
{"f_10405:support_2escm",(void*)f_10405},
{"f_6057:support_2escm",(void*)f_6057},
{"f_4842:support_2escm",(void*)f_4842},
{"f_10419:support_2escm",(void*)f_10419},
{"f_9530:support_2escm",(void*)f_9530},
{"f_13869:support_2escm",(void*)f_13869},
{"f_9535:support_2escm",(void*)f_9535},
{"f_13280:support_2escm",(void*)f_13280},
{"f_4833:support_2escm",(void*)f_4833},
{"f_14074:support_2escm",(void*)f_14074},
{"f_14076:support_2escm",(void*)f_14076},
{"f_9524:support_2escm",(void*)f_9524},
{"f_4869:support_2escm",(void*)f_4869},
{"f_14463:support_2escm",(void*)f_14463},
{"f_13842:support_2escm",(void*)f_13842},
{"f_14460:support_2escm",(void*)f_14460},
{"f_4853:support_2escm",(void*)f_4853},
{"f_7573:support_2escm",(void*)f_7573},
{"f_12871:support_2escm",(void*)f_12871},
{"f_10044:support_2escm",(void*)f_10044},
{"f_14451:support_2escm",(void*)f_14451},
{"f_14450:support_2escm",(void*)f_14450},
{"f_13835:support_2escm",(void*)f_13835},
{"f_4881:support_2escm",(void*)f_4881},
{"f_4887:support_2escm",(void*)f_4887},
{"f_14445:support_2escm",(void*)f_14445},
{"f_8983:support_2escm",(void*)f_8983},
{"f_14440:support_2escm",(void*)f_14440},
{"f_7414:support_2escm",(void*)f_7414},
{"f_4877:support_2escm",(void*)f_4877},
{"f_4875:support_2escm",(void*)f_4875},
{"f_14436:support_2escm",(void*)f_14436},
{"f_4879:support_2escm",(void*)f_4879},
{"f_12814:support_2escm",(void*)f_12814},
{"f_13897:support_2escm",(void*)f_13897},
{"f_13892:support_2escm",(void*)f_13892},
{"f_7527:support_2escm",(void*)f_7527},
{"f_10461:support_2escm",(void*)f_10461},
{"f_10033:support_2escm",(void*)f_10033},
{"f_10039:support_2escm",(void*)f_10039},
{"f_13888:support_2escm",(void*)f_13888},
{"f_13883:support_2escm",(void*)f_13883},
{"f_7538:support_2escm",(void*)f_7538},
{"f_4896:support_2escm",(void*)f_4896},
{"f_14499:support_2escm",(void*)f_14499},
{"f_10470:support_2escm",(void*)f_10470},
{"f_9408:support_2escm",(void*)f_9408},
{"f_10006:support_2escm",(void*)f_10006},
{"f_13872:support_2escm",(void*)f_13872},
{"f_13877:support_2escm",(void*)f_13877},
{"f_14487:support_2escm",(void*)f_14487},
{"f_10485:support_2escm",(void*)f_10485},
{"f_10481:support_2escm",(void*)f_10481},
{"f_14478:support_2escm",(void*)f_14478},
{"f_8993:support_2escm",(void*)f_8993},
{"f_10490:support_2escm",(void*)f_10490},
{"f_10492:support_2escm",(void*)f_10492},
{"f_12850:support_2escm",(void*)f_12850},
{"f_10028:support_2escm",(void*)f_10028},
{"f_14473:support_2escm",(void*)f_14473},
{"f_8922:support_2escm",(void*)f_8922},
{"f_8924:support_2escm",(void*)f_8924},
{"f_9419:support_2escm",(void*)f_9419},
{"f_9592:support_2escm",(void*)f_9592},
{"f_9595:support_2escm",(void*)f_9595},
{"f_9581:support_2escm",(void*)f_9581},
{"f_9586:support_2escm",(void*)f_9586},
{"f_6607:support_2escm",(void*)f_6607},
{"f_6601:support_2escm",(void*)f_6601},
{"f_8907:support_2escm",(void*)f_8907},
{"f_8902:support_2escm",(void*)f_8902},
{"f_5361:support_2escm",(void*)f_5361},
{"f_5365:support_2escm",(void*)f_5365},
{"f_6627:support_2escm",(void*)f_6627},
{"f_5992:support_2escm",(void*)f_5992},
{"f_5990:support_2escm",(void*)f_5990},
{"f_8965:support_2escm",(void*)f_8965},
{"f_5994:support_2escm",(void*)f_5994},
{"toplevel:support_2escm",(void*)C_support_toplevel},
{"f_9556:support_2escm",(void*)f_9556},
{"f_9554:support_2escm",(void*)f_9554},
{"f_8939:support_2escm",(void*)f_8939},
{"f_5943:support_2escm",(void*)f_5943},
{"f_9543:support_2escm",(void*)f_9543},
{"f_9541:support_2escm",(void*)f_9541},
{"f_9549:support_2escm",(void*)f_9549},
{"f_8943:support_2escm",(void*)f_8943},
{"f_5939:support_2escm",(void*)f_5939},
{"f_8942:support_2escm",(void*)f_8942},
{"f_5100:support_2escm",(void*)f_5100},
{"f_5106:support_2escm",(void*)f_5106},
{"f_14114:support_2escm",(void*)f_14114},
{"f_14117:support_2escm",(void*)f_14117},
{"f_14119:support_2escm",(void*)f_14119},
{"f_8915:support_2escm",(void*)f_8915},
{"f_8917:support_2escm",(void*)f_8917},
{"f_8912:support_2escm",(void*)f_8912},
{"f_7845:support_2escm",(void*)f_7845},
{"f_12102:support_2escm",(void*)f_12102},
{"f_8508:support_2escm",(void*)f_8508},
{"f_14136:support_2escm",(void*)f_14136},
{"f_14133:support_2escm",(void*)f_14133},
{"f_6205:support_2escm",(void*)f_6205},
{"f_7863:support_2escm",(void*)f_7863},
{"f_6200:support_2escm",(void*)f_6200},
{"f_7861:support_2escm",(void*)f_7861},
{"f_14124:support_2escm",(void*)f_14124},
{"f_6209:support_2escm",(void*)f_6209},
{"f_7810:support_2escm",(void*)f_7810},
{"f_14150:support_2escm",(void*)f_14150},
{"f_14159:support_2escm",(void*)f_14159},
{"f_5138:support_2escm",(void*)f_5138},
{"f_8958:support_2escm",(void*)f_8958},
{"f_5132:support_2escm",(void*)f_5132},
{"f_7808:support_2escm",(void*)f_7808},
{"f_8881:support_2escm",(void*)f_8881},
{"f_8884:support_2escm",(void*)f_8884},
{"f_8896:support_2escm",(void*)f_8896},
{"f_9196:support_2escm",(void*)f_9196},
{"f_9195:support_2escm",(void*)f_9195},
{"f_9193:support_2escm",(void*)f_9193},
{"f_14503:support_2escm",(void*)f_14503},
{"f_14501:support_2escm",(void*)f_14501},
{"f_14505:support_2escm",(void*)f_14505},
{"f_14508:support_2escm",(void*)f_14508},
{"f_14523:support_2escm",(void*)f_14523},
{"f_13326:support_2escm",(void*)f_13326},
{"f_13325:support_2escm",(void*)f_13325},
{"f_14529:support_2escm",(void*)f_14529},
{"f_14101:support_2escm",(void*)f_14101},
{"f_14106:support_2escm",(void*)f_14106},
{"f_13312:support_2escm",(void*)f_13312},
{"f_14511:support_2escm",(void*)f_14511},
{"f_13316:support_2escm",(void*)f_13316},
{"f_14514:support_2escm",(void*)f_14514},
{"f_14516:support_2escm",(void*)f_14516},
{"f_13319:support_2escm",(void*)f_13319},
{"f_6469:support_2escm",(void*)f_6469},
{"f_6473:support_2escm",(void*)f_6473},
{"f_6478:support_2escm",(void*)f_6478},
{"f_9518:support_2escm",(void*)f_9518},
{"f_9183:support_2escm",(void*)f_9183},
{"f_9181:support_2escm",(void*)f_9181},
{"f_9186:support_2escm",(void*)f_9186},
{"f_9512:support_2escm",(void*)f_9512},
{"f_9510:support_2escm",(void*)f_9510},
{"f_9188:support_2escm",(void*)f_9188},
{"f_6296:support_2escm",(void*)f_6296},
{"f_6294:support_2escm",(void*)f_6294},
{"f_6290:support_2escm",(void*)f_6290},
{"f_9504:support_2escm",(void*)f_9504},
{"f_9502:support_2escm",(void*)f_9502},
{"f_9161:support_2escm",(void*)f_9161},
{"f_7835:support_2escm",(void*)f_7835},
{"f_11608:support_2escm",(void*)f_11608},
{"f_11602:support_2escm",(void*)f_11602},
{"f_6246:support_2escm",(void*)f_6246},
{"f_9813:support_2escm",(void*)f_9813},
{"f_9810:support_2escm",(void*)f_9810},
{"f_11615:support_2escm",(void*)f_11615},
{"f_9141:support_2escm",(void*)f_9141},
{"f_9145:support_2escm",(void*)f_9145},
{"f_9146:support_2escm",(void*)f_9146},
{"f_11611:support_2escm",(void*)f_11611},
{"f_6250:support_2escm",(void*)f_6250},
{"f_9827:support_2escm",(void*)f_9827},
{"f_9120:support_2escm",(void*)f_9120},
{"f_9126:support_2escm",(void*)f_9126},
{"f_8858:support_2escm",(void*)f_8858},
{"f_8852:support_2escm",(void*)f_8852},
{"f_8869:support_2escm",(void*)f_8869},
{"f_9105:support_2escm",(void*)f_9105},
{"f_8066:support_2escm",(void*)f_8066},
{"f_8068:support_2escm",(void*)f_8068},
{"f_9865:support_2escm",(void*)f_9865},
{"f_9139:support_2escm",(void*)f_9139},
{"f_8053:support_2escm",(void*)f_8053},
{"f_11539:support_2escm",(void*)f_11539},
{"f_9791:support_2escm",(void*)f_9791},
{"f_11556:support_2escm",(void*)f_11556},
{"f_11666:support_2escm",(void*)f_11666},
{"f_4941:support_2escm",(void*)f_4941},
{"f_10531:support_2escm",(void*)f_10531},
{"f_10537:support_2escm",(void*)f_10537},
{"f_11649:support_2escm",(void*)f_11649},
{"f_4936:support_2escm",(void*)f_4936},
{"f_4934:support_2escm",(void*)f_4934},
{"f_11643:support_2escm",(void*)f_11643},
{"f_4967:support_2escm",(void*)f_4967},
{"f_4969:support_2escm",(void*)f_4969},
{"f_14544:support_2escm",(void*)f_14544},
{"f_14540:support_2escm",(void*)f_14540},
{"f_14546:support_2escm",(void*)f_14546},
{"f_7505:support_2escm",(void*)f_7505},
{"f_7502:support_2escm",(void*)f_7502},
{"f_11658:support_2escm",(void*)f_11658},
{"f_4963:support_2escm",(void*)f_4963},
{"f_4965:support_2escm",(void*)f_4965},
{"f_4961:support_2escm",(void*)f_4961},
{"f_5436:support_2escm",(void*)f_5436},
{"f_7514:support_2escm",(void*)f_7514},
{"f_4950:support_2escm",(void*)f_4950},
{"f_14562:support_2escm",(void*)f_14562},
{"f_14564:support_2escm",(void*)f_14564},
{"f_13365:support_2escm",(void*)f_13365},
{"f_14560:support_2escm",(void*)f_14560},
{"f_12404:support_2escm",(void*)f_12404},
{"f_12408:support_2escm",(void*)f_12408},
{"f_14566:support_2escm",(void*)f_14566},
{"f_5423:support_2escm",(void*)f_5423},
{"f_4978:support_2escm",(void*)f_4978},
{"f_14551:support_2escm",(void*)f_14551},
{"f_5416:support_2escm",(void*)f_5416},
{"f_14557:support_2escm",(void*)f_14557},
{"f_9804:support_2escm",(void*)f_9804},
{"f_9800:support_2escm",(void*)f_9800},
{"f_4976:support_2escm",(void*)f_4976},
{"f_4974:support_2escm",(void*)f_4974},
{"f_14585:support_2escm",(void*)f_14585},
{"f_13347:support_2escm",(void*)f_13347},
{"f_5409:support_2escm",(void*)f_5409},
{"f_5407:support_2escm",(void*)f_5407},
{"f_11585:support_2escm",(void*)f_11585},
{"f_4999:support_2escm",(void*)f_4999},
{"f_14571:support_2escm",(void*)f_14571},
{"f_13332:support_2escm",(void*)f_13332},
{"f_13333:support_2escm",(void*)f_13333},
{"f_14579:support_2escm",(void*)f_14579},
{"f_14577:support_2escm",(void*)f_14577},
{"f_4995:support_2escm",(void*)f_4995},
{"f_13339:support_2escm",(void*)f_13339},
{"f_11677:support_2escm",(void*)f_11677},
{"f_13398:support_2escm",(void*)f_13398},
{"f_11573:support_2escm",(void*)f_11573},
{"f_11544:support_2escm",(void*)f_11544},
{"f_13375:support_2escm",(void*)f_13375},
{"f_6192:support_2escm",(void*)f_6192},
{"f_13371:support_2escm",(void*)f_13371},
{"f_14080:support_2escm",(void*)f_14080},
{"f_9682:support_2escm",(void*)f_9682},
{"f_14084:support_2escm",(void*)f_14084},
{"f_14082:support_2escm",(void*)f_14082},
{"f_9778:support_2escm",(void*)f_9778},
{"f_4702:support_2escm",(void*)f_4702},
{"f_11638:support_2escm",(void*)f_11638},
{"f_14088:support_2escm",(void*)f_14088},
{"f_4706:support_2escm",(void*)f_4706},
{"f_14086:support_2escm",(void*)f_14086},
{"f_5491:support_2escm",(void*)f_5491},
{"f_14091:support_2escm",(void*)f_14091},
{"f_14092:support_2escm",(void*)f_14092},
{"f_9785:support_2escm",(void*)f_9785},
{"f_9673:support_2escm",(void*)f_9673},
{"f_11688:support_2escm",(void*)f_11688},
{"f_6188:support_2escm",(void*)f_6188},
{"f_5489:support_2escm",(void*)f_5489},
{"f_14061:support_2escm",(void*)f_14061},
{"f_14060:support_2escm",(void*)f_14060},
{"f_9660:support_2escm",(void*)f_9660},
{"f_9666:support_2escm",(void*)f_9666},
{"f_4725:support_2escm",(void*)f_4725},
{"f_11693:support_2escm",(void*)f_11693},
{"f_14067:support_2escm",(void*)f_14067},
{"f_4729:support_2escm",(void*)f_4729},
{"f_14068:support_2escm",(void*)f_14068},
{"f_11697:support_2escm",(void*)f_11697},
{"f_4726:support_2escm",(void*)f_4726},
{"f_5476:support_2escm",(void*)f_5476},
{"f_6151:support_2escm",(void*)f_6151},
{"f_9653:support_2escm",(void*)f_9653},
{"f_9651:support_2escm",(void*)f_9651},
{"f_9659:support_2escm",(void*)f_9659},
{"f_4715:support_2escm",(void*)f_4715},
{"f_4712:support_2escm",(void*)f_4712},
{"f_4717:support_2escm",(void*)f_4717},
{"f_11084:support_2escm",(void*)f_11084},
{"f_5464:support_2escm",(void*)f_5464},
{"f_6160:support_2escm",(void*)f_6160},
{"f_11080:support_2escm",(void*)f_11080},
{"f_9642:support_2escm",(void*)f_9642},
{"f_9647:support_2escm",(void*)f_9647},
{"f_6140:support_2escm",(void*)f_6140},
{"f_6111:support_2escm",(void*)f_6111},
{"f_13730:support_2escm",(void*)f_13730},
{"f_6120:support_2escm",(void*)f_6120},
{"f_8435:support_2escm",(void*)f_8435},
{"f_8438:support_2escm",(void*)f_8438},
{"f_6171:support_2escm",(void*)f_6171},
{"f_6175:support_2escm",(void*)f_6175},
{"f_13710:support_2escm",(void*)f_13710},
{"f_5005:support_2escm",(void*)f_5005},
{"f_5037:support_2escm",(void*)f_5037},
{"f_13718:support_2escm",(void*)f_13718},
{"f_5030:support_2escm",(void*)f_5030},
{"f_13742:support_2escm",(void*)f_13742},
{"f_13745:support_2escm",(void*)f_13745},
{"f_6980:support_2escm",(void*)f_6980},
{"f_6986:support_2escm",(void*)f_6986},
{"f_8445:support_2escm",(void*)f_8445},
{"f_13777:support_2escm",(void*)f_13777},
{"f_13771:support_2escm",(void*)f_13771},
{"f_8479:support_2escm",(void*)f_8479},
{"f_8293:support_2escm",(void*)f_8293},
{"f_8290:support_2escm",(void*)f_8290},
{"f_13754:support_2escm",(void*)f_13754},
{"f_13759:support_2escm",(void*)f_13759},
{"f_8467:support_2escm",(void*)f_8467},
{"f_13751:support_2escm",(void*)f_13751},
{"f_13782:support_2escm",(void*)f_13782},
{"f_13784:support_2escm",(void*)f_13784},
{"f_13780:support_2escm",(void*)f_13780},
{"f_13789:support_2escm",(void*)f_13789},
{"f_8489:support_2escm",(void*)f_8489},
{"f_13612:support_2escm",(void*)f_13612},
{"f_13614:support_2escm",(void*)f_13614},
{"f_13616:support_2escm",(void*)f_13616},
{"f_13618:support_2escm",(void*)f_13618},
{"f_9272:support_2escm",(void*)f_9272},
{"f_9270:support_2escm",(void*)f_9270},
{"f_6995:support_2escm",(void*)f_6995},
{"f_10567:support_2escm",(void*)f_10567},
{"f_13763:support_2escm",(void*)f_13763},
{"f_14240:support_2escm",(void*)f_14240},
{"f_10576:support_2escm",(void*)f_10576},
{"f_14249:support_2escm",(void*)f_14249},
{"f_14245:support_2escm",(void*)f_14245},
{"f_9261:support_2escm",(void*)f_9261},
{"f_5807:support_2escm",(void*)f_5807},
{"f_14236:support_2escm",(void*)f_14236},
{"f_6972:support_2escm",(void*)f_6972},
{"f_6974:support_2escm",(void*)f_6974},
{"f_10587:support_2escm",(void*)f_10587},
{"f_9255:support_2escm",(void*)f_9255},
{"f_5800:support_2escm",(void*)f_5800},
{"f_5802:support_2escm",(void*)f_5802},
{"f_5803:support_2escm",(void*)f_5803},
{"f_13621:support_2escm",(void*)f_13621},
{"f_10593:support_2escm",(void*)f_10593},
{"f_13624:support_2escm",(void*)f_13624},
{"f_13627:support_2escm",(void*)f_13627},
{"f_10598:support_2escm",(void*)f_10598},
{"f_14214:support_2escm",(void*)f_14214},
{"f_14266:support_2escm",(void*)f_14266},
{"f_5817:support_2escm",(void*)f_5817},
{"f_6722:support_2escm",(void*)f_6722},
{"f_6724:support_2escm",(void*)f_6724},
{"f_6726:support_2escm",(void*)f_6726},
{"f_14208:support_2escm",(void*)f_14208},
{"f_6720:support_2escm",(void*)f_6720},
{"f_13605:support_2escm",(void*)f_13605},
{"f_14277:support_2escm",(void*)f_14277},
{"f_5812:support_2escm",(void*)f_5812},
{"f_11019:support_2escm",(void*)f_11019},
{"f_9218:support_2escm",(void*)f_9218},
{"f_5059:support_2escm",(void*)f_5059},
{"f_9216:support_2escm",(void*)f_9216},
{"f_5051:support_2escm",(void*)f_5051},
{"f_9283:support_2escm",(void*)f_9283},
{"f_14007:support_2escm",(void*)f_14007},
{"f_5828:support_2escm",(void*)f_5828},
{"f_5822:support_2escm",(void*)f_5822},
{"f_11042:support_2escm",(void*)f_11042},
{"f_14037:support_2escm",(void*)f_14037},
{"f_5831:support_2escm",(void*)f_5831},
{"f_5839:support_2escm",(void*)f_5839},
{"f_7270:support_2escm",(void*)f_7270},
{"f_14288:support_2escm",(void*)f_14288},
{"f_5865:support_2escm",(void*)f_5865},
{"f_14012:support_2escm",(void*)f_14012},
{"f_5527:support_2escm",(void*)f_5527},
{"f_14290:support_2escm",(void*)f_14290},
{"f_14225:support_2escm",(void*)f_14225},
{"f_14223:support_2escm",(void*)f_14223},
{"f_14297:support_2escm",(void*)f_14297},
{"f_9249:support_2escm",(void*)f_9249},
{"f_5048:support_2escm",(void*)f_5048},
{"f_5041:support_2escm",(void*)f_5041},
{"f_9243:support_2escm",(void*)f_9243},
{"f_14042:support_2escm",(void*)f_14042},
{"f_14046:support_2escm",(void*)f_14046},
{"f_7276:support_2escm",(void*)f_7276},
{"f_7278:support_2escm",(void*)f_7278},
{"f_5515:support_2escm",(void*)f_5515},
{"f_7252:support_2escm",(void*)f_7252},
{"f_11005:support_2escm",(void*)f_11005},
{"f_11007:support_2escm",(void*)f_11007},
{"f_7920:support_2escm",(void*)f_7920},
{"f_5027:support_2escm",(void*)f_5027},
{"f_5533:support_2escm",(void*)f_5533},
{"f_7918:support_2escm",(void*)f_7918},
{"f_13634:support_2escm",(void*)f_13634},
{"f_13630:support_2escm",(void*)f_13630},
{"f_7903:support_2escm",(void*)f_7903},
{"f_14051:support_2escm",(void*)f_14051},
{"f_7901:support_2escm",(void*)f_7901},
{"f_14054:support_2escm",(void*)f_14054},
{"f_13665:support_2escm",(void*)f_13665},
{"f_13660:support_2escm",(void*)f_13660},
{"f_5882:support_2escm",(void*)f_5882},
{"f_7963:support_2escm",(void*)f_7963},
{"f_13645:support_2escm",(void*)f_13645},
{"f_5573:support_2escm",(void*)f_5573},
{"f_5571:support_2escm",(void*)f_5571},
{"f_7954:support_2escm",(void*)f_7954},
{"f_7956:support_2escm",(void*)f_7956},
{"f_7951:support_2escm",(void*)f_7951},
{"f_8783:support_2escm",(void*)f_8783},
{"f_7945:support_2escm",(void*)f_7945},
{"f_5891:support_2escm",(void*)f_5891},
{"f_5894:support_2escm",(void*)f_5894},
{"f_5898:support_2escm",(void*)f_5898},
{"f_6337:support_2escm",(void*)f_6337},
{"f_5841:support_2escm",(void*)f_5841},
{"f15836:support_2escm",(void*)f15836},
{"f_5844:support_2escm",(void*)f_5844},
{"f_6396:support_2escm",(void*)f_6396},
{"f_6390:support_2escm",(void*)f_6390},
{"f_5870:support_2escm",(void*)f_5870},
{"f_5877:support_2escm",(void*)f_5877},
{"f_5876:support_2escm",(void*)f_5876},
{"f_7257:support_2escm",(void*)f_7257},
{"f_7255:support_2escm",(void*)f_7255},
{"f_7230:support_2escm",(void*)f_7230},
{"f_14170:support_2escm",(void*)f_14170},
{"f_14174:support_2escm",(void*)f_14174},
{"f_8716:support_2escm",(void*)f_8716},
{"f_8714:support_2escm",(void*)f_8714},
{"f_9617:support_2escm",(void*)f_9617},
{"f_9615:support_2escm",(void*)f_9615},
{"f_7238:support_2escm",(void*)f_7238},
{"f_13695:support_2escm",(void*)f_13695},
{"f_12513:support_2escm",(void*)f_12513},
{"f_13697:support_2escm",(void*)f_13697},
{"f_14177:support_2escm",(void*)f_14177},
{"f_6341:support_2escm",(void*)f_6341},
{"f_6346:support_2escm",(void*)f_6346},
{"f_7249:support_2escm",(void*)f_7249},
{"f_6355:support_2escm",(void*)f_6355},
{"f_13670:support_2escm",(void*)f_13670},
{"f_9715:support_2escm",(void*)f_9715},
{"f_9712:support_2escm",(void*)f_9712},
{"f_9711:support_2escm",(void*)f_9711},
{"f_12072:support_2escm",(void*)f_12072},
{"f_9728:support_2escm",(void*)f_9728},
{"f_9723:support_2escm",(void*)f_9723},
{"f_8758:support_2escm",(void*)f_8758},
{"f_8756:support_2escm",(void*)f_8756},
{"f_9720:support_2escm",(void*)f_9720},
{"f_8750:support_2escm",(void*)f_8750},
{"f_13656:support_2escm",(void*)f_13656},
{"f_13652:support_2escm",(void*)f_13652},
{"f_9737:support_2escm",(void*)f_9737},
{"f_14192:support_2escm",(void*)f_14192},
{"f_14189:support_2escm",(void*)f_14189},
{"f_9749:support_2escm",(void*)f_9749},
{"f_9757:support_2escm",(void*)f_9757},
{"f_9751:support_2escm",(void*)f_9751},
{"f_8741:support_2escm",(void*)f_8741},
{"f_12669:support_2escm",(void*)f_12669},
{"f_8207:support_2escm",(void*)f_8207},
{"f_12068:support_2escm",(void*)f_12068},
{"f_8205:support_2escm",(void*)f_8205},
{"f_12063:support_2escm",(void*)f_12063},
{"f_10192:support_2escm",(void*)f_10192},
{"f_8232:support_2escm",(void*)f_8232},
{"f_10186:support_2escm",(void*)f_10186},
{"f_10184:support_2escm",(void*)f_10184},
{"f_10178:support_2escm",(void*)f_10178},
{"f_10690:support_2escm",(void*)f_10690},
{"f_10235:support_2escm",(void*)f_10235},
{"f_7602:support_2escm",(void*)f_7602},
{"f_7648:support_2escm",(void*)f_7648},
{"f_10244:support_2escm",(void*)f_10244},
{"f_10238:support_2escm",(void*)f_10238},
{"f_7623:support_2escm",(void*)f_7623},
{"f_7621:support_2escm",(void*)f_7621},
{"f_8417:support_2escm",(void*)f_8417},
{"f_4665:support_2escm",(void*)f_4665},
{"f_4663:support_2escm",(void*)f_4663},
{"f_4669:support_2escm",(void*)f_4669},
{"f_8375:support_2escm",(void*)f_8375},
{"f_5310:support_2escm",(void*)f_5310},
{"f_10264:support_2escm",(void*)f_10264},
{"f_10261:support_2escm",(void*)f_10261},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}

/*
S|applied compiler syntax:
S|  map		30
S|  sprintf		4
S|  fprintf		5
S|  printf		19
S|  for-each		15
o|eliminated procedure checks: 337 
o|specializations:
o|  1 (eqv? (not float) *)
o|  3 (= fixnum fixnum)
o|  1 (assq * list)
o|  1 (current-output-port)
o|  1 (second (pair * pair))
o|  3 (first pair)
o|  5 (cddr (pair * pair))
o|  1 (caddr (pair * (pair * pair)))
o|  348 (eqv? * (not float))
o|  1 (##sys#call-with-values (procedure () *) *)
o|  1 (cadr (pair * pair))
o|  1 (current-input-port)
o|  3 (memq * list)
o|  1 (>= fixnum fixnum)
o|  3 (< fixnum fixnum)
o|  2 (current-error-port)
o|  8 (##sys#check-list (or pair list) *)
o|  31 (cdr pair)
o|  27 (car pair)
o|safe globals: (##compiler#bomb ##compiler#disabled-warnings ##compiler#debugging-chicken ##compiler#compiler-cleanup-hook constant25 constant22) 
o|Removed `not' forms: 7 
o|removed side-effect free assignment to unused variable: constant22 
o|inlining procedure: k4678 
o|inlining procedure: k4678 
o|inlining procedure: k4716 
o|inlining procedure: k4743 
o|inlining procedure: k4743 
o|inlining procedure: k4716 
o|propagated global variable: out7882 ##compiler#collected-debugging-output 
o|inlining procedure: k4770 
o|inlining procedure: k4770 
o|inlining procedure: k4821 
o|inlining procedure: k4821 
o|inlining procedure: k4836 
o|inlining procedure: k4836 
o|inlining procedure: k4856 
o|inlining procedure: k4856 
o|inlining procedure: k4870 
o|inlining procedure: k4870 
o|inlining procedure: k4944 
o|inlining procedure: k4944 
o|inlining procedure: k5008 
o|inlining procedure: k5008 
o|inlining procedure: k5062 
o|inlining procedure: k5062 
o|inlining procedure: k5081 
o|inlining procedure: k5081 
o|inlining procedure: k5109 
o|inlining procedure: k5109 
o|inlining procedure: k5141 
o|inlining procedure: k5141 
o|inlining procedure: k5167 
o|inlining procedure: k5167 
o|inlining procedure: k5193 
o|inlining procedure: k5193 
o|inlining procedure: k5247 
o|inlining procedure: k5247 
o|inlining procedure: k5294 
o|inlining procedure: k5294 
o|inlining procedure: k5331 
o|inlining procedure: k5331 
o|substituted constant variable: a5338 
o|substituted constant variable: a5340 
o|inlining procedure: k5351 
o|inlining procedure: k5351 
o|substituted constant variable: a5355 
o|substituted constant variable: a5357 
o|substituted constant variable: a5359 
o|inlining procedure: k5366 
o|inlining procedure: k5389 
o|inlining procedure: k5389 
o|inlining procedure: k5366 
o|inlining procedure: k5426 
o|propagated global variable: f_542514636 ##sys#standard-input 
o|inlining procedure: k5426 
o|inlining procedure: k5440 
o|inlining procedure: k5440 
o|inlining procedure: k5467 
o|inlining procedure: k5467 
o|inlining procedure: k5479 
o|inlining procedure: k5479 
o|inlining procedure: k5497 
o|inlining procedure: k5497 
o|inlining procedure: k5536 
o|inlining procedure: k5536 
o|inlining procedure: k5578 
o|inlining procedure: k5578 
o|inlining procedure: k5588 
o|inlining procedure: k5588 
o|inlining procedure: k5598 
o|inlining procedure: k5598 
o|inlining procedure: k5618 
o|inlining procedure: k5618 
o|inlining procedure: k5628 
o|inlining procedure: k5628 
o|inlining procedure: k5645 
o|inlining procedure: k5645 
o|inlining procedure: k5655 
o|inlining procedure: k5655 
o|inlining procedure: k5665 
o|inlining procedure: k5665 
o|inlining procedure: k5686 
o|inlining procedure: k5686 
o|inlining procedure: k5696 
o|inlining procedure: k5696 
o|inlining procedure: k5704 
o|inlining procedure: k5704 
o|inlining procedure: k5742 
o|inlining procedure: k5742 
o|inlining procedure: k5754 
o|inlining procedure: k5754 
o|inlining procedure: k5789 
o|inlining procedure: k5789 
o|inlining procedure: k5827 
o|inlining procedure: k5827 
o|inlining procedure: k5845 
o|inlining procedure: k5845 
o|inlining procedure: k5907 
o|inlining procedure: k5907 
o|inlining procedure: k5920 
o|inlining procedure: k5920 
o|inlining procedure: k6011 
o|inlining procedure: k6011 
o|inlining procedure: k6058 
o|inlining procedure: k6058 
o|inlining procedure: k5989 
o|inlining procedure: k6114 
o|inlining procedure: k6114 
o|propagated global variable: g631633 ##compiler#internal-bindings 
o|inlining procedure: k6134 
o|inlining procedure: k6134 
o|propagated global variable: g582584 extended-bindings 
o|inlining procedure: k6154 
o|inlining procedure: k6154 
o|propagated global variable: g533535 standard-bindings 
o|inlining procedure: k5989 
o|inlining procedure: k6176 
o|inlining procedure: k6176 
o|inlining procedure: k6193 
o|inlining procedure: k6193 
o|inlining procedure: k6210 
o|inlining procedure: k6221 
o|inlining procedure: k6221 
o|inlining procedure: k6210 
o|inlining procedure: k6251 
o|inlining procedure: k6251 
o|inlining procedure: k6297 
o|inlining procedure: k6297 
o|inlining procedure: k6342 
o|inlining procedure: k6342 
o|inlining procedure: k6364 
o|inlining procedure: k6364 
o|inlining procedure: k6401 
o|inlining procedure: k6401 
o|inlining procedure: k6421 
o|inlining procedure: k6442 
o|inlining procedure: k6442 
o|propagated global variable: out744748 ##sys#standard-output 
o|inlining procedure: k6421 
o|inlining procedure: k6480 
o|inlining procedure: k6480 
o|propagated global variable: out965969 ##sys#standard-output 
o|propagated global variable: out956960 ##sys#standard-output 
o|propagated global variable: out909913 ##sys#standard-output 
o|inlining procedure: k6548 
o|propagated global variable: out925929 ##sys#standard-output 
o|inlining procedure: k6548 
o|propagated global variable: out941945 ##sys#standard-output 
o|inlining procedure: k6630 
o|substituted constant variable: names779 
o|propagated global variable: out859863 ##sys#standard-output 
o|inlining procedure: k6664 
o|inlining procedure: k6664 
o|inlining procedure: k6677 
o|inlining procedure: k6677 
o|inlining procedure: k6687 
o|inlining procedure: k6687 
o|inlining procedure: k6713 
o|propagated global variable: out892896 ##sys#standard-output 
o|inlining procedure: k6713 
o|inlining procedure: k6746 
o|inlining procedure: k6746 
o|substituted constant variable: a6762 
o|substituted constant variable: a6764 
o|inlining procedure: k6767 
o|inlining procedure: k6767 
o|inlining procedure: k6777 
o|inlining procedure: k6777 
o|inlining procedure: k6787 
o|inlining procedure: k6787 
o|inlining procedure: k6797 
o|inlining procedure: k6797 
o|substituted constant variable: a6804 
o|substituted constant variable: a6806 
o|substituted constant variable: a6808 
o|substituted constant variable: a6810 
o|substituted constant variable: a6812 
o|substituted constant variable: a6814 
o|substituted constant variable: a6816 
o|substituted constant variable: a6818 
o|substituted constant variable: a6820 
o|substituted constant variable: a6822 
o|substituted constant variable: a6824 
o|substituted constant variable: a6826 
o|substituted constant variable: a6828 
o|inlining procedure: k6831 
o|inlining procedure: k6831 
o|inlining procedure: k6841 
o|inlining procedure: k6841 
o|inlining procedure: k6851 
o|inlining procedure: k6851 
o|inlining procedure: k6861 
o|inlining procedure: k6861 
o|inlining procedure: k6871 
o|inlining procedure: k6871 
o|inlining procedure: k6881 
o|inlining procedure: k6881 
o|inlining procedure: k6891 
o|inlining procedure: k6891 
o|inlining procedure: k6901 
o|inlining procedure: k6901 
o|inlining procedure: k6911 
o|inlining procedure: k6911 
o|inlining procedure: k6921 
o|inlining procedure: k6921 
o|substituted constant variable: a6928 
o|substituted constant variable: a6930 
o|substituted constant variable: a6932 
o|substituted constant variable: a6934 
o|substituted constant variable: a6936 
o|substituted constant variable: a6938 
o|substituted constant variable: a6940 
o|substituted constant variable: a6942 
o|substituted constant variable: a6944 
o|substituted constant variable: a6946 
o|substituted constant variable: a6948 
o|substituted constant variable: a6950 
o|substituted constant variable: a6952 
o|substituted constant variable: a6954 
o|substituted constant variable: a6956 
o|substituted constant variable: a6958 
o|substituted constant variable: a6960 
o|substituted constant variable: a6962 
o|substituted constant variable: a6964 
o|substituted constant variable: a6966 
o|substituted constant variable: a6968 
o|inlining procedure: k6630 
o|inlining procedure: k7083 
o|inlining procedure: k7083 
o|inlining procedure: k7101 
o|inlining procedure: k7101 
o|inlining procedure: k7117 
o|inlining procedure: k7145 
o|inlining procedure: k7145 
o|inlining procedure: k7117 
o|inlining procedure: k7183 
o|inlining procedure: k7183 
o|inlining procedure: k7199 
o|inlining procedure: k7199 
o|inlining procedure: k7211 
o|inlining procedure: k7240 
o|inlining procedure: k7240 
o|inlining procedure: k7281 
o|inlining procedure: k7281 
o|inlining procedure: k7311 
o|inlining procedure: k7311 
o|inlining procedure: k7211 
o|inlining procedure: k7367 
o|inlining procedure: k7367 
o|inlining procedure: k7417 
o|inlining procedure: k7417 
o|inlining procedure: k7519 
o|inlining procedure: k7551 
o|inlining procedure: k7551 
o|inlining procedure: k7578 
o|inlining procedure: k7578 
o|inlining procedure: k7519 
o|inlining procedure: k7626 
o|inlining procedure: k7626 
o|inlining procedure: k7655 
o|inlining procedure: k7655 
o|inlining procedure: k7704 
o|inlining procedure: k7704 
o|inlining procedure: k7733 
o|inlining procedure: k7733 
o|inlining procedure: k7813 
o|inlining procedure: k7813 
o|inlining procedure: k7839 
o|inlining procedure: k7866 
o|inlining procedure: k7866 
o|inlining procedure: k7839 
o|inlining procedure: k7923 
o|inlining procedure: k7923 
o|inlining procedure: k7953 
o|inlining procedure: k7961 
o|inlining procedure: k7961 
o|inlining procedure: k7953 
o|substituted constant variable: a7982 
o|inlining procedure: k7985 
o|inlining procedure: k7985 
o|inlining procedure: k7995 
o|inlining procedure: k7995 
o|substituted constant variable: a8002 
o|substituted constant variable: a8004 
o|substituted constant variable: a8006 
o|substituted constant variable: a8008 
o|substituted constant variable: a8010 
o|substituted constant variable: a8012 
o|substituted constant variable: a8017 
o|substituted constant variable: a8019 
o|substituted constant variable: a8021 
o|substituted constant variable: a8026 
o|substituted constant variable: a8028 
o|substituted constant variable: a8030 
o|substituted constant variable: a8032 
o|substituted constant variable: a8034 
o|substituted constant variable: a8039 
o|substituted constant variable: a8041 
o|substituted constant variable: a8043 
o|substituted constant variable: a8045 
o|substituted constant variable: a8050 
o|substituted constant variable: a8052 
o|inlining procedure: k8071 
o|inlining procedure: k8071 
o|inlining procedure: k8102 
o|inlining procedure: k8102 
o|inlining procedure: k8141 
o|inlining procedure: k8162 
o|inlining procedure: k8162 
o|inlining procedure: k8141 
o|inlining procedure: k8210 
o|inlining procedure: k8210 
o|inlining procedure: k8236 
o|inlining procedure: k8236 
o|inlining procedure: k8253 
o|inlining procedure: k8253 
o|inlining procedure: k8268 
o|inlining procedure: k8268 
o|inlining procedure: k8279 
o|inlining procedure: k8311 
o|inlining procedure: k8311 
o|inlining procedure: k8353 
o|inlining procedure: k8353 
o|inlining procedure: k8279 
o|inlining procedure: k8403 
o|inlining procedure: k8403 
o|inlining procedure: k8448 
o|inlining procedure: k8448 
o|inlining procedure: k8496 
o|inlining procedure: k8511 
o|inlining procedure: k8511 
o|inlining procedure: k8496 
o|inlining procedure: k8559 
o|inlining procedure: k8559 
o|inlining procedure: k8585 
o|inlining procedure: k8585 
o|inlining procedure: k8610 
o|inlining procedure: k8610 
o|inlining procedure: k8644 
o|inlining procedure: k8669 
o|inlining procedure: k8669 
o|inlining procedure: k8644 
o|inlining procedure: k8719 
o|inlining procedure: k8719 
o|inlining procedure: k8761 
o|inlining procedure: k8761 
o|substituted constant variable: a8791 
o|substituted constant variable: a8793 
o|inlining procedure: k8796 
o|inlining procedure: k8796 
o|substituted constant variable: a8808 
o|substituted constant variable: a8810 
o|substituted constant variable: a8812 
o|substituted constant variable: a8814 
o|substituted constant variable: a8816 
o|substituted constant variable: a8818 
o|substituted constant variable: a8820 
o|substituted constant variable: a8822 
o|substituted constant variable: a8824 
o|substituted constant variable: a8826 
o|substituted constant variable: a8828 
o|substituted constant variable: a8830 
o|substituted constant variable: a8832 
o|substituted constant variable: a8834 
o|substituted constant variable: a8836 
o|inlining procedure: k8839 
o|inlining procedure: k8839 
o|substituted constant variable: a8846 
o|substituted constant variable: a8848 
o|substituted constant variable: a8850 
o|inlining procedure: k8861 
o|inlining procedure: k8861 
o|inlining procedure: k8957 
o|inlining procedure: k8957 
o|inlining procedure: k8996 
o|inlining procedure: k8996 
o|inlining procedure: k9064 
o|inlining procedure: k9064 
o|inlining procedure: "(support.scm:722) rename1895" 
o|inlining procedure: k9099 
o|inlining procedure: "(support.scm:725) rename1895" 
o|inlining procedure: k9099 
o|inlining procedure: k9168 
o|inlining procedure: k9221 
o|inlining procedure: k9221 
o|inlining procedure: k9260 
o|inlining procedure: "(support.scm:749) rename1895" 
o|inlining procedure: k9260 
o|inlining procedure: k9275 
o|inlining procedure: k9275 
o|inlining procedure: k9317 
o|inlining procedure: k9317 
o|inlining procedure: k9168 
o|inlining procedure: k9368 
o|inlining procedure: k9368 
o|substituted constant variable: a9395 
o|substituted constant variable: a9397 
o|substituted constant variable: a9399 
o|substituted constant variable: a9401 
o|substituted constant variable: a9403 
o|inlining procedure: k9411 
o|inlining procedure: k9411 
o|inlining procedure: k9459 
o|inlining procedure: k9459 
o|inlining procedure: k9559 
o|inlining procedure: k9559 
o|inlining procedure: k9620 
o|inlining procedure: k9620 
o|inlining procedure: k9654 
o|inlining procedure: k9676 
o|inlining procedure: k9676 
o|inlining procedure: k9654 
o|inlining procedure: k9731 
o|inlining procedure: k9731 
o|inlining procedure: k9753 
o|contracted procedure: k9766 
o|inlining procedure: k9763 
o|inlining procedure: k9763 
o|inlining procedure: k9779 
o|inlining procedure: k9795 
o|inlining procedure: k9795 
o|inlining procedure: k9833 
o|inlining procedure: k9833 
o|substituted constant variable: a9846 
o|substituted constant variable: a9848 
o|inlining procedure: k9779 
o|inlining procedure: k9753 
o|inlining procedure: k9897 
o|inlining procedure: k9897 
o|inlining procedure: k9942 
o|inlining procedure: k9942 
o|inlining procedure: k9972 
o|inlining procedure: k9972 
o|inlining procedure: k9986 
o|inlining procedure: k9986 
o|inlining procedure: k10009 
o|inlining procedure: k10009 
o|inlining procedure: k10023 
o|inlining procedure: k10047 
o|inlining procedure: k10047 
o|inlining procedure: k10064 
o|inlining procedure: k10064 
o|inlining procedure: k10023 
o|inlining procedure: k10113 
o|inlining procedure: k10113 
o|inlining procedure: k10158 
o|inlining procedure: k10158 
o|inlining procedure: k10193 
o|inlining procedure: k10193 
o|substituted constant variable: a10208 
o|substituted constant variable: a10210 
o|substituted constant variable: a10212 
o|inlining procedure: k10215 
o|inlining procedure: k10215 
o|substituted constant variable: a10227 
o|substituted constant variable: a10229 
o|substituted constant variable: a10231 
o|substituted constant variable: a10233 
o|inlining procedure: k10249 
o|inlining procedure: k10271 
o|inlining procedure: k10292 
o|inlining procedure: k10292 
o|inlining procedure: k10271 
o|substituted constant variable: a10340 
o|substituted constant variable: a10342 
o|inlining procedure: k10249 
o|inlining procedure: k10356 
o|inlining procedure: k10356 
o|inlining procedure: k10369 
o|inlining procedure: k10369 
o|inlining procedure: k10393 
o|inlining procedure: k10393 
o|inlining procedure: k10406 
o|inlining procedure: k10406 
o|inlining procedure: k10427 
o|inlining procedure: k10443 
o|inlining procedure: k10443 
o|inlining procedure: k10427 
o|inlining procedure: k10464 
o|inlining procedure: k10464 
o|contracted procedure: k10474 
o|inlining procedure: k10500 
o|inlining procedure: k10500 
o|inlining procedure: k10520 
o|inlining procedure: k10520 
o|inlining procedure: k10540 
o|inlining procedure: k10540 
o|substituted constant variable: a10556 
o|substituted constant variable: a10558 
o|substituted constant variable: a10560 
o|inlining procedure: k10570 
o|inlining procedure: k10570 
o|inlining procedure: k10600 
o|propagated global variable: out25472551 ##sys#standard-output 
o|propagated global variable: out25372541 ##sys#standard-output 
o|propagated global variable: out25272531 ##sys#standard-output 
o|propagated global variable: out25172521 ##sys#standard-output 
o|propagated global variable: out25072511 ##sys#standard-output 
o|propagated global variable: out24952499 ##sys#standard-output 
o|inlining procedure: k10600 
o|inlining procedure: k10659 
o|inlining procedure: k10659 
o|inlining procedure: k10684 
o|inlining procedure: k10684 
o|inlining procedure: k10718 
o|inlining procedure: k10718 
o|inlining procedure: k10740 
o|inlining procedure: k10740 
o|inlining procedure: k10746 
o|inlining procedure: k10746 
o|inlining procedure: k10791 
o|inlining procedure: k10791 
o|inlining procedure: k10837 
o|inlining procedure: k10837 
o|inlining procedure: k10886 
o|substituted constant variable: tmap2584 
o|substituted constant variable: tmap2584 
o|inlining procedure: k10886 
o|inlining procedure: k10917 
o|inlining procedure: k10917 
o|inlining procedure: k10923 
o|inlining procedure: k10923 
o|inlining procedure: k10943 
o|inlining procedure: k10943 
o|inlining procedure: k10949 
o|inlining procedure: k10949 
o|inlining procedure: k10989 
o|inlining procedure: k10989 
o|inlining procedure: k11035 
o|inlining procedure: k11035 
o|inlining procedure: k11061 
o|inlining procedure: k11061 
o|inlining procedure: k11089 
o|inlining procedure: k11089 
o|inlining procedure: k11081 
o|inlining procedure: k11081 
o|inlining procedure: k11107 
o|inlining procedure: k11107 
o|inlining procedure: k11166 
o|inlining procedure: k11166 
o|inlining procedure: k11190 
o|inlining procedure: k11190 
o|substituted constant variable: a11217 
o|substituted constant variable: a11219 
o|substituted constant variable: a11221 
o|substituted constant variable: a11223 
o|substituted constant variable: a11225 
o|substituted constant variable: a11230 
o|substituted constant variable: a11232 
o|inlining procedure: k11235 
o|inlining procedure: k11235 
o|substituted constant variable: a11247 
o|substituted constant variable: a11249 
o|substituted constant variable: a11251 
o|substituted constant variable: a11253 
o|substituted constant variable: a11261 
o|inlining procedure: k11264 
o|inlining procedure: k11264 
o|substituted constant variable: a11271 
o|substituted constant variable: a11273 
o|substituted constant variable: a11275 
o|inlining procedure: k11278 
o|inlining procedure: k11278 
o|substituted constant variable: a11290 
o|substituted constant variable: a11292 
o|substituted constant variable: a11294 
o|substituted constant variable: a11296 
o|substituted constant variable: a11298 
o|inlining procedure: k11301 
o|inlining procedure: k11301 
o|substituted constant variable: a11308 
o|substituted constant variable: a11310 
o|substituted constant variable: a11312 
o|substituted constant variable: a11314 
o|inlining procedure: k11317 
o|inlining procedure: k11317 
o|substituted constant variable: a11324 
o|substituted constant variable: a11326 
o|substituted constant variable: a11328 
o|substituted constant variable: a11330 
o|inlining procedure: k11333 
o|inlining procedure: k11333 
o|substituted constant variable: a11345 
o|substituted constant variable: a11347 
o|substituted constant variable: a11349 
o|substituted constant variable: a11351 
o|inlining procedure: k11354 
o|inlining procedure: k11354 
o|inlining procedure: k11364 
o|inlining procedure: k11364 
o|inlining procedure: k11374 
o|inlining procedure: k11374 
o|substituted constant variable: a11386 
o|substituted constant variable: a11388 
o|substituted constant variable: a11390 
o|substituted constant variable: a11392 
o|substituted constant variable: a11394 
o|substituted constant variable: a11396 
o|substituted constant variable: a11398 
o|substituted constant variable: a11400 
o|inlining procedure: k11403 
o|inlining procedure: k11403 
o|inlining procedure: k11413 
o|inlining procedure: k11413 
o|inlining procedure: k11423 
o|inlining procedure: k11423 
o|substituted constant variable: a11435 
o|substituted constant variable: a11437 
o|substituted constant variable: a11439 
o|substituted constant variable: a11441 
o|substituted constant variable: a11443 
o|substituted constant variable: a11445 
o|substituted constant variable: a11447 
o|substituted constant variable: a11449 
o|substituted constant variable: a11451 
o|substituted constant variable: a11453 
o|substituted constant variable: a11458 
o|substituted constant variable: a11460 
o|substituted constant variable: a11465 
o|substituted constant variable: a11467 
o|inlining procedure: k11470 
o|inlining procedure: k11470 
o|substituted constant variable: a11477 
o|substituted constant variable: a11479 
o|substituted constant variable: a11481 
o|inlining procedure: k11484 
o|inlining procedure: k11484 
o|inlining procedure: k11494 
o|inlining procedure: k11494 
o|inlining procedure: k11504 
o|inlining procedure: k11504 
o|substituted constant variable: a11516 
o|substituted constant variable: a11518 
o|substituted constant variable: a11520 
o|substituted constant variable: a11522 
o|substituted constant variable: a11524 
o|substituted constant variable: a11526 
o|substituted constant variable: a11528 
o|substituted constant variable: a11530 
o|substituted constant variable: a11535 
o|substituted constant variable: a11537 
o|inlining procedure: k11549 
o|inlining procedure: k11549 
o|inlining procedure: k11557 
o|inlining procedure: k11557 
o|inlining procedure: k11578 
o|inlining procedure: k11578 
o|inlining procedure: k11586 
o|inlining procedure: k11586 
o|inlining procedure: k11620 
o|inlining procedure: k11620 
o|inlining procedure: k11612 
o|inlining procedure: k11612 
o|inlining procedure: k11651 
o|inlining procedure: k11651 
o|inlining procedure: "(support.scm:1169) words->bytes" 
o|inlining procedure: k11670 
o|inlining procedure: "(support.scm:1171) words->bytes" 
o|inlining procedure: k11670 
o|inlining procedure: "(support.scm:1173) words->bytes" 
o|inlining procedure: k11702 
o|inlining procedure: k11702 
o|inlining procedure: k11694 
o|inlining procedure: k11694 
o|inlining procedure: k11720 
o|inlining procedure: "(support.scm:1181) words->bytes" 
o|inlining procedure: k11720 
o|inlining procedure: k11733 
o|inlining procedure: k11733 
o|inlining procedure: k11743 
o|inlining procedure: k11743 
o|inlining procedure: k11753 
o|inlining procedure: k11753 
o|inlining procedure: k11763 
o|inlining procedure: k11763 
o|substituted constant variable: a11770 
o|substituted constant variable: a11772 
o|substituted constant variable: a11774 
o|substituted constant variable: a11776 
o|substituted constant variable: a11778 
o|substituted constant variable: a11780 
o|substituted constant variable: a11782 
o|substituted constant variable: a11784 
o|substituted constant variable: a11786 
o|inlining procedure: k11795 
o|inlining procedure: k11795 
o|inlining procedure: k11805 
o|inlining procedure: k11805 
o|substituted constant variable: a11812 
o|substituted constant variable: a11814 
o|substituted constant variable: a11816 
o|substituted constant variable: a11818 
o|substituted constant variable: a11820 
o|inlining procedure: k11823 
o|inlining procedure: k11823 
o|inlining procedure: k11833 
o|inlining procedure: k11833 
o|inlining procedure: k11843 
o|inlining procedure: k11843 
o|substituted constant variable: a11850 
o|substituted constant variable: a11852 
o|substituted constant variable: a11854 
o|substituted constant variable: a11856 
o|substituted constant variable: a11858 
o|substituted constant variable: a11860 
o|substituted constant variable: a11862 
o|inlining procedure: k11865 
o|inlining procedure: k11865 
o|inlining procedure: k11875 
o|inlining procedure: k11875 
o|inlining procedure: k11885 
o|inlining procedure: k11885 
o|inlining procedure: k11895 
o|inlining procedure: k11895 
o|inlining procedure: k11905 
o|inlining procedure: k11905 
o|substituted constant variable: a11917 
o|substituted constant variable: a11919 
o|substituted constant variable: a11921 
o|substituted constant variable: a11923 
o|substituted constant variable: a11925 
o|substituted constant variable: a11927 
o|substituted constant variable: a11929 
o|substituted constant variable: a11931 
o|substituted constant variable: a11933 
o|substituted constant variable: a11935 
o|substituted constant variable: a11937 
o|substituted constant variable: a11939 
o|inlining procedure: k11942 
o|inlining procedure: k11942 
o|inlining procedure: k11952 
o|inlining procedure: k11952 
o|inlining procedure: k11962 
o|inlining procedure: k11962 
o|inlining procedure: k11972 
o|inlining procedure: k11972 
o|inlining procedure: k11982 
o|inlining procedure: k11982 
o|inlining procedure: k11992 
o|inlining procedure: k11992 
o|substituted constant variable: a11999 
o|substituted constant variable: a12001 
o|substituted constant variable: a12003 
o|substituted constant variable: a12005 
o|substituted constant variable: a12007 
o|substituted constant variable: a12009 
o|substituted constant variable: a12011 
o|substituted constant variable: a12013 
o|substituted constant variable: a12015 
o|substituted constant variable: a12017 
o|substituted constant variable: a12019 
o|substituted constant variable: a12021 
o|substituted constant variable: a12023 
o|inlining procedure: k12045 
o|inlining procedure: "(support.scm:1198) words->bytes" 
o|inlining procedure: k12045 
o|inlining procedure: "(support.scm:1200) words->bytes" 
o|inlining procedure: k12077 
o|inlining procedure: k12077 
o|inlining procedure: k12069 
o|inlining procedure: k12069 
o|inlining procedure: k12095 
o|inlining procedure: "(support.scm:1207) words->bytes" 
o|inlining procedure: k12095 
o|inlining procedure: "(support.scm:1208) err3012" 
o|inlining procedure: k12111 
o|inlining procedure: k12111 
o|inlining procedure: k12121 
o|inlining procedure: k12121 
o|substituted constant variable: a12133 
o|substituted constant variable: a12135 
o|substituted constant variable: a12137 
o|substituted constant variable: a12139 
o|substituted constant variable: a12141 
o|substituted constant variable: a12143 
o|inlining procedure: "(support.scm:1209) err3012" 
o|inlining procedure: k12155 
o|inlining procedure: k12155 
o|substituted constant variable: a12167 
o|substituted constant variable: a12169 
o|substituted constant variable: a12171 
o|substituted constant variable: a12173 
o|inlining procedure: k12176 
o|inlining procedure: k12176 
o|inlining procedure: k12186 
o|inlining procedure: k12186 
o|inlining procedure: k12196 
o|inlining procedure: k12196 
o|inlining procedure: k12206 
o|inlining procedure: k12206 
o|inlining procedure: k12216 
o|inlining procedure: k12216 
o|inlining procedure: k12226 
o|inlining procedure: k12226 
o|inlining procedure: k12236 
o|inlining procedure: k12236 
o|inlining procedure: k12246 
o|inlining procedure: k12246 
o|inlining procedure: k12256 
o|inlining procedure: k12256 
o|inlining procedure: k12266 
o|inlining procedure: k12266 
o|inlining procedure: k12276 
o|inlining procedure: k12276 
o|inlining procedure: k12286 
o|inlining procedure: k12286 
o|inlining procedure: k12296 
o|inlining procedure: k12296 
o|inlining procedure: k12306 
o|inlining procedure: k12306 
o|inlining procedure: k12316 
o|inlining procedure: k12316 
o|inlining procedure: k12326 
o|inlining procedure: k12326 
o|substituted constant variable: a12333 
o|substituted constant variable: a12335 
o|substituted constant variable: a12337 
o|substituted constant variable: a12339 
o|substituted constant variable: a12341 
o|substituted constant variable: a12343 
o|substituted constant variable: a12345 
o|substituted constant variable: a12347 
o|substituted constant variable: a12349 
o|substituted constant variable: a12351 
o|substituted constant variable: a12353 
o|substituted constant variable: a12355 
o|substituted constant variable: a12357 
o|substituted constant variable: a12359 
o|substituted constant variable: a12361 
o|substituted constant variable: a12363 
o|substituted constant variable: a12365 
o|substituted constant variable: a12367 
o|substituted constant variable: a12369 
o|substituted constant variable: a12371 
o|substituted constant variable: a12373 
o|substituted constant variable: a12375 
o|substituted constant variable: a12377 
o|substituted constant variable: a12379 
o|substituted constant variable: a12381 
o|substituted constant variable: a12383 
o|substituted constant variable: a12385 
o|substituted constant variable: a12387 
o|substituted constant variable: a12389 
o|substituted constant variable: a12391 
o|substituted constant variable: a12393 
o|substituted constant variable: a12395 
o|substituted constant variable: a12397 
o|inlining procedure: k12409 
o|inlining procedure: k12409 
o|inlining procedure: k12435 
o|inlining procedure: k12435 
o|inlining procedure: k12463 
o|inlining procedure: k12463 
o|inlining procedure: k12490 
o|inlining procedure: k12490 
o|inlining procedure: k12508 
o|inlining procedure: k12508 
o|inlining procedure: k12528 
o|inlining procedure: k12528 
o|substituted constant variable: a12581 
o|substituted constant variable: a12586 
o|substituted constant variable: a12588 
o|substituted constant variable: a12589 
o|inlining procedure: k12596 
o|substituted constant variable: a12605 
o|inlining procedure: k12596 
o|substituted constant variable: a12606 
o|substituted constant variable: a12614 
o|substituted constant variable: a12616 
o|substituted constant variable: a12618 
o|substituted constant variable: a12623 
o|substituted constant variable: a12625 
o|substituted constant variable: a12630 
o|substituted constant variable: a12632 
o|substituted constant variable: a12634 
o|substituted constant variable: a12639 
o|substituted constant variable: a12641 
o|inlining procedure: k12648 
o|inlining procedure: k12648 
o|inlining procedure: k12662 
o|inlining procedure: k12662 
o|inlining procedure: k12678 
o|inlining procedure: k12678 
o|substituted constant variable: a12685 
o|inlining procedure: k12686 
o|inlining procedure: k12686 
o|inlining procedure: k12700 
o|inlining procedure: k12700 
o|substituted constant variable: a12707 
o|inlining procedure: k12708 
o|inlining procedure: k12708 
o|inlining procedure: k12720 
o|inlining procedure: k12720 
o|substituted constant variable: a12727 
o|inlining procedure: k12728 
o|inlining procedure: k12728 
o|inlining procedure: k12742 
o|inlining procedure: k12742 
o|substituted constant variable: a12758 
o|inlining procedure: k12759 
o|inlining procedure: k12759 
o|inlining procedure: k12771 
o|inlining procedure: k12771 
o|inlining procedure: k12783 
o|inlining procedure: k12783 
o|inlining procedure: k12795 
o|inlining procedure: k12795 
o|inlining procedure: k12807 
o|inlining procedure: k12807 
o|inlining procedure: k12821 
o|inlining procedure: k12821 
o|inlining procedure: k12835 
o|inlining procedure: k12835 
o|inlining procedure: k12851 
o|inlining procedure: k12851 
o|inlining procedure: k12864 
o|inlining procedure: k12864 
o|inlining procedure: k12884 
o|inlining procedure: k12884 
o|inlining procedure: k12895 
o|inlining procedure: k12895 
o|substituted constant variable: a12902 
o|substituted constant variable: a12904 
o|substituted constant variable: a12906 
o|substituted constant variable: a12908 
o|inlining procedure: k12911 
o|inlining procedure: k12911 
o|substituted constant variable: a12923 
o|substituted constant variable: a12925 
o|substituted constant variable: a12927 
o|substituted constant variable: a12929 
o|substituted constant variable: a12931 
o|inlining procedure: k12934 
o|inlining procedure: k12934 
o|substituted constant variable: a12941 
o|substituted constant variable: a12943 
o|substituted constant variable: a12945 
o|substituted constant variable: a12950 
o|substituted constant variable: a12952 
o|inlining procedure: k12955 
o|inlining procedure: k12955 
o|substituted constant variable: a12967 
o|substituted constant variable: a12969 
o|substituted constant variable: a12971 
o|substituted constant variable: a12973 
o|substituted constant variable: a12975 
o|substituted constant variable: a12977 
o|inlining procedure: k12980 
o|inlining procedure: k12980 
o|inlining procedure: k12990 
o|inlining procedure: k12990 
o|inlining procedure: k13000 
o|inlining procedure: k13000 
o|substituted constant variable: a13012 
o|substituted constant variable: a13014 
o|substituted constant variable: a13016 
o|substituted constant variable: a13018 
o|substituted constant variable: a13020 
o|substituted constant variable: a13022 
o|substituted constant variable: a13024 
o|substituted constant variable: a13026 
o|substituted constant variable: a13028 
o|substituted constant variable: a13030 
o|substituted constant variable: a13032 
o|substituted constant variable: a13034 
o|substituted constant variable: a13036 
o|substituted constant variable: a13038 
o|substituted constant variable: a13040 
o|substituted constant variable: a13042 
o|inlining procedure: k13045 
o|inlining procedure: k13045 
o|inlining procedure: k13055 
o|inlining procedure: k13055 
o|inlining procedure: k13065 
o|inlining procedure: k13065 
o|substituted constant variable: a13077 
o|substituted constant variable: a13079 
o|substituted constant variable: a13081 
o|substituted constant variable: a13083 
o|substituted constant variable: a13085 
o|substituted constant variable: a13087 
o|substituted constant variable: a13089 
o|substituted constant variable: a13091 
o|substituted constant variable: a13093 
o|substituted constant variable: a13095 
o|substituted constant variable: a13097 
o|substituted constant variable: a13099 
o|substituted constant variable: a13104 
o|substituted constant variable: a13106 
o|substituted constant variable: a13111 
o|substituted constant variable: a13113 
o|inlining procedure: k13116 
o|inlining procedure: k13116 
o|inlining procedure: k13126 
o|inlining procedure: k13126 
o|inlining procedure: k13136 
o|inlining procedure: k13136 
o|substituted constant variable: a13148 
o|substituted constant variable: a13150 
o|substituted constant variable: a13152 
o|substituted constant variable: a13154 
o|substituted constant variable: a13156 
o|substituted constant variable: a13158 
o|substituted constant variable: a13160 
o|substituted constant variable: a13162 
o|substituted constant variable: a13167 
o|substituted constant variable: a13169 
o|substituted constant variable: a13171 
o|inlining procedure: k13196 
o|inlining procedure: k13217 
o|inlining procedure: k13217 
o|inlining procedure: k13196 
o|inlining procedure: k13274 
o|inlining procedure: k13274 
o|inlining procedure: k13292 
o|inlining procedure: k13292 
o|substituted constant variable: a13299 
o|substituted constant variable: a13301 
o|substituted constant variable: a13303 
o|substituted constant variable: a13308 
o|substituted constant variable: a13310 
o|inlining procedure: k13340 
o|inlining procedure: k13340 
o|inlining procedure: k13356 
o|inlining procedure: k13356 
o|inlining procedure: k13376 
o|inlining procedure: k13376 
o|inlining procedure: k13419 
o|inlining procedure: k13419 
o|substituted constant variable: a13446 
o|substituted constant variable: a13448 
o|substituted constant variable: a13450 
o|substituted constant variable: a13452 
o|inlining procedure: k13455 
o|inlining procedure: k13455 
o|inlining procedure: k13465 
o|inlining procedure: k13465 
o|substituted constant variable: a13472 
o|substituted constant variable: a13474 
o|substituted constant variable: a13476 
o|substituted constant variable: a13478 
o|substituted constant variable: a13480 
o|inlining procedure: k13498 
o|inlining procedure: k13498 
o|inlining procedure: k13525 
o|inlining procedure: k13525 
o|substituted constant variable: a13540 
o|inlining procedure: k13557 
o|inlining procedure: k13557 
o|inlining procedure: k13632 
o|inlining procedure: k13632 
o|inlining procedure: k13661 
o|inlining procedure: k13661 
o|contracted procedure: k13674 
o|inlining procedure: k13671 
o|inlining procedure: k13700 
o|inlining procedure: k13700 
o|inlining procedure: k13719 
o|inlining procedure: k13719 
o|inlining procedure: k13671 
o|inlining procedure: k13764 
o|inlining procedure: k13764 
o|propagated global variable: out35793583 ##sys#standard-output 
o|inlining procedure: k13792 
o|inlining procedure: k13792 
o|inlining procedure: k13820 
o|inlining procedure: k13820 
o|inlining procedure: k13843 
o|inlining procedure: k13843 
o|inlining procedure: k13846 
o|inlining procedure: k13846 
o|inlining procedure: k13924 
o|substituted constant variable: a13949 
o|inlining procedure: k13924 
o|inlining procedure: k13985 
o|inlining procedure: k13985 
o|inlining procedure: k14015 
o|inlining procedure: k14015 
o|inlining procedure: k14104 
o|inlining procedure: k14127 
o|inlining procedure: k14127 
o|propagated global variable: out37593763 ##sys#standard-output 
o|propagated global variable: out37473751 ##sys#standard-output 
o|inlining procedure: k14104 
o|inlining procedure: k14153 
o|inlining procedure: k14153 
o|propagated global variable: out37083712 ##sys#standard-output 
o|inlining procedure: k14173 
o|inlining procedure: k14193 
o|inlining procedure: k14193 
o|inlining procedure: k14173 
o|inlining procedure: k14217 
o|inlining procedure: k14217 
o|inlining procedure: k14250 
o|inlining procedure: k14250 
o|inlining procedure: k14270 
o|substituted constant variable: a14294 
o|inlining procedure: k14270 
o|inlining procedure: k14305 
o|inlining procedure: k14318 
o|inlining procedure: k14318 
o|inlining procedure: k14305 
o|inlining procedure: k14372 
o|inlining procedure: k14372 
o|substituted constant variable: a14388 
o|substituted constant variable: a14390 
o|inlining procedure: k14441 
o|inlining procedure: k14481 
o|inlining procedure: k14481 
o|inlining procedure: k14441 
o|substituted constant variable: constant25 
o|replaced variables: 2030 
o|removed binding forms: 301 
o|removed side-effect free assignment to unused variable: constant25 
o|substituted constant variable: r477114598 
o|inlining procedure: k4782 
o|substituted constant variable: r477114599 
o|inlining procedure: k4790 
o|substituted constant variable: f_500714610 
o|converted assignments to bindings: (err219) 
o|substituted constant variable: f_510814616 
o|substituted constant variable: f_514014618 
o|substituted constant variable: f_529314626 
o|substituted constant variable: r533214628 
o|substituted constant variable: r533214629 
o|substituted constant variable: r536714635 
o|substituted constant variable: r570514669 
o|substituted constant variable: f_574114670 
o|substituted constant variable: r584614678 
o|substituted constant variable: r617714699 
o|substituted constant variable: r619414701 
o|substituted constant variable: r634314711 
o|inlining procedure: k6494 
o|substituted constant variable: r720014775 
o|removed side-effect free assignment to unused variable: rename1895 
o|substituted constant variable: a925914900 
o|substituted constant variable: r976414923 
o|substituted constant variable: r979614926 
o|substituted constant variable: r983414928 
o|substituted constant variable: r978014930 
o|substituted constant variable: r998714939 
o|substituted constant variable: r1006514945 
o|substituted constant variable: r1002414947 
o|substituted constant variable: r1011414949 
o|substituted constant variable: r1015914950 
o|substituted constant variable: r1019414953 
o|substituted constant variable: r1029314959 
o|substituted constant variable: r1025014961 
o|substituted constant variable: r1037014965 
o|substituted constant variable: r1040714969 
o|substituted constant variable: a1044214972 
o|substituted constant variable: r1155815061 
o|substituted constant variable: r1158715065 
o|substituted constant variable: r1165215070 
o|substituted constant variable: a35035315073 
o|substituted constant variable: a35035315079 
o|substituted constant variable: a35035315085 
o|substituted constant variable: a35035315095 
o|substituted constant variable: r1172115099 
o|removed side-effect free assignment to unused variable: err3012 
o|substituted constant variable: a35035315142 
o|substituted constant variable: a35035315148 
o|substituted constant variable: a35035315158 
o|substituted constant variable: r1259715224 
o|substituted constant variable: r1264915225 
o|substituted constant variable: r1266315227 
o|substituted constant variable: r1267915229 
o|substituted constant variable: r1267915230 
o|substituted constant variable: r1268715231 
o|substituted constant variable: r1270115233 
o|substituted constant variable: r1270115234 
o|substituted constant variable: r1270915235 
o|substituted constant variable: r1272115237 
o|substituted constant variable: r1272115238 
o|substituted constant variable: r1272915239 
o|substituted constant variable: r1276015243 
o|substituted constant variable: r1277215245 
o|substituted constant variable: r1278415247 
o|substituted constant variable: r1279615249 
o|substituted constant variable: r1280815251 
o|substituted constant variable: r1282215253 
o|substituted constant variable: r1283615255 
o|substituted constant variable: r1285215257 
o|substituted constant variable: r1286515259 
o|substituted constant variable: r1288515261 
o|substituted constant variable: r1334115297 
o|converted assignments to bindings: (resolve3548) 
o|substituted constant variable: r1376515328 
o|substituted constant variable: r1384715336 
o|substituted constant variable: r1419415360 
o|substituted constant variable: r1419415360 
o|substituted constant variable: f_1430415372 
o|substituted constant variable: r1437315373 
o|substituted constant variable: r1444215378 
o|simplifications: ((let . 2)) 
o|replaced variables: 21 
o|removed binding forms: 2048 
o|substituted constant variable: r47711459815384 
o|substituted constant variable: r47711459915386 
o|inlining procedure: k5996 
o|inlining procedure: k6019 
o|inlining procedure: k6043 
o|inlining procedure: k6066 
o|inlining procedure: k6090 
o|inlining procedure: k6637 
o|inlining procedure: k6637 
o|inlining procedure: k6637 
o|inlining procedure: k6637 
o|inlining procedure: k6637 
o|inlining procedure: k6637 
o|inlining procedure: k6637 
o|inlining procedure: k6637 
o|inlining procedure: k9905 
o|inlining procedure: k10198 
o|inlining procedure: k11207 
o|inlining procedure: k11547 
o|inlining procedure: k11547 
o|inlining procedure: k11547 
o|inlining procedure: k11576 
o|inlining procedure: k11576 
o|inlining procedure: k11576 
o|inlining procedure: k13384 
o|inlining procedure: k13384 
o|inlining procedure: k13840 
o|inlining procedure: k13840 
o|inlining procedure: k14330 
o|inlining procedure: k14351 
o|inlining procedure: k14395 
o|inlining procedure: k14522 
o|replaced variables: 1 
o|removed binding forms: 103 
o|substituted constant variable: r599715634 
o|substituted constant variable: r602015635 
o|substituted constant variable: r604415636 
o|substituted constant variable: r606715637 
o|substituted constant variable: r609115638 
o|substituted constant variable: r990615755 
o|substituted constant variable: tmp2840284215773 
o|substituted constant variable: tmp2840284215773 
o|substituted constant variable: tmp2840284215773 
o|substituted constant variable: tmp2840284215776 
o|substituted constant variable: tmp2840284215776 
o|substituted constant variable: tmp2840284215776 
o|substituted constant variable: tmp2840284215779 
o|substituted constant variable: tmp2840284215779 
o|substituted constant variable: tmp2840284215779 
o|substituted constant variable: tmp2847284915782 
o|substituted constant variable: tmp2847284915782 
o|substituted constant variable: tmp2847284915782 
o|substituted constant variable: tmp2847284915785 
o|substituted constant variable: tmp2847284915785 
o|substituted constant variable: tmp2847284915785 
o|substituted constant variable: tmp2847284915788 
o|substituted constant variable: tmp2847284915788 
o|substituted constant variable: tmp2847284915788 
o|substituted constant variable: r1384115811 
o|substituted constant variable: r1384115811 
o|substituted constant variable: r1384115811 
o|substituted constant variable: r1384115814 
o|substituted constant variable: r1384115814 
o|substituted constant variable: r1384115814 
o|substituted constant variable: r1433115829 
o|substituted constant variable: r1435215830 
o|substituted constant variable: r1439615831 
o|removed binding forms: 16 
o|removed conditional forms: 8 
o|removed binding forms: 18 
o|simplifications: ((if . 67) (##core#call . 1404)) 
o|  call simplifications:
o|    ##sys#fudge
o|    read-char	3
o|    ##sys#size
o|    fx>	2
o|    procedure?
o|    fx+	2
o|    string-length	3
o|    >	2
o|    string-ref	2
o|    list?	4
o|    vector-ref	6
o|    <
o|    *
o|    -	2
o|    first	18
o|    positive?
o|    not-pair?	5
o|    ##sys#call-with-values	5
o|    cdddr
o|    second	10
o|    third	6
o|    fourth	4
o|    caddr	4
o|    cadr	24
o|    integer?
o|    inexact->exact
o|    ##sys#check-structure	7
o|    ##sys#block-ref	4
o|    ##sys#structure?	4
o|    ##sys#make-structure	31
o|    cdar	6
o|    caar	5
o|    length	8
o|    values	4
o|    +	7
o|    ##sys#setslot	36
o|    assq	17
o|    alist-cons	8
o|    atom?
o|    ##sys#apply	2
o|    ##sys#cons	7
o|    equal?	3
o|    ##sys#list	124
o|    vector?	7
o|    fixnum?	2
o|    number?	4
o|    char?	4
o|    boolean?	4
o|    eof-object?	5
o|    member
o|    cddr	3
o|    list	49
o|    string=?	2
o|    not	12
o|    ##sys#foreign-fixnum-argument	9
o|    char-alphabetic?	2
o|    char-numeric?
o|    char=?	6
o|    char->integer
o|    fx>=	2
o|    fx<	4
o|    number->string
o|    string->list	3
o|    list->string
o|    zero?	3
o|    sub1	4
o|    string?	4
o|    eqv?
o|    eq?	375
o|    add1	4
o|    null?	41
o|    cons	61
o|    car	51
o|    cdr	20
o|    ##sys#check-list	40
o|    symbol?	18
o|    memq	12
o|    ##sys#slot	152
o|    write-char	36
o|    pair?	69
o|    apply	5
o|contracted procedure: k4680 
o|contracted procedure: k4721 
o|contracted procedure: k4745 
o|contracted procedure: k4754 
o|contracted procedure: k4757 
o|contracted procedure: k4773 
o|contracted procedure: k4784 
o|contracted procedure: k4792 
o|contracted procedure: k4823 
o|propagated global variable: out117121 ##compiler#collected-debugging-output 
o|contracted procedure: k4838 
o|contracted procedure: k4847 
o|contracted procedure: k4850 
o|contracted procedure: k4858 
o|contracted procedure: k4930 
o|contracted procedure: k4946 
o|contracted procedure: k4955 
o|contracted procedure: k4958 
o|contracted procedure: k4982 
o|contracted procedure: k4986 
o|contracted procedure: k4990 
o|contracted procedure: k5010 
o|contracted procedure: k5016 
o|contracted procedure: k5034 
o|contracted procedure: k5053 
o|contracted procedure: k5064 
o|contracted procedure: k5070 
o|contracted procedure: k5076 
o|contracted procedure: k5084 
o|contracted procedure: k5094 
o|contracted procedure: k5097 
o|contracted procedure: k5111 
o|contracted procedure: k5129 
o|contracted procedure: k5117 
o|contracted procedure: k5126 
o|contracted procedure: k5143 
o|contracted procedure: k5161 
o|contracted procedure: k5149 
o|contracted procedure: k5158 
o|contracted procedure: k5169 
o|contracted procedure: k5175 
o|contracted procedure: k5195 
o|contracted procedure: k5201 
o|contracted procedure: k5249 
o|contracted procedure: k5251 
o|contracted procedure: k5261 
o|contracted procedure: k5269 
o|contracted procedure: k5282 
o|contracted procedure: k5296 
o|contracted procedure: k5299 
o|contracted procedure: k5301 
o|contracted procedure: k5306 
o|contracted procedure: k5328 
o|contracted procedure: k5334 
o|contracted procedure: k5349 
o|contracted procedure: k5369 
o|contracted procedure: k5376 
o|contracted procedure: k5378 
o|contracted procedure: k5387 
o|contracted procedure: k5392 
o|contracted procedure: k5413 
o|contracted procedure: k5420 
o|contracted procedure: k5428 
o|contracted procedure: k5443 
o|contracted procedure: k5455 
o|contracted procedure: k5461 
o|contracted procedure: k5469 
o|contracted procedure: k5524 
o|contracted procedure: k5481 
o|contracted procedure: k5521 
o|contracted procedure: k5499 
o|inlining procedure: k5497 
o|inlining procedure: k5497 
o|contracted procedure: k5538 
o|contracted procedure: k5553 
o|contracted procedure: k5576 
o|contracted procedure: k5581 
o|contracted procedure: k5586 
o|contracted procedure: k5591 
o|contracted procedure: k5596 
o|contracted procedure: k5604 
o|contracted procedure: k5616 
o|contracted procedure: k5621 
o|contracted procedure: k5626 
o|contracted procedure: k5631 
o|contracted procedure: k5648 
o|contracted procedure: k5653 
o|contracted procedure: k5658 
o|contracted procedure: k5663 
o|contracted procedure: k5671 
o|contracted procedure: k5684 
o|contracted procedure: k5689 
o|contracted procedure: k5707 
o|contracted procedure: k5723 
o|contracted procedure: k5744 
o|contracted procedure: k5796 
o|contracted procedure: k5750 
o|contracted procedure: k5758 
o|contracted procedure: k5780 
o|contracted procedure: k5772 
o|contracted procedure: k5848 
o|contracted procedure: k5862 
o|contracted procedure: k5854 
o|contracted procedure: k5909 
o|contracted procedure: k5915 
o|contracted procedure: k5923 
o|contracted procedure: k5933 
o|contracted procedure: k5936 
o|contracted procedure: k5945 
o|contracted procedure: k5949 
o|contracted procedure: k5983 
o|contracted procedure: k5980 
o|contracted procedure: k5959 
o|contracted procedure: k5977 
o|contracted procedure: k5974 
o|contracted procedure: k5962 
o|contracted procedure: k5971 
o|contracted procedure: k5968 
o|contracted procedure: k5965 
o|contracted procedure: k5956 
o|contracted procedure: k6002 
o|contracted procedure: k5996 
o|contracted procedure: k6014 
o|contracted procedure: k6025 
o|contracted procedure: k6019 
o|contracted procedure: k6034 
o|contracted procedure: k6049 
o|contracted procedure: k6043 
o|contracted procedure: k6061 
o|contracted procedure: k6072 
o|contracted procedure: k6066 
o|contracted procedure: k6081 
o|contracted procedure: k6096 
o|contracted procedure: k6090 
o|contracted procedure: k6105 
o|contracted procedure: k6116 
o|contracted procedure: k6125 
o|contracted procedure: k6128 
o|propagated global variable: g631633 ##compiler#internal-bindings 
o|contracted procedure: k6136 
o|contracted procedure: k6145 
o|contracted procedure: k6148 
o|propagated global variable: g582584 extended-bindings 
o|contracted procedure: k6156 
o|contracted procedure: k6165 
o|contracted procedure: k6168 
o|propagated global variable: g533535 standard-bindings 
o|contracted procedure: k6179 
o|contracted procedure: k6213 
o|contracted procedure: k6231 
o|contracted procedure: k6228 
o|contracted procedure: k6243 
o|contracted procedure: k6240 
o|contracted procedure: k6254 
o|contracted procedure: k6266 
o|contracted procedure: k6263 
o|contracted procedure: k6275 
o|contracted procedure: k6278 
o|contracted procedure: k6272 
o|contracted procedure: k6287 
o|contracted procedure: k6284 
o|contracted procedure: k6300 
o|contracted procedure: k6312 
o|contracted procedure: k6309 
o|contracted procedure: k6321 
o|contracted procedure: k6318 
o|contracted procedure: k6330 
o|contracted procedure: k6327 
o|contracted procedure: k6332 
o|contracted procedure: k6352 
o|contracted procedure: k6358 
o|contracted procedure: k6372 
o|contracted procedure: k6375 
o|contracted procedure: k6387 
o|contracted procedure: k6399 
o|contracted procedure: k6433 
o|contracted procedure: k6444 
o|contracted procedure: k6466 
o|contracted procedure: k6463 
o|contracted procedure: k6447 
o|contracted procedure: k6456 
o|contracted procedure: k6483 
o|contracted procedure: k6499 
o|contracted procedure: k6508 
o|contracted procedure: k6510 
o|contracted procedure: k6519 
o|contracted procedure: k6530 
o|contracted procedure: k6560 
o|contracted procedure: k6590 
o|contracted procedure: k6612 
o|contracted procedure: k6618 
o|contracted procedure: k6624 
o|contracted procedure: k6632 
o|contracted procedure: k6635 
o|contracted procedure: k6645 
o|contracted procedure: k6662 
o|contracted procedure: k6659 
o|contracted procedure: k6656 
o|contracted procedure: k6667 
o|contracted procedure: k6674 
o|contracted procedure: k6680 
o|contracted procedure: k6684 
o|contracted procedure: k6690 
o|contracted procedure: k6696 
o|contracted procedure: k6700 
o|contracted procedure: k6706 
o|contracted procedure: k6710 
o|contracted procedure: k6716 
o|contracted procedure: k6731 
o|contracted procedure: k6734 
o|contracted procedure: k6739 
o|contracted procedure: k6743 
o|contracted procedure: k6749 
o|contracted procedure: k6753 
o|contracted procedure: k6765 
o|contracted procedure: k6770 
o|contracted procedure: k6775 
o|contracted procedure: k6780 
o|contracted procedure: k6785 
o|contracted procedure: k6790 
o|contracted procedure: k6795 
o|contracted procedure: k6829 
o|contracted procedure: k6834 
o|contracted procedure: k6839 
o|contracted procedure: k6844 
o|contracted procedure: k6849 
o|contracted procedure: k6854 
o|contracted procedure: k6859 
o|contracted procedure: k6864 
o|contracted procedure: k6869 
o|contracted procedure: k6874 
o|contracted procedure: k6879 
o|contracted procedure: k6884 
o|contracted procedure: k6889 
o|contracted procedure: k6894 
o|contracted procedure: k6899 
o|contracted procedure: k6904 
o|contracted procedure: k6909 
o|contracted procedure: k6914 
o|contracted procedure: k6919 
o|contracted procedure: k6989 
o|contracted procedure: k6998 
o|contracted procedure: k7007 
o|contracted procedure: k7016 
o|contracted procedure: k7025 
o|contracted procedure: k7034 
o|contracted procedure: k7059 
o|contracted procedure: k7073 
o|contracted procedure: k7085 
o|contracted procedure: k7104 
o|contracted procedure: k8098 
o|contracted procedure: k7113 
o|contracted procedure: k7120 
o|contracted procedure: k7122 
o|contracted procedure: k7136 
o|contracted procedure: k7147 
o|contracted procedure: k7150 
o|contracted procedure: k7159 
o|contracted procedure: k7169 
o|contracted procedure: k7174 
o|contracted procedure: k7177 
o|contracted procedure: k7183 
o|contracted procedure: k7196 
o|contracted procedure: k7202 
o|contracted procedure: k7209 
o|contracted procedure: k7214 
o|contracted procedure: k7217 
o|contracted procedure: k7219 
o|contracted procedure: k7224 
o|contracted procedure: k7242 
o|contracted procedure: k7262 
o|contracted procedure: k7264 
o|contracted procedure: k7266 
o|contracted procedure: k7272 
o|contracted procedure: k7283 
o|contracted procedure: k7286 
o|contracted procedure: k7295 
o|contracted procedure: k7305 
o|contracted procedure: k7313 
o|contracted procedure: k7316 
o|contracted procedure: k7325 
o|contracted procedure: k7335 
o|contracted procedure: k7340 
o|contracted procedure: k7342 
o|contracted procedure: k7365 
o|contracted procedure: k7353 
o|contracted procedure: k7356 
o|contracted procedure: k7362 
o|contracted procedure: k7370 
o|contracted procedure: k7393 
o|contracted procedure: k7396 
o|contracted procedure: k7381 
o|contracted procedure: k7384 
o|contracted procedure: k7390 
o|contracted procedure: k7401 
o|contracted procedure: k7408 
o|contracted procedure: k7411 
o|contracted procedure: k7419 
o|contracted procedure: k7447 
o|contracted procedure: k7430 
o|contracted procedure: k7436 
o|contracted procedure: k7510 
o|contracted procedure: k7455 
o|contracted procedure: k7481 
o|contracted procedure: k7466 
o|contracted procedure: k7472 
o|contracted procedure: k7487 
o|contracted procedure: k7507 
o|contracted procedure: k7495 
o|contracted procedure: k7498 
o|contracted procedure: k7522 
o|contracted procedure: k7525 
o|contracted procedure: k7542 
o|contracted procedure: k7553 
o|contracted procedure: k7556 
o|contracted procedure: k7565 
o|contracted procedure: k7575 
o|contracted procedure: k7578 
o|contracted procedure: k7586 
o|contracted procedure: k7597 
o|contracted procedure: k7599 
o|contracted procedure: k7653 
o|contracted procedure: k7612 
o|contracted procedure: k7617 
o|contracted procedure: k7628 
o|contracted procedure: k7631 
o|contracted procedure: k7640 
o|contracted procedure: k7650 
o|contracted procedure: k7658 
o|contracted procedure: k7672 
o|contracted procedure: k7669 
o|contracted procedure: k7677 
o|contracted procedure: k7679 
o|contracted procedure: k7731 
o|contracted procedure: k7690 
o|contracted procedure: k7695 
o|contracted procedure: k7706 
o|contracted procedure: k7709 
o|contracted procedure: k7718 
o|contracted procedure: k7728 
o|contracted procedure: k7736 
o|contracted procedure: k7779 
o|contracted procedure: k7739 
o|contracted procedure: k7776 
o|contracted procedure: k7761 
o|contracted procedure: k7773 
o|contracted procedure: k7764 
o|contracted procedure: k7767 
o|contracted procedure: k7749 
o|contracted procedure: k7752 
o|contracted procedure: k7784 
o|contracted procedure: k7799 
o|contracted procedure: k7804 
o|contracted procedure: k7815 
o|contracted procedure: k7818 
o|contracted procedure: k7827 
o|contracted procedure: k7837 
o|contracted procedure: k7842 
o|contracted procedure: k7853 
o|contracted procedure: k7857 
o|contracted procedure: k7868 
o|contracted procedure: k7871 
o|contracted procedure: k7880 
o|contracted procedure: k7890 
o|contracted procedure: k7911 
o|contracted procedure: k7914 
o|contracted procedure: k7925 
o|contracted procedure: k7928 
o|contracted procedure: k7937 
o|contracted procedure: k7947 
o|contracted procedure: k7978 
o|contracted procedure: k7983 
o|contracted procedure: k7988 
o|contracted procedure: k7993 
o|contracted procedure: k8061 
o|contracted procedure: k8073 
o|contracted procedure: k8076 
o|contracted procedure: k8085 
o|contracted procedure: k8095 
o|contracted procedure: k8104 
o|contracted procedure: k8144 
o|contracted procedure: k8153 
o|contracted procedure: k8164 
o|contracted procedure: k8167 
o|contracted procedure: k8176 
o|contracted procedure: k8186 
o|contracted procedure: k8191 
o|contracted procedure: k8201 
o|contracted procedure: k8198 
o|contracted procedure: k8212 
o|contracted procedure: k8215 
o|contracted procedure: k8224 
o|contracted procedure: k8234 
o|contracted procedure: k8239 
o|contracted procedure: k8248 
o|contracted procedure: k8251 
o|contracted procedure: k8256 
o|contracted procedure: k8266 
o|contracted procedure: k8271 
o|contracted procedure: k8282 
o|contracted procedure: k8294 
o|contracted procedure: k8296 
o|contracted procedure: k8343 
o|contracted procedure: k8313 
o|contracted procedure: k8338 
o|contracted procedure: k8341 
o|contracted procedure: k8335 
o|contracted procedure: k8316 
o|contracted procedure: k8325 
o|contracted procedure: k8328 
o|contracted procedure: k8355 
o|contracted procedure: k8358 
o|contracted procedure: k8367 
o|contracted procedure: k8377 
o|contracted procedure: k8382 
o|contracted procedure: k8400 
o|contracted procedure: k8389 
o|contracted procedure: k8392 
o|contracted procedure: k8398 
o|contracted procedure: k8406 
o|contracted procedure: k8413 
o|contracted procedure: k8419 
o|contracted procedure: k8424 
o|contracted procedure: k8431 
o|contracted procedure: k8440 
o|contracted procedure: k8450 
o|contracted procedure: k8456 
o|contracted procedure: k8463 
o|contracted procedure: k8469 
o|contracted procedure: k8485 
o|contracted procedure: k8475 
o|contracted procedure: k8491 
o|contracted procedure: k8494 
o|contracted procedure: k8499 
o|contracted procedure: k8502 
o|contracted procedure: k8513 
o|contracted procedure: k8516 
o|contracted procedure: k8525 
o|contracted procedure: k8535 
o|contracted procedure: k8540 
o|contracted procedure: k8547 
o|contracted procedure: k8550 
o|contracted procedure: k8561 
o|contracted procedure: k8564 
o|contracted procedure: k8573 
o|contracted procedure: k8583 
o|contracted procedure: k8588 
o|contracted procedure: k8597 
o|contracted procedure: k8604 
o|contracted procedure: k8612 
o|contracted procedure: k8625 
o|contracted procedure: k8631 
o|contracted procedure: k8634 
o|contracted procedure: k8637 
o|contracted procedure: k8647 
o|contracted procedure: k8660 
o|contracted procedure: k8671 
o|contracted procedure: k8674 
o|contracted procedure: k8683 
o|contracted procedure: k8693 
o|contracted procedure: k8696 
o|contracted procedure: k8701 
o|contracted procedure: k8703 
o|contracted procedure: k8710 
o|contracted procedure: k8721 
o|contracted procedure: k8724 
o|contracted procedure: k8733 
o|contracted procedure: k8743 
o|contracted procedure: k8752 
o|contracted procedure: k8763 
o|contracted procedure: k8766 
o|contracted procedure: k8775 
o|contracted procedure: k8785 
o|contracted procedure: k8794 
o|contracted procedure: k8799 
o|contracted procedure: k8837 
o|contracted procedure: k8893 
o|contracted procedure: k8863 
o|contracted procedure: k8877 
o|contracted procedure: k8890 
o|contracted procedure: k8932 
o|contracted procedure: k8935 
o|contracted procedure: k8951 
o|contracted procedure: k8954 
o|contracted procedure: k8959 
o|contracted procedure: k8979 
o|contracted procedure: k8976 
o|contracted procedure: k8973 
o|contracted procedure: k8987 
o|contracted procedure: k8998 
o|contracted procedure: k9001 
o|contracted procedure: k9010 
o|contracted procedure: k9020 
o|contracted procedure: k9026 
o|contracted procedure: k9028 
o|contracted procedure: k9067 
o|contracted procedure: k9080 
o|contracted procedure: k9083 
o|contracted procedure: k9102 
o|contracted procedure: k9113 
o|contracted procedure: k9116 
o|contracted procedure: k9122 
o|contracted procedure: k9128 
o|contracted procedure: k9133 
o|contracted procedure: k9136 
o|contracted procedure: k9142 
o|contracted procedure: k9154 
o|contracted procedure: k9157 
o|contracted procedure: k9163 
o|contracted procedure: k9166 
o|contracted procedure: k9171 
o|contracted procedure: k9178 
o|contracted procedure: k9189 
o|contracted procedure: k9251 
o|contracted procedure: k9257 
o|contracted procedure: k9204 
o|contracted procedure: k9212 
o|contracted procedure: k9223 
o|contracted procedure: k9226 
o|contracted procedure: k9235 
o|contracted procedure: k9245 
o|contracted procedure: k9266 
o|contracted procedure: k9307 
o|contracted procedure: k9277 
o|contracted procedure: k9302 
o|contracted procedure: k9305 
o|contracted procedure: k9299 
o|contracted procedure: k9280 
o|contracted procedure: k9289 
o|contracted procedure: k9292 
o|contracted procedure: k9319 
o|contracted procedure: k9322 
o|contracted procedure: k9331 
o|contracted procedure: k9341 
o|contracted procedure: k9359 
o|contracted procedure: k9370 
o|contracted procedure: k9373 
o|contracted procedure: k9382 
o|contracted procedure: k9392 
o|contracted procedure: k9443 
o|contracted procedure: k9413 
o|contracted procedure: k9438 
o|contracted procedure: k9441 
o|contracted procedure: k9435 
o|contracted procedure: k9416 
o|contracted procedure: k9425 
o|contracted procedure: k9428 
o|contracted procedure: k9461 
o|contracted procedure: k9550 
o|contracted procedure: k9532 
o|contracted procedure: k9561 
o|contracted procedure: k9564 
o|contracted procedure: k9573 
o|contracted procedure: k9583 
o|contracted procedure: k9603 
o|contracted procedure: k9606 
o|contracted procedure: k9611 
o|contracted procedure: k9622 
o|contracted procedure: k9625 
o|contracted procedure: k9634 
o|contracted procedure: k9644 
o|contracted procedure: k9667 
o|contracted procedure: k9678 
o|contracted procedure: k9687 
o|contracted procedure: k9690 
o|contracted procedure: k9692 
o|contracted procedure: k9698 
o|contracted procedure: k9733 
o|contracted procedure: k9742 
o|contracted procedure: k9745 
o|contracted procedure: k9758 
o|contracted procedure: k9772 
o|contracted procedure: k9774 
o|contracted procedure: k9782 
o|contracted procedure: k9815 
o|contracted procedure: k9823 
o|contracted procedure: k9819 
o|contracted procedure: k9830 
o|contracted procedure: k9836 
o|contracted procedure: k9843 
o|contracted procedure: k9853 
o|contracted procedure: k9862 
o|contracted procedure: k9859 
o|contracted procedure: k9900 
o|contracted procedure: k9911 
o|contracted procedure: k9905 
o|contracted procedure: k9924 
o|contracted procedure: k9930 
o|contracted procedure: k9940 
o|contracted procedure: k9950 
o|contracted procedure: k9958 
o|contracted procedure: k9962 
o|contracted procedure: k9974 
o|contracted procedure: k9983 
o|contracted procedure: k10000 
o|contracted procedure: k10003 
o|contracted procedure: k10011 
o|contracted procedure: k10109 
o|contracted procedure: k10020 
o|contracted procedure: k10041 
o|contracted procedure: k10049 
o|contracted procedure: k10058 
o|contracted procedure: k10067 
o|contracted procedure: k10084 
o|contracted procedure: k10087 
o|contracted procedure: k10098 
o|contracted procedure: k10161 
o|contracted procedure: k10169 
o|contracted procedure: k10172 
o|contracted procedure: k10196 
o|contracted procedure: k10198 
o|contracted procedure: k10213 
o|contracted procedure: k10218 
o|contracted procedure: k10245 
o|contracted procedure: k10274 
o|contracted procedure: k10284 
o|contracted procedure: k10289 
o|contracted procedure: k10304 
o|contracted procedure: k10295 
o|contracted procedure: k10325 
o|contracted procedure: k10343 
o|contracted procedure: k10372 
o|contracted procedure: k10379 
o|contracted procedure: k10409 
o|contracted procedure: k10429 
o|contracted procedure: k10432 
o|contracted procedure: k10449 
o|contracted procedure: k10443 
o|inlining procedure: k10440 
o|inlining procedure: k10440 
o|contracted procedure: k10466 
o|contracted procedure: k10495 
o|contracted procedure: k10498 
o|contracted procedure: k10503 
o|contracted procedure: k10507 
o|contracted procedure: k10513 
o|contracted procedure: k10517 
o|contracted procedure: k10523 
o|contracted procedure: k10527 
o|contracted procedure: k10543 
o|contracted procedure: k10551 
o|contracted procedure: k10547 
o|contracted procedure: k10561 
o|contracted procedure: k10572 
o|contracted procedure: k10581 
o|contracted procedure: k10584 
o|contracted procedure: k10675 
o|contracted procedure: k10686 
o|contracted procedure: k10695 
o|contracted procedure: k10698 
o|contracted procedure: k10721 
o|contracted procedure: k10723 
o|contracted procedure: k10735 
o|contracted procedure: k10749 
o|contracted procedure: k10763 
o|contracted procedure: k10765 
o|contracted procedure: k10789 
o|contracted procedure: k10774 
o|contracted procedure: k10780 
o|contracted procedure: k10783 
o|contracted procedure: k10777 
o|contracted procedure: k10794 
o|contracted procedure: k10796 
o|contracted procedure: k10808 
o|contracted procedure: k10835 
o|contracted procedure: k10817 
o|contracted procedure: k10826 
o|contracted procedure: k10820 
o|contracted procedure: k10832 
o|contracted procedure: k10840 
o|contracted procedure: k10850 
o|contracted procedure: k10855 
o|contracted procedure: k10884 
o|contracted procedure: k10866 
o|contracted procedure: k10875 
o|contracted procedure: k10869 
o|contracted procedure: k10881 
o|contracted procedure: k10889 
o|contracted procedure: k10904 
o|contracted procedure: k10901 
o|contracted procedure: k10912 
o|contracted procedure: k10926 
o|contracted procedure: k10938 
o|contracted procedure: k10952 
o|contracted procedure: k10964 
o|contracted procedure: k10987 
o|contracted procedure: k10975 
o|contracted procedure: k10981 
o|contracted procedure: k10984 
o|contracted procedure: k10978 
o|contracted procedure: k10992 
o|contracted procedure: k11001 
o|contracted procedure: k11033 
o|contracted procedure: k11012 
o|contracted procedure: k11021 
o|contracted procedure: k11015 
o|contracted procedure: k11030 
o|contracted procedure: k11038 
o|contracted procedure: k11053 
o|contracted procedure: k11058 
o|contracted procedure: k11068 
o|contracted procedure: k11077 
o|contracted procedure: k11074 
o|contracted procedure: k11091 
o|contracted procedure: k11089 
o|contracted procedure: k11103 
o|contracted procedure: k11110 
o|contracted procedure: k11133 
o|contracted procedure: k11121 
o|contracted procedure: k11127 
o|contracted procedure: k11130 
o|contracted procedure: k11124 
o|contracted procedure: k11138 
o|contracted procedure: k11140 
o|contracted procedure: k11164 
o|contracted procedure: k11149 
o|contracted procedure: k11161 
o|contracted procedure: k11155 
o|contracted procedure: k11158 
o|contracted procedure: k11152 
o|contracted procedure: k11169 
o|contracted procedure: k11176 
o|contracted procedure: k11181 
o|contracted procedure: k11188 
o|contracted procedure: k11193 
o|contracted procedure: k11205 
o|contracted procedure: k11207 
o|contracted procedure: k11233 
o|contracted procedure: k11238 
o|contracted procedure: k11254 
o|contracted procedure: k11262 
o|contracted procedure: k11276 
o|contracted procedure: k11281 
o|contracted procedure: k11299 
o|contracted procedure: k11315 
o|contracted procedure: k11331 
o|contracted procedure: k11336 
o|contracted procedure: k11352 
o|contracted procedure: k11357 
o|contracted procedure: k11362 
o|contracted procedure: k11367 
o|contracted procedure: k11372 
o|contracted procedure: k11377 
o|contracted procedure: k11401 
o|contracted procedure: k11406 
o|contracted procedure: k11411 
o|contracted procedure: k11416 
o|contracted procedure: k11421 
o|contracted procedure: k11426 
o|contracted procedure: k11468 
o|contracted procedure: k11482 
o|contracted procedure: k11487 
o|contracted procedure: k11492 
o|contracted procedure: k11497 
o|contracted procedure: k11502 
o|contracted procedure: k11507 
o|contracted procedure: k11552 
o|contracted procedure: k11563 
o|contracted procedure: k11570 
o|contracted procedure: k11547 
o|contracted procedure: k11581 
o|contracted procedure: k11592 
o|contracted procedure: k11599 
o|contracted procedure: k11576 
o|contracted procedure: k11622 
o|contracted procedure: k11620 
o|contracted procedure: k11631 
o|contracted procedure: k11654 
o|contracted procedure: k11662 
o|contracted procedure: k542015076 
o|contracted procedure: k11673 
o|contracted procedure: k542015082 
o|contracted procedure: k11684 
o|contracted procedure: k542015088 
o|contracted procedure: k11704 
o|contracted procedure: k11702 
o|contracted procedure: k11716 
o|contracted procedure: k11723 
o|contracted procedure: k542015098 
o|contracted procedure: k11731 
o|contracted procedure: k11736 
o|contracted procedure: k11741 
o|contracted procedure: k11746 
o|contracted procedure: k11751 
o|contracted procedure: k11756 
o|contracted procedure: k11761 
o|contracted procedure: k11787 
o|contracted procedure: k11793 
o|contracted procedure: k11798 
o|contracted procedure: k11803 
o|contracted procedure: k11821 
o|contracted procedure: k11826 
o|contracted procedure: k11831 
o|contracted procedure: k11836 
o|contracted procedure: k11841 
o|contracted procedure: k11863 
o|contracted procedure: k11868 
o|contracted procedure: k11873 
o|contracted procedure: k11878 
o|contracted procedure: k11883 
o|contracted procedure: k11888 
o|contracted procedure: k11893 
o|contracted procedure: k11898 
o|contracted procedure: k11903 
o|contracted procedure: k11908 
o|contracted procedure: k11940 
o|contracted procedure: k11945 
o|contracted procedure: k11950 
o|contracted procedure: k11955 
o|contracted procedure: k11960 
o|contracted procedure: k11965 
o|contracted procedure: k11970 
o|contracted procedure: k11975 
o|contracted procedure: k11980 
o|contracted procedure: k11985 
o|contracted procedure: k11990 
o|contracted procedure: k12048 
o|contracted procedure: k542015145 
o|contracted procedure: k12059 
o|contracted procedure: k542015151 
o|contracted procedure: k12079 
o|contracted procedure: k12077 
o|contracted procedure: k12091 
o|contracted procedure: k12098 
o|contracted procedure: k542015161 
o|contracted procedure: k12109 
o|contracted procedure: k12114 
o|contracted procedure: k12119 
o|contracted procedure: k12124 
o|contracted procedure: k12147 
o|contracted procedure: k12153 
o|contracted procedure: k12158 
o|contracted procedure: k12174 
o|contracted procedure: k12179 
o|contracted procedure: k12184 
o|contracted procedure: k12189 
o|contracted procedure: k12194 
o|contracted procedure: k12199 
o|contracted procedure: k12204 
o|contracted procedure: k12209 
o|contracted procedure: k12214 
o|contracted procedure: k12219 
o|contracted procedure: k12224 
o|contracted procedure: k12229 
o|contracted procedure: k12234 
o|contracted procedure: k12239 
o|contracted procedure: k12244 
o|contracted procedure: k12249 
o|contracted procedure: k12254 
o|contracted procedure: k12259 
o|contracted procedure: k12264 
o|contracted procedure: k12269 
o|contracted procedure: k12274 
o|contracted procedure: k12279 
o|contracted procedure: k12284 
o|contracted procedure: k12289 
o|contracted procedure: k12294 
o|contracted procedure: k12299 
o|contracted procedure: k12304 
o|contracted procedure: k12309 
o|contracted procedure: k12314 
o|contracted procedure: k12319 
o|contracted procedure: k12324 
o|contracted procedure: k12412 
o|contracted procedure: k12414 
o|contracted procedure: k12421 
o|contracted procedure: k12426 
o|contracted procedure: k12433 
o|contracted procedure: k12438 
o|contracted procedure: k12440 
o|contracted procedure: k12447 
o|contracted procedure: k12452 
o|contracted procedure: k12454 
o|contracted procedure: k12461 
o|contracted procedure: k12466 
o|contracted procedure: k12476 
o|contracted procedure: k12473 
o|contracted procedure: k12481 
o|contracted procedure: k12488 
o|contracted procedure: k12493 
o|contracted procedure: k12500 
o|contracted procedure: k12505 
o|contracted procedure: k12518 
o|contracted procedure: k12591 
o|contracted procedure: k12523 
o|contracted procedure: k12526 
o|contracted procedure: k12531 
o|contracted procedure: k12563 
o|contracted procedure: k12542 
o|contracted procedure: k12560 
o|contracted procedure: k12548 
o|contracted procedure: k12554 
o|contracted procedure: k12557 
o|contracted procedure: k12551 
o|contracted procedure: k12545 
o|contracted procedure: k12568 
o|contracted procedure: k12575 
o|contracted procedure: k12578 
o|contracted procedure: k12611 
o|contracted procedure: k12593 
o|contracted procedure: k12608 
o|contracted procedure: k12599 
o|contracted procedure: k12603 
o|contracted procedure: k12651 
o|contracted procedure: k12657 
o|contracted procedure: k12659 
o|contracted procedure: k12665 
o|contracted procedure: k12673 
o|contracted procedure: k12675 
o|contracted procedure: k12681 
o|contracted procedure: k12689 
o|contracted procedure: k12691 
o|contracted procedure: k12697 
o|contracted procedure: k12703 
o|contracted procedure: k12711 
o|contracted procedure: k12717 
o|contracted procedure: k12723 
o|contracted procedure: k12731 
o|contracted procedure: k12737 
o|contracted procedure: k12745 
o|contracted procedure: k12752 
o|contracted procedure: k12762 
o|contracted procedure: k12768 
o|contracted procedure: k12774 
o|contracted procedure: k12780 
o|contracted procedure: k12786 
o|contracted procedure: k12792 
o|contracted procedure: k12798 
o|contracted procedure: k12804 
o|contracted procedure: k12810 
o|contracted procedure: k12818 
o|contracted procedure: k12824 
o|contracted procedure: k12830 
o|contracted procedure: k12838 
o|contracted procedure: k12840 
o|contracted procedure: k12846 
o|contracted procedure: k12854 
o|contracted procedure: k12860 
o|contracted procedure: k12867 
o|contracted procedure: k12875 
o|contracted procedure: k12882 
o|contracted procedure: k12887 
o|contracted procedure: k12893 
o|contracted procedure: k12895 
o|contracted procedure: k12909 
o|contracted procedure: k12914 
o|contracted procedure: k12932 
o|contracted procedure: k12953 
o|contracted procedure: k12958 
o|contracted procedure: k12978 
o|contracted procedure: k12983 
o|contracted procedure: k12988 
o|contracted procedure: k12993 
o|contracted procedure: k12998 
o|contracted procedure: k13003 
o|contracted procedure: k13043 
o|contracted procedure: k13048 
o|contracted procedure: k13053 
o|contracted procedure: k13058 
o|contracted procedure: k13063 
o|contracted procedure: k13068 
o|contracted procedure: k13114 
o|contracted procedure: k13119 
o|contracted procedure: k13124 
o|contracted procedure: k13129 
o|contracted procedure: k13134 
o|contracted procedure: k13139 
o|contracted procedure: k13199 
o|contracted procedure: k13201 
o|contracted procedure: k13204 
o|contracted procedure: k13208 
o|contracted procedure: k13219 
o|contracted procedure: k13228 
o|contracted procedure: k13231 
o|contracted procedure: k13237 
o|contracted procedure: k13240 
o|contracted procedure: k13247 
o|contracted procedure: k13260 
o|contracted procedure: k13265 
o|contracted procedure: k13276 
o|contracted procedure: k13285 
o|contracted procedure: k13288 
o|contracted procedure: k13290 
o|contracted procedure: k13343 
o|contracted procedure: k13351 
o|contracted procedure: k13354 
o|contracted procedure: k13359 
o|contracted procedure: k13379 
o|contracted procedure: k13382 
o|contracted procedure: k13392 
o|contracted procedure: k1339015800 
o|contracted procedure: k1339015804 
o|contracted procedure: k13402 
o|contracted procedure: k13411 
o|contracted procedure: k13417 
o|contracted procedure: k13422 
o|contracted procedure: k13429 
o|contracted procedure: k13437 
o|contracted procedure: k13453 
o|contracted procedure: k13458 
o|contracted procedure: k13463 
o|contracted procedure: k13489 
o|contracted procedure: k13500 
o|contracted procedure: k13509 
o|contracted procedure: k13512 
o|contracted procedure: k13542 
o|contracted procedure: k13523 
o|contracted procedure: k13534 
o|contracted procedure: k13538 
o|contracted procedure: k13581 
o|contracted procedure: k13548 
o|contracted procedure: k13559 
o|contracted procedure: k13578 
o|contracted procedure: k13565 
o|contracted procedure: k13575 
o|contracted procedure: k13599 
o|contracted procedure: k13635 
o|inlining procedure: k13632 
o|contracted procedure: k13683 
o|contracted procedure: k13691 
o|contracted procedure: k13702 
o|contracted procedure: k13712 
o|contracted procedure: k13722 
o|contracted procedure: k13735 
o|contracted procedure: k13738 
o|contracted procedure: k13794 
o|contracted procedure: k13797 
o|contracted procedure: k13799 
o|contracted procedure: k13814 
o|contracted procedure: k13811 
o|contracted procedure: k13822 
o|contracted procedure: k13866 
o|contracted procedure: k13859 
o|contracted procedure: k13838 
o|contracted procedure: k13849 
o|contracted procedure: k13852 
o|contracted procedure: k13854 
o|contracted procedure: k13884 
o|contracted procedure: k13976 
o|contracted procedure: k13889 
o|contracted procedure: k13922 
o|contracted procedure: k13927 
o|contracted procedure: k13951 
o|contracted procedure: k13935 
o|contracted procedure: k13944 
o|contracted procedure: k13987 
o|contracted procedure: k13990 
o|contracted procedure: k13999 
o|contracted procedure: k14009 
o|contracted procedure: k14017 
o|contracted procedure: k14020 
o|contracted procedure: k14029 
o|contracted procedure: k14039 
o|contracted procedure: k14077 
o|contracted procedure: k14097 
o|contracted procedure: k14102 
o|contracted procedure: k14110 
o|contracted procedure: k14129 
o|contracted procedure: k14141 
o|contracted procedure: k14144 
o|contracted procedure: k14147 
o|contracted procedure: k14155 
o|contracted procedure: k14164 
o|contracted procedure: k14167 
o|contracted procedure: k14182 
o|inlining procedure: k14185 
o|inlining procedure: k14185 
o|contracted procedure: k14198 
o|contracted procedure: k14205 
o|contracted procedure: k14219 
o|contracted procedure: k14230 
o|contracted procedure: k14253 
o|contracted procedure: k14262 
o|contracted procedure: k14273 
o|contracted procedure: k14281 
o|contracted procedure: k14307 
o|contracted procedure: k14313 
o|contracted procedure: k14316 
o|contracted procedure: k14336 
o|contracted procedure: k14330 
o|contracted procedure: k14357 
o|contracted procedure: k14351 
o|contracted procedure: k14375 
o|contracted procedure: k14381 
o|contracted procedure: k14401 
o|contracted procedure: k14395 
o|contracted procedure: k14453 
o|contracted procedure: k14464 
o|contracted procedure: k14468 
o|contracted procedure: k14483 
o|contracted procedure: k14492 
o|contracted procedure: k14495 
o|contracted procedure: k14533 
o|contracted procedure: k14519 
o|simplifications: ((let . 161)) 
o|removed binding forms: 1083 
o|inlining procedure: k6449 
o|inlining procedure: k6449 
o|inlining procedure: k7152 
o|inlining procedure: k7152 
o|inlining procedure: k7288 
o|inlining procedure: k7288 
o|inlining procedure: k7318 
o|inlining procedure: k7318 
o|inlining procedure: k7558 
o|inlining procedure: k7558 
o|inlining procedure: k7633 
o|inlining procedure: k7633 
o|inlining procedure: k7711 
o|inlining procedure: k7711 
o|inlining procedure: k7820 
o|inlining procedure: k7820 
o|inlining procedure: k7873 
o|inlining procedure: k7873 
o|inlining procedure: k7930 
o|inlining procedure: k7930 
o|inlining procedure: k8078 
o|inlining procedure: k8078 
o|inlining procedure: k8169 
o|inlining procedure: k8169 
o|inlining procedure: k8217 
o|inlining procedure: k8217 
o|inlining procedure: k8360 
o|inlining procedure: k8360 
o|inlining procedure: k8518 
o|inlining procedure: k8518 
o|inlining procedure: k8566 
o|inlining procedure: k8566 
o|inlining procedure: k8676 
o|inlining procedure: k8676 
o|inlining procedure: k8726 
o|inlining procedure: k8726 
o|inlining procedure: k8768 
o|inlining procedure: k8768 
o|inlining procedure: k9003 
o|inlining procedure: k9003 
o|inlining procedure: k9228 
o|inlining procedure: k9228 
o|inlining procedure: k9324 
o|inlining procedure: k9324 
o|inlining procedure: k9375 
o|inlining procedure: k9375 
o|inlining procedure: "(support.scm:764) node-subexpressions-set!" 
o|inlining procedure: "(support.scm:763) node-parameters-set!" 
o|inlining procedure: "(support.scm:762) node-class-set!" 
o|inlining procedure: k9566 
o|inlining procedure: k9566 
o|inlining procedure: k9627 
o|inlining procedure: k9627 
o|inlining procedure: k11725 
o|inlining procedure: k11725 
o|inlining procedure: k11725 
o|inlining procedure: k11725 
o|inlining procedure: k11725 
o|inlining procedure: k11725 
o|inlining procedure: k11725 
o|inlining procedure: k11725 
o|inlining procedure: k11725 
o|inlining procedure: k13992 
o|inlining procedure: k13992 
o|inlining procedure: k14022 
o|inlining procedure: k14022 
o|replaced variables: 162 
o|removed binding forms: 3 
o|simplifications: ((if . 19)) 
o|replaced variables: 14 
o|removed binding forms: 216 
o|inlining procedure: k7580 
o|inlining procedure: k7580 
o|inlining procedure: k8258 
o|inlining procedure: k8258 
o|inlining procedure: k8258 
o|contracted procedure: k10247 
o|contracted procedure: k12533 
o|removed binding forms: 16 
o|substituted constant variable: r758117188 
o|replaced variables: 2 
o|removed binding forms: 2 
o|removed conditional forms: 1 
o|removed binding forms: 3 
o|direct leaf routine/allocation: loop501 0 
o|converted assignments to bindings: (loop501) 
o|simplifications: ((let . 1)) 
o|customizable procedures: (for-each-loop39173932 loop3796 k14175 for-each-loop37203738 doloop37533754 loop3688 map-loop36123633 map-loop36433664 resolve3548 loop3559 loop3500 k13528 for-each-loop34743485 k13345 walkeach3431 walk3430 k13262 for-each-loop34093419 k13233 k13206 walk3361 for-each-loop33853395 k12667 k12739 k12812 k12832 k12848 k12869 k12511 k12050 k12061 k12100 k11656 k11664 k11675 k11686 k10737 k10751 k10857 k10891 k10914 k10940 k10966 k11003 k11040 k11112 repeat2589 k11018 k10872 k10823 for-each-loop25652577 for-each-loop24562477 k10395 k10358 k10163 matchn2295 loop2322 match12294 resolve2293 loop2269 k9776 k9811 for-each-loop22202232 for-each-loop22422260 walk2151 map-loop21602177 walk2108 map-loop21212141 rec2088 k9418 map-loop18661885 map-loop20522077 map-loop19461966 k9282 map-loop19761995 map-loop20132038 walk1896 map-loop18141831 fold1791 k8146 k8649 map-loop17631780 map-loop17371754 map-loop17081725 loop1689 map-loop16651682 map-loop16391656 loop1630 map-loop15901607 k8318 map-loop15691614 map-loop15271544 walk1471 map-loop14981515 map-loop14421459 k7786 k7950 map-loop14111428 map-loop13661383 map-loop13351352 map-loop12861303 map-loop12471264 k7537 map-loop12131230 loop1181 map-loop11161134 map-loop11431161 k7185 walk1056 map-loop10791096 k6472 k6647 k6718 loop789 k6521 k6551 k6581 map-loop751768 loop730 k6362 k6295 for-each-loop526568 for-each-loop575617 for-each-loop624650 k5760 loop458 k5643 loop380 fold373 k5445 k5308 k5315 loop311 loop295 loop244 loop234 loop220 err219 loop209 k4921 for-each-loop177195 test-mode99 collect98 for-each-loop103125 text42 dump43 for-each-loop4666) 
o|calls to known targets: 592 
o|identified direct recursive calls: f_5059 1 
o|identified direct recursive calls: f_5106 1 
o|identified direct recursive calls: f_5138 1 
o|identified direct recursive calls: f_5244 1 
o|identified direct recursive calls: f_5491 1 
o|identified direct recursive calls: f_5904 1 
o|identified direct recursive calls: f_6439 2 
o|identified direct recursive calls: f_9456 1 
o|identified direct recursive calls: f_9969 1 
o|identified direct recursive calls: f_13554 1 
o|fast box initializations: 87 
o|dropping unused closure argument: f_5904 
o|dropping unused closure argument: f_4853 
o|dropping unused closure argument: f_13656 
*/
/* end of file */
