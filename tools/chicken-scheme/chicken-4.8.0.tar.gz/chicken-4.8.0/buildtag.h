#define C_BUILD_TAG "compiled 2012-09-24 on debian (Linux)"
