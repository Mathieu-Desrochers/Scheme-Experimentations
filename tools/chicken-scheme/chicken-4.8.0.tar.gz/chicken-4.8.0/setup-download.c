/* Generated from setup-download.scm by the CHICKEN compiler
   http://www.call-cc.org
   2012-09-24 17:52
   Version 4.8.0 (rev 0db1908)
   linux-unix-gnu-x86-64 [ 64bit manyargs ptables ]
   compiled 2012-09-24 on debian (Linux)
   command line: setup-download.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -feature chicken-bootstrap -no-warnings -specialize -types ./types.db -feature chicken-compile-shared -dynamic -emit-import-library setup-download -output-file setup-download.c
   used units: library eval extras irregex posix utils srfi_2d1 data_2dstructures tcp srfi_2d13 files
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_irregex_toplevel)
C_externimport void C_ccall C_irregex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_posix_toplevel)
C_externimport void C_ccall C_posix_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_2d1_toplevel)
C_externimport void C_ccall C_srfi_2d1_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_2dstructures_toplevel)
C_externimport void C_ccall C_data_2dstructures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_tcp_toplevel)
C_externimport void C_ccall C_tcp_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_2d13_toplevel)
C_externimport void C_ccall C_srfi_2d13_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[255];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,34),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,100,32,102,115,116,114,49,56,57,32,97,114,103,115,49,57,48,41,0,0,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,40),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,103,101,116,45,116,101,109,112,111,114,97,114,121,45,100,105,114,101,99,116,111,114,121,41};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,57),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,101,120,105,115,116,105,110,103,45,118,101,114,115,105,111,110,32,101,103,103,50,48,49,32,118,101,114,115,105,111,110,50,48,50,32,118,115,50,48,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,8),40,102,95,49,53,48,56,41};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,13),40,102,95,49,54,49,50,32,102,51,56,55,41,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,26),40,102,111,114,45,101,97,99,104,45,108,111,111,112,51,55,55,32,103,51,56,52,51,57,48,41,0,0,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,19),40,102,95,49,54,52,53,32,103,51,55,48,51,55,49,51,55,50,41,0,0,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,34),40,102,95,49,53,52,49,32,115,114,99,51,49,53,51,49,54,51,50,50,32,118,101,114,51,49,55,51,49,56,51,50,51,41,0,0,0,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,59),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,108,111,99,97,116,101,45,101,103,103,47,108,111,99,97,108,32,101,103,103,50,57,50,32,100,105,114,50,57,51,32,46,32,116,109,112,50,57,49,50,57,52,41,0,0,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,8),40,102,95,49,55,50,56,41};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,8),40,102,95,49,55,55,55,41};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,14),40,102,95,49,55,55,50,32,101,120,52,49,55,41,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,8),40,102,95,49,55,57,48,41};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,8),40,102,95,49,56,48,48,41};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,21),40,102,95,49,55,57,53,32,46,32,97,114,103,115,52,49,49,52,49,57,41,0,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,8),40,102,95,49,55,56,53,41};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,16),40,102,95,49,55,54,55,32,107,52,49,48,52,49,54,41};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,18),40,102,95,49,55,52,55,32,114,101,116,117,114,110,52,48,57,41,0,0,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,38),40,102,95,49,55,51,51,32,108,111,99,51,57,57,52,48,48,52,48,51,32,118,101,114,115,105,111,110,52,48,49,52,48,50,52,48,52,41,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,15),40,102,95,49,55,50,51,32,101,103,103,51,57,56,41,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,46),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,103,97,116,104,101,114,45,101,103,103,45,105,110,102,111,114,109,97,116,105,111,110,32,100,105,114,51,57,54,41,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,66),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,109,97,107,101,45,115,118,110,45,108,115,45,99,109,100,32,117,97,114,103,52,50,54,32,112,97,114,103,52,50,55,32,112,110,97,109,52,50,56,32,116,109,112,52,50,53,52,50,57,41,0,0,0,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,8),40,102,95,50,48,55,52,41};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,38),40,102,95,50,48,57,57,32,102,105,108,101,100,105,114,53,54,53,53,54,54,53,55,48,32,118,101,114,53,54,55,53,54,56,53,55,49,41,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,13),40,102,95,50,49,53,54,32,102,53,54,51,41,0,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,58),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,108,111,99,97,116,101,45,101,103,103,47,115,118,110,32,101,103,103,53,52,49,32,114,101,112,111,53,52,50,32,46,32,116,109,112,53,52,48,53,52,51,41,0,0,0,0,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,39),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,100,101,99,111,110,115,116,114,117,99,116,45,117,114,108,32,117,114,108,53,56,54,41,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,8),40,102,95,50,51,48,52,41};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,8),40,102,95,50,56,51,56,41};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,13),40,102,95,50,54,55,57,32,109,55,54,48,41,0,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,6),40,115,107,105,112,41,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,8),40,102,95,50,56,49,50,41};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,20),40,103,101,116,45,102,105,108,101,115,32,102,105,108,101,115,55,55,53,41,0,0,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,33),40,102,95,50,56,52,51,32,105,110,56,48,57,56,49,48,56,49,51,32,111,117,116,56,49,49,56,49,50,56,49,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,50),40,102,95,50,51,48,57,32,104,111,115,116,54,50,52,54,50,53,54,51,48,32,112,111,114,116,54,50,54,54,50,55,54,51,49,32,108,111,99,110,54,50,56,54,50,57,54,51,50,41,0,0,0,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,58),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,108,111,99,97,116,101,45,101,103,103,47,104,116,116,112,32,101,103,103,53,57,57,32,117,114,108,54,48,48,32,46,32,116,109,112,53,57,56,54,48,49,41,0,0,0,0,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,8),40,102,95,50,52,55,49,41};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,8),40,102,95,50,52,55,52,41};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,8),40,102,95,50,52,55,55,41};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,8),40,102,95,50,52,56,48,41};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,78),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,109,97,107,101,45,72,84,84,80,45,71,69,84,47,49,46,49,32,108,111,99,97,116,105,111,110,54,53,53,32,117,115,101,114,45,97,103,101,110,116,54,53,54,32,104,111,115,116,54,53,55,32,116,109,112,54,53,52,54,53,56,41,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,53),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,114,101,115,112,111,110,115,101,45,109,97,116,99,104,45,99,111,100,101,63,32,109,114,115,112,54,55,48,32,99,111,100,101,54,55,49,41,0,0,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,8),40,102,95,50,53,50,53,41};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,20),40,103,101,116,45,99,104,117,110,107,115,32,100,97,116,97,56,53,49,41,0,0,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,8),40,102,95,50,54,48,53,41};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,37),40,102,95,50,54,49,48,32,105,110,112,120,55,49,54,55,49,55,55,50,48,32,111,117,116,112,120,55,49,56,55,49,57,55,50,49,41,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,33),40,102,95,50,53,51,56,32,105,110,54,57,57,55,48,48,55,48,57,32,111,117,116,55,48,49,55,48,50,55,49,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,100),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,104,116,116,112,45,99,111,110,110,101,99,116,32,104,111,115,116,54,55,54,32,112,111,114,116,54,55,55,32,108,111,99,110,54,55,56,32,112,114,111,120,121,45,104,111,115,116,54,55,57,32,112,114,111,120,121,45,112,111,114,116,54,56,48,32,112,114,111,120,121,45,117,115,101,114,45,112,97,115,115,54,56,49,41,0,0,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,39),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,99,104,101,99,107,45,101,103,103,45,110,97,109,101,32,110,97,109,101,56,54,55,41,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,8),40,102,95,51,48,49,55,41};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,8),40,102,95,51,48,50,54,41};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,8),40,102,95,51,48,54,53,41};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,8),40,102,95,51,48,55,52,41};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,80),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,114,101,116,114,105,101,118,101,45,101,120,116,101,110,115,105,111,110,32,110,97,109,101,56,55,52,32,116,114,97,110,115,112,111,114,116,56,55,53,32,108,111,99,97,116,105,111,110,56,55,54,32,46,32,116,109,112,56,55,51,56,55,55,41};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,8),40,102,95,51,48,57,54,41};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,19),40,102,95,49,51,56,49,32,103,50,51,51,50,51,52,50,51,53,41,0,0,0,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,50,49,51,32,103,50,50,53,50,51,57,41,0,0,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,13),40,102,95,49,56,53,50,32,115,52,55,54,41,0,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,52,53,57,32,103,52,55,49,52,55,56,41,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,8),40,102,95,50,56,53,53,41};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,8),40,102,95,50,56,54,54,41};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,33),40,102,95,50,56,55,52,32,105,110,56,51,52,56,51,53,56,51,56,32,111,117,116,56,51,54,56,51,55,56,51,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,50),40,102,95,50,56,54,48,32,104,111,115,116,56,50,50,56,50,51,56,50,56,32,112,111,114,116,56,50,52,56,50,53,56,50,57,32,108,111,99,110,56,50,54,56,50,55,56,51,48,41,0,0,0,0,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,8),40,102,95,51,49,48,49,41};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,8),40,102,95,51,49,52,48,41};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,69),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,108,105,115,116,45,101,120,116,101,110,115,105,111,110,115,32,116,114,97,110,115,112,111,114,116,57,51,50,32,108,111,99,97,116,105,111,110,57,51,51,32,46,32,116,109,112,57,51,49,57,51,52,41,0,0,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,8),40,102,95,51,49,54,48,41};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,19),40,102,95,49,52,51,55,32,103,50,55,52,50,55,53,50,55,54,41,0,0,0,0,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,50,53,52,32,103,50,54,54,50,56,48,41,0,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,13),40,102,95,49,57,53,55,32,115,53,50,55,41,0,0,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,21),40,109,97,112,45,108,111,111,112,53,49,48,32,103,53,50,50,53,50,57,41,0,0,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,8),40,102,95,51,49,54,53,41};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,8),40,102,95,51,49,57,51,41};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,85),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,108,105,115,116,45,101,120,116,101,110,115,105,111,110,45,118,101,114,115,105,111,110,115,32,110,97,109,101,57,54,50,32,116,114,97,110,115,112,111,114,116,57,54,51,32,108,111,99,97,116,105,111,110,57,54,52,32,46,32,116,109,112,57,54,49,57,54,53,41,0,0,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(f_2495)
static void C_fcall f_2495(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2734)
static void C_fcall f_2734(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1574)
static void C_ccall f_1574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1572)
static void C_ccall f_1572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1578)
static void C_ccall f_1578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1576)
static void C_ccall f_1576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1858)
static void C_ccall f_1858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1570)
static void C_ccall f_1570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1852)
static void C_ccall f_1852(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2738)
static void C_ccall f_2738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1723)
static void C_ccall f_1723(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1728)
static void C_ccall f_1728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2679)
static void C_ccall f_2679(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1333)
static void C_ccall f_1333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1338)
static void C_ccall f_1338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1845)
static void C_ccall f_1845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1847)
static void C_ccall f_1847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1841)
static void C_ccall f_1841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2670)
static void C_ccall f_2670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1843)
static void C_ccall f_1843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2675)
static void C_ccall f_2675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1714)
static void C_ccall f_1714(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1718)
static void C_ccall f_1718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3199)
static void C_ccall f_3199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3193)
static void C_ccall f_3193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2794)
static void C_ccall f_2794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2792)
static void C_ccall f_2792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1592)
static void C_ccall f_1592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1320)
static void C_ccall f_1320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1595)
static void C_ccall f_1595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1327)
static void C_ccall f_1327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1329)
static void C_fcall f_1329(C_word t0) C_noret;
C_noret_decl(f_2798)
static void C_ccall f_2798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2796)
static void C_ccall f_2796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2662)
static void C_ccall f_2662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1590)
static void C_ccall f_1590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2699)
static void C_fcall f_2699(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2782)
static void C_ccall f_2782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2784)
static void C_ccall f_2784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1588)
static void C_ccall f_1588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1357)
static void C_ccall f_1357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1586)
static void C_ccall f_1586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1868)
static void C_fcall f_1868(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2786)
static void C_ccall f_2786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1866)
static void C_ccall f_1866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1581)
static void C_ccall f_1581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1861)
static void C_ccall f_1861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2687)
static void C_fcall f_2687(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2102)
static void C_ccall f_2102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2104)
static void C_ccall f_2104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1536)
static void C_ccall f_1536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2106)
static void C_ccall f_2106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2061)
static void C_ccall f_2061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2682)
static void C_ccall f_2682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2063)
static void C_ccall f_2063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2065)
static void C_ccall f_2065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1818)
static void C_ccall f_1818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2067)
static void C_ccall f_2067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2638)
static void C_ccall f_2638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2636)
static void C_ccall f_2636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3165)
static void C_ccall f_3165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1652)
static void C_ccall f_1652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2570)
static void C_ccall f_2570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3160)
static void C_ccall f_3160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2574)
static void C_ccall f_2574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2634)
static void C_ccall f_2634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1800)
static void C_ccall f_1800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2631)
static void C_ccall f_2631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1805)
static void C_fcall f_1805(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2069)
static void C_ccall f_2069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2576)
static void C_fcall f_2576(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3155)
static void C_ccall f_3155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1432)
static void C_ccall f_1432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1437)
static void C_ccall f_1437(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1555)
static void C_ccall f_1555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1551)
static void C_ccall f_1551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1553)
static void C_ccall f_1553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2083)
static void C_ccall f_2083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1785)
static void C_ccall f_1785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2085)
static void C_ccall f_2085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2059)
static void C_ccall f_2059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1780)
static void C_ccall f_1780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2656)
static void C_ccall f_2656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2658)
static void C_fcall f_2658(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3145)
static void C_ccall f_3145(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_3145)
static void C_ccall f_3145r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_1426)
static void C_ccall f_1426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1676)
static void C_ccall f_1676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1547)
static void C_ccall f_1547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1670)
static void C_ccall f_1670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2551)
static void C_ccall f_2551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2553)
static void C_ccall f_2553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1541)
static void C_ccall f_1541(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3140)
static void C_ccall f_3140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1772)
static void C_ccall f_1772(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1777)
static void C_ccall f_1777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2074)
static void C_ccall f_2074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2555)
static void C_ccall f_2555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2558)
static void C_ccall f_2558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2647)
static void C_ccall f_2647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1549)
static void C_ccall f_1549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2580)
static void C_ccall f_2580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2644)
static void C_ccall f_2644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2642)
static void C_ccall f_2642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2640)
static void C_ccall f_2640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2586)
static void C_ccall f_2586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2720)
static void C_ccall f_2720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2252)
static void C_ccall f_2252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2254)
static void C_ccall f_2254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2877)
static void C_ccall f_2877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2879)
static void C_ccall f_2879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2538)
static void C_ccall f_2538(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1645)
static void C_ccall f_1645(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2890)
static void C_ccall f_2890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2240)
static void C_ccall f_2240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2893)
static void C_ccall f_2893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2243)
static void C_ccall f_2243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2246)
static void C_ccall f_2246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1517)
static void C_ccall f_1517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1519)
static void C_ccall f_1519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2619)
static void C_ccall f_2619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2566)
static void C_ccall f_2566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2568)
static void C_ccall f_2568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2701)
static void C_ccall f_2701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1634)
static void C_ccall f_1634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2843)
static void C_ccall f_2843(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3101)
static void C_ccall f_3101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1503)
static void C_ccall f_1503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1501)
static void C_ccall f_1501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1508)
static void C_ccall f_1508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2899)
static void C_ccall f_2899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2896)
static void C_ccall f_2896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2610)
static void C_ccall f_2610(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1664)
static void C_ccall f_1664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2543)
static void C_ccall f_2543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2541)
static void C_ccall f_2541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2600)
static void C_ccall f_2600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2605)
static void C_ccall f_2605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2549)
static void C_ccall f_2549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2547)
static void C_ccall f_2547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2545)
static void C_ccall f_2545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2860)
static void C_ccall f_2860(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2838)
static void C_ccall f_2838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1601)
static void C_ccall f_1601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1606)
static void C_ccall f_1606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1604)
static void C_ccall f_1604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2520)
static void C_ccall f_2520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2525)
static void C_ccall f_2525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2866)
static void C_ccall f_2866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2154)
static void C_ccall f_2154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2156)
static void C_ccall f_2156(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2159)
static void C_ccall f_2159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2855)
static void C_ccall f_2855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2148)
static void C_ccall f_2148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1625)
static void C_fcall f_1625(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2505)
static void C_ccall f_2505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2508)
static void C_ccall f_2508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2430)
static void C_ccall f_2430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2433)
static void C_ccall f_2433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2436)
static void C_ccall f_2436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2812)
static void C_ccall f_2812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2810)
static void C_ccall f_2810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2438)
static void C_fcall f_2438(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2596)
static void C_ccall f_2596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1521)
static void C_ccall f_1521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1527)
static void C_ccall f_1527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2625)
static void C_ccall f_2625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2881)
static void C_ccall f_2881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2872)
static void C_ccall f_2872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2874)
static void C_ccall f_2874(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3065)
static void C_ccall f_3065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1611)
static void C_ccall f_1611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1612)
static void C_ccall f_1612(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1615)
static void C_ccall f_1615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3017)
static void C_ccall f_3017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3012)
static void C_ccall f_3012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2516)
static void C_fcall f_2516(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_1998)
static void C_ccall f_1998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3026)
static void C_ccall f_3026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3008)
static void C_ccall f_3008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2801)
static void C_ccall f_2801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1957)
static void C_ccall f_1957(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1944)
static void C_ccall f_1944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1942)
static void C_ccall f_1942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1946)
static void C_ccall f_1946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1940)
static void C_ccall f_1940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1973)
static void C_fcall f_1973(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1971)
static void C_ccall f_1971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1963)
static void C_ccall f_1963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1966)
static void C_ccall f_1966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2984)
static void C_ccall f_2984(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_2984)
static void C_ccall f_2984r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_1381)
static void C_ccall f_1381(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1387)
static void C_ccall f_1387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2972)
static void C_fcall f_2972(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2979)
static void C_ccall f_2979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2952)
static void C_ccall f_2952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1499)
static void C_ccall f_1499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1497)
static void C_ccall f_1497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1342)
static void C_fcall f_1342(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1340)
static void C_ccall f_1340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2948)
static void C_ccall f_2948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2039)
static void C_ccall f_2039(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2039)
static void C_ccall f_2039r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1481)
static void C_ccall f_1481(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1481)
static void C_ccall f_1481r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2935)
static void C_ccall f_2935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2930)
static void C_ccall f_2930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2937)
static void C_ccall f_2937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2939)
static void C_ccall f_2939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2004)
static void C_ccall f_2004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2911)
static void C_ccall f_2911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1392)
static void C_fcall f_1392(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1390)
static void C_ccall f_1390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2007)
static void C_ccall f_2007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1304)
static void C_ccall f_1304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1302)
static void C_ccall f_1302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1300)
static void C_ccall f_1300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2907)
static void C_fcall f_2907(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1443)
static void C_ccall f_1443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1446)
static void C_ccall f_1446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1309)
static void C_ccall f_1309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1448)
static void C_fcall f_1448(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2314)
static void C_ccall f_2314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2312)
static void C_ccall f_2312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2318)
static void C_ccall f_2318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2316)
static void C_ccall f_2316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1479)
static void C_ccall f_1479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1473)
static void C_ccall f_1473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2304)
static void C_ccall f_2304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2309)
static void C_ccall f_2309(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2270)
static void C_ccall f_2270(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2270)
static void C_ccall f_2270r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1417)
static void C_ccall f_1417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2299)
static void C_ccall f_2299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3096)
static void C_ccall f_3096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2168)
static void C_ccall f_2168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2340)
static void C_ccall f_2340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1279)
static void C_ccall f_1279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1277)
static void C_ccall f_1277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1275)
static void C_ccall f_1275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2230)
static void C_fcall f_2230(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1314)
static void C_fcall f_1314(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f3375)
static void C_ccall f3375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2234)
static void C_ccall f_2234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3074)
static void C_ccall f_3074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3077)
static void C_ccall f_3077(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3077)
static void C_ccall f_3077r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f3379)
static void C_ccall f3379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2331)
static void C_ccall f_2331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2337)
static void C_ccall f_2337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1291)
static void C_ccall f_1291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1297)
static void C_ccall f_1297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1293)
static void C_ccall f_1293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1295)
static void C_ccall f_1295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2480)
static void C_ccall f_2480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2132)
static void C_ccall f_2132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2138)
static void C_ccall f_2138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1795)
static void C_ccall f_1795(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1795)
static void C_ccall f_1795r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1281)
static void C_ccall f_1281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1790)
static void C_ccall f_1790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1287)
static void C_ccall f_1287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1289)
static void C_ccall f_1289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1283)
static void C_ccall f_1283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1285)
static void C_ccall f_1285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2121)
static void C_ccall f_2121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2127)
static void C_ccall f_2127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2124)
static void C_ccall f_2124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1747)
static void C_ccall f_1747(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1742)
static void C_ccall f_1742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1736)
static void C_ccall f_1736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1733)
static void C_ccall f_1733(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1893)
static void C_ccall f_1893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1767)
static void C_ccall f_1767(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1765)
static void C_ccall f_1765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1762)
static void C_ccall f_1762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2442)
static void C_ccall f_2442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2446)
static void C_ccall f_2446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2444)
static void C_ccall f_2444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2767)
static void C_ccall f_2767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2765)
static void C_ccall f_2765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1753)
static void C_ccall f_1753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2474)
static void C_ccall f_2474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2471)
static void C_ccall f_2471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2448)
static void C_ccall f_2448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2463)
static void C_ccall f_2463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2460)
static void C_ccall f_2460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2477)
static void C_ccall f_2477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2740)
static void C_ccall f_2740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2099)
static void C_ccall f_2099(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2746)
static void C_fcall f_2746(C_word t0,C_word t1) C_noret;

C_noret_decl(trf_2495)
static void C_fcall trf_2495(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2495(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2495(t0,t1,t2);}

C_noret_decl(trf_2734)
static void C_fcall trf_2734(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2734(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2734(t0,t1,t2);}

C_noret_decl(trf_1329)
static void C_fcall trf_1329(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1329(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_1329(t0);}

C_noret_decl(trf_2699)
static void C_fcall trf_2699(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2699(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2699(t0,t1);}

C_noret_decl(trf_1868)
static void C_fcall trf_1868(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1868(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1868(t0,t1,t2);}

C_noret_decl(trf_2687)
static void C_fcall trf_2687(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2687(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2687(t0,t1);}

C_noret_decl(trf_1805)
static void C_fcall trf_1805(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1805(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1805(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2576)
static void C_fcall trf_2576(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2576(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2576(t0,t1);}

C_noret_decl(trf_2658)
static void C_fcall trf_2658(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2658(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2658(t0,t1);}

C_noret_decl(trf_1625)
static void C_fcall trf_1625(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1625(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1625(t0,t1,t2);}

C_noret_decl(trf_2438)
static void C_fcall trf_2438(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2438(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2438(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2516)
static void C_fcall trf_2516(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2516(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_2516(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_1973)
static void C_fcall trf_1973(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1973(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1973(t0,t1,t2);}

C_noret_decl(trf_2972)
static void C_fcall trf_2972(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2972(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2972(t0,t1);}

C_noret_decl(trf_1342)
static void C_fcall trf_1342(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1342(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1342(t0,t1,t2,t3);}

C_noret_decl(trf_1392)
static void C_fcall trf_1392(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1392(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1392(t0,t1,t2);}

C_noret_decl(trf_2907)
static void C_fcall trf_2907(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2907(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2907(t0,t1,t2);}

C_noret_decl(trf_1448)
static void C_fcall trf_1448(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1448(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1448(t0,t1,t2);}

C_noret_decl(trf_2230)
static void C_fcall trf_2230(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2230(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2230(t0,t1);}

C_noret_decl(trf_1314)
static void C_fcall trf_1314(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1314(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1314(t0,t1,t2);}

C_noret_decl(trf_2746)
static void C_fcall trf_2746(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2746(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2746(t0,t1);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

/* setup-download#response-match-code? in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_fcall f_2495(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2495,NULL,3,t1,t2,t3);}
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2505,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:285: number->string");
C_number_to_string(3,0,t4,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* get-files in k2655 */
static void C_fcall f_2734(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2734,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2738,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
C_trace("setup-download.scm:356: skip");
t4=((C_word*)((C_word*)t0)[7])[1];
f_2658(t4,t3);}

/* k1573 in k1571 in k1550 in k1548 in k1546 */
static void C_ccall f_1574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1574,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1576,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:114: display");
t3=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[6],((C_word*)t0)[5]);}

/* k1571 in k1550 in k1548 in k1546 */
static void C_ccall f_1572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1572,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1574,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
C_trace("setup-download.scm:114: display");
t4=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[34],t2);}

/* k1577 in k1575 in k1573 in k1571 in k1550 in k1548 in k1546 */
static void C_ccall f_1578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1578,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1581,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:114: display");
t3=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[4],((C_word*)t0)[5]);}

/* k1575 in k1573 in k1571 in k1550 in k1548 in k1546 */
static void C_ccall f_1576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1576,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1578,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("write-char/port");
t3=C_fast_retrieve(lf[33]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(32),((C_word*)t0)[5]);}

/* k1857 */
static void C_ccall f_1858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#string-append");
((C_proc4)C_fast_retrieve_symbol_proc(lf[216]))(4,*((C_word*)lf[216]+1),((C_word*)t0)[2],t1,lf[217]);}

/* k1569 in k1554 in k1552 in k1550 in k1548 in k1546 */
static void C_ccall f_1570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_eqp(t1,C_fix(0));
if(C_truep(t2)){
C_trace("setup-download.scm:118: values");
C_values(4,0,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4]);}
else{
C_trace("setup-download.scm:119: values");
C_values(4,0,((C_word*)t0)[2],C_SCHEME_FALSE,lf[28]);}}

/* f_1852 in k1846 in k1844 in k1842 in k1840 */
static void C_ccall f_1852(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1852,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1858,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:164: string-chomp");
t4=C_fast_retrieve(lf[171]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[218]);}

/* k2737 in get-files in k2655 */
static void C_ccall f_2738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2738,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2740,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
C_trace("setup-download.scm:357: read");
t3=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* f_1723 in k1717 in setup-download#gather-egg-information in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_1723(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1723,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1728,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li9),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1733,a[2]=t2,a[3]=((C_word)li18),tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:134: ##sys#call-with-values");
C_call_with_values(4,0,t1,t3,t4);}

/* f_1728 */
static void C_ccall f_1728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1728,2,t0,t1);}
C_trace("setup-download.scm:135: locate-egg/local");
((C_proc4)C_fast_retrieve_symbol_proc(lf[19]))(4,*((C_word*)lf[19]+1),t1,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* f_2679 in k2674 in k2668 in k2661 in skip in k2655 */
static void C_ccall f_2679(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2679,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2682,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:342: irregex-match-substring");
t4=C_fast_retrieve(lf[81]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,C_fix(1));}

/* k1332 in setup-download#get-temporary-directory in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_1333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1333,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1338,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:68: create-temporary-directory");
t3=C_fast_retrieve(lf[13]);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k1337 in k1332 in setup-download#get-temporary-directory in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_1338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1338,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1340,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:69: temporary-directory");
((C_proc3)C_fast_retrieve_symbol_proc(lf[11]))(3,*((C_word*)lf[11]+1),t2,t1);}

/* k1844 in k1842 in k1840 */
static void C_ccall f_1845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1845,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1847,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:162: d");
f_1314(t2,lf[220],C_a_i_list(&a,1,t1));}

/* k1846 in k1844 in k1842 in k1840 */
static void C_ccall f_1847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1847,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1852,a[2]=((C_word)li58),tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1861,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t3,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:165: with-input-from-pipe");
t8=C_fast_retrieve(lf[84]);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,((C_word*)t0)[3],C_fast_retrieve(lf[85]));}

/* k1840 */
static void C_ccall f_1841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1841,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1843,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
C_trace("setup-download.scm:160: string-append");
t3=*((C_word*)lf[67]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[221],((C_word*)t0)[4],lf[222]);}
else{
t3=t2;
f_1843(2,t3,lf[223]);}}

/* k2668 in k2661 in skip in k2655 */
static void C_ccall f_2670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2670,2,t0,t1);}
if(C_truep(t1)){
C_trace("setup-download.scm:339: open-input-string");
t2=C_fast_retrieve(lf[101]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[102]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2675,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:340: irregex-match");
t3=C_fast_retrieve(lf[96]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[109],((C_word*)t0)[3]);}}

/* k1842 in k1840 */
static void C_ccall f_1843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1843,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1845,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:161: make-svn-ls-cmd");
f_1805(t2,((C_word*)t0)[3],t1,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);}

/* k2674 in k2668 in k2661 in skip in k2655 */
static void C_ccall f_2675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2675,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2679,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li29),tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:334: g758");
t3=t2;
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[4],t1);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2720,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:350: string-every");
t3=C_fast_retrieve(lf[107]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_fast_retrieve(lf[108]),((C_word*)t0)[2]);}}

/* setup-download#gather-egg-information in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_1714(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1714,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1718,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:132: directory");
t4=C_fast_retrieve(lf[47]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k1717 in setup-download#gather-egg-information in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_1718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1718,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1723,a[2]=((C_word*)t0)[2],a[3]=((C_word)li19),tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:133: filter-map");
t3=C_fast_retrieve(lf[59]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,t1);}

/* k3198 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_3199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:54: conc");
t2=C_fast_retrieve(lf[64]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[248],t1);}

/* f_3193 in k3154 in setup-download#list-extension-versions in k2950 in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_3193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3193,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,C_retrieve2(lf[0],"setup-download#\052quiet\052"));
t3=C_mutate(&lf[0] /* (set! setup-download#*quiet* ...) */,((C_word*)((C_word*)t0)[3])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* k2793 in k2780 in k2744 in k2739 in k2737 in get-files in k2655 */
static void C_ccall f_2794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2794,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2796,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
C_trace("setup-download.scm:372: read");
t3=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[8]);}

/* k2791 in k2783 in k2780 in k2744 in k2739 in k2737 in get-files in k2655 */
static void C_ccall f_2792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:368: create-directory");
t2=C_fast_retrieve(lf[40]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1591 in k1589 in k1587 in k1585 in k1550 in k1548 in k1546 */
static void C_ccall f_1592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1592,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1595,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:115: display");
t3=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[4],((C_word*)t0)[5]);}

/* k1319 in setup-download#d in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_1320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:62: flush-output");
t2=*((C_word*)lf[9]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k1593 in k1591 in k1589 in k1587 in k1585 in k1550 in k1548 in k1546 */
static void C_ccall f_1595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:115: get-output-string");
t2=C_fast_retrieve(lf[31]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_1327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[36],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1327,2,t0,t1);}
t2=C_mutate((C_word*)lf[11]+1 /* (set! setup-download#temporary-directory ...) */,t1);
t3=C_mutate(&lf[12] /* (set! setup-download#get-temporary-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1329,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate(&lf[14] /* (set! setup-download#existing-version ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1342,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[19]+1 /* (set! setup-download#locate-egg/local ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1481,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[49]+1 /* (set! setup-download#gather-egg-information ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1714,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate(&lf[60] /* (set! setup-download#make-svn-ls-cmd ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1805,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[66]+1 /* (set! setup-download#locate-egg/svn ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2039,a[2]=((C_word)li25),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate(&lf[93] /* (set! setup-download#deconstruct-url ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2230,a[2]=((C_word)li26),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[98]+1 /* (set! setup-download#locate-egg/http ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2270,a[2]=((C_word)li35),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate(&lf[137] /* (set! setup-download#make-HTTP-GET/1.1 ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2438,a[2]=((C_word)li40),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate(&lf[165] /* (set! setup-download#response-match-code? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2495,a[2]=((C_word)li41),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate(&lf[100] /* (set! setup-download#http-connect ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2516,a[2]=((C_word)li48),tmp=(C_word)a,a+=3,tmp));
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2952,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:420: char-set");
t15=C_fast_retrieve(lf[246]);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t14,C_make_character(92),C_make_character(47));}

/* setup-download#get-temporary-directory in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_fcall f_1329(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1329,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1333,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:67: temporary-directory");
((C_proc2)C_fast_retrieve_symbol_proc(lf[11]))(2,*((C_word*)lf[11]+1),t2);}

/* k2797 in k2795 in k2793 in k2780 in k2744 in k2739 in k2737 in get-files in k2655 */
static void C_ccall f_2798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2798,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2801,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2810,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:374: make-pathname");
t4=C_fast_retrieve(lf[20]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[6],((C_word*)t0)[2]);}

/* k2795 in k2793 in k2780 in k2744 in k2739 in k2737 in get-files in k2655 */
static void C_ccall f_2796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2796,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2798,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("read-string/port");
t3=C_fast_retrieve(lf[125]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,((C_word*)t0)[7]);}

/* k2661 in skip in k2655 */
static void C_ccall f_2662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2662,2,t0,t1);}
t2=C_eofp(t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2670,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_2670(2,t4,t2);}
else{
C_trace("setup-download.scm:338: irregex-match");
t4=C_fast_retrieve(lf[96]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[110],t1);}}

/* k1589 in k1587 in k1585 in k1550 in k1548 in k1546 */
static void C_ccall f_1590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1590,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1592,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:115: display");
t3=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[36],((C_word*)t0)[5]);}

/* k2697 in k2685 in k2681 */
static void C_fcall f_2699(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2699,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2701,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:345: warning");
t3=C_fast_retrieve(lf[25]);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[104],((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}
else{
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,((C_word*)t0)[5]);
C_trace("setup-download.scm:349: open-input-string");
t3=C_fast_retrieve(lf[101]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[3],((C_word*)t0)[4]);}}

/* k2780 in k2744 in k2739 in k2737 in get-files in k2655 */
static void C_ccall f_2782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2782,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2784,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("setup-download.scm:367: d");
f_1314(t2,lf[122],C_a_i_list(&a,1,((C_word*)t0)[6]));}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2794,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
C_trace("setup-download.scm:371: d");
f_1314(t2,lf[126],C_a_i_list(&a,1,((C_word*)t0)[6]));}}

/* k2783 in k2780 in k2744 in k2739 in k2737 in get-files in k2655 */
static void C_ccall f_2784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2784,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2786,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2792,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:368: make-pathname");
t4=C_fast_retrieve(lf[20]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[5],((C_word*)t0)[6]);}

/* k1587 in k1585 in k1550 in k1548 in k1546 */
static void C_ccall f_1588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1588,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1590,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:115: display");
t3=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[6],((C_word*)t0)[5]);}

/* k1356 in setup-download#existing-version in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_1357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(C_i_pairp(t1))){
t2=t1;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_u_i_car(t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k1585 in k1550 in k1548 in k1546 */
static void C_ccall f_1586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1586,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1588,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
C_trace("setup-download.scm:115: display");
t4=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[37],t2);}

/* map-loop459 in k1860 in k1846 in k1844 in k1842 in k1840 */
static void C_fcall f_1868(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1868,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1893,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
C_trace("setup-download.scm:164: g465");
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2785 in k2783 in k2780 in k2744 in k2739 in k2737 in get-files in k2655 */
static void C_ccall f_2786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:369: get-files");
t2=((C_word*)((C_word*)t0)[2])[1];
f_2734(t2,((C_word*)t0)[3],((C_word*)t0)[4]);}

/* k1864 in k1860 in k1846 in k1844 in k1842 in k1840 */
static void C_ccall f_1866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:163: string-concatenate");
t2=C_fast_retrieve(lf[215]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1579 in k1577 in k1575 in k1573 in k1571 in k1550 in k1548 in k1546 */
static void C_ccall f_1581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:114: get-output-string");
t2=C_fast_retrieve(lf[31]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k1860 in k1846 in k1844 in k1842 in k1840 */
static void C_ccall f_1861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1861,2,t0,t1);}
t2=C_i_check_list_2(t1,lf[219]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1866,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1868,a[2]=((C_word*)t0)[3],a[3]=t5,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word)li59),tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_1868(t7,t3,t1);}

/* k2685 in k2681 */
static void C_fcall f_2687(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2687,NULL,2,t0,t1);}
if(C_truep(t1)){
C_trace("setup-download.scm:349: open-input-string");
t2=C_fast_retrieve(lf[101]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2699,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t3=C_i_string_equal_p(((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);
t4=t2;
f_2699(t4,C_i_not(t3));}
else{
t3=t2;
f_2699(t3,C_SCHEME_FALSE);}}}

/* k2101 */
static void C_ccall f_2102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2102,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2104,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2124,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2138,a[2]=t3,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t5=C_eqp(C_retrieve2(lf[3],"setup-download#\052mode\052"),lf[79]);
if(C_truep(t5)){
t6=((C_word*)t0)[8];
t7=((C_word*)t0)[6];
C_trace("setup-download.scm:218: conc");
t8=C_fast_retrieve(lf[64]);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t4,t6,C_make_character(47),t7,lf[80]);}
else{
t6=((C_word*)t0)[8];
C_trace("setup-download.scm:202: conc");
t7=C_fast_retrieve(lf[64]);
((C_proc7)(void*)(*((C_word*)t7+1)))(7,t7,t3,((C_word*)t0)[7],C_make_character(47),((C_word*)t0)[6],C_make_character(47),t6);}}

/* k2103 in k2101 */
static void C_ccall f_2104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2104,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2106,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:212: d");
f_1314(t2,lf[75],C_a_i_list(&a,1,t1));}

/* k1534 in k1520 in k1518 */
static void C_ccall f_1536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("setup-download.scm:106: directory?");
t2=C_fast_retrieve(lf[23]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
C_trace("setup-download.scm:108: values");
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[5],lf[22]);}}

/* k2105 in k2103 in k2101 */
static void C_ccall f_2106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2106,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2121,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:213: system");
t3=C_fast_retrieve(lf[29]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k2060 in k2058 in setup-download#locate-egg/svn in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_2061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2061,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2063,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2168,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:181: make-pathname");
t4=C_fast_retrieve(lf[20]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[5],((C_word*)t0)[2]);}

/* k2681 */
static void C_ccall f_2682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2682,2,t0,t1);}
t2=C_i_string_equal_p(lf[103],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2687,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_2687(t4,t2);}
else{
t4=t1;
t5=t3;
f_2687(t5,C_u_i_string_equal_p(lf[105],t4));}}

/* k2062 in k2060 in k2058 in setup-download#locate-egg/svn in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_2063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2063,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2065,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
C_trace("setup-download.scm:182: d");
f_1314(t2,lf[86],C_a_i_list(&a,1,t1));}

/* k2064 in k2062 in k2060 in k2058 in setup-download#locate-egg/svn in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 in ... */
static void C_ccall f_2065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2065,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2067,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
C_trace("setup-download.scm:183: with-input-from-pipe");
t3=C_fast_retrieve(lf[84]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[9],C_fast_retrieve(lf[85]));}

/* k1817 in setup-download#make-svn-ls-cmd in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_1818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:152: conc");
t2=C_fast_retrieve(lf[64]);
((C_proc8)(void*)(*((C_word*)t2+1)))(8,t2,((C_word*)t0)[2],lf[65],((C_word*)t0)[3],C_make_character(32),((C_word*)t0)[4],((C_word*)t0)[5],t1);}

/* k2066 in k2064 in k2062 in k2060 in k2058 in setup-download#locate-egg/svn in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in ... */
static void C_ccall f_2067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2067,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2069,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2154,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2156,a[2]=((C_word)li24),tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:186: filter-map");
t5=C_fast_retrieve(lf[59]);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t1);}

/* k2637 in k2635 in setup-download#http-connect in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_2638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2638,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2640,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:293: display");
t3=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[6],((C_word*)t0)[4]);}

/* k2635 in setup-download#http-connect in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_2636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2636,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2638,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
C_trace("setup-download.scm:293: display");
t4=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[189],t2);}

/* f_3165 in k3154 in setup-download#list-extension-versions in k2950 in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_3165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[12],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3165,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_eqp(t2,lf[207]);
if(C_truep(t3)){
t4=t1;
t5=((C_word*)t0)[3];
t6=((C_word*)t0)[4];
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1426,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1479,a[2]=t7,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:88: string-append");
t9=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,t5,lf[234]);}
else{
t4=C_eqp(t2,lf[208]);
if(C_truep(t4)){
t5=t1;
t6=((C_word*)t0)[3];
t7=((C_word*)t0)[4];
t8=C_a_i_list(&a,2,((C_word*)t0)[5],((C_word*)t0)[6]);
t9=C_i_nullp(t8);
t10=(C_truep(t9)?C_SCHEME_FALSE:C_i_car(t8));
t11=C_i_nullp(t8);
t12=(C_truep(t11)?C_SCHEME_END_OF_LIST:C_i_cdr(t8));
t13=C_i_nullp(t12);
t14=(C_truep(t13)?C_SCHEME_FALSE:C_i_car(t12));
t15=C_i_nullp(t12);
t16=(C_truep(t15)?C_SCHEME_END_OF_LIST:C_i_cdr(t12));
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1940,a[2]=t5,a[3]=t7,a[4]=t6,a[5]=t14,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t10)){
C_trace("setup-download.scm:168: string-append");
t18=*((C_word*)lf[67]+1);
((C_proc5)(void*)(*((C_word*)t18+1)))(5,t18,t17,lf[242],t10,lf[243]);}
else{
t18=t17;
f_1940(2,t18,lf[244]);}}
else{
C_trace("setup-download.scm:470: error");
t5=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,lf[245],((C_word*)t0)[2]);}}}

/* k1651 */
static void C_ccall f_1652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:123: filter");
t2=C_fast_retrieve(lf[46]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* k2569 in k2567 in k2565 in k2556 in k2554 in k2552 in k2550 in k2548 in k2546 in k2544 in k2542 in k2540 */
static void C_ccall f_2570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2570,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2574,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:329: open-input-string");
t3=C_fast_retrieve(lf[101]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* f_3160 in k3154 in setup-download#list-extension-versions in k2950 in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_3160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3160,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,C_retrieve2(lf[0],"setup-download#\052quiet\052"));
t3=C_mutate(&lf[0] /* (set! setup-download#*quiet* ...) */,((C_word*)((C_word*)t0)[3])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* k2572 in k2569 in k2567 in k2565 in k2556 in k2554 in k2552 in k2550 in k2548 in k2546 in k2544 in k2542 in k2540 */
static void C_ccall f_2574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
C_trace("setup-download.scm:330: values");
C_values(4,0,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],((C_word*)((C_word*)t0)[4])[1]);}

/* k2633 in setup-download#http-connect in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_2634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2634,2,t0,t1);}
C_trace("setup-download.scm:291: d");
f_1314(((C_word*)t0)[2],lf[187],C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[4],t1));}

/* f_1800 */
static void C_ccall f_1800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1800,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* k2630 in k2540 */
static void C_ccall f_2631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:297: display");
t2=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,((C_word*)((C_word*)t0)[3])[1]);}

/* setup-download#make-svn-ls-cmd in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_fcall f_1805(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1805,NULL,5,t1,t2,t3,t4,t5);}
t6=C_i_get_keyword(lf[61],t5,C_SCHEME_FALSE);
t7=(C_truep(t6)?lf[62]:lf[63]);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1818,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:152: qs");
t9=C_fast_retrieve(lf[38]);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t4);}

/* k2068 in k2066 in k2064 in k2062 in k2060 in k2058 in setup-download#locate-egg/svn in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in ... */
static void C_ccall f_2069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2069,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2074,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word)li22),tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2099,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word)li23),tmp=(C_word)a,a+=8,tmp);
C_trace("setup-download.scm:183: ##sys#call-with-values");
C_call_with_values(4,0,((C_word*)t0)[9],t2,t3);}

/* loop in k2554 in k2552 in k2550 in k2548 in k2546 in k2544 in k2542 in k2540 */
static void C_fcall f_2576(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2576,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2580,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:320: read-line");
t3=C_fast_retrieve(lf[111]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[4])[1]);}

/* k3154 in setup-download#list-extension-versions in k2950 in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_3155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3155,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3160,a[2]=t5,a[3]=t3,a[4]=((C_word)li67),tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3165,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word)li72),tmp=(C_word)a,a+=8,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3193,a[2]=t3,a[3]=t5,a[4]=((C_word)li73),tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:463: ##sys#dynamic-wind");
t9=*((C_word*)lf[211]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,((C_word*)t0)[8],t6,t7,t8);}

/* k1430 in k1425 */
static void C_ccall f_1432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1432,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1437,a[2]=((C_word)li68),tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1443,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t3,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:91: directory");
t8=C_fast_retrieve(lf[47]);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[232]);}}

/* f_1437 in k1430 in k1425 */
static void C_ccall f_1437(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1437,3,t0,t1,t2);}
t3=*((C_word*)lf[67]+1);
C_trace("setup-download.scm:91: g277");
t4=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,lf[231]);}

/* k1554 in k1552 in k1550 in k1548 in k1546 */
static void C_ccall f_1555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1555,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1570,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:117: system");
t3=C_fast_retrieve(lf[29]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k1550 in k1548 in k1546 */
static void C_ccall f_1551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1551,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1553,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve2(lf[5],"setup-download#\052windows-shell\052"))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1572,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:114: open-output-string");
t4=C_fast_retrieve(lf[35]);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1586,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:115: open-output-string");
t4=C_fast_retrieve(lf[35]);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1552 in k1550 in k1548 in k1546 */
static void C_ccall f_1553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1553,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1555,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:116: d");
f_1314(t2,lf[30],C_a_i_list(&a,1,t1));}

/* k2082 */
static void C_ccall f_2083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:193: values");
C_values(4,0,((C_word*)t0)[2],t1,((C_word*)t0)[3]);}

/* f_1785 */
static void C_ccall f_1785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1785,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1790,a[2]=((C_word*)t0)[2],a[3]=((C_word)li12),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1795,a[2]=((C_word*)t0)[3],a[3]=((C_word)li14),tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:142: ##sys#call-with-values");
C_call_with_values(4,0,t1,t2,t3);}

/* k2084 */
static void C_ccall f_2085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_i_member(lf[69],((C_word*)t0)[2]))){
C_trace("setup-download.scm:197: values");
C_values(4,0,((C_word*)t0)[3],lf[70],lf[71]);}
else{
C_trace("setup-download.scm:198: values");
C_values(4,0,((C_word*)t0)[3],lf[72],lf[73]);}}

/* k2058 in setup-download#locate-egg/svn in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_2059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2059,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2061,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[7])){
C_trace("setup-download.scm:180: string-append");
t3=*((C_word*)lf[67]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[87],((C_word*)t0)[7],lf[88]);}
else{
t3=t2;
f_2061(2,t3,lf[89]);}}

/* k1779 */
static void C_ccall f_1780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:147: return");
t2=((C_word*)t0)[2];
((C_proc3)C_fast_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],C_SCHEME_FALSE);}

/* k2655 */
static void C_ccall f_2656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2656,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2658,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[2],a[5]=((C_word)li30),tmp=(C_word)a,a+=6,tmp));
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2734,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=t8,a[6]=((C_word*)t0)[4],a[7]=t5,a[8]=((C_word)li32),tmp=(C_word)a,a+=9,tmp));
t10=((C_word*)t8)[1];
f_2734(t10,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);}

/* skip in k2655 */
static void C_fcall f_2658(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2658,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2662,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:336: read-line");
t3=C_fast_retrieve(lf[111]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* setup-download#list-extension-versions in k2950 in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_3145(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr5r,(void*)f_3145r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_3145r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_3145r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(9);
t6=C_i_get_keyword(lf[200],t5,C_SCHEME_FALSE);
t7=C_i_get_keyword(lf[202],t5,C_SCHEME_FALSE);
t8=C_i_get_keyword(lf[203],t5,C_SCHEME_FALSE);
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3155,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t4,a[6]=t7,a[7]=t8,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
C_trace("setup-download.scm:462: check-egg-name");
f_2972(t9,t2);}

/* k1425 */
static void C_ccall f_1426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1426,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1432,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:89: directory-exists?");
t3=C_fast_retrieve(lf[233]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k1675 in k1668 in k1662 in k1498 in k1496 in setup-download#locate-egg/local in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in ... */
static void C_ccall f_1676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:99: existing-version");
f_1342(((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* k1546 */
static void C_ccall f_1547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1547,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1549,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1604,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:111: normalize-pathname");
t4=C_fast_retrieve(lf[39]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}

/* k1668 in k1662 in k1498 in k1496 in setup-download#locate-egg/local in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 in ... */
static void C_ccall f_1670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1670,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1676,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:99: directory");
t3=C_fast_retrieve(lf[47]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=((C_word*)t0)[2];
f_1501(2,t2,C_SCHEME_FALSE);}}

/* k2550 in k2548 in k2546 in k2544 in k2542 in k2540 */
static void C_ccall f_2551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2551,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2553,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t1,tmp=(C_word)a,a+=14,tmp);
C_trace("setup-download.scm:306: d");
f_1314(t2,lf[182],C_a_i_list(&a,1,((C_word*)t0)[12]));}

/* k2552 in k2550 in k2548 in k2546 in k2544 in k2542 in k2540 */
static void C_ccall f_2553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2553,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2555,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2600,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=t2,a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
C_trace("setup-download.scm:308: response-match-code?");
f_2495(t3,((C_word*)t0)[13],C_fix(407));}

/* f_1541 in k1502 in k1500 in k1498 in k1496 in setup-download#locate-egg/local in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in ... */
static void C_ccall f_1541(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1541,4,t0,t1,t2,t3);}
if(C_truep(((C_word*)t0)[2])){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1547,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:110: create-directory");
t5=C_fast_retrieve(lf[40]);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1606,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[3])){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1611,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1645,a[2]=((C_word)li6),tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1652,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:123: directory");
t8=C_fast_retrieve(lf[47]);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
C_trace("setup-download.scm:129: values");
C_values(4,0,t1,t2,t3);}}}

/* f_3140 in setup-download#list-extensions in k2950 in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_3140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3140,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,C_retrieve2(lf[0],"setup-download#\052quiet\052"));
t3=C_mutate(&lf[0] /* (set! setup-download#*quiet* ...) */,((C_word*)((C_word*)t0)[3])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* f_1772 */
static void C_ccall f_1772(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1772,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1777,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li10),tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:142: k410");
t4=((C_word*)t0)[4];
((C_proc3)C_fast_retrieve_proc(t4))(3,t4,t1,t3);}

/* f_1777 */
static void C_ccall f_1777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1777,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1780,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:144: warning");
t3=C_fast_retrieve(lf[25]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[51],((C_word*)t0)[3]);}

/* f_2074 in k2068 in k2066 in k2064 in k2062 in k2060 in k2058 in setup-download#locate-egg/svn in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in ... */
static void C_ccall f_2074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2074,2,t0,t1);}
if(C_truep(((C_word*)t0)[2])){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2083,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:193: string-append");
t3=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[68],((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2085,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[4];
if(C_truep(((C_word*)t0)[5])){
C_trace("setup-download.scm:82: warning");
t4=C_fast_retrieve(lf[25]);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,lf[26],t3,((C_word*)t0)[5]);}
else{
if(C_truep(C_i_member(lf[69],((C_word*)t0)[3]))){
C_trace("setup-download.scm:197: values");
C_values(4,0,t1,lf[70],lf[71]);}
else{
C_trace("setup-download.scm:198: values");
C_values(4,0,t1,lf[72],lf[73]);}}}}

/* k2554 in k2552 in k2550 in k2548 in k2546 in k2544 in k2542 in k2540 */
static void C_ccall f_2555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2555,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2558,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2576,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=((C_word)li44),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_2576(t6,t2);}

/* k2556 in k2554 in k2552 in k2550 in k2548 in k2546 in k2544 in k2542 in k2540 */
static void C_ccall f_2558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2558,2,t0,t1);}
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2566,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:326: d");
f_1314(t2,lf[173],C_SCHEME_END_OF_LIST);}
else{
C_trace("setup-download.scm:330: values");
C_values(4,0,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[5])[1]);}}

/* k2645 in k2643 in k2641 in k2639 in k2637 in k2635 in setup-download#http-connect in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in ... */
static void C_ccall f_2647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:293: get-output-string");
t2=C_fast_retrieve(lf[31]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k1548 in k1546 */
static void C_ccall f_1549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1549,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1551,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1601,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:112: normalize-pathname");
t4=C_fast_retrieve(lf[39]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[5]);}

/* k2579 in loop in k2554 in k2552 in k2550 in k2548 in k2546 in k2544 in k2542 in k2540 */
static void C_ccall f_2580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2580,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2586,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:321: string-null?");
t3=C_fast_retrieve(lf[176]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k2643 in k2641 in k2639 in k2637 in k2635 in setup-download#http-connect in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in ... */
static void C_ccall f_2644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2644,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2647,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:293: display");
t3=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[188],((C_word*)t0)[4]);}

/* k2641 in k2639 in k2637 in k2635 in setup-download#http-connect in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 in ... */
static void C_ccall f_2642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2642,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2644,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:293: display");
t3=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[5],((C_word*)t0)[4]);}

/* k2639 in k2637 in k2635 in setup-download#http-connect in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_2640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2640,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2642,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("write-char/port");
t3=C_fast_retrieve(lf[33]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(58),((C_word*)t0)[4]);}

/* k2584 in k2579 in loop in k2554 in k2552 in k2550 in k2548 in k2546 in k2544 in k2542 in k2540 */
static void C_ccall f_2586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2586,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2596,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[5];
C_trace("setup-download.scm:288: irregex-match");
t4=C_fast_retrieve(lf[96]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[175],t3);}}

/* k2718 in k2674 in k2668 in k2661 in skip in k2655 */
static void C_ccall f_2720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("setup-download.scm:351: skip");
t2=((C_word*)((C_word*)t0)[2])[1];
f_2658(t2,((C_word*)t0)[3]);}
else{
C_trace("setup-download.scm:353: error");
t2=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],lf[106],((C_word*)t0)[4]);}}

/* k2250 in k2239 in k2233 in setup-download#deconstruct-url in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_2252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2252,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2254,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:225: irregex-match-substring");
t3=C_fast_retrieve(lf[81]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],C_fix(4));}
else{
t2=((C_word*)t0)[2];
f_2243(2,t2,C_fix(80));}}

/* k2253 in k2250 in k2239 in k2233 in setup-download#deconstruct-url in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 in ... */
static void C_ccall f_2254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2254,2,t0,t1);}
t2=C_a_i_string_to_number(&a,2,t1,C_fix(10));
if(C_truep(t2)){
t3=((C_word*)t0)[2];
f_2243(2,t3,t2);}
else{
C_trace("setup-download.scm:227: error");
t3=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],lf[95],t1);}}

/* k2876 */
static void C_ccall f_2877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2877,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2879,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:390: close-input-port");
t3=*((C_word*)lf[121]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k2878 in k2876 */
static void C_ccall f_2879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2879,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2881,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:391: close-output-port");
t3=*((C_word*)lf[120]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* f_2538 in k2519 in setup-download#http-connect in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_2538(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2538,4,t0,t1,t2,t3);}
t4=t2;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=t3;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2541,a[2]=t5,a[3]=t1,a[4]=t7,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
C_trace("setup-download.scm:296: d");
f_1314(t8,lf[186],C_a_i_list(&a,1,((C_word*)t0)[4]));}

/* f_1645 */
static void C_ccall f_1645(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1645,3,t0,t1,t2);}
t3=C_fast_retrieve(lf[44]);
C_trace("setup-download.scm:123: g373");
t4=C_fast_retrieve(lf[44]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,lf[45],t2);}

/* k2889 in k2744 in k2739 in k2737 in get-files in k2655 */
static void C_ccall f_2890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:395: abort");
t2=C_fast_retrieve(lf[112]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2239 in k2233 in setup-download#deconstruct-url in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_2240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2240,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2243,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2252,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
C_trace("setup-download.scm:224: irregex-match-substring");
t4=C_fast_retrieve(lf[81]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],C_fix(3));}
else{
t4=t3;
f_2252(2,t4,C_SCHEME_FALSE);}}

/* k2892 in k2744 in k2739 in k2737 in get-files in k2655 */
static void C_ccall f_2893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2893,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2896,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:401: make-property-condition");
t3=C_fast_retrieve(lf[114]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[115]);}

/* k2242 in k2239 in k2233 in setup-download#deconstruct-url in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_2243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2243,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2246,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
C_trace("setup-download.scm:229: irregex-match-substring");
t3=C_fast_retrieve(lf[81]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[4],C_fix(5));}
else{
C_trace("setup-download.scm:222: values");
C_values(5,0,((C_word*)t0)[2],((C_word*)t0)[3],t1,lf[94]);}}

/* k2245 in k2242 in k2239 in k2233 in setup-download#deconstruct-url in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 in ... */
static void C_ccall f_2246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:222: values");
C_values(5,0,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* k1516 */
static void C_ccall f_1517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:103: values");
C_values(4,0,((C_word*)t0)[2],t1,((C_word*)t0)[3]);}

/* k1518 */
static void C_ccall f_1519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1519,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1521,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[4];
if(C_truep(((C_word*)t0)[5])){
C_trace("setup-download.scm:82: warning");
t4=C_fast_retrieve(lf[25]);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,lf[26],t3,((C_word*)t0)[5]);}
else{
t4=C_SCHEME_UNDEFINED;
t5=t2;
f_1521(2,t5,t4);}}

/* k2618 */
static void C_ccall f_2619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:311: display");
t2=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,((C_word*)((C_word*)t0)[3])[1]);}

/* k2565 in k2556 in k2554 in k2552 in k2550 in k2548 in k2546 in k2544 in k2542 in k2540 */
static void C_ccall f_2566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2566,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2568,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)((C_word*)t0)[2])[1];
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2907,a[2]=t5,a[3]=t3,a[4]=((C_word)li43),tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_2907(t7,t2,C_SCHEME_END_OF_LIST);}

/* k2567 in k2565 in k2556 in k2554 in k2552 in k2550 in k2548 in k2546 in k2544 in k2542 in k2540 */
static void C_ccall f_2568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2568,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2570,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:328: close-input-port");
t3=*((C_word*)lf[121]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k2700 in k2697 in k2685 in k2681 */
static void C_ccall f_2701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_FALSE);
C_trace("setup-download.scm:349: open-input-string");
t3=C_fast_retrieve(lf[101]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[3],((C_word*)t0)[4]);}

/* k1633 in for-each-loop377 in k1610 */
static void C_ccall f_1634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_1625(t3,((C_word*)t0)[4],t2);}

/* f_2843 in k2315 in k2313 in k2311 */
static void C_ccall f_2843(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2843,4,t0,t1,t2,t3);}
t4=t1;
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2656,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:333: d");
f_1314(t5,lf[129],C_SCHEME_END_OF_LIST);}

/* f_3101 in setup-download#list-extensions in k2950 in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_3101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word ab[13],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3101,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_eqp(t2,lf[207]);
if(C_truep(t3)){
t4=t1;
t5=((C_word*)t0)[3];
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1381,a[2]=((C_word)li56),tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1387,a[2]=t4,a[3]=t9,a[4]=t7,a[5]=t10,tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:85: directory");
t12=C_fast_retrieve(lf[47]);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,t5);}
else{
t4=C_eqp(t2,lf[208]);
if(C_truep(t4)){
t5=t1;
t6=((C_word*)t0)[3];
t7=C_a_i_list(&a,2,((C_word*)t0)[4],((C_word*)t0)[5]);
t8=C_i_nullp(t7);
t9=(C_truep(t8)?C_SCHEME_FALSE:C_i_car(t7));
t10=C_i_nullp(t7);
t11=(C_truep(t10)?C_SCHEME_END_OF_LIST:C_i_cdr(t7));
t12=C_i_nullp(t11);
t13=(C_truep(t12)?C_SCHEME_FALSE:C_i_car(t11));
t14=C_i_nullp(t11);
t15=(C_truep(t14)?C_SCHEME_END_OF_LIST:C_i_cdr(t11));
t16=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1841,a[2]=t5,a[3]=t6,a[4]=t13,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t9)){
C_trace("setup-download.scm:159: string-append");
t17=*((C_word*)lf[67]+1);
((C_proc5)(void*)(*((C_word*)t17+1)))(5,t17,t16,lf[224],t9,lf[225]);}
else{
t17=t16;
f_1841(2,t17,lf[226]);}}
else{
t5=C_eqp(t2,lf[209]);
if(C_truep(t5)){
t6=t1;
t7=((C_word*)t0)[3];
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2855,a[2]=t7,a[3]=((C_word)li60),tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2860,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word)li63),tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:382: ##sys#call-with-values");
C_call_with_values(4,0,t6,t8,t9);}
else{
C_trace("setup-download.scm:459: error");
t6=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,lf[229],((C_word*)t0)[2]);}}}}

/* k1502 in k1500 in k1498 in k1496 in setup-download#locate-egg/local in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 in ... */
static void C_ccall f_1503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1503,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1508,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word)li3),tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1541,a[2]=t1,a[3]=((C_word*)t0)[7],a[4]=((C_word)li7),tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:94: ##sys#call-with-values");
C_call_with_values(4,0,((C_word*)t0)[8],t2,t3);}

/* k1500 in k1498 in k1496 in setup-download#locate-egg/local in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_1501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1501,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1503,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[8])){
C_trace("setup-download.scm:100: make-pathname");
t3=C_fast_retrieve(lf[20]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[8],((C_word*)t0)[4]);}
else{
t3=t2;
f_1503(2,t3,C_SCHEME_FALSE);}}

/* f_1508 in k1502 in k1500 in k1498 in k1496 in setup-download#locate-egg/local in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in ... */
static void C_ccall f_1508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1508,2,t0,t1);}
if(C_truep(((C_word*)t0)[2])){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1517,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:103: make-pathname");
t3=C_fast_retrieve(lf[20]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1519,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:104: make-pathname");
t3=C_fast_retrieve(lf[20]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[4],lf[27]);}}

/* k2898 in k2744 in k2739 in k2737 in get-files in k2655 */
static void C_ccall f_2899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:397: make-property-condition");
t2=C_fast_retrieve(lf[114]);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[2],lf[116],lf[117],t1,lf[118],((C_word*)t0)[3]);}

/* k2895 in k2892 in k2744 in k2739 in k2737 in get-files in k2655 */
static void C_ccall f_2896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:396: make-composite-condition");
t2=C_fast_retrieve(lf[113]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* f_2610 in k2598 in k2552 in k2550 in k2548 in k2546 in k2544 in k2542 in k2540 */
static void C_ccall f_2610(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[34],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2610,4,t0,t1,t2,t3);}
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2619,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:312: make-HTTP-GET/1.1");
f_2438(t6,((C_word*)t0)[4],C_retrieve2(lf[1],"setup-download#\052chicken-install-user-agent\052"),((C_word*)t0)[5],C_a_i_list(&a,10,lf[164],((C_word*)t0)[6],lf[161],lf[177],lf[138],((C_word*)t0)[7],lf[178],((C_word*)t0)[8],lf[139],((C_word*)t0)[9]));}

/* k1662 in k1498 in k1496 in setup-download#locate-egg/local in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_1664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1664,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1670,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:98: directory?");
t3=C_fast_retrieve(lf[23]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=((C_word*)t0)[2];
f_1501(2,t2,C_SCHEME_FALSE);}}

/* k2542 in k2540 */
static void C_ccall f_2543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2543,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2545,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
C_trace("setup-download.scm:301: flush-output");
t3=*((C_word*)lf[9]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)((C_word*)t0)[4])[1]);}

/* k2540 */
static void C_ccall f_2541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[39],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2541,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2543,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2631,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:298: make-HTTP-GET/1.1");
f_2438(t3,((C_word*)t0)[7],C_retrieve2(lf[1],"setup-download#\052chicken-install-user-agent\052"),((C_word*)t0)[8],C_a_i_list(&a,8,lf[164],((C_word*)t0)[9],lf[161],lf[185],lf[138],((C_word*)t0)[5],lf[178],((C_word*)t0)[6]));}

/* k2598 in k2552 in k2550 in k2548 in k2546 in k2544 in k2542 in k2540 */
static void C_ccall f_2600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2600,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2605,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li45),tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2610,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[2],a[8]=((C_word*)t0)[3],a[9]=((C_word*)t0)[9],a[10]=((C_word)li46),tmp=(C_word)a,a+=11,tmp);
C_trace("setup-download.scm:309: ##sys#call-with-values");
C_call_with_values(4,0,((C_word*)t0)[10],t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2625,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:317: response-match-code?");
f_2495(t2,((C_word*)t0)[12],C_fix(200));}}

/* f_2605 in k2598 in k2552 in k2550 in k2548 in k2546 in k2544 in k2542 in k2540 */
static void C_ccall f_2605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2605,2,t0,t1);}
C_trace("setup-download.scm:309: tcp-connect");
t2=C_fast_retrieve(lf[166]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k2548 in k2546 in k2544 in k2542 in k2540 */
static void C_ccall f_2549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2549,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2551,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t1,tmp=(C_word)a,a+=13,tmp);
t3=t1;
if(C_truep(C_i_stringp(t3))){
C_trace("setup-download.scm:282: irregex-match");
t4=C_fast_retrieve(lf[96]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[183],t3);}
else{
t4=t2;
f_2551(2,t4,C_SCHEME_FALSE);}}

/* k2546 in k2544 in k2542 in k2540 */
static void C_ccall f_2547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2547,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2549,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
C_trace("setup-download.scm:304: read-line");
t5=C_fast_retrieve(lf[111]);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)((C_word*)t0)[2])[1]);}

/* k2544 in k2542 in k2540 */
static void C_ccall f_2545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2545,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2547,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
C_trace("setup-download.scm:302: d");
f_1314(t2,lf[184],C_SCHEME_END_OF_LIST);}

/* f_2860 */
static void C_ccall f_2860(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2860,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2866,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t4,a[8]=((C_word)li61),tmp=(C_word)a,a+=9,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2874,a[2]=((C_word)li62),tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:382: ##sys#call-with-values");
C_call_with_values(4,0,t1,t5,t6);}

/* f_2838 in k2315 in k2313 in k2311 */
static void C_ccall f_2838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2838,2,t0,t1);}
C_trace("setup-download.scm:379: http-connect");
f_2516(t1,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[7]);}

/* k1600 in k1548 in k1546 */
static void C_ccall f_1601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:112: qs");
t2=C_fast_retrieve(lf[38]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1605 */
static void C_ccall f_1606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:129: values");
C_values(4,0,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4]);}

/* k1603 in k1546 */
static void C_ccall f_1604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:111: qs");
t2=C_fast_retrieve(lf[38]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2519 in setup-download#http-connect in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_2520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2520,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2525,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word)li42),tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2538,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[7],a[8]=((C_word)li47),tmp=(C_word)a,a+=9,tmp);
C_trace("setup-download.scm:295: ##sys#call-with-values");
C_call_with_values(4,0,((C_word*)t0)[8],t2,t3);}

/* f_2525 in k2519 in setup-download#http-connect in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_2525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2525,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(C_truep(t2)?t2:((C_word*)t0)[3]);
t4=((C_word*)t0)[4];
if(C_truep(t4)){
C_trace("setup-download.scm:295: tcp-connect");
t5=C_fast_retrieve(lf[166]);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}
else{
t5=((C_word*)t0)[5];
C_trace("setup-download.scm:295: tcp-connect");
t6=C_fast_retrieve(lf[166]);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t3,t5);}}

/* f_2866 */
static void C_ccall f_2866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2866,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2872,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
C_trace("setup-download.scm:387: string-append");
t3=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[7],lf[227]);}

/* k2153 in k2066 in k2064 in k2062 in k2060 in k2058 in setup-download#locate-egg/svn in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in ... */
static void C_ccall f_2154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:184: existing-version");
f_1342(((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* f_2156 in k2066 in k2064 in k2062 in k2060 in k2058 in setup-download#locate-egg/svn in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in ... */
static void C_ccall f_2156(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2156,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2159,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:188: irregex-search");
t4=C_fast_retrieve(lf[82]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[83],t2);}

/* k2158 */
static void C_ccall f_2159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("setup-download.scm:189: irregex-match-substring");
t2=C_fast_retrieve(lf[81]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_fix(1));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* f_2855 */
static void C_ccall f_2855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2855,2,t0,t1);}
C_trace("setup-download.scm:383: deconstruct-url");
f_2230(t1,((C_word*)t0)[2]);}

/* k2146 */
static void C_ccall f_2148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:199: make-pathname");
t2=C_fast_retrieve(lf[20]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,((C_word*)t0)[3]);}

/* for-each-loop377 in k1610 */
static void C_fcall f_1625(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1625,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1634,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
C_trace("setup-download.scm:123: g378");
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2504 in setup-download#response-match-code? in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_2505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2505,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2508,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:285: irregex-match-substring");
t3=C_fast_retrieve(lf[81]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],C_fix(1));}

/* k2507 in k2504 in setup-download#response-match-code? in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_2508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_i_string_equal_p(((C_word*)t0)[3],t1));}

/* k2429 in k2623 in k2598 in k2552 in k2550 in k2548 in k2546 in k2544 in k2542 in k2540 */
static void C_ccall f_2430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:249: signal");
t2=C_fast_retrieve(lf[179]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2432 in k2623 in k2598 in k2552 in k2550 in k2548 in k2546 in k2544 in k2542 in k2540 */
static void C_ccall f_2433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2433,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2436,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:255: make-property-condition");
t3=C_fast_retrieve(lf[114]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[180]);}

/* k2435 in k2432 in k2623 in k2598 in k2552 in k2550 in k2548 in k2546 in k2544 in k2542 in k2540 */
static void C_ccall f_2436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:250: make-composite-condition");
t2=C_fast_retrieve(lf[113]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* f_2812 in k2809 in k2797 in k2795 in k2793 in k2780 in k2744 in k2739 in k2737 in get-files in k2655 */
static void C_ccall f_2812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2812,2,t0,t1);}
t2=*((C_word*)lf[32]+1);
C_trace("setup-download.scm:374: g794");
t3=*((C_word*)lf[32]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,((C_word*)t0)[2]);}

/* k2809 in k2797 in k2795 in k2793 in k2780 in k2744 in k2739 in k2737 in get-files in k2655 */
static void C_ccall f_2810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2810,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2812,a[2]=((C_word*)t0)[2],a[3]=((C_word)li31),tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:374: with-output-to-file");
t3=C_fast_retrieve(lf[123]);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],t1,t2,lf[124]);}

/* setup-download#make-HTTP-GET/1.1 in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_fcall f_2438(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2438,NULL,5,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2442,a[2]=t5,a[3]=t1,a[4]=t3,a[5]=t4,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2480,a[2]=((C_word)li39),tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:257: ##sys#get-keyword");
((C_proc5)C_fast_retrieve_proc(*((C_word*)lf[158]+1)))(5,*((C_word*)lf[158]+1),t6,lf[164],t5,t7);}

/* k2594 in k2584 in k2579 in loop in k2554 in k2552 in k2550 in k2548 in k2546 in k2544 in k2542 in k2540 */
static void C_ccall f_2596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2596,2,t0,t1);}
if(C_truep(t1)){
t2=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f3375,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:323: d");
f_1314(t3,lf[174],C_a_i_list(&a,1,((C_word*)t0)[5]));}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f3379,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:323: d");
f_1314(t2,lf[174],C_a_i_list(&a,1,((C_word*)t0)[5]));}}

/* k1520 in k1518 */
static void C_ccall f_1521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1521,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1527,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1536,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:106: file-exists?");
t4=C_fast_retrieve(lf[24]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}

/* k1525 in k1520 in k1518 */
static void C_ccall f_1527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("setup-download.scm:107: values");
C_values(4,0,((C_word*)t0)[2],((C_word*)t0)[3],lf[21]);}
else{
C_trace("setup-download.scm:108: values");
C_values(4,0,((C_word*)t0)[2],((C_word*)t0)[4],lf[22]);}}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1090)){
C_save(t1);
C_rereclaim2(1090*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,255);
lf[4]=C_h_intern(&lf[4],7,"default");
lf[7]=C_h_intern(&lf[7],18,"\003sysstandard-error");
lf[8]=C_h_intern(&lf[8],19,"\003sysstandard-output");
lf[9]=C_h_intern(&lf[9],12,"flush-output");
lf[10]=C_h_intern(&lf[10],7,"fprintf");
lf[11]=C_h_intern(&lf[11],34,"setup-download#temporary-directory");
lf[13]=C_h_intern(&lf[13],26,"create-temporary-directory");
lf[15]=C_h_intern(&lf[15],5,"error");
lf[16]=C_decode_literal(C_heaptop,"\376B\000\000\021version not found");
lf[17]=C_h_intern(&lf[17],4,"sort");
lf[18]=C_h_intern(&lf[18],20,"setup-api#version>=\077");
lf[19]=C_h_intern(&lf[19],31,"setup-download#locate-egg/local");
lf[20]=C_h_intern(&lf[20],13,"make-pathname");
lf[21]=C_decode_literal(C_heaptop,"\376B\000\000\005trunk");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[23]=C_h_intern(&lf[23],10,"directory\077");
lf[24]=C_h_intern(&lf[24],12,"file-exists\077");
lf[25]=C_h_intern(&lf[25],7,"warning");
lf[26]=C_decode_literal(C_heaptop,"\376B\000\000-extension has no such version - using default");
lf[27]=C_decode_literal(C_heaptop,"\376B\000\000\005trunk");
lf[28]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[29]=C_h_intern(&lf[29],6,"system");
lf[30]=C_decode_literal(C_heaptop,"\376B\000\000\006  ~a~%");
lf[31]=C_h_intern(&lf[31],17,"get-output-string");
lf[32]=C_h_intern(&lf[32],7,"display");
lf[33]=C_h_intern(&lf[33],19,"\003syswrite-char/port");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\006xcopy ");
lf[35]=C_h_intern(&lf[35],18,"open-output-string");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\003/\052 ");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\006cp -r ");
lf[38]=C_h_intern(&lf[38],2,"qs");
lf[39]=C_h_intern(&lf[39],18,"normalize-pathname");
lf[40]=C_h_intern(&lf[40],16,"create-directory");
lf[41]=C_h_intern(&lf[41],12,"delete-file\052");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\0006 deleting stale file `~a\047 from local build directory~%");
lf[43]=C_h_intern(&lf[43],8,"for-each");
lf[44]=C_h_intern(&lf[44],14,"string-suffix\077");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\003.so");
lf[46]=C_h_intern(&lf[46],6,"filter");
lf[47]=C_h_intern(&lf[47],9,"directory");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\004tags");
lf[49]=C_h_intern(&lf[49],37,"setup-download#gather-egg-information");
lf[50]=C_h_intern(&lf[50],7,"version");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000.extension has syntactically invalid .meta file");
lf[52]=C_h_intern(&lf[52],20,"with-input-from-file");
lf[53]=C_h_intern(&lf[53],4,"read");
lf[54]=C_h_intern(&lf[54],22,"with-exception-handler");
lf[55]=C_h_intern(&lf[55],30,"call-with-current-continuation");
lf[56]=C_h_intern(&lf[56],14,"string->symbol");
lf[57]=C_h_intern(&lf[57],7,"call/cc");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\000\004meta");
lf[59]=C_h_intern(&lf[59],10,"filter-map");
lf[61]=C_h_intern(&lf[61],11,"\000recursive\077");
lf[62]=C_decode_literal(C_heaptop,"\376B\000\000\004 -R ");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[64]=C_h_intern(&lf[64],4,"conc");
lf[65]=C_decode_literal(C_heaptop,"\376B\000\000\007svn ls ");
lf[66]=C_h_intern(&lf[66],29,"setup-download#locate-egg/svn");
lf[67]=C_h_intern(&lf[67],13,"string-append");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\000\005tags/");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\006trunk/");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\005trunk");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000\005trunk");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\006  ~a~%");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000\005 1>&2");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000\013svn export ");
lf[79]=C_h_intern(&lf[79],4,"meta");
lf[80]=C_decode_literal(C_heaptop,"\376B\000\000\005.meta");
lf[81]=C_h_intern(&lf[81],23,"irregex-match-substring");
lf[82]=C_h_intern(&lf[82],14,"irregex-search");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000\016^tags/([^/]+)/");
lf[84]=C_h_intern(&lf[84],20,"with-input-from-pipe");
lf[85]=C_h_intern(&lf[85],10,"read-lines");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000\047checking available versions ...~%  ~a~%");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\014--password=\047");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\001\047");
lf[89]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[90]=C_decode_literal(C_heaptop,"\376B\000\000\014--username=\047");
lf[91]=C_decode_literal(C_heaptop,"\376B\000\000\001\047");
lf[92]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000\020not a valid port");
lf[96]=C_h_intern(&lf[96],13,"irregex-match");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000#(http://)\077([^/:]+)(:([^:/]+))\077(/.+)");
lf[98]=C_h_intern(&lf[98],30,"setup-download#locate-egg/http");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[101]=C_h_intern(&lf[101],17,"open-input-string");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000 files-versions are not identical");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\002#f");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000=unrecognized file-information - possibly corrupt transmission");
lf[107]=C_h_intern(&lf[107],12,"string-every");
lf[108]=C_h_intern(&lf[108],19,"char-set:whitespace");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\031 \052#\134|[- ]\052([^- ]\052) \052\134|#.\052");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000\011 \052#!eof \052");
lf[111]=C_h_intern(&lf[111],9,"read-line");
lf[112]=C_h_intern(&lf[112],5,"abort");
lf[113]=C_h_intern(&lf[113],24,"make-composite-condition");
lf[114]=C_h_intern(&lf[114],23,"make-property-condition");
lf[115]=C_h_intern(&lf[115],20,"setup-download-error");
lf[116]=C_h_intern(&lf[116],3,"exn");
lf[117]=C_h_intern(&lf[117],7,"message");
lf[118]=C_h_intern(&lf[118],9,"arguments");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000\011[Server] ");
lf[120]=C_h_intern(&lf[120],17,"close-output-port");
lf[121]=C_h_intern(&lf[121],16,"close-input-port");
lf[122]=C_decode_literal(C_heaptop,"\376B\000\000\006  ~a~%");
lf[123]=C_h_intern(&lf[123],19,"with-output-to-file");
lf[124]=C_h_intern(&lf[124],7,"\000binary");
lf[125]=C_h_intern(&lf[125],20,"\003sysread-string/port");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\006  ~a~%");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\0001invalid file name - possibly corrupt transmission");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000\023reading files ...~%");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\006\077name=");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000\006&mode=");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000\012&tests=yes");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[134]=C_h_intern(&lf[134],8,"->string");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\011&version=");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[138]=C_h_intern(&lf[138],11,"\000proxy-host");
lf[139]=C_h_intern(&lf[139],16,"\000proxy-user-pass");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\004GET ");
lf[141]=C_decode_literal(C_heaptop,"\376B\000\000\011 HTTP/1.1");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\002\015\012");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\014Connection: ");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000\002\015\012");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000\014User-Agent: ");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000\002\015\012");
lf[147]=C_decode_literal(C_heaptop,"\376B\000\000\010Accept: ");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000\002\015\012");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\006Host: ");
lf[150]=C_decode_literal(C_heaptop,"\376B\000\000\002\015\012");
lf[151]=C_decode_literal(C_heaptop,"\376B\000\000\020Content-length: ");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\002\015\012");
lf[153]=C_decode_literal(C_heaptop,"\376B\000\000\002\015\012");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\033Proxy-Authorization: Basic ");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\002\015\012");
lf[156]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\000\007http://");
lf[158]=C_h_intern(&lf[158],15,"\003sysget-keyword");
lf[159]=C_h_intern(&lf[159],15,"\000content-length");
lf[160]=C_decode_literal(C_heaptop,"\376B\000\000\001\052");
lf[161]=C_h_intern(&lf[161],7,"\000accept");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000\005close");
lf[163]=C_h_intern(&lf[163],11,"\000connection");
lf[164]=C_h_intern(&lf[164],5,"\000port");
lf[166]=C_h_intern(&lf[166],11,"tcp-connect");
lf[167]=C_h_intern(&lf[167],26,"string-concatenate-reverse");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000\002~%");
lf[169]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[170]=C_decode_literal(C_heaptop,"\376B\000\000/invalid response from server - please try again");
lf[171]=C_h_intern(&lf[171],12,"string-chomp");
lf[172]=C_decode_literal(C_heaptop,"\376B\000\000\001\015");
lf[173]=C_decode_literal(C_heaptop,"\376B\000\000\017reading chunks ");
lf[174]=C_decode_literal(C_heaptop,"\376B\000\000\004~a~%");
lf[175]=C_decode_literal(C_heaptop,"\376B\000\000$[Tt]ransfer-[Ee]ncoding:\134s\052chunked.\052");
lf[176]=C_h_intern(&lf[176],12,"string-null\077");
lf[177]=C_decode_literal(C_heaptop,"\376B\000\000\003\052/\052");
lf[178]=C_h_intern(&lf[178],11,"\000proxy-port");
lf[179]=C_h_intern(&lf[179],6,"signal");
lf[180]=C_h_intern(&lf[180],10,"http-fetch");
lf[181]=C_decode_literal(C_heaptop,"\376B\000\000\034invalid response from server");
lf[182]=C_decode_literal(C_heaptop,"\376B\000\000\004~a~%");
lf[183]=C_decode_literal(C_heaptop,"\376B\000\000\034HTTP/[0-9.]+\134s+([0-9]+)\134s+.\052");
lf[184]=C_decode_literal(C_heaptop,"\376B\000\000\026reading response ...~%");
lf[185]=C_decode_literal(C_heaptop,"\376B\000\000\003\052/\052");
lf[186]=C_decode_literal(C_heaptop,"\376B\000\000\023requesting ~s ...~%");
lf[187]=C_decode_literal(C_heaptop,"\376B\000\000&connecting to host ~s, port ~a ~a...~%");
lf[188]=C_decode_literal(C_heaptop,"\376B\000\000\002) ");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000\005(via ");
lf[190]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[193]=C_decode_literal(C_heaptop,"\376B\000\000\026invalid extension name");
lf[194]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[195]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[196]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[197]=C_h_intern(&lf[197],12,"string-index");
lf[198]=C_h_intern(&lf[198],33,"setup-download#retrieve-extension");
lf[199]=C_h_intern(&lf[199],8,"\000version");
lf[200]=C_h_intern(&lf[200],6,"\000quiet");
lf[201]=C_h_intern(&lf[201],12,"\000destination");
lf[202]=C_h_intern(&lf[202],9,"\000username");
lf[203]=C_h_intern(&lf[203],9,"\000password");
lf[204]=C_h_intern(&lf[204],6,"\000tests");
lf[205]=C_h_intern(&lf[205],6,"\000trunk");
lf[206]=C_h_intern(&lf[206],6,"\000clean");
lf[207]=C_h_intern(&lf[207],5,"local");
lf[208]=C_h_intern(&lf[208],3,"svn");
lf[209]=C_h_intern(&lf[209],4,"http");
lf[210]=C_decode_literal(C_heaptop,"\376B\000\0001cannot retrieve extension - unsupported transport");
lf[211]=C_h_intern(&lf[211],16,"\003sysdynamic-wind");
lf[212]=C_h_intern(&lf[212],5,"\000mode");
lf[213]=C_h_intern(&lf[213],30,"setup-download#list-extensions");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[215]=C_h_intern(&lf[215],18,"string-concatenate");
lf[216]=C_h_intern(&lf[216],17,"\003sysstring-append");
lf[217]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[219]=C_h_intern(&lf[219],3,"map");
lf[220]=C_decode_literal(C_heaptop,"\376B\000\000\047listing extension directory ...~%  ~a~%");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\014--password=\047");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\001\047");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000\014--username=\047");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000\001\047");
lf[226]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[227]=C_decode_literal(C_heaptop,"\376B\000\000\007\077list=1");
lf[228]=C_h_intern(&lf[228],8,"read-all");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000.cannot list extensions - unsupported transport");
lf[230]=C_h_intern(&lf[230],38,"setup-download#list-extension-versions");
lf[231]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[232]=C_decode_literal(C_heaptop,"\376B\000\000\010unknown\012");
lf[233]=C_h_intern(&lf[233],17,"directory-exists\077");
lf[234]=C_decode_literal(C_heaptop,"\376B\000\000\005/tags");
lf[235]=C_decode_literal(C_heaptop,"\376B\000\000\010unknown\012");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[237]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[238]=C_decode_literal(C_heaptop,"\376B\000\000\005/tags");
lf[239]=C_decode_literal(C_heaptop,"\376B\000\000\014--password=\047");
lf[240]=C_decode_literal(C_heaptop,"\376B\000\000\001\047");
lf[241]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[242]=C_decode_literal(C_heaptop,"\376B\000\000\014--username=\047");
lf[243]=C_decode_literal(C_heaptop,"\376B\000\000\001\047");
lf[244]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[245]=C_decode_literal(C_heaptop,"\376B\000\000.cannot list extensions - unsupported transport");
lf[246]=C_h_intern(&lf[246],8,"char-set");
lf[247]=C_h_intern(&lf[247],14,"make-parameter");
lf[248]=C_decode_literal(C_heaptop,"\376B\000\000\020chicken-install ");
lf[249]=C_h_intern(&lf[249],15,"chicken-version");
lf[250]=C_h_intern(&lf[250],17,"tcp-write-timeout");
lf[251]=C_h_intern(&lf[251],16,"tcp-read-timeout");
lf[252]=C_h_intern(&lf[252],19,"tcp-connect-timeout");
lf[253]=C_h_intern(&lf[253],11,"\003sysrequire");
lf[254]=C_h_intern(&lf[254],9,"setup-api");
C_register_lf2(lf,255,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1275,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2623 in k2598 in k2552 in k2550 in k2548 in k2546 in k2544 in k2542 in k2540 */
static void C_ccall f_2625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2625,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
f_2555(2,t3,t2);}
else{
t2=C_a_i_list(&a,1,((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2430,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2433,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:251: make-property-condition");
t5=C_fast_retrieve(lf[114]);
((C_proc7)(void*)(*((C_word*)t5+1)))(7,t5,t4,lf[116],lf[117],lf[181],lf[118],t2);}}

/* k2880 in k2878 in k2876 */
static void C_ccall f_2881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}

/* k2871 */
static void C_ccall f_2872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:385: http-connect");
f_2516(((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],t1,((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[7]);}

/* f_2874 */
static void C_ccall f_2874(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2874,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2877,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:389: read-all");
t5=C_fast_retrieve(lf[228]);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* f_3065 in k3011 in k3007 in setup-download#retrieve-extension in k2950 in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 in ... */
static void C_ccall f_3065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3065,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,C_retrieve2(lf[0],"setup-download#\052quiet\052"));
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve2(lf[2],"setup-download#\052trunk\052"));
t4=C_mutate(((C_word *)((C_word*)t0)[4])+1,C_retrieve2(lf[3],"setup-download#\052mode\052"));
t5=C_mutate(&lf[0] /* (set! setup-download#*quiet* ...) */,((C_word*)((C_word*)t0)[5])[1]);
t6=C_mutate(&lf[2] /* (set! setup-download#*trunk* ...) */,((C_word*)((C_word*)t0)[6])[1]);
t7=C_mutate(&lf[3] /* (set! setup-download#*mode* ...) */,((C_word*)((C_word*)t0)[7])[1]);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_UNDEFINED);}

/* k1610 */
static void C_ccall f_1611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1611,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1612,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp);
t3=C_i_check_list_2(t1,lf[43]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1625,a[2]=t5,a[3]=t2,a[4]=((C_word)li5),tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_1625(t7,((C_word*)t0)[2],t1);}

/* f_1612 in k1610 */
static void C_ccall f_1612(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1612,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1615,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:126: d");
f_1314(t3,lf[42],C_a_i_list(&a,1,t2));}

/* k1614 */
static void C_ccall f_1615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:127: delete-file*");
t2=C_fast_retrieve(lf[41]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* f_3017 in k3011 in k3007 in setup-download#retrieve-extension in k2950 in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 in ... */
static void C_ccall f_3017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3017,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,C_retrieve2(lf[0],"setup-download#\052quiet\052"));
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve2(lf[2],"setup-download#\052trunk\052"));
t4=C_mutate(((C_word *)((C_word*)t0)[4])+1,C_retrieve2(lf[3],"setup-download#\052mode\052"));
t5=C_mutate(&lf[0] /* (set! setup-download#*quiet* ...) */,((C_word*)((C_word*)t0)[5])[1]);
t6=C_mutate(&lf[2] /* (set! setup-download#*trunk* ...) */,((C_word*)((C_word*)t0)[6])[1]);
t7=C_mutate(&lf[3] /* (set! setup-download#*mode* ...) */,((C_word*)((C_word*)t0)[7])[1]);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_UNDEFINED);}

/* k3011 in k3007 in setup-download#retrieve-extension in k2950 in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_3012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[45],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3012,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=((C_word*)t0)[3];
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=((C_word*)t0)[4];
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_FALSE;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_FALSE;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3017,a[2]=t9,a[3]=t11,a[4]=t13,a[5]=t3,a[6]=t5,a[7]=t7,a[8]=((C_word)li50),tmp=(C_word)a,a+=9,tmp);
t15=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_3026,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[14],a[12]=((C_word*)t0)[15],a[13]=((C_word*)t0)[16],a[14]=((C_word)li51),tmp=(C_word)a,a+=15,tmp);
t16=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3065,a[2]=t3,a[3]=t5,a[4]=t7,a[5]=t9,a[6]=t11,a[7]=t13,a[8]=((C_word)li52),tmp=(C_word)a,a+=9,tmp);
C_trace("setup-download.scm:435: ##sys#dynamic-wind");
t17=*((C_word*)lf[211]+1);
((C_proc5)(void*)(*((C_word*)t17+1)))(5,t17,((C_word*)t0)[17],t14,t15,t16);}

/* setup-download#http-connect in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_fcall f_2516(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[23],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2516,NULL,7,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2520,a[2]=t5,a[3]=t2,a[4]=t6,a[5]=t3,a[6]=t4,a[7]=t7,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2634,a[2]=t8,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2636,a[2]=t9,a[3]=t6,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:293: open-output-string");
t11=C_fast_retrieve(lf[35]);
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,t10);}
else{
C_trace("setup-download.scm:291: d");
f_1314(t8,lf[187],C_a_i_list(&a,3,t2,t3,lf[190]));}}

/* k1997 in map-loop510 in k1965 in k1945 in k1943 in k1941 in k1939 */
static void C_ccall f_1998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1998,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_1973(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_1973(t6,((C_word*)t0)[5],t5);}}

/* f_3026 in k3011 in k3007 in setup-download#retrieve-extension in k2950 in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 in ... */
static void C_ccall f_3026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3026,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_eqp(t2,lf[207]);
if(C_truep(t3)){
C_trace("setup-download.scm:440: locate-egg/local");
((C_proc7)C_fast_retrieve_symbol_proc(lf[19]))(7,*((C_word*)lf[19]+1),t1,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[7]);}
else{
t4=C_eqp(t2,lf[208]);
if(C_truep(t4)){
C_trace("setup-download.scm:442: locate-egg/svn");
((C_proc8)C_fast_retrieve_symbol_proc(lf[66]))(8,*((C_word*)lf[66]+1),t1,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[8],((C_word*)t0)[9]);}
else{
t5=C_eqp(t2,lf[209]);
if(C_truep(t5)){
C_trace("setup-download.scm:444: locate-egg/http");
((C_proc10)C_fast_retrieve_symbol_proc(lf[98]))(10,*((C_word*)lf[98]+1),t1,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[10],((C_word*)t0)[11],((C_word*)t0)[12],((C_word*)t0)[13]);}
else{
C_trace("setup-download.scm:446: error");
t6=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,lf[210],((C_word*)t0)[2]);}}}}

/* k3007 in setup-download#retrieve-extension in k2950 in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_3008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3008,2,t0,t1);}
t2=C_i_get_keyword(lf[206],((C_word*)t0)[2],C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_3012,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t2,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],tmp=(C_word)a,a+=18,tmp);
C_trace("setup-download.scm:434: check-egg-name");
f_2972(t3,((C_word*)t0)[6]);}

/* k2799 in k2797 in k2795 in k2793 in k2780 in k2744 in k2739 in k2737 in get-files in k2655 */
static void C_ccall f_2801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2801,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
C_trace("setup-download.scm:375: get-files");
t3=((C_word*)((C_word*)t0)[4])[1];
f_2734(t3,((C_word*)t0)[5],t2);}

/* f_1957 in k1945 in k1943 in k1941 in k1939 */
static void C_ccall f_1957(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1957,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1963,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:175: string-chomp");
t4=C_fast_retrieve(lf[171]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[237]);}

/* k1943 in k1941 in k1939 */
static void C_ccall f_1944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1944,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1946,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:171: with-input-from-pipe");
t3=C_fast_retrieve(lf[84]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,C_fast_retrieve(lf[85]));}

/* k1941 in k1939 */
static void C_ccall f_1942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1942,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1944,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2004,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2007,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:170: string-append");
t5=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[5],lf[238]);}

/* k1945 in k1943 in k1941 in k1939 */
static void C_ccall f_1946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1946,2,t0,t1);}
if(C_truep(C_i_nullp(t1))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[235]);}
else{
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1957,a[2]=((C_word)li70),tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1966,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t3,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:176: with-input-from-pipe");
t8=C_fast_retrieve(lf[84]);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,((C_word*)t0)[3],C_fast_retrieve(lf[85]));}}

/* k1939 */
static void C_ccall f_1940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1940,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1942,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[5])){
C_trace("setup-download.scm:169: string-append");
t3=*((C_word*)lf[67]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[239],((C_word*)t0)[5],lf[240]);}
else{
t3=t2;
f_1942(2,t3,lf[241]);}}

/* map-loop510 in k1965 in k1945 in k1943 in k1941 in k1939 */
static void C_fcall f_1973(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1973,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1998,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
C_trace("setup-download.scm:175: g516");
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1969 in k1965 in k1945 in k1943 in k1941 in k1939 */
static void C_ccall f_1971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:174: string-concatenate");
t2=C_fast_retrieve(lf[215]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1962 */
static void C_ccall f_1963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#string-append");
((C_proc4)C_fast_retrieve_symbol_proc(lf[216]))(4,*((C_word*)lf[216]+1),((C_word*)t0)[2],t1,lf[236]);}

/* k1965 in k1945 in k1943 in k1941 in k1939 */
static void C_ccall f_1966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1966,2,t0,t1);}
t2=C_i_check_list_2(t1,lf[219]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1971,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1973,a[2]=((C_word*)t0)[3],a[3]=t5,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word)li71),tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_1973(t7,t3,t1);}

/* setup-download#retrieve-extension in k2950 in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_2984(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+20)){
C_save_and_reclaim((void*)tr5r,(void*)f_2984r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_2984r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_2984r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a=C_alloc(20);
t6=C_i_get_keyword(lf[199],t5,C_SCHEME_FALSE);
t7=C_i_get_keyword(lf[200],t5,C_SCHEME_FALSE);
t8=C_i_get_keyword(lf[201],t5,C_SCHEME_FALSE);
t9=C_i_get_keyword(lf[202],t5,C_SCHEME_FALSE);
t10=C_i_get_keyword(lf[203],t5,C_SCHEME_FALSE);
t11=C_i_get_keyword(lf[204],t5,C_SCHEME_FALSE);
t12=C_i_get_keyword(lf[138],t5,C_SCHEME_FALSE);
t13=C_i_get_keyword(lf[178],t5,C_SCHEME_FALSE);
t14=C_i_get_keyword(lf[139],t5,C_SCHEME_FALSE);
t15=C_i_get_keyword(lf[205],t5,C_SCHEME_FALSE);
t16=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_3008,a[2]=t5,a[3]=t7,a[4]=t15,a[5]=t3,a[6]=t2,a[7]=t4,a[8]=t6,a[9]=t8,a[10]=t9,a[11]=t10,a[12]=t11,a[13]=t12,a[14]=t13,a[15]=t14,a[16]=t1,tmp=(C_word)a,a+=17,tmp);
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3074,a[2]=((C_word)li53),tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:430: ##sys#get-keyword");
((C_proc5)C_fast_retrieve_proc(*((C_word*)lf[158]+1)))(5,*((C_word*)lf[158]+1),t16,lf[212],t5,t17);}

/* f_1381 */
static void C_ccall f_1381(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1381,3,t0,t1,t2);}
t3=*((C_word*)lf[67]+1);
C_trace("setup-download.scm:85: g236");
t4=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,lf[214]);}

/* k1386 */
static void C_ccall f_1387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1387,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1390,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1392,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word)li57),tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_1392(t6,t2,t1);}

/* setup-download#check-egg-name in k2950 in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_fcall f_2972(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2972,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2979,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=t2;
if(C_truep((C_truep(C_i_equalp(t4,lf[194]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t4,lf[195]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t4,lf[196]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))){
C_trace("setup-download.scm:428: error");
t5=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,lf[193],t2);}
else{
C_trace("setup-download.scm:424: string-index");
t5=C_fast_retrieve(lf[197]);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_retrieve2(lf[191],"setup-download#slashes"));}}

/* k2977 in setup-download#check-egg-name in k2950 in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_2979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
C_trace("setup-download.scm:428: error");
t2=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[193],((C_word*)t0)[3]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k2950 in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_2952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2952,2,t0,t1);}
t2=C_mutate(&lf[191] /* (set! setup-download#slashes ...) */,t1);
t3=C_mutate(&lf[192] /* (set! setup-download#check-egg-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2972,a[2]=((C_word)li49),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[198]+1 /* (set! setup-download#retrieve-extension ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2984,a[2]=((C_word)li54),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[213]+1 /* (set! setup-download#list-extensions ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3077,a[2]=((C_word)li66),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[230]+1 /* (set! setup-download#list-extension-versions ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3145,a[2]=((C_word)li74),tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_UNDEFINED);}

/* k1498 in k1496 in setup-download#locate-egg/local in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_1499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1499,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1501,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=C_retrieve2(lf[2],"setup-download#\052trunk\052");
if(C_truep(C_retrieve2(lf[2],"setup-download#\052trunk\052"))){
t4=t2;
f_1501(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1664,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:98: file-exists?");
t5=C_fast_retrieve(lf[24]);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t1);}}

/* k1496 in setup-download#locate-egg/local in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_1497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1497,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1499,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
C_trace("setup-download.scm:96: make-pathname");
t3=C_fast_retrieve(lf[20]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,lf[48]);}

/* setup-download#existing-version in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_fcall f_1342(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1342,NULL,4,t1,t2,t3,t4);}
if(C_truep(t3)){
if(C_truep(C_i_member(t3,t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
C_trace("setup-download.scm:76: error");
t5=*((C_word*)lf[15]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,lf[16],t2,t3);}}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1357,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:77: sort");
t6=C_fast_retrieve(lf[17]);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t4,C_fast_retrieve(lf[18]));}}

/* k1339 in k1337 in k1332 in setup-download#get-temporary-directory in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_1340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2947 in k2910 in get-chunks in k2565 in k2556 in k2554 in k2552 in k2550 in k2548 in k2546 in k2544 in k2542 in k2540 */
static void C_ccall f_2948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2948,2,t0,t1);}
t2=C_a_i_string_to_number(&a,2,t1,C_fix(16));
if(C_truep(t2)){
if(C_truep(C_i_zerop(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2930,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:412: d");
f_1314(t3,lf[168],C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2935,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("read-string/port");
t4=C_fast_retrieve(lf[125]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,((C_word*)t0)[5]);}}
else{
C_trace("setup-download.scm:410: error");
t3=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],lf[170]);}}

/* setup-download#locate-egg/svn in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_2039(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr4r,(void*)f_2039r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2039r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2039r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word *a=C_alloc(8);
t5=C_i_nullp(t4);
t6=(C_truep(t5)?C_SCHEME_FALSE:C_i_car(t4));
t7=C_i_nullp(t4);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:C_i_cdr(t4));
t9=C_i_nullp(t8);
t10=(C_truep(t9)?C_SCHEME_FALSE:C_i_car(t8));
t11=C_i_nullp(t8);
t12=(C_truep(t11)?C_SCHEME_END_OF_LIST:C_i_cdr(t8));
t13=C_i_nullp(t12);
t14=(C_truep(t13)?C_SCHEME_FALSE:C_i_car(t12));
t15=C_i_nullp(t12);
t16=(C_truep(t15)?C_SCHEME_END_OF_LIST:C_i_cdr(t12));
t17=C_i_nullp(t16);
t18=(C_truep(t17)?C_SCHEME_FALSE:C_i_car(t16));
t19=C_i_nullp(t16);
t20=(C_truep(t19)?C_SCHEME_END_OF_LIST:C_i_cdr(t16));
t21=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2059,a[2]=t2,a[3]=t6,a[4]=t3,a[5]=t10,a[6]=t1,a[7]=t18,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t14)){
C_trace("setup-download.scm:179: string-append");
t22=*((C_word*)lf[67]+1);
((C_proc5)(void*)(*((C_word*)t22+1)))(5,t22,t21,lf[90],t14,lf[91]);}
else{
t22=t21;
f_2059(2,t22,lf[92]);}}

/* setup-download#locate-egg/local in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_1481(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr4r,(void*)f_1481r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1481r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1481r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a=C_alloc(7);
t5=C_i_nullp(t4);
t6=(C_truep(t5)?C_SCHEME_FALSE:C_i_car(t4));
t7=C_i_nullp(t4);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:C_i_cdr(t4));
t9=C_i_nullp(t8);
t10=(C_truep(t9)?C_SCHEME_FALSE:C_i_car(t8));
t11=C_i_nullp(t8);
t12=(C_truep(t11)?C_SCHEME_END_OF_LIST:C_i_cdr(t8));
t13=C_i_nullp(t12);
t14=(C_truep(t13)?C_SCHEME_FALSE:C_i_car(t12));
t15=C_i_nullp(t12);
t16=(C_truep(t15)?C_SCHEME_END_OF_LIST:C_i_cdr(t12));
t17=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1497,a[2]=t2,a[3]=t6,a[4]=t14,a[5]=t1,a[6]=t10,tmp=(C_word)a,a+=7,tmp);
C_trace("setup-download.scm:95: make-pathname");
t18=C_fast_retrieve(lf[20]);
((C_proc4)(void*)(*((C_word*)t18+1)))(4,t18,t17,t3,t2);}

/* k2934 in k2947 in k2910 in get-chunks in k2565 in k2556 in k2554 in k2552 in k2550 in k2548 in k2546 in k2544 in k2542 in k2540 */
static void C_ccall f_2935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2935,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2937,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("setup-download.scm:416: d");
f_1314(t2,lf[169],C_SCHEME_END_OF_LIST);}

/* k2929 in k2947 in k2910 in get-chunks in k2565 in k2556 in k2554 in k2552 in k2550 in k2548 in k2546 in k2544 in k2542 in k2540 */
static void C_ccall f_2930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:413: string-concatenate-reverse");
t2=C_fast_retrieve(lf[167]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k2936 in k2934 in k2947 in k2910 in get-chunks in k2565 in k2556 in k2554 in k2552 in k2550 in k2548 in k2546 in k2544 in k2542 in k2540 */
static void C_ccall f_2937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2937,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2939,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:417: read-line");
t3=C_fast_retrieve(lf[111]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}

/* k2938 in k2936 in k2934 in k2947 in k2910 in get-chunks in k2565 in k2556 in k2554 in k2552 in k2550 in k2548 in k2546 in k2544 in k2542 in k2540 */
static void C_ccall f_2939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2939,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
C_trace("setup-download.scm:418: get-chunks");
t3=((C_word*)((C_word*)t0)[4])[1];
f_2907(t3,((C_word*)t0)[5],t2);}

/* k2003 in k1941 in k1939 */
static void C_ccall f_2004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:170: make-svn-ls-cmd");
f_1805(((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],t1,C_SCHEME_END_OF_LIST);}

/* k2910 in get-chunks in k2565 in k2556 in k2554 in k2552 in k2550 in k2548 in k2546 in k2544 in k2542 in k2540 */
static void C_ccall f_2911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2911,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2948,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:408: string-chomp");
t3=C_fast_retrieve(lf[171]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,lf[172]);}

/* map-loop213 in k1386 */
static void C_fcall f_1392(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1392,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1417,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
C_trace("setup-download.scm:85: g219");
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1388 in k1386 */
static void C_ccall f_1390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:85: string-concatenate");
t2=C_fast_retrieve(lf[215]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2006 in k1941 in k1939 */
static void C_ccall f_2007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:170: make-pathname");
t2=C_fast_retrieve(lf[20]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_1304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1304,2,t0,t1);}
t2=lf[0] /* setup-download#*quiet* */ =C_SCHEME_FALSE;;
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1309,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3199,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:54: chicken-version");
t5=C_fast_retrieve(lf[249]);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_1302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1302,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1304,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:51: tcp-write-timeout");
t3=C_fast_retrieve(lf[250]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_fix(30000));}

/* k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_1300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1300,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1302,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:50: tcp-read-timeout");
t3=C_fast_retrieve(lf[251]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_fix(30000));}

/* get-chunks in k2565 in k2556 in k2554 in k2552 in k2550 in k2548 in k2546 in k2544 in k2542 in k2540 */
static void C_fcall f_2907(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2907,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2911,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:405: read-line");
t4=C_fast_retrieve(lf[111]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}

/* k1442 in k1430 in k1425 */
static void C_ccall f_1443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1443,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1446,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1448,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word)li69),tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_1448(t6,t2,t1);}

/* k1444 in k1442 in k1430 in k1425 */
static void C_ccall f_1446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:90: string-concatenate");
t2=C_fast_retrieve(lf[215]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_1309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1309,2,t0,t1);}
t2=C_mutate(&lf[1] /* (set! setup-download#*chicken-install-user-agent* ...) */,t1);
t3=lf[2] /* setup-download#*trunk* */ =C_SCHEME_FALSE;;
t4=C_mutate(&lf[3] /* (set! setup-download#*mode* ...) */,lf[4]);
t5=C_mutate(&lf[5] /* (set! setup-download#*windows-shell* ...) */,C_mk_bool(C_WINDOWS_SHELL));
t6=C_mutate(&lf[6] /* (set! setup-download#d ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1314,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1327,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:64: make-parameter");
t8=C_fast_retrieve(lf[247]);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,C_SCHEME_FALSE);}

/* map-loop254 in k1442 in k1430 in k1425 */
static void C_fcall f_1448(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1448,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1473,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
C_trace("setup-download.scm:91: g260");
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2313 in k2311 */
static void C_ccall f_2314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2314,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2316,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2331,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:242: file-exists?");
t4=C_fast_retrieve(lf[24]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t1);}

/* k2311 */
static void C_ccall f_2312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2312,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2314,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
C_trace("setup-download.scm:241: make-pathname");
t3=C_fast_retrieve(lf[20]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[9],((C_word*)t0)[10]);}

/* k2317 in k2315 in k2313 in k2311 */
static void C_ccall f_2318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=t1;
C_trace("setup-download.scm:246: values");
C_values(4,0,((C_word*)t0)[2],((C_word*)t0)[3],t2);}
else{
if(C_truep(((C_word*)t0)[4])){
C_trace("setup-download.scm:246: values");
C_values(4,0,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4]);}
else{
C_trace("setup-download.scm:246: values");
C_values(4,0,((C_word*)t0)[2],((C_word*)t0)[3],lf[99]);}}}

/* k2315 in k2313 in k2311 */
static void C_ccall f_2316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2316,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2318,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[5];
t4=((C_word*)t0)[6];
t5=((C_word*)t0)[7];
t6=((C_word*)t0)[3];
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2838,a[2]=t3,a[3]=t4,a[4]=t5,a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word)li28),tmp=(C_word)a,a+=9,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2843,a[2]=t6,a[3]=((C_word)li33),tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:377: ##sys#call-with-values");
C_call_with_values(4,0,t2,t7,t8);}

/* k1478 */
static void C_ccall f_1479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:88: make-pathname");
t2=C_fast_retrieve(lf[20]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* k1472 in map-loop254 in k1442 in k1430 in k1425 */
static void C_ccall f_1473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1473,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_1448(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_1448(t6,((C_word*)t0)[5],t5);}}

/* f_2304 in k2297 in setup-download#locate-egg/http in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_2304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2304,2,t0,t1);}
C_trace("setup-download.scm:234: deconstruct-url");
f_2230(t1,((C_word*)t0)[2]);}

/* f_2309 in k2297 in setup-download#locate-egg/http in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_2309(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2309,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2312,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2337,a[2]=((C_word*)t0)[8],a[3]=t5,a[4]=t4,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
C_trace("setup-download.scm:238: string-append");
t7=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,lf[135],((C_word*)t0)[2]);}
else{
t7=t6;
f_2337(2,t7,lf[136]);}}

/* setup-download#locate-egg/http in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_2270(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_2270r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2270r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2270r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word *a=C_alloc(10);
t5=C_i_nullp(t4);
t6=(C_truep(t5)?C_SCHEME_FALSE:C_i_car(t4));
t7=C_i_nullp(t4);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:C_i_cdr(t4));
t9=C_i_nullp(t8);
t10=(C_truep(t9)?C_SCHEME_FALSE:C_i_car(t8));
t11=C_i_nullp(t8);
t12=(C_truep(t11)?C_SCHEME_END_OF_LIST:C_i_cdr(t8));
t13=C_i_nullp(t12);
t14=(C_truep(t13)?C_SCHEME_FALSE:C_i_car(t12));
t15=C_i_nullp(t12);
t16=(C_truep(t15)?C_SCHEME_END_OF_LIST:C_i_cdr(t12));
t17=C_i_nullp(t16);
t18=(C_truep(t17)?C_SCHEME_FALSE:C_i_car(t16));
t19=C_i_nullp(t16);
t20=(C_truep(t19)?C_SCHEME_END_OF_LIST:C_i_cdr(t16));
t21=C_i_nullp(t20);
t22=(C_truep(t21)?C_SCHEME_FALSE:C_i_car(t20));
t23=C_i_nullp(t20);
t24=(C_truep(t23)?C_SCHEME_END_OF_LIST:C_i_cdr(t20));
t25=C_i_nullp(t24);
t26=(C_truep(t25)?C_SCHEME_FALSE:C_i_car(t24));
t27=C_i_nullp(t24);
t28=(C_truep(t27)?C_SCHEME_END_OF_LIST:C_i_cdr(t24));
t29=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2299,a[2]=t3,a[3]=t6,a[4]=t18,a[5]=t22,a[6]=t26,a[7]=t2,a[8]=t14,a[9]=t1,tmp=(C_word)a,a+=10,tmp);
if(C_truep(t10)){
t30=t29;
f_2299(2,t30,t10);}
else{
C_trace("setup-download.scm:233: get-temporary-directory");
f_1329(t29);}}

/* k1416 in map-loop213 in k1386 */
static void C_ccall f_1417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1417,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_1392(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_1392(t6,((C_word*)t0)[5],t5);}}

/* k2297 in setup-download#locate-egg/http in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_2299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2299,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2304,a[2]=((C_word*)t0)[2],a[3]=((C_word)li27),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2309,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word)li34),tmp=(C_word)a,a+=10,tmp);
C_trace("setup-download.scm:231: ##sys#call-with-values");
C_call_with_values(4,0,((C_word*)t0)[9],t2,t3);}

/* f_3096 in setup-download#list-extensions in k2950 in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_3096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3096,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,C_retrieve2(lf[0],"setup-download#\052quiet\052"));
t3=C_mutate(&lf[0] /* (set! setup-download#*quiet* ...) */,((C_word*)((C_word*)t0)[3])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* k2167 in k2060 in k2058 in setup-download#locate-egg/svn in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_2168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2168,2,t0,t1);}
C_trace("setup-download.scm:181: make-svn-ls-cmd");
f_1805(((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],t1,C_a_i_list(&a,2,lf[61],C_SCHEME_TRUE));}

/* k2339 in k2336 */
static void C_ccall f_2340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[2])){
C_trace("setup-download.scm:235: string-append");
t2=*((C_word*)lf[67]+1);
((C_proc9)(void*)(*((C_word*)t2+1)))(9,t2,((C_word*)t0)[3],((C_word*)t0)[4],lf[130],((C_word*)t0)[5],((C_word*)t0)[6],lf[131],t1,lf[132]);}
else{
C_trace("setup-download.scm:235: string-append");
t2=*((C_word*)lf[67]+1);
((C_proc9)(void*)(*((C_word*)t2+1)))(9,t2,((C_word*)t0)[3],((C_word*)t0)[4],lf[130],((C_word*)t0)[5],((C_word*)t0)[6],lf[131],t1,lf[133]);}}

/* k1278 in k1276 in k1274 */
static void C_ccall f_1279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1279,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1281,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_irregex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1276 in k1274 */
static void C_ccall f_1277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1277,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1279,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1274 */
static void C_ccall f_1275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1275,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1277,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* setup-download#deconstruct-url in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_fcall f_2230(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2230,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2234,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:221: irregex-match");
t4=C_fast_retrieve(lf[96]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[97],t2);}

/* setup-download#d in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_fcall f_1314(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1314,NULL,3,t1,t2,t3);}
t4=(C_truep(C_retrieve2(lf[0],"setup-download#\052quiet\052"))?*((C_word*)lf[7]+1):*((C_word*)lf[8]+1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1320,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
C_apply(6,0,t5,*((C_word*)lf[10]+1),t4,t2,t3);}

/* f3375 in k2594 in k2584 in k2579 in loop in k2554 in k2552 in k2550 in k2548 in k2546 in k2544 in k2542 in k2540 */
static void C_ccall f3375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:324: loop");
t2=((C_word*)((C_word*)t0)[2])[1];
f_2576(t2,((C_word*)t0)[3]);}

/* k2233 in setup-download#deconstruct-url in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_2234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2234,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2240,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
C_trace("setup-download.scm:223: irregex-match-substring");
t3=C_fast_retrieve(lf[81]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,C_fix(2));}
else{
t3=t2;
f_2240(2,t3,((C_word*)t0)[3]);}}

/* f_3074 in setup-download#retrieve-extension in k2950 in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_3074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3074,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[4]);}

/* setup-download#list-extensions in k2950 in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_3077(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+24)){
C_save_and_reclaim((void*)tr4r,(void*)f_3077r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3077r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3077r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a=C_alloc(24);
t5=C_i_get_keyword(lf[200],t4,C_SCHEME_FALSE);
t6=C_i_get_keyword(lf[202],t4,C_SCHEME_FALSE);
t7=C_i_get_keyword(lf[203],t4,C_SCHEME_FALSE);
t8=C_i_get_keyword(lf[138],t4,C_SCHEME_FALSE);
t9=C_i_get_keyword(lf[178],t4,C_SCHEME_FALSE);
t10=C_i_get_keyword(lf[139],t4,C_SCHEME_FALSE);
t11=t5;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_SCHEME_FALSE;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3096,a[2]=t14,a[3]=t12,a[4]=((C_word)li55),tmp=(C_word)a,a+=5,tmp);
t16=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3101,a[2]=t2,a[3]=t3,a[4]=t6,a[5]=t7,a[6]=t8,a[7]=t9,a[8]=t10,a[9]=((C_word)li64),tmp=(C_word)a,a+=10,tmp);
t17=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3140,a[2]=t12,a[3]=t14,a[4]=((C_word)li65),tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:448: ##sys#dynamic-wind");
t18=*((C_word*)lf[211]+1);
((C_proc5)(void*)(*((C_word*)t18+1)))(5,t18,t1,t15,t16,t17);}

/* f3379 in k2594 in k2584 in k2579 in loop in k2554 in k2552 in k2550 in k2548 in k2546 in k2544 in k2542 in k2540 */
static void C_ccall f3379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:324: loop");
t2=((C_word*)((C_word*)t0)[2])[1];
f_2576(t2,((C_word*)t0)[3]);}

/* k2329 in k2313 in k2311 */
static void C_ccall f_2331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_2316(2,t2,C_SCHEME_UNDEFINED);}
else{
C_trace("setup-download.scm:242: create-directory");
t2=C_fast_retrieve(lf[40]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* k2336 */
static void C_ccall f_2337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2337,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2340,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
C_trace("setup-download.scm:239: ->string");
t3=C_fast_retrieve(lf[134]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_retrieve2(lf[3],"setup-download#\052mode\052"));}

/* k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_1291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1291,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1293,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_2d13_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_1297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1297,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1300,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:49: tcp-connect-timeout");
t3=C_fast_retrieve(lf[252]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_fix(30000));}

/* k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_1293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1293,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1295,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_1295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1295,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1297,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:27: ##sys#require");
((C_proc3)C_fast_retrieve_symbol_proc(lf[253]))(3,*((C_word*)lf[253]+1),t2,lf[254]);}

/* f_2480 in setup-download#make-HTTP-GET/1.1 in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_2480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2480,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(80));}

/* k2131 in k2123 in k2101 */
static void C_ccall f_2132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
C_trace("setup-download.scm:218: conc");
t4=C_fast_retrieve(lf[64]);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,((C_word*)t0)[4],t2,C_make_character(47),t3,lf[80]);}

/* k2137 in k2101 */
static void C_ccall f_2138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:202: conc");
t2=C_fast_retrieve(lf[64]);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[2],((C_word*)t0)[3],C_make_character(47),((C_word*)t0)[4],C_make_character(47),t1);}

/* f_1795 */
static void C_ccall f_1795(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1795r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1795r(t0,t1,t2);}}

static void C_ccall f_1795r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1800,a[2]=t2,a[3]=((C_word)li13),tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:142: k410");
t4=((C_word*)t0)[2];
((C_proc3)C_fast_retrieve_proc(t4))(3,t4,t1,t3);}

/* k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_1281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1281,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1283,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_posix_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* f_1790 */
static void C_ccall f_1790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1790,2,t0,t1);}
C_trace("setup-download.scm:148: with-input-from-file");
t2=C_fast_retrieve(lf[52]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,((C_word*)t0)[2],*((C_word*)lf[53]+1));}

/* k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_1287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1287,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1289,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_2dstructures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_1289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1289,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1291,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_tcp_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_1283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1283,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1285,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_1285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1285,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1287,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_2d1_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2120 in k2105 in k2103 in k2101 */
static void C_ccall f_2121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_eqp(t1,C_fix(0));
if(C_truep(t2)){
C_trace("setup-download.scm:214: values");
C_values(4,0,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4]);}
else{
C_trace("setup-download.scm:215: values");
C_values(4,0,((C_word*)t0)[2],C_SCHEME_FALSE,lf[74]);}}

/* k2126 in k2123 in k2101 */
static void C_ccall f_2127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[4];
t5=(C_truep(C_retrieve2(lf[0],"setup-download#\052quiet\052"))?lf[76]:lf[77]);
C_trace("setup-download.scm:155: conc");
t6=C_fast_retrieve(lf[64]);
((C_proc15)(void*)(*((C_word*)t6+1)))(15,t6,((C_word*)t0)[5],lf[78],t2,C_make_character(32),t3,C_make_character(32),C_make_character(34),t4,C_make_character(34),C_make_character(32),C_make_character(34),t1,C_make_character(34),t5);}

/* k2123 in k2101 */
static void C_ccall f_2124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2124,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2127,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=C_eqp(C_retrieve2(lf[3],"setup-download#\052mode\052"),lf[79]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2132,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:209: create-directory");
t5=C_fast_retrieve(lf[40]);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[5]);}
else{
t4=t2;
f_2127(2,t4,((C_word*)t0)[5]);}}

/* f_1747 in k1740 in k1735 */
static void C_ccall f_1747(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1747,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1753,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
C_trace("setup-download.scm:140: string->symbol");
t4=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}

/* k1740 in k1735 */
static void C_ccall f_1742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1742,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1747,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word)li17),tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:138: call/cc");
t3=*((C_word*)lf[57]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[5],t2);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k1735 */
static void C_ccall f_1736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1736,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1742,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:137: file-exists?");
t3=C_fast_retrieve(lf[24]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* f_1733 */
static void C_ccall f_1733(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1733,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1736,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:136: make-pathname");
t5=C_fast_retrieve(lf[20]);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,t2,((C_word*)t0)[2],lf[58]);}

/* k1892 in map-loop459 in k1860 in k1846 in k1844 in k1842 in k1840 */
static void C_ccall f_1893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1893,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_1868(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_1868(t6,((C_word*)t0)[5],t5);}}

/* f_1767 in k1752 */
static void C_ccall f_1767(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1767,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1772,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word)li11),tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1785,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word)li15),tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:142: with-exception-handler");
t5=C_fast_retrieve(lf[54]);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* k1763 in k1761 in k1752 */
static void C_ccall f_1765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1765,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,((C_word*)t0)[4],t2));}

/* k1761 in k1752 */
static void C_ccall f_1762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1762,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1765,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:142: g414");
t3=t1;
((C_proc2)C_fast_retrieve_proc(t3))(2,t3,t2);}

/* k2441 in setup-download#make-HTTP-GET/1.1 in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_2442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2442,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2444,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2477,a[2]=((C_word)li38),tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:257: ##sys#get-keyword");
((C_proc5)C_fast_retrieve_proc(*((C_word*)lf[158]+1)))(5,*((C_word*)lf[158]+1),t2,lf[163],((C_word*)t0)[2],t3);}

/* k2445 in k2443 in k2441 in setup-download#make-HTTP-GET/1.1 in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_2446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2446,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2448,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2471,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:257: ##sys#get-keyword");
((C_proc5)C_fast_retrieve_proc(*((C_word*)lf[158]+1)))(5,*((C_word*)lf[158]+1),t2,lf[159],((C_word*)t0)[2],t3);}

/* k2443 in k2441 in setup-download#make-HTTP-GET/1.1 in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_2444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2444,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2446,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2474,a[2]=((C_word)li37),tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download.scm:257: ##sys#get-keyword");
((C_proc5)C_fast_retrieve_proc(*((C_word*)lf[158]+1)))(5,*((C_word*)lf[158]+1),t2,lf[161],((C_word*)t0)[2],t3);}

/* k2766 in k2764 in k2744 in k2739 in k2737 in get-files in k2655 */
static void C_ccall f_2767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[3])[1]);}

/* k2764 in k2744 in k2739 in k2737 in get-files in k2655 */
static void C_ccall f_2765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2765,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2767,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:362: close-output-port");
t3=*((C_word*)lf[120]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k1752 */
static void C_ccall f_1753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1753,2,t0,t1);}
t2=C_a_i_list2(&a,2,lf[50],((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1762,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1767,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word)li16),tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download.scm:142: call-with-current-continuation");
t5=*((C_word*)lf[55]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* f_2474 in k2443 in k2441 in setup-download#make-HTTP-GET/1.1 in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_2474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2474,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[160]);}

/* f_2471 in k2445 in k2443 in k2441 in setup-download#make-HTTP-GET/1.1 in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 in ... */
static void C_ccall f_2471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2471,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}

/* k2447 in k2445 in k2443 in k2441 in setup-download#make-HTTP-GET/1.1 in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 in ... */
static void C_ccall f_2448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2448,2,t0,t1);}
t2=C_i_get_keyword(lf[138],((C_word*)t0)[2],C_SCHEME_FALSE);
t3=C_i_get_keyword(lf[139],((C_word*)t0)[2],C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2460,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=t3,tmp=(C_word)a,a+=10,tmp);
if(C_truep(t2)){
C_trace("setup-download.scm:267: string-append");
t5=*((C_word*)lf[67]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,lf[157],((C_word*)t0)[7],((C_word*)t0)[9]);}
else{
t5=t4;
f_2460(2,t5,((C_word*)t0)[9]);}}

/* k2462 in k2459 in k2447 in k2445 in k2443 in k2441 in setup-download#make-HTTP-GET/1.1 in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in ... */
static void C_ccall f_2463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download.scm:264: conc");
t2=C_fast_retrieve(lf[64]);
((C_proc25)(void*)(*((C_word*)t2+1)))(25,t2,((C_word*)t0)[2],lf[140],((C_word*)t0)[3],lf[141],lf[142],lf[143],((C_word*)t0)[4],lf[144],lf[145],((C_word*)t0)[5],lf[146],lf[147],((C_word*)t0)[6],lf[148],lf[149],((C_word*)t0)[7],C_make_character(58),((C_word*)t0)[8],lf[150],t1,lf[151],((C_word*)t0)[9],lf[152],lf[153]);}

/* k2459 in k2447 in k2445 in k2443 in k2441 in setup-download#make-HTTP-GET/1.1 in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in ... */
static void C_ccall f_2460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2460,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2463,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[9])){
C_trace("setup-download.scm:275: string-append");
t3=*((C_word*)lf[67]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[154],((C_word*)t0)[9],lf[155]);}
else{
t3=t2;
f_2463(2,t3,lf[156]);}}

/* f_2477 in k2441 in setup-download#make-HTTP-GET/1.1 in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in k1278 in k1276 in k1274 */
static void C_ccall f_2477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2477,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[162]);}

/* k2739 in k2737 in get-files in k2655 */
static void C_ccall f_2740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2740,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2746,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
if(C_truep(C_i_pairp(t1))){
t3=t1;
t4=C_u_i_car(t3);
t5=t2;
f_2746(t5,C_eqp(lf[15],t4));}
else{
t3=t2;
f_2746(t3,C_SCHEME_FALSE);}}

/* f_2099 in k2068 in k2066 in k2064 in k2062 in k2060 in k2058 in setup-download#locate-egg/svn in k1325 in k1307 in k1303 in k1301 in k1299 in k1296 in k1294 in k1292 in k1290 in k1288 in k1286 in k1284 in k1282 in k1280 in ... */
static void C_ccall f_2099(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2099,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2102,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2148,a[2]=t4,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[6])){
C_trace("setup-download.scm:199: make-pathname");
t6=C_fast_retrieve(lf[20]);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)t0)[6],((C_word*)t0)[4]);}
else{
C_trace("setup-download.scm:199: get-temporary-directory");
f_1329(t5);}}

/* k2744 in k2739 in k2737 in get-files in k2655 */
static void C_fcall f_2746(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2746,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_cadr(((C_word*)t0)[2]);
t3=((C_word*)t0)[2];
t4=C_u_i_cdr(t3);
t5=C_u_i_cdr(t4);
t6=((C_word*)t0)[3];
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2890,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2893,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2899,a[2]=t8,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download.scm:399: string-append");
t10=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,lf[119],t2);}
else{
t2=C_eofp(((C_word*)t0)[2]);
t3=(C_truep(t2)?t2:C_i_not(((C_word*)t0)[2]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2765,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-download.scm:361: close-input-port");
t5=*((C_word*)lf[121]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[6]);}
else{
if(C_truep(C_i_stringp(((C_word*)t0)[2]))){
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2782,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
C_trace("setup-download.scm:366: string-suffix?");
t5=C_fast_retrieve(lf[44]);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,lf[127],((C_word*)t0)[2]);}
else{
C_trace("setup-download.scm:365: error");
t4=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[3],lf[128],((C_word*)t0)[2]);}}}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[287] = {
{"f_2495:setup_2ddownload_2escm",(void*)f_2495},
{"f_2734:setup_2ddownload_2escm",(void*)f_2734},
{"f_1574:setup_2ddownload_2escm",(void*)f_1574},
{"f_1572:setup_2ddownload_2escm",(void*)f_1572},
{"f_1578:setup_2ddownload_2escm",(void*)f_1578},
{"f_1576:setup_2ddownload_2escm",(void*)f_1576},
{"f_1858:setup_2ddownload_2escm",(void*)f_1858},
{"f_1570:setup_2ddownload_2escm",(void*)f_1570},
{"f_1852:setup_2ddownload_2escm",(void*)f_1852},
{"f_2738:setup_2ddownload_2escm",(void*)f_2738},
{"f_1723:setup_2ddownload_2escm",(void*)f_1723},
{"f_1728:setup_2ddownload_2escm",(void*)f_1728},
{"f_2679:setup_2ddownload_2escm",(void*)f_2679},
{"f_1333:setup_2ddownload_2escm",(void*)f_1333},
{"f_1338:setup_2ddownload_2escm",(void*)f_1338},
{"f_1845:setup_2ddownload_2escm",(void*)f_1845},
{"f_1847:setup_2ddownload_2escm",(void*)f_1847},
{"f_1841:setup_2ddownload_2escm",(void*)f_1841},
{"f_2670:setup_2ddownload_2escm",(void*)f_2670},
{"f_1843:setup_2ddownload_2escm",(void*)f_1843},
{"f_2675:setup_2ddownload_2escm",(void*)f_2675},
{"f_1714:setup_2ddownload_2escm",(void*)f_1714},
{"f_1718:setup_2ddownload_2escm",(void*)f_1718},
{"f_3199:setup_2ddownload_2escm",(void*)f_3199},
{"f_3193:setup_2ddownload_2escm",(void*)f_3193},
{"f_2794:setup_2ddownload_2escm",(void*)f_2794},
{"f_2792:setup_2ddownload_2escm",(void*)f_2792},
{"f_1592:setup_2ddownload_2escm",(void*)f_1592},
{"f_1320:setup_2ddownload_2escm",(void*)f_1320},
{"f_1595:setup_2ddownload_2escm",(void*)f_1595},
{"f_1327:setup_2ddownload_2escm",(void*)f_1327},
{"f_1329:setup_2ddownload_2escm",(void*)f_1329},
{"f_2798:setup_2ddownload_2escm",(void*)f_2798},
{"f_2796:setup_2ddownload_2escm",(void*)f_2796},
{"f_2662:setup_2ddownload_2escm",(void*)f_2662},
{"f_1590:setup_2ddownload_2escm",(void*)f_1590},
{"f_2699:setup_2ddownload_2escm",(void*)f_2699},
{"f_2782:setup_2ddownload_2escm",(void*)f_2782},
{"f_2784:setup_2ddownload_2escm",(void*)f_2784},
{"f_1588:setup_2ddownload_2escm",(void*)f_1588},
{"f_1357:setup_2ddownload_2escm",(void*)f_1357},
{"f_1586:setup_2ddownload_2escm",(void*)f_1586},
{"f_1868:setup_2ddownload_2escm",(void*)f_1868},
{"f_2786:setup_2ddownload_2escm",(void*)f_2786},
{"f_1866:setup_2ddownload_2escm",(void*)f_1866},
{"f_1581:setup_2ddownload_2escm",(void*)f_1581},
{"f_1861:setup_2ddownload_2escm",(void*)f_1861},
{"f_2687:setup_2ddownload_2escm",(void*)f_2687},
{"f_2102:setup_2ddownload_2escm",(void*)f_2102},
{"f_2104:setup_2ddownload_2escm",(void*)f_2104},
{"f_1536:setup_2ddownload_2escm",(void*)f_1536},
{"f_2106:setup_2ddownload_2escm",(void*)f_2106},
{"f_2061:setup_2ddownload_2escm",(void*)f_2061},
{"f_2682:setup_2ddownload_2escm",(void*)f_2682},
{"f_2063:setup_2ddownload_2escm",(void*)f_2063},
{"f_2065:setup_2ddownload_2escm",(void*)f_2065},
{"f_1818:setup_2ddownload_2escm",(void*)f_1818},
{"f_2067:setup_2ddownload_2escm",(void*)f_2067},
{"f_2638:setup_2ddownload_2escm",(void*)f_2638},
{"f_2636:setup_2ddownload_2escm",(void*)f_2636},
{"f_3165:setup_2ddownload_2escm",(void*)f_3165},
{"f_1652:setup_2ddownload_2escm",(void*)f_1652},
{"f_2570:setup_2ddownload_2escm",(void*)f_2570},
{"f_3160:setup_2ddownload_2escm",(void*)f_3160},
{"f_2574:setup_2ddownload_2escm",(void*)f_2574},
{"f_2634:setup_2ddownload_2escm",(void*)f_2634},
{"f_1800:setup_2ddownload_2escm",(void*)f_1800},
{"f_2631:setup_2ddownload_2escm",(void*)f_2631},
{"f_1805:setup_2ddownload_2escm",(void*)f_1805},
{"f_2069:setup_2ddownload_2escm",(void*)f_2069},
{"f_2576:setup_2ddownload_2escm",(void*)f_2576},
{"f_3155:setup_2ddownload_2escm",(void*)f_3155},
{"f_1432:setup_2ddownload_2escm",(void*)f_1432},
{"f_1437:setup_2ddownload_2escm",(void*)f_1437},
{"f_1555:setup_2ddownload_2escm",(void*)f_1555},
{"f_1551:setup_2ddownload_2escm",(void*)f_1551},
{"f_1553:setup_2ddownload_2escm",(void*)f_1553},
{"f_2083:setup_2ddownload_2escm",(void*)f_2083},
{"f_1785:setup_2ddownload_2escm",(void*)f_1785},
{"f_2085:setup_2ddownload_2escm",(void*)f_2085},
{"f_2059:setup_2ddownload_2escm",(void*)f_2059},
{"f_1780:setup_2ddownload_2escm",(void*)f_1780},
{"f_2656:setup_2ddownload_2escm",(void*)f_2656},
{"f_2658:setup_2ddownload_2escm",(void*)f_2658},
{"f_3145:setup_2ddownload_2escm",(void*)f_3145},
{"f_1426:setup_2ddownload_2escm",(void*)f_1426},
{"f_1676:setup_2ddownload_2escm",(void*)f_1676},
{"f_1547:setup_2ddownload_2escm",(void*)f_1547},
{"f_1670:setup_2ddownload_2escm",(void*)f_1670},
{"f_2551:setup_2ddownload_2escm",(void*)f_2551},
{"f_2553:setup_2ddownload_2escm",(void*)f_2553},
{"f_1541:setup_2ddownload_2escm",(void*)f_1541},
{"f_3140:setup_2ddownload_2escm",(void*)f_3140},
{"f_1772:setup_2ddownload_2escm",(void*)f_1772},
{"f_1777:setup_2ddownload_2escm",(void*)f_1777},
{"f_2074:setup_2ddownload_2escm",(void*)f_2074},
{"f_2555:setup_2ddownload_2escm",(void*)f_2555},
{"f_2558:setup_2ddownload_2escm",(void*)f_2558},
{"f_2647:setup_2ddownload_2escm",(void*)f_2647},
{"f_1549:setup_2ddownload_2escm",(void*)f_1549},
{"f_2580:setup_2ddownload_2escm",(void*)f_2580},
{"f_2644:setup_2ddownload_2escm",(void*)f_2644},
{"f_2642:setup_2ddownload_2escm",(void*)f_2642},
{"f_2640:setup_2ddownload_2escm",(void*)f_2640},
{"f_2586:setup_2ddownload_2escm",(void*)f_2586},
{"f_2720:setup_2ddownload_2escm",(void*)f_2720},
{"f_2252:setup_2ddownload_2escm",(void*)f_2252},
{"f_2254:setup_2ddownload_2escm",(void*)f_2254},
{"f_2877:setup_2ddownload_2escm",(void*)f_2877},
{"f_2879:setup_2ddownload_2escm",(void*)f_2879},
{"f_2538:setup_2ddownload_2escm",(void*)f_2538},
{"f_1645:setup_2ddownload_2escm",(void*)f_1645},
{"f_2890:setup_2ddownload_2escm",(void*)f_2890},
{"f_2240:setup_2ddownload_2escm",(void*)f_2240},
{"f_2893:setup_2ddownload_2escm",(void*)f_2893},
{"f_2243:setup_2ddownload_2escm",(void*)f_2243},
{"f_2246:setup_2ddownload_2escm",(void*)f_2246},
{"f_1517:setup_2ddownload_2escm",(void*)f_1517},
{"f_1519:setup_2ddownload_2escm",(void*)f_1519},
{"f_2619:setup_2ddownload_2escm",(void*)f_2619},
{"f_2566:setup_2ddownload_2escm",(void*)f_2566},
{"f_2568:setup_2ddownload_2escm",(void*)f_2568},
{"f_2701:setup_2ddownload_2escm",(void*)f_2701},
{"f_1634:setup_2ddownload_2escm",(void*)f_1634},
{"f_2843:setup_2ddownload_2escm",(void*)f_2843},
{"f_3101:setup_2ddownload_2escm",(void*)f_3101},
{"f_1503:setup_2ddownload_2escm",(void*)f_1503},
{"f_1501:setup_2ddownload_2escm",(void*)f_1501},
{"f_1508:setup_2ddownload_2escm",(void*)f_1508},
{"f_2899:setup_2ddownload_2escm",(void*)f_2899},
{"f_2896:setup_2ddownload_2escm",(void*)f_2896},
{"f_2610:setup_2ddownload_2escm",(void*)f_2610},
{"f_1664:setup_2ddownload_2escm",(void*)f_1664},
{"f_2543:setup_2ddownload_2escm",(void*)f_2543},
{"f_2541:setup_2ddownload_2escm",(void*)f_2541},
{"f_2600:setup_2ddownload_2escm",(void*)f_2600},
{"f_2605:setup_2ddownload_2escm",(void*)f_2605},
{"f_2549:setup_2ddownload_2escm",(void*)f_2549},
{"f_2547:setup_2ddownload_2escm",(void*)f_2547},
{"f_2545:setup_2ddownload_2escm",(void*)f_2545},
{"f_2860:setup_2ddownload_2escm",(void*)f_2860},
{"f_2838:setup_2ddownload_2escm",(void*)f_2838},
{"f_1601:setup_2ddownload_2escm",(void*)f_1601},
{"f_1606:setup_2ddownload_2escm",(void*)f_1606},
{"f_1604:setup_2ddownload_2escm",(void*)f_1604},
{"f_2520:setup_2ddownload_2escm",(void*)f_2520},
{"f_2525:setup_2ddownload_2escm",(void*)f_2525},
{"f_2866:setup_2ddownload_2escm",(void*)f_2866},
{"f_2154:setup_2ddownload_2escm",(void*)f_2154},
{"f_2156:setup_2ddownload_2escm",(void*)f_2156},
{"f_2159:setup_2ddownload_2escm",(void*)f_2159},
{"f_2855:setup_2ddownload_2escm",(void*)f_2855},
{"f_2148:setup_2ddownload_2escm",(void*)f_2148},
{"f_1625:setup_2ddownload_2escm",(void*)f_1625},
{"f_2505:setup_2ddownload_2escm",(void*)f_2505},
{"f_2508:setup_2ddownload_2escm",(void*)f_2508},
{"f_2430:setup_2ddownload_2escm",(void*)f_2430},
{"f_2433:setup_2ddownload_2escm",(void*)f_2433},
{"f_2436:setup_2ddownload_2escm",(void*)f_2436},
{"f_2812:setup_2ddownload_2escm",(void*)f_2812},
{"f_2810:setup_2ddownload_2escm",(void*)f_2810},
{"f_2438:setup_2ddownload_2escm",(void*)f_2438},
{"f_2596:setup_2ddownload_2escm",(void*)f_2596},
{"f_1521:setup_2ddownload_2escm",(void*)f_1521},
{"f_1527:setup_2ddownload_2escm",(void*)f_1527},
{"toplevel:setup_2ddownload_2escm",(void*)C_toplevel},
{"f_2625:setup_2ddownload_2escm",(void*)f_2625},
{"f_2881:setup_2ddownload_2escm",(void*)f_2881},
{"f_2872:setup_2ddownload_2escm",(void*)f_2872},
{"f_2874:setup_2ddownload_2escm",(void*)f_2874},
{"f_3065:setup_2ddownload_2escm",(void*)f_3065},
{"f_1611:setup_2ddownload_2escm",(void*)f_1611},
{"f_1612:setup_2ddownload_2escm",(void*)f_1612},
{"f_1615:setup_2ddownload_2escm",(void*)f_1615},
{"f_3017:setup_2ddownload_2escm",(void*)f_3017},
{"f_3012:setup_2ddownload_2escm",(void*)f_3012},
{"f_2516:setup_2ddownload_2escm",(void*)f_2516},
{"f_1998:setup_2ddownload_2escm",(void*)f_1998},
{"f_3026:setup_2ddownload_2escm",(void*)f_3026},
{"f_3008:setup_2ddownload_2escm",(void*)f_3008},
{"f_2801:setup_2ddownload_2escm",(void*)f_2801},
{"f_1957:setup_2ddownload_2escm",(void*)f_1957},
{"f_1944:setup_2ddownload_2escm",(void*)f_1944},
{"f_1942:setup_2ddownload_2escm",(void*)f_1942},
{"f_1946:setup_2ddownload_2escm",(void*)f_1946},
{"f_1940:setup_2ddownload_2escm",(void*)f_1940},
{"f_1973:setup_2ddownload_2escm",(void*)f_1973},
{"f_1971:setup_2ddownload_2escm",(void*)f_1971},
{"f_1963:setup_2ddownload_2escm",(void*)f_1963},
{"f_1966:setup_2ddownload_2escm",(void*)f_1966},
{"f_2984:setup_2ddownload_2escm",(void*)f_2984},
{"f_1381:setup_2ddownload_2escm",(void*)f_1381},
{"f_1387:setup_2ddownload_2escm",(void*)f_1387},
{"f_2972:setup_2ddownload_2escm",(void*)f_2972},
{"f_2979:setup_2ddownload_2escm",(void*)f_2979},
{"f_2952:setup_2ddownload_2escm",(void*)f_2952},
{"f_1499:setup_2ddownload_2escm",(void*)f_1499},
{"f_1497:setup_2ddownload_2escm",(void*)f_1497},
{"f_1342:setup_2ddownload_2escm",(void*)f_1342},
{"f_1340:setup_2ddownload_2escm",(void*)f_1340},
{"f_2948:setup_2ddownload_2escm",(void*)f_2948},
{"f_2039:setup_2ddownload_2escm",(void*)f_2039},
{"f_1481:setup_2ddownload_2escm",(void*)f_1481},
{"f_2935:setup_2ddownload_2escm",(void*)f_2935},
{"f_2930:setup_2ddownload_2escm",(void*)f_2930},
{"f_2937:setup_2ddownload_2escm",(void*)f_2937},
{"f_2939:setup_2ddownload_2escm",(void*)f_2939},
{"f_2004:setup_2ddownload_2escm",(void*)f_2004},
{"f_2911:setup_2ddownload_2escm",(void*)f_2911},
{"f_1392:setup_2ddownload_2escm",(void*)f_1392},
{"f_1390:setup_2ddownload_2escm",(void*)f_1390},
{"f_2007:setup_2ddownload_2escm",(void*)f_2007},
{"f_1304:setup_2ddownload_2escm",(void*)f_1304},
{"f_1302:setup_2ddownload_2escm",(void*)f_1302},
{"f_1300:setup_2ddownload_2escm",(void*)f_1300},
{"f_2907:setup_2ddownload_2escm",(void*)f_2907},
{"f_1443:setup_2ddownload_2escm",(void*)f_1443},
{"f_1446:setup_2ddownload_2escm",(void*)f_1446},
{"f_1309:setup_2ddownload_2escm",(void*)f_1309},
{"f_1448:setup_2ddownload_2escm",(void*)f_1448},
{"f_2314:setup_2ddownload_2escm",(void*)f_2314},
{"f_2312:setup_2ddownload_2escm",(void*)f_2312},
{"f_2318:setup_2ddownload_2escm",(void*)f_2318},
{"f_2316:setup_2ddownload_2escm",(void*)f_2316},
{"f_1479:setup_2ddownload_2escm",(void*)f_1479},
{"f_1473:setup_2ddownload_2escm",(void*)f_1473},
{"f_2304:setup_2ddownload_2escm",(void*)f_2304},
{"f_2309:setup_2ddownload_2escm",(void*)f_2309},
{"f_2270:setup_2ddownload_2escm",(void*)f_2270},
{"f_1417:setup_2ddownload_2escm",(void*)f_1417},
{"f_2299:setup_2ddownload_2escm",(void*)f_2299},
{"f_3096:setup_2ddownload_2escm",(void*)f_3096},
{"f_2168:setup_2ddownload_2escm",(void*)f_2168},
{"f_2340:setup_2ddownload_2escm",(void*)f_2340},
{"f_1279:setup_2ddownload_2escm",(void*)f_1279},
{"f_1277:setup_2ddownload_2escm",(void*)f_1277},
{"f_1275:setup_2ddownload_2escm",(void*)f_1275},
{"f_2230:setup_2ddownload_2escm",(void*)f_2230},
{"f_1314:setup_2ddownload_2escm",(void*)f_1314},
{"f3375:setup_2ddownload_2escm",(void*)f3375},
{"f_2234:setup_2ddownload_2escm",(void*)f_2234},
{"f_3074:setup_2ddownload_2escm",(void*)f_3074},
{"f_3077:setup_2ddownload_2escm",(void*)f_3077},
{"f3379:setup_2ddownload_2escm",(void*)f3379},
{"f_2331:setup_2ddownload_2escm",(void*)f_2331},
{"f_2337:setup_2ddownload_2escm",(void*)f_2337},
{"f_1291:setup_2ddownload_2escm",(void*)f_1291},
{"f_1297:setup_2ddownload_2escm",(void*)f_1297},
{"f_1293:setup_2ddownload_2escm",(void*)f_1293},
{"f_1295:setup_2ddownload_2escm",(void*)f_1295},
{"f_2480:setup_2ddownload_2escm",(void*)f_2480},
{"f_2132:setup_2ddownload_2escm",(void*)f_2132},
{"f_2138:setup_2ddownload_2escm",(void*)f_2138},
{"f_1795:setup_2ddownload_2escm",(void*)f_1795},
{"f_1281:setup_2ddownload_2escm",(void*)f_1281},
{"f_1790:setup_2ddownload_2escm",(void*)f_1790},
{"f_1287:setup_2ddownload_2escm",(void*)f_1287},
{"f_1289:setup_2ddownload_2escm",(void*)f_1289},
{"f_1283:setup_2ddownload_2escm",(void*)f_1283},
{"f_1285:setup_2ddownload_2escm",(void*)f_1285},
{"f_2121:setup_2ddownload_2escm",(void*)f_2121},
{"f_2127:setup_2ddownload_2escm",(void*)f_2127},
{"f_2124:setup_2ddownload_2escm",(void*)f_2124},
{"f_1747:setup_2ddownload_2escm",(void*)f_1747},
{"f_1742:setup_2ddownload_2escm",(void*)f_1742},
{"f_1736:setup_2ddownload_2escm",(void*)f_1736},
{"f_1733:setup_2ddownload_2escm",(void*)f_1733},
{"f_1893:setup_2ddownload_2escm",(void*)f_1893},
{"f_1767:setup_2ddownload_2escm",(void*)f_1767},
{"f_1765:setup_2ddownload_2escm",(void*)f_1765},
{"f_1762:setup_2ddownload_2escm",(void*)f_1762},
{"f_2442:setup_2ddownload_2escm",(void*)f_2442},
{"f_2446:setup_2ddownload_2escm",(void*)f_2446},
{"f_2444:setup_2ddownload_2escm",(void*)f_2444},
{"f_2767:setup_2ddownload_2escm",(void*)f_2767},
{"f_2765:setup_2ddownload_2escm",(void*)f_2765},
{"f_1753:setup_2ddownload_2escm",(void*)f_1753},
{"f_2474:setup_2ddownload_2escm",(void*)f_2474},
{"f_2471:setup_2ddownload_2escm",(void*)f_2471},
{"f_2448:setup_2ddownload_2escm",(void*)f_2448},
{"f_2463:setup_2ddownload_2escm",(void*)f_2463},
{"f_2460:setup_2ddownload_2escm",(void*)f_2460},
{"f_2477:setup_2ddownload_2escm",(void*)f_2477},
{"f_2740:setup_2ddownload_2escm",(void*)f_2740},
{"f_2099:setup_2ddownload_2escm",(void*)f_2099},
{"f_2746:setup_2ddownload_2escm",(void*)f_2746},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}

/*
o|hiding nonexported module bindings: setup-download#constant180 
o|hiding nonexported module bindings: setup-download#*quiet* 
o|hiding nonexported module bindings: setup-download#*chicken-install-user-agent* 
o|hiding nonexported module bindings: setup-download#*trunk* 
o|hiding nonexported module bindings: setup-download#*mode* 
o|hiding nonexported module bindings: setup-download#*windows-shell* 
o|hiding nonexported module bindings: setup-download#d 
o|hiding nonexported module bindings: setup-download#get-temporary-directory 
o|hiding nonexported module bindings: setup-download#existing-version 
o|hiding nonexported module bindings: setup-download#when-no-such-version-warning 
o|hiding nonexported module bindings: setup-download#list-eggs/local 
o|hiding nonexported module bindings: setup-download#list-egg-versions/local 
o|hiding nonexported module bindings: setup-download#make-svn-ls-cmd 
o|hiding nonexported module bindings: setup-download#make-svn-export-cmd 
o|hiding nonexported module bindings: setup-download#list-eggs/svn 
o|hiding nonexported module bindings: setup-download#list-egg-versions/svn 
o|hiding nonexported module bindings: setup-download#metafile 
o|hiding nonexported module bindings: setup-download#deconstruct-url 
o|hiding nonexported module bindings: setup-download#network-failure 
o|hiding nonexported module bindings: setup-download#make-HTTP-GET/1.1 
o|hiding nonexported module bindings: setup-download#match-http-response 
o|hiding nonexported module bindings: setup-download#response-match-code? 
o|hiding nonexported module bindings: setup-download#match-chunked-transfer-encoding 
o|hiding nonexported module bindings: setup-download#http-connect 
o|hiding nonexported module bindings: setup-download#http-retrieve-files 
o|hiding nonexported module bindings: setup-download#http-fetch 
o|hiding nonexported module bindings: setup-download#list-eggs/http 
o|hiding nonexported module bindings: setup-download#throw-server-error 
o|hiding nonexported module bindings: setup-download#read-chunks 
o|hiding nonexported module bindings: setup-download#slashes 
o|hiding nonexported module bindings: setup-download#valid-extension-name? 
o|hiding nonexported module bindings: setup-download#check-egg-name 
S|applied compiler syntax:
S|  for-each		1
S|  sprintf		3
S|  map		4
o|eliminated procedure checks: 27 
o|specializations:
o|  8 (eqv? * (not float))
o|  1 (cddr (pair * pair))
o|  1 (string=? string string)
o|  2 (string-append string string)
o|  2 (zero? fixnum)
o|  2 (##sys#check-list (or pair list) *)
o|  2 (car pair)
o|  1 (current-output-port)
o|  1 (current-error-port)
o|Removed `not' forms: 4 
o|merged explicitly consed rest parameter: args190 
o|inlining procedure: k1334 
o|inlining procedure: k1334 
o|inlining procedure: k1345 
o|inlining procedure: k1345 
o|inlining procedure: k1369 
o|inlining procedure: k1369 
o|inlining procedure: k1510 
o|inlining procedure: k1510 
o|inlining procedure: k1543 
o|consed rest parameter at call site: "(setup-download.scm:116) setup-download#d" 2 
o|inlining procedure: k1543 
o|consed rest parameter at call site: "(setup-download.scm:126) setup-download#d" 2 
o|inlining procedure: k1628 
o|inlining procedure: k1628 
o|propagated global variable: g373374 string-suffix? 
o|contracted procedure: k1656 
o|propagated global variable: r1657 setup-download#*trunk* 
o|inlining procedure: k1659 
o|inlining procedure: k1659 
o|inlining procedure: k1737 
o|inlining procedure: k1737 
o|merged explicitly consed rest parameter: tmp425429 
o|inlining procedure: k2076 
o|inlining procedure: k2076 
o|inlining procedure: k2107 
o|inlining procedure: k2107 
o|consed rest parameter at call site: "(setup-download.scm:212) setup-download#d" 2 
o|contracted procedure: "(setup-download.scm:200) setup-download#make-svn-export-cmd" 
o|inlining procedure: "(setup-download.scm:210) setup-download#metafile" 
o|inlining procedure: k2137 
o|inlining procedure: "(setup-download.scm:205) setup-download#metafile" 
o|inlining procedure: k2137 
o|inlining procedure: k2146 
o|inlining procedure: k2146 
o|inlining procedure: k2160 
o|inlining procedure: k2160 
o|consed rest parameter at call site: "(setup-download.scm:182) setup-download#d" 2 
o|consed rest parameter at call site: "(setup-download.scm:181) setup-download#make-svn-ls-cmd" 4 
o|inlining procedure: k2245 
o|inlining procedure: k2245 
o|inlining procedure: k2257 
o|inlining procedure: k2257 
o|substituted constant variable: setup-download#constant180 
o|inlining procedure: k2323 
o|inlining procedure: k2323 
o|contracted procedure: "(setup-download.scm:244) setup-download#http-fetch" 
o|contracted procedure: "(setup-download.scm:380) setup-download#http-retrieve-files" 
o|inlining procedure: k2663 
o|inlining procedure: k2663 
o|inlining procedure: k2688 
o|inlining procedure: k2688 
o|substituted constant variable: a2710 
o|inlining procedure: k2715 
o|inlining procedure: k2715 
o|inlining procedure: k2741 
o|contracted procedure: "(setup-download.scm:359) setup-download#throw-server-error" 
o|inlining procedure: k2741 
o|inlining procedure: k2768 
o|consed rest parameter at call site: "(setup-download.scm:367) setup-download#d" 2 
o|consed rest parameter at call site: "(setup-download.scm:371) setup-download#d" 2 
o|inlining procedure: k2768 
o|consed rest parameter at call site: "(setup-download.scm:333) setup-download#d" 2 
o|inlining procedure: k2342 
o|inlining procedure: k2342 
o|merged explicitly consed rest parameter: tmp654658 
o|removed call to pure procedure with unused result: "(setup-download.scm:257) get-keyword" 
o|inlining procedure: k2498 
o|inlining procedure: k2498 
o|inlining procedure: k2534 
o|inlining procedure: k2534 
o|inlining procedure: k2559 
o|contracted procedure: "(setup-download.scm:327) setup-download#read-chunks" 
o|contracted procedure: k2917 
o|inlining procedure: k2914 
o|consed rest parameter at call site: "(setup-download.scm:412) setup-download#d" 2 
o|consed rest parameter at call site: "(setup-download.scm:416) setup-download#d" 2 
o|inlining procedure: k2914 
o|consed rest parameter at call site: "(setup-download.scm:326) setup-download#d" 2 
o|inlining procedure: k2559 
o|inlining procedure: k2581 
o|inlining procedure: k2581 
o|consed rest parameter at call site: "(setup-download.scm:323) setup-download#d" 2 
o|contracted procedure: "(setup-download.scm:322) setup-download#match-chunked-transfer-encoding" 
o|consed rest parameter at call site: "(setup-download.scm:312) setup-download#make-HTTP-GET/1.1" 4 
o|inlining procedure: k2620 
o|inlining procedure: k2620 
o|contracted procedure: "(setup-download.scm:318) setup-download#network-failure" 
o|consed rest parameter at call site: "(setup-download.scm:306) setup-download#d" 2 
o|contracted procedure: "(setup-download.scm:305) setup-download#match-http-response" 
o|inlining procedure: k2486 
o|inlining procedure: k2486 
o|consed rest parameter at call site: "(setup-download.scm:302) setup-download#d" 2 
o|consed rest parameter at call site: "(setup-download.scm:298) setup-download#make-HTTP-GET/1.1" 4 
o|consed rest parameter at call site: "(setup-download.scm:296) setup-download#d" 2 
o|consed rest parameter at call site: "(setup-download.scm:291) setup-download#d" 2 
o|inlining procedure: k2633 
o|consed rest parameter at call site: "(setup-download.scm:291) setup-download#d" 2 
o|inlining procedure: k2633 
o|consed rest parameter at call site: "(setup-download.scm:291) setup-download#d" 2 
o|inlining procedure: k2975 
o|inlining procedure: k2975 
o|contracted procedure: "(setup-download.scm:427) setup-download#valid-extension-name?" 
o|inlining procedure: k2957 
o|inlining procedure: k2957 
o|inlining procedure: k3028 
o|inlining procedure: k3028 
o|inlining procedure: k3046 
o|inlining procedure: k3046 
o|substituted constant variable: a3059 
o|substituted constant variable: a3061 
o|substituted constant variable: a3063 
o|inlining procedure: k3103 
o|contracted procedure: "(setup-download.scm:453) setup-download#list-eggs/local" 
o|inlining procedure: k1395 
o|inlining procedure: k1395 
o|inlining procedure: k3103 
o|contracted procedure: "(setup-download.scm:455) setup-download#list-eggs/svn" 
o|substituted constant variable: a1859 
o|inlining procedure: k1871 
o|inlining procedure: k1871 
o|consed rest parameter at call site: "(setup-download.scm:162) setup-download#d" 2 
o|consed rest parameter at call site: "(setup-download.scm:161) setup-download#make-svn-ls-cmd" 4 
o|inlining procedure: k3121 
o|contracted procedure: "(setup-download.scm:457) setup-download#list-eggs/http" 
o|inlining procedure: k3121 
o|substituted constant variable: a3134 
o|substituted constant variable: a3136 
o|substituted constant variable: a3138 
o|inlining procedure: k3167 
o|contracted procedure: "(setup-download.scm:466) setup-download#list-egg-versions/local" 
o|inlining procedure: k1427 
o|inlining procedure: k1451 
o|inlining procedure: k1451 
o|inlining procedure: k1427 
o|inlining procedure: k3167 
o|contracted procedure: "(setup-download.scm:468) setup-download#list-egg-versions/svn" 
o|inlining procedure: k1947 
o|inlining procedure: k1947 
o|substituted constant variable: a1964 
o|inlining procedure: k1976 
o|inlining procedure: k1976 
o|consed rest parameter at call site: "(setup-download.scm:170) setup-download#make-svn-ls-cmd" 4 
o|substituted constant variable: a3189 
o|substituted constant variable: a3191 
o|replaced variables: 289 
o|removed binding forms: 89 
o|removed side-effect free assignment to unused variable: setup-download#constant180 
o|substituted constant variable: r16603213 
o|substituted constant variable: r17383215 
o|substituted constant variable: r21613239 
o|removed side-effect free assignment to unused variable: setup-download#metafile 
o|substituted constant variable: a22443241 
o|inlining procedure: k2323 
o|inlining procedure: k2323 
o|inlining procedure: k2688 
o|inlining procedure: k2688 
o|substituted constant variable: a23413266 
o|substituted constant variable: a23413267 
o|contracted procedure: k2451 
o|substituted constant variable: f_24973269 
o|substituted constant variable: f_24853291 
o|substituted constant variable: a26323293 
o|substituted constant variable: f_29563296 
o|substituted constant variable: r14283314 
o|substituted constant variable: r19483316 
o|replaced variables: 27 
o|removed binding forms: 295 
o|inlining procedure: "(setup-download.scm:105) setup-download#when-no-such-version-warning" 
o|inlining procedure: k1605 
o|inlining procedure: "(setup-download.scm:195) setup-download#when-no-such-version-warning" 
o|inlining procedure: k2587 
o|inlining procedure: k2587 
o|inlining procedure: k2977 
o|replaced variables: 5 
o|removed binding forms: 50 
o|Removed `not' forms: 1 
o|removed side-effect free assignment to unused variable: setup-download#when-no-such-version-warning 
o|substituted constant variable: r23243326 
o|substituted constant variable: r29783383 
o|replaced variables: 5 
o|removed binding forms: 7 
o|removed conditional forms: 1 
o|removed binding forms: 6 
o|simplifications: ((if . 39) (##core#call . 190)) 
o|  call simplifications:
o|    ##sys#setslot	4
o|    zero?
o|    number->string
o|    string?	2
o|    read-string	2
o|    cadr
o|    eof-object?	2
o|    string=?	3
o|    not	2
o|    string->number	2
o|    ##sys#get-keyword	23
o|    list
o|    ##sys#apply
o|    cons	8
o|    car	17
o|    null?	35
o|    cdr	17
o|    ##sys#call-with-values	10
o|    ##sys#check-list	3
o|    ##sys#slot	10
o|    write-char	2
o|    eq?	13
o|    values	19
o|    pair?	7
o|    member	3
o|    apply
o|contracted procedure: k1317 
o|contracted procedure: k1350 
o|contracted procedure: k1361 
o|contracted procedure: k1707 
o|contracted procedure: k1484 
o|contracted procedure: k1701 
o|contracted procedure: k1486 
o|contracted procedure: k1695 
o|contracted procedure: k1488 
o|contracted procedure: k1689 
o|contracted procedure: k1490 
o|contracted procedure: k1683 
o|contracted procedure: k1492 
o|contracted procedure: k1677 
o|contracted procedure: k1494 
o|inlining procedure: k1525 
o|contracted procedure: k1559 
o|contracted procedure: k1619 
o|contracted procedure: k1630 
o|contracted procedure: k1639 
o|contracted procedure: k1642 
o|contracted procedure: k1758 
o|contracted procedure: k1755 
o|contracted procedure: k1808 
o|contracted procedure: k1814 
o|contracted procedure: k2217 
o|contracted procedure: k2042 
o|contracted procedure: k2211 
o|contracted procedure: k2044 
o|contracted procedure: k2205 
o|contracted procedure: k2046 
o|contracted procedure: k2199 
o|contracted procedure: k2048 
o|contracted procedure: k2193 
o|contracted procedure: k2050 
o|contracted procedure: k2187 
o|contracted procedure: k2052 
o|contracted procedure: k2181 
o|contracted procedure: k2054 
o|contracted procedure: k2175 
o|contracted procedure: k2056 
o|contracted procedure: k2089 
o|contracted procedure: k2110 
o|contracted procedure: k1826 
o|contracted procedure: k2128 
o|contracted procedure: k2139 
o|contracted procedure: k2255 
o|contracted procedure: k2416 
o|contracted procedure: k2273 
o|contracted procedure: k2410 
o|contracted procedure: k2275 
o|contracted procedure: k2404 
o|contracted procedure: k2277 
o|contracted procedure: k2398 
o|contracted procedure: k2279 
o|contracted procedure: k2392 
o|contracted procedure: k2281 
o|contracted procedure: k2386 
o|contracted procedure: k2283 
o|contracted procedure: k2380 
o|contracted procedure: k2285 
o|contracted procedure: k2374 
o|contracted procedure: k2287 
o|contracted procedure: k2368 
o|contracted procedure: k2289 
o|contracted procedure: k2362 
o|contracted procedure: k2291 
o|contracted procedure: k2356 
o|contracted procedure: k2293 
o|contracted procedure: k2350 
o|contracted procedure: k2295 
o|contracted procedure: k2666 
o|contracted procedure: k2683 
o|contracted procedure: k2708 
o|contracted procedure: k2751 
o|contracted procedure: k2759 
o|contracted procedure: k2761 
o|contracted procedure: k2771 
o|contracted procedure: k2806 
o|contracted procedure: k2823 
o|contracted procedure: k2449 
o|contracted procedure: k2453 
o|contracted procedure: k2530 
o|contracted procedure: k2912 
o|contracted procedure: k2926 
o|contracted procedure: k2944 
o|contracted procedure: k2488 
o|contracted procedure: k2959 
o|contracted procedure: k2987 
o|contracted procedure: k2989 
o|contracted procedure: k2991 
o|contracted procedure: k2993 
o|contracted procedure: k2995 
o|contracted procedure: k2997 
o|contracted procedure: k2999 
o|contracted procedure: k3001 
o|contracted procedure: k3003 
o|contracted procedure: k3005 
o|contracted procedure: k3009 
o|contracted procedure: k3031 
o|contracted procedure: k3040 
o|contracted procedure: k3049 
o|contracted procedure: k3080 
o|contracted procedure: k3082 
o|contracted procedure: k3084 
o|contracted procedure: k3086 
o|contracted procedure: k3088 
o|contracted procedure: k3090 
o|contracted procedure: k3106 
o|contracted procedure: k1397 
o|contracted procedure: k1400 
o|contracted procedure: k1409 
o|contracted procedure: k1419 
o|contracted procedure: k3115 
o|contracted procedure: k1921 
o|contracted procedure: k1832 
o|contracted procedure: k1915 
o|contracted procedure: k1834 
o|contracted procedure: k1909 
o|contracted procedure: k1836 
o|contracted procedure: k1903 
o|contracted procedure: k1838 
o|contracted procedure: k1862 
o|contracted procedure: k1873 
o|contracted procedure: k1876 
o|contracted procedure: k1885 
o|contracted procedure: k1895 
o|contracted procedure: k3124 
o|contracted procedure: k3148 
o|contracted procedure: k3150 
o|contracted procedure: k3152 
o|contracted procedure: k3170 
o|contracted procedure: k1453 
o|contracted procedure: k1456 
o|contracted procedure: k1465 
o|contracted procedure: k1475 
o|contracted procedure: k3179 
o|contracted procedure: k2032 
o|contracted procedure: k1931 
o|contracted procedure: k2026 
o|contracted procedure: k1933 
o|contracted procedure: k2020 
o|contracted procedure: k1935 
o|contracted procedure: k2014 
o|contracted procedure: k1937 
o|contracted procedure: k1950 
o|contracted procedure: k1967 
o|contracted procedure: k1978 
o|contracted procedure: k1981 
o|contracted procedure: k1990 
o|contracted procedure: k2000 
o|simplifications: ((if . 1) (let . 14)) 
o|removed binding forms: 150 
o|substituted constant variable: r15263465 
o|inlining procedure: k2084 
o|inlining procedure: k1402 
o|inlining procedure: k1402 
o|inlining procedure: k1878 
o|inlining procedure: k1878 
o|inlining procedure: k1458 
o|inlining procedure: k1458 
o|inlining procedure: k1983 
o|inlining procedure: k1983 
o|replaced variables: 21 
o|removed conditional forms: 1 
o|removed binding forms: 24 
o|removed binding forms: 1 
o|customizable procedures: (map-loop510528 map-loop254279 map-loop459477 map-loop213238 setup-download#check-egg-name setup-download#response-match-code? setup-download#make-HTTP-GET/1.1 loop726 get-chunks850 k2744 get-files774 skip748 k2685 k2697 setup-download#http-connect setup-download#deconstruct-url setup-download#make-svn-ls-cmd setup-download#get-temporary-directory setup-download#existing-version for-each-loop377389 setup-download#d) 
o|calls to known targets: 89 
o|fast box initializations: 9 
o|fast global references: 56 
o|fast global assignments: 25 
o|dropping unused closure argument: f_2495 
o|dropping unused closure argument: f_1329 
o|dropping unused closure argument: f_1805 
o|dropping unused closure argument: f_2438 
o|dropping unused closure argument: f_2516 
o|dropping unused closure argument: f_2972 
o|dropping unused closure argument: f_1342 
o|dropping unused closure argument: f_2230 
o|dropping unused closure argument: f_1314 
*/
/* end of file */
