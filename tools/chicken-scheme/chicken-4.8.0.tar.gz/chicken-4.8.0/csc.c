/* Generated from csc.scm by the CHICKEN compiler
   http://www.call-cc.org
   2012-09-24 17:52
   Version 4.8.0 (rev 0db1908)
   linux-unix-gnu-x86-64 [ 64bit manyargs ptables ]
   compiled 2012-09-24 on debian (Linux)
   command line: csc.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -feature chicken-bootstrap -no-warnings -specialize -types ./types.db -no-lambda-info -local -no-trace -output-file csc.c
   used units: library eval data_2dstructures ports srfi_2d1 srfi_2d13 utils files extras
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_2dstructures_toplevel)
C_externimport void C_ccall C_data_2dstructures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_2d1_toplevel)
C_externimport void C_ccall C_srfi_2d1_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_2d13_toplevel)
C_externimport void C_ccall C_srfi_2d13_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[418];
static double C_possibly_force_alignment;


C_noret_decl(f_4449)
static void C_ccall f_4449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4589)
static void C_ccall f_4589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4586)
static void C_ccall f_4586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1643)
static void C_ccall f_1643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1649)
static void C_ccall f_1649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1646)
static void C_ccall f_1646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4431)
static void C_ccall f_4431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4434)
static void C_ccall f_4434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4437)
static void C_ccall f_4437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2553)
static void C_ccall f_2553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1673)
static void C_ccall f_1673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4461)
static void C_ccall f_4461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4467)
static void C_ccall f_4467(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4464)
static void C_ccall f_4464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4465)
static void C_ccall f_4465(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2569)
static void C_ccall f_2569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1367)
static void C_ccall f_1367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1365)
static void C_ccall f_1365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1369)
static void C_ccall f_1369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1363)
static void C_ccall f_1363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1361)
static void C_ccall f_1361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2573)
static void C_ccall f_2573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4458)
static void C_fcall f_4458(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2644)
static void C_ccall f_2644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1357)
static void C_ccall f_1357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1355)
static void C_ccall f_1355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1359)
static void C_ccall f_1359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1353)
static void C_ccall f_1353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3773)
static void C_ccall f_3773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4404)
static void C_ccall f_4404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2587)
static void C_ccall f_2587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2657)
static void C_fcall f_2657(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4409)
static void C_ccall f_4409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3791)
static void C_ccall f_3791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1606)
static void C_fcall f_1606(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4216)
static void C_ccall f_4216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4210)
static void C_ccall f_4210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5424)
static void C_ccall f5424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1601)
static void C_ccall f_1601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2667)
static void C_ccall f_2667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2661)
static void C_ccall f_2661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4203)
static void C_ccall f_4203(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4429)
static void C_ccall f_4429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5437)
static void C_ccall f5437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2670)
static void C_ccall f_2670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4700)
static void C_ccall f_4700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4067)
static void C_ccall f_4067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4069)
static void C_ccall f_4069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4063)
static void C_ccall f_4063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4065)
static void C_ccall f_4065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4415)
static void C_ccall f_4415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3789)
static void C_fcall f_3789(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4095)
static void C_ccall f_4095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5411)
static void C_ccall f5411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2611)
static void C_ccall f_2611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5416)
static void C_ccall f5416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4080)
static void C_ccall f_4080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4088)
static void C_fcall f_4088(C_word t0) C_noret;
C_noret_decl(f_4083)
static void C_ccall f_4083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3045)
static void C_fcall f_3045(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3049)
static void C_ccall f_3049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1695)
static void C_ccall f_1695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4056)
static void C_fcall f_4056(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4054)
static void C_ccall f_4054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3034)
static void C_ccall f_3034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1689)
static void C_ccall f_1689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4041)
static void C_ccall f_4041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4478)
static void C_fcall f_4478(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4473)
static void C_ccall f_4473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5362)
static void C_ccall f5362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5369)
static void C_ccall f5369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4071)
static void C_ccall f_4071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4077)
static void C_ccall f_4077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4074)
static void C_ccall f_4074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2696)
static void C_ccall f_2696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3063)
static void C_ccall f_3063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3069)
static void C_ccall f_3069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4032)
static void C_ccall f_4032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4038)
static void C_ccall f_4038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4658)
static void C_ccall f_4658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3056)
static void C_ccall f_3056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4640)
static void C_ccall f_4640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3975)
static void C_ccall f_3975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4649)
static void C_ccall f_4649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1506)
static void C_ccall f_1506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1501)
static void C_ccall f_1501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3917)
static void C_ccall f_3917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3919)
static void C_ccall f_3919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4667)
static void C_ccall f_4667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3911)
static void C_ccall f_3911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4616)
static void C_ccall f_4616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3909)
static void C_ccall f_3909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4610)
static void C_ccall f_4610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3099)
static void C_ccall f_3099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1511)
static void C_ccall f_1511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3934)
static void C_ccall f_3934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3936)
static void C_ccall f_3936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3939)
static void C_ccall f_3939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3295)
static void C_ccall f_3295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3291)
static void C_ccall f_3291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3931)
static void C_ccall f_3931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3299)
static void C_ccall f_3299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1546)
static void C_ccall f_1546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1542)
static void C_ccall f_1542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3925)
static void C_ccall f_3925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3928)
static void C_ccall f_3928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4631)
static void C_ccall f_4631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3286)
static void C_ccall f_3286(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3922)
static void C_ccall f_3922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3289)
static void C_ccall f_3289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2912)
static void C_ccall f_2912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4622)
static void C_ccall f_4622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1568)
static void C_ccall f_1568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1560)
static void C_ccall f_1560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4162)
static void C_ccall f_4162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4164)
static void C_fcall f_4164(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4195)
static void C_ccall f_4195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1586)
static void C_fcall f_1586(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1589)
static void C_ccall f_1589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2900)
static void C_ccall f_2900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2909)
static void C_ccall f_2909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4189)
static void C_fcall f_4189(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4185)
static void C_ccall f_4185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1576)
static void C_ccall f_1576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2958)
static void C_ccall f_2958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2953)
static void C_ccall f_2953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4697)
static void C_ccall f_4697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4691)
static void C_ccall f_4691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4694)
static void C_ccall f_4694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3987)
static void C_ccall f_3987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2927)
static void C_ccall f_2927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4122)
static void C_ccall f_4122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3980)
static void C_fcall f_3980(C_word t0) C_noret;
C_noret_decl(f_2025)
static void C_ccall f_2025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4125)
static void C_fcall f_4125(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1592)
static void C_ccall f_1592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1593)
static void C_ccall f_1593(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1595)
static void C_ccall f_1595(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4682)
static void C_ccall f_4682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2033)
static void C_ccall f_2033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2738)
static void C_ccall f_2738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2039)
static void C_ccall f_2039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4156)
static void C_ccall f_4156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4159)
static void C_ccall f_4159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4147)
static void C_ccall f_4147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4005)
static void C_ccall f_4005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3950)
static void C_fcall f_3950(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f5462)
static void C_ccall f5462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5467)
static void C_ccall f5467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3948)
static void C_ccall f_3948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3945)
static void C_ccall f_3945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3942)
static void C_ccall f_3942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5472)
static void C_ccall f5472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2070)
static void C_ccall f_2070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5442)
static void C_ccall f5442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5447)
static void C_ccall f5447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4679)
static void C_ccall f_4679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4676)
static void C_ccall f_4676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4673)
static void C_ccall f_4673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4670)
static void C_ccall f_4670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2081)
static void C_ccall f_2081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5452)
static void C_ccall f5452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5457)
static void C_ccall f5457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1843)
static void C_ccall f_1843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1846)
static void C_ccall f_1846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1860)
static void C_ccall f_1860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2744)
static void C_ccall f_2744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1875)
static void C_ccall f_1875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1872)
static void C_ccall f_1872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2754)
static void C_fcall f_2754(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1863)
static void C_ccall f_1863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1869)
static void C_ccall f_1869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1866)
static void C_ccall f_1866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5296)
static void C_ccall f5296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2261)
static void C_ccall f_2261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2267)
static void C_ccall f_2267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2265)
static void C_ccall f_2265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2763)
static void C_fcall f_2763(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1892)
static void C_ccall f_1892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1894)
static void C_ccall f_1894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2861)
static void C_ccall f_2861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2773)
static void C_ccall f_2773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2863)
static void C_ccall f_2863(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2704)
static void C_fcall f_2704(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2702)
static void C_fcall f_2702(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2700)
static void C_ccall f_2700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2008)
static void C_ccall f_2008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2875)
static void C_fcall f_2875(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2873)
static void C_ccall f_2873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2710)
static void C_ccall f_2710(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2019)
static void C_ccall f_2019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3331)
static void C_ccall f_3331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3333)
static void C_fcall f_3333(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1901)
static void C_ccall f_1901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3358)
static void C_ccall f_3358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5332)
static void C_ccall f5332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4115)
static void C_fcall f_4115(C_word t0) C_noret;
C_noret_decl(f_1929)
static void C_fcall f_1929(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1927)
static void C_fcall f_1927(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4113)
static void C_ccall f_4113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5327)
static void C_ccall f5327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3308)
static void C_ccall f_3308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2786)
static void C_ccall f_2786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5301)
static void C_ccall f5301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4101)
static void C_fcall f_4101(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3320)
static void C_fcall f_3320(C_word t0,C_word t1) C_noret;
C_noret_decl(f5337)
static void C_ccall f5337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2799)
static void C_ccall f_2799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3311)
static void C_ccall f_3311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1730)
static void C_fcall f_1730(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3326)
static void C_ccall f_3326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1936)
static void C_ccall f_1936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4332)
static void C_ccall f_4332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1728)
static void C_ccall f_1728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4335)
static void C_ccall f_4335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4338)
static void C_ccall f_4338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1401)
static void C_ccall f_1401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1722)
static void C_fcall f_1722(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3317)
static void C_ccall f_3317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3314)
static void C_ccall f_3314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3407)
static void C_fcall f_3407(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4353)
static void C_ccall f_4353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4351)
static void C_ccall f_4351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4356)
static void C_ccall f_4356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1404)
static void C_ccall f_1404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4358)
static void C_ccall f_4358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3466)
static void C_ccall f_3466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4341)
static void C_ccall f_4341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4347)
static void C_ccall f_4347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4349)
static void C_ccall f_4349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1410)
static void C_ccall f_1410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5322)
static void C_ccall f5322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3455)
static void C_ccall f_3455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1440)
static void C_ccall f_1440(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3453)
static void C_ccall f_3453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3450)
static void C_ccall f_3450(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1418)
static void C_ccall f_1418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1414)
static void C_ccall f_1414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4363)
static void C_ccall f_4363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4360)
static void C_ccall f_4360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4365)
static void C_ccall f_4365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2407)
static void C_ccall f_2407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3436)
static void C_ccall f_3436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1447)
static void C_ccall f_1447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3376)
static void C_ccall f_3376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4302)
static void C_ccall f_4302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1451)
static void C_ccall f_1451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2427)
static void C_ccall f_2427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1467)
static void C_ccall f_1467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3397)
static void C_ccall f_3397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2437)
static void C_ccall f_2437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1455)
static void C_ccall f_1455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1459)
static void C_ccall f_1459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4326)
static void C_ccall f_4326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4324)
static void C_ccall f_4324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4322)
static void C_ccall f_4322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4320)
static void C_ccall f_4320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3481)
static void C_fcall f_3481(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3484)
static void C_ccall f_3484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1755)
static void C_fcall f_1755(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4329)
static void C_ccall f_4329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1471)
static void C_ccall f_1471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2447)
static void C_ccall f_2447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1487)
static void C_fcall f_1487(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3475)
static void C_ccall f_3475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3478)
static void C_ccall f_3478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3806)
static void C_ccall f_3806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3809)
static void C_ccall f_3809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1475)
static void C_ccall f_1475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1778)
static C_word C_fcall f_1778(C_word *a);
C_noret_decl(f_1493)
static void C_ccall f_1493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2467)
static void C_ccall f_2467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2139)
static void C_ccall f_2139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2397)
static void C_ccall f_2397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4377)
static void C_ccall f_4377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1765)
static void C_ccall f_1765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4370)
static void C_ccall f_4370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1761)
static void C_ccall f_1761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1497)
static void C_ccall f_1497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2316)
static void C_ccall f_2316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2483)
static void C_fcall f_2483(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2319)
static void C_ccall f_2319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4398)
static void C_ccall f_4398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4392)
static void C_ccall f_4392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3849)
static void C_ccall f_3849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1463)
static void C_ccall f_1463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3843)
static void C_ccall f_3843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2322)
static void C_ccall f_2322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2417)
static void C_ccall f_2417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2128)
static void C_ccall f_2128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3427)
static void C_fcall f_3427(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3837)
static void C_ccall f_3837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3834)
static void C_ccall f_3834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2174)
static void C_ccall f_2174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3416)
static void C_ccall f_3416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3824)
static void C_ccall f_3824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3815)
static void C_ccall f_3815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3812)
static void C_ccall f_3812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2457)
static void C_ccall f_2457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2160)
static void C_fcall f_2160(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2162)
static void C_ccall f_2162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5831)
static void C_ccall f5831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5839)
static void C_ccall f5839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5835)
static void C_ccall f5835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3551)
static void C_fcall f_3551(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3544)
static void C_ccall f_3544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2387)
static void C_ccall f_2387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1796)
static void C_fcall f_1796(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f5389)
static void C_ccall f5389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5384)
static void C_ccall f5384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3560)
static void C_ccall f_3560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5394)
static void C_ccall f5394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3518)
static void C_ccall f_3518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3499)
static void C_ccall f_3499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3494)
static void C_ccall f_3494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3507)
static void C_ccall f_3507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3505)
static void C_ccall f_3505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2345)
static void C_ccall f_2345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3501)
static void C_fcall f_3501(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3502)
static void C_ccall f_3502(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2974)
static void C_ccall f_2974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5374)
static void C_ccall f5374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5379)
static void C_ccall f5379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3536)
static void C_ccall f_3536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2355)
static void C_ccall f_2355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2117)
static void C_ccall f_2117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3532)
static void C_ccall f_3532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4262)
static void C_ccall f_4262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5342)
static void C_ccall f5342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4268)
static void C_ccall f_4268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5347)
static void C_ccall f5347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4266)
static void C_ccall f_4266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4264)
static void C_ccall f_4264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3527)
static void C_ccall f_3527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3524)
static void C_ccall f_3524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2368)
static void C_ccall f_2368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5352)
static void C_ccall f5352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4298)
static void C_ccall f_4298(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f5357)
static void C_ccall f5357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2963)
static void C_ccall f_2963(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4536)
static void C_ccall f_4536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4539)
static void C_ccall f_4539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4283)
static void C_fcall f_4283(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2106)
static void C_ccall f_2106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3658)
static void C_fcall f_3658(C_word t0) C_noret;
C_noret_decl(f_4560)
static void C_ccall f_4560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4232)
static void C_ccall f_4232(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2987)
static void C_ccall f_2987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4551)
static void C_ccall f_4551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4554)
static void C_ccall f_4554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4557)
static void C_ccall f_4557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4221)
static void C_ccall f_4221(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3636)
static void C_ccall f_3636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1964)
static void C_ccall f_1964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3638)
static void C_fcall f_3638(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1962)
static void C_ccall f_1962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1966)
static void C_ccall f_1966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1811)
static void C_ccall f_1811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1960)
static void C_ccall f_1960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3630)
static void C_ccall f_3630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3592)
static void C_ccall f_3592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3594)
static void C_fcall f_3594(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3665)
static void C_ccall f_3665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4243)
static void C_ccall f_4243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4245)
static void C_ccall f_4245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4247)
static void C_ccall f_4247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4249)
static void C_ccall f_4249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3580)
static void C_ccall f_3580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1817)
static void C_fcall f_1817(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1813)
static void C_ccall f_1813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1815)
static void C_ccall f_1815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3617)
static void C_ccall f_3617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3619)
static void C_ccall f_3619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4524)
static void C_ccall f_4524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3615)
static void C_fcall f_3615(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1987)
static void C_ccall f_1987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1981)
static void C_ccall f_1981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4527)
static void C_ccall f_4527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1807)
static void C_ccall f_1807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3647)
static void C_ccall f_3647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4515)
static void C_ccall f_4515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1975)
static void C_ccall f_1975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1822)
static void C_ccall f_1822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1839)
static void C_ccall f_1839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3881)
static void C_ccall f_3881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1837)
static void C_ccall f_1837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1835)
static void C_ccall f_1835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4548)
static void C_ccall f_4548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3879)
static void C_ccall f_3879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3873)
static void C_ccall f_3873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1827)
static void C_ccall f_1827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1995)
static void C_ccall f_1995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1998)
static void C_ccall f_1998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1841)
static void C_ccall f_1841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1990)
static void C_ccall f_1990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1631)
static void C_ccall f_1631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2814)
static void C_ccall f_2814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3869)
static void C_ccall f_3869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3865)
static void C_ccall f_3865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3863)
static void C_ccall f_3863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1852)
static void C_ccall f_1852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1854)
static void C_ccall f_1854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1856)
static void C_ccall f_1856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1858)
static void C_ccall f_1858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3859)
static void C_ccall f_3859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3855)
static void C_ccall f_3855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3000)
static void C_ccall f_3000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2827)
static void C_ccall f_2827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3571)
static void C_fcall f_3571(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3723)
static void C_ccall f_3723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3721)
static void C_ccall f_3721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3852)
static void C_ccall f_3852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3603)
static void C_ccall f_3603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3735)
static void C_fcall f_3735(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2836)
static void C_fcall f_2836(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4503)
static void C_ccall f_4503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3725)
static void C_fcall f_3725(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2840)
static void C_ccall f_2840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2626)
static void C_ccall f_2626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2622)
static void C_ccall f_2622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3758)
static void C_ccall f_3758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3756)
static void C_fcall f_3756(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2633)
static void C_ccall f_2633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3770)
static void C_ccall f_3770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3697)
static void C_ccall f_3697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3744)
static void C_ccall f_3744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3899)
static void C_ccall f_3899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3890)
static void C_ccall f_3890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4598)
static void C_ccall f_4598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2505)
static void C_ccall f_2505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2598)
static void C_ccall f_2598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2591)
static void C_ccall f_2591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3672)
static void C_fcall f_3672(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3670)
static void C_ccall f_3670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3715)
static void C_ccall f_3715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3717)
static void C_ccall f_3717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3719)
static void C_ccall f_3719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3011)
static void C_fcall f_3011(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2521)
static void C_ccall f_2521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3016)
static void C_ccall f_3016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2537)
static void C_ccall f_2537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1393)
static void C_fcall f_1393(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1390)
static void C_ccall f_1390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1658)
static void C_ccall f_1658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1399)
static void C_ccall f_1399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1397)
static void C_ccall f_1397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4440)
static void C_ccall f_4440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4443)
static void C_ccall f_4443(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_4458)
static void C_fcall trf_4458(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4458(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4458(t0,t1);}

C_noret_decl(trf_2657)
static void C_fcall trf_2657(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2657(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2657(t0,t1);}

C_noret_decl(trf_1606)
static void C_fcall trf_1606(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1606(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1606(t0,t1,t2);}

C_noret_decl(trf_3789)
static void C_fcall trf_3789(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3789(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3789(t0,t1);}

C_noret_decl(trf_4088)
static void C_fcall trf_4088(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4088(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_4088(t0);}

C_noret_decl(trf_3045)
static void C_fcall trf_3045(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3045(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3045(t0,t1);}

C_noret_decl(trf_4056)
static void C_fcall trf_4056(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4056(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4056(t0,t1,t2);}

C_noret_decl(trf_4478)
static void C_fcall trf_4478(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4478(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4478(t0,t1,t2);}

C_noret_decl(trf_4164)
static void C_fcall trf_4164(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4164(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4164(t0,t1,t2);}

C_noret_decl(trf_1586)
static void C_fcall trf_1586(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1586(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1586(t0,t1);}

C_noret_decl(trf_4189)
static void C_fcall trf_4189(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4189(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4189(t0,t1);}

C_noret_decl(trf_3980)
static void C_fcall trf_3980(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3980(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_3980(t0);}

C_noret_decl(trf_4125)
static void C_fcall trf_4125(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4125(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4125(t0,t1);}

C_noret_decl(trf_3950)
static void C_fcall trf_3950(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3950(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3950(t0,t1,t2);}

C_noret_decl(trf_2754)
static void C_fcall trf_2754(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2754(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2754(t0,t1);}

C_noret_decl(trf_2763)
static void C_fcall trf_2763(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2763(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2763(t0,t1);}

C_noret_decl(trf_2704)
static void C_fcall trf_2704(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2704(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2704(t0,t1);}

C_noret_decl(trf_2702)
static void C_fcall trf_2702(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2702(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2702(t0,t1);}

C_noret_decl(trf_2875)
static void C_fcall trf_2875(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2875(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2875(t0,t1,t2);}

C_noret_decl(trf_3333)
static void C_fcall trf_3333(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3333(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3333(t0,t1,t2);}

C_noret_decl(trf_4115)
static void C_fcall trf_4115(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4115(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_4115(t0);}

C_noret_decl(trf_1929)
static void C_fcall trf_1929(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1929(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1929(t0,t1);}

C_noret_decl(trf_1927)
static void C_fcall trf_1927(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1927(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1927(t0,t1);}

C_noret_decl(trf_4101)
static void C_fcall trf_4101(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4101(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4101(t0,t1);}

C_noret_decl(trf_3320)
static void C_fcall trf_3320(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3320(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3320(t0,t1);}

C_noret_decl(trf_1730)
static void C_fcall trf_1730(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1730(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1730(t0,t1,t2,t3);}

C_noret_decl(trf_1722)
static void C_fcall trf_1722(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1722(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1722(t0,t1);}

C_noret_decl(trf_3407)
static void C_fcall trf_3407(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3407(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3407(t0,t1,t2);}

C_noret_decl(trf_3481)
static void C_fcall trf_3481(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3481(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3481(t0,t1);}

C_noret_decl(trf_1755)
static void C_fcall trf_1755(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1755(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1755(t0,t1);}

C_noret_decl(trf_1487)
static void C_fcall trf_1487(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1487(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1487(t0,t1);}

C_noret_decl(trf_2483)
static void C_fcall trf_2483(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2483(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2483(t0,t1);}

C_noret_decl(trf_3427)
static void C_fcall trf_3427(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3427(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3427(t0,t1,t2);}

C_noret_decl(trf_2160)
static void C_fcall trf_2160(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2160(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2160(t0,t1);}

C_noret_decl(trf_3551)
static void C_fcall trf_3551(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3551(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3551(t0,t1,t2);}

C_noret_decl(trf_1796)
static void C_fcall trf_1796(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1796(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1796(t0,t1,t2);}

C_noret_decl(trf_3501)
static void C_fcall trf_3501(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3501(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3501(t0,t1);}

C_noret_decl(trf_4283)
static void C_fcall trf_4283(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4283(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4283(t0,t1);}

C_noret_decl(trf_3658)
static void C_fcall trf_3658(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3658(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_3658(t0);}

C_noret_decl(trf_3638)
static void C_fcall trf_3638(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3638(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3638(t0,t1,t2);}

C_noret_decl(trf_3594)
static void C_fcall trf_3594(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3594(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3594(t0,t1,t2);}

C_noret_decl(trf_1817)
static void C_fcall trf_1817(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1817(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1817(t0,t1);}

C_noret_decl(trf_3615)
static void C_fcall trf_3615(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3615(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3615(t0,t1);}

C_noret_decl(trf_3571)
static void C_fcall trf_3571(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3571(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3571(t0,t1,t2);}

C_noret_decl(trf_3735)
static void C_fcall trf_3735(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3735(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3735(t0,t1,t2);}

C_noret_decl(trf_2836)
static void C_fcall trf_2836(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2836(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2836(t0,t1);}

C_noret_decl(trf_3725)
static void C_fcall trf_3725(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3725(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3725(t0,t1);}

C_noret_decl(trf_3756)
static void C_fcall trf_3756(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3756(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3756(t0,t1);}

C_noret_decl(trf_3672)
static void C_fcall trf_3672(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3672(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3672(t0,t1,t2);}

C_noret_decl(trf_3011)
static void C_fcall trf_3011(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3011(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3011(t0,t1);}

C_noret_decl(trf_1393)
static void C_fcall trf_1393(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1393(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1393(t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

/* k4448 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in k1449 in k1416 in k1412 in ... */
static void C_ccall f_4449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4449,2,t0,t1);}
if(C_truep(C_retrieve2(lf[19],"chicken-prefix"))){
t2=C_a_i_list2(&a,2,C_retrieve2(lf[19],"chicken-prefix"),lf[391]);
/* csc.scm:88: make-pathname */
t3=C_fast_retrieve(lf[104]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,lf[392]);}
else{
t2=((C_word*)t0)[2];
f_1576(2,t2,t1);}}

/* k4588 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in k1449 in k1416 in k1412 in k1389 in k4690 in k4693 in k4696 in k4699 in k1368 in k1366 in k1364 in ... */
static void C_ccall f_4589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:132: string-split */
t2=C_fast_retrieve(lf[224]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4585 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in k1449 in k1416 in k1412 in k1389 in k4690 in k4693 in k4696 in k4699 in k1368 in k1366 in ... */
static void C_ccall f_4586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:134: string-split */
t2=C_fast_retrieve(lf[224]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1642 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in ... */
static void C_ccall f_1643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1643,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1646,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1649,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_truep(C_retrieve2(lf[69],"deployed"))?C_i_not(C_retrieve2(lf[6],"netbsd")):C_SCHEME_FALSE);
if(C_truep(t4)){
/* csc.scm:269: conc */
t5=C_fast_retrieve(lf[228]);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,lf[229],lf[231],lf[230]);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1658,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[22],"host-mode"))){
/* ##sys#peek-c-string */
t6=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)C_INSTALL_LIB_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t6=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)C_TARGET_RUN_LIB_HOME),C_fix(0));}}}

/* k1648 in k1642 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in ... */
static void C_ccall f_1649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:269: conc */
t2=C_fast_retrieve(lf[228]);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[229],t1,lf[230]);}

/* k1645 in k1642 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in ... */
static void C_ccall f_1646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1646,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1586(t2,C_a_i_list2(&a,2,((C_word*)t0)[3],t1));}

/* k4430 in k4428 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in k1449 in ... */
static void C_ccall f_4431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* k4432 in k4428 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in k1449 in ... */
static void C_ccall f_4434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_fast_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in k1449 in k1416 in ... */
static void C_ccall f_4437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4437,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1722,tmp=(C_word)a,a+=2,tmp));
t11=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1730,tmp=(C_word)a,a+=2,tmp));
t12=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1755,tmp=(C_word)a,a+=2,tmp));
t13=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1778,tmp=(C_word)a,a+=2,tmp));
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1796,a[2]=t9,a[3]=t15,a[4]=t3,a[5]=t5,a[6]=t7,tmp=(C_word)a,a+=7,tmp));
t17=((C_word*)t15)[1];
f_1796(t17,((C_word*)t0)[2],t1);}

/* k2552 in k2481 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in ... */
static void C_ccall f_2553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=C_i_car(((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate(&lf[32] /* (set! linker ...) */,t2);
t4=C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
/* csc.scm:796: loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_1796(t6,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* k1672 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in ... */
static void C_ccall f_1673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1673,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1586(t2,C_a_i_list1(&a,1,t1));}

/* k4460 in k4457 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in k1449 in k1416 in k1412 in ... */
static void C_ccall f_4461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4461,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4464,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4465,tmp=(C_word)a,a+=2,tmp);
/* csc.scm:246: g106 */
t4=t3;
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t1);}
else{
/* csc.scm:244: append */
t3=*((C_word*)lf[101]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],((C_word*)t0)[3],C_SCHEME_END_OF_LIST);}}

/* f_4467 */
static void C_ccall f_4467(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4467,3,t0,t1,t2);}
t3=*((C_word*)lf[119]+1);
/* csc.scm:248: g134 */
t4=*((C_word*)lf[119]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,lf[393],t2,lf[394]);}

/* k4462 in k4460 in k4457 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in k1449 in k1416 in ... */
static void C_ccall f_4464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:244: append */
t2=*((C_word*)lf[101]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* f_4465 in k4460 in k4457 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in k1449 in k1416 in ... */
static void C_ccall f_4465(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4465,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4467,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4473,a[2]=t6,a[3]=t4,a[4]=t7,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* csc.scm:248: string-split */
t9=C_fast_retrieve(lf[224]);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,t2,lf[395]);}

/* k2568 in k2481 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in ... */
static void C_ccall f_2569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2569,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2573,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_i_car(((C_word*)((C_word*)t0)[2])[1]);
t4=C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
/* csc.scm:711: cons* */
t5=C_fast_retrieve(lf[125]);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,lf[342],t3,t4);}

/* k1366 in k1364 in k1362 in k1360 in k1358 in k1356 in k1354 in k1352 */
static void C_ccall f_1367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1367,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1369,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1364 in k1362 in k1360 in k1358 in k1356 in k1354 in k1352 */
static void C_ccall f_1365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1365,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1367,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1368 in k1366 in k1364 in k1362 in k1360 in k1358 in k1356 in k1354 in k1352 */
static void C_ccall f_1369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1369,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4700,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:68: build-platform */
t3=C_fast_retrieve(lf[351]);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1362 in k1360 in k1358 in k1356 in k1354 in k1352 */
static void C_ccall f_1363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1363,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1365,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1360 in k1358 in k1356 in k1354 in k1352 */
static void C_ccall f_1361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1361,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1363,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_2d13_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k2571 in k2568 in k2481 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in ... */
static void C_ccall f_2573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
/* csc.scm:796: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1796(t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* k4457 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in k1449 in k1416 in k1412 in k1389 in ... */
static void C_fcall f_4458(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4458,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4461,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csc.scm:246: get-environment-variable */
t3=C_fast_retrieve(lf[226]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[396]);}

/* k2643 in k2481 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in ... */
static void C_ccall f_2644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2644,2,t0,t1);}
t2=C_i_car(((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate(&lf[70] /* (set! rpath ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2657,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2670,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:725: build-platform */
t6=C_fast_retrieve(lf[351]);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k1356 in k1354 in k1352 */
static void C_ccall f_1357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1357,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1359,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1354 in k1352 */
static void C_ccall f_1355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1355,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1357,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_2dstructures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1358 in k1356 in k1354 in k1352 */
static void C_ccall f_1359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1359,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1361,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_2d1_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1352 */
static void C_ccall f_1353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1353,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1355,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3772 in k3754 in k3722 in k3720 in k3718 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in ... */
static void C_ccall f_3773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3773,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4032,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4038,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4005,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_LIB_HOME),C_fix(0));}

/* k4403 in k3629 in k3616 in k3613 in k3497 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in ... */
static void C_ccall f_4404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4404,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4409,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:1090: with-output-to-file */
t3=C_fast_retrieve(lf[155]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[4],t2);}

/* k2586 in k2481 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in ... */
static void C_ccall f_2587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2587,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2591,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2598,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_i_car(((C_word*)((C_word*)t0)[2])[1]);
/* csc.scm:714: string-split */
t5=C_fast_retrieve(lf[224]);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k2655 in k2643 in k2481 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in ... */
static void C_fcall f_2657(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2657,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2661,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2667,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:727: string-append */
t4=*((C_word*)lf[119]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[348],C_retrieve2(lf[70],"rpath"));}
else{
t2=C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
/* csc.scm:796: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1796(t4,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}}

/* f_4409 in k4403 in k3629 in k3616 in k3613 in k3497 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in ... */
static void C_ccall f_4409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4409,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4415,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=C_a_i_cons(&a,2,lf[202],C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,((C_word*)t0)[2],t3);
t5=C_a_i_cons(&a,2,lf[203],t4);
/* csc.scm:1088: ##sys#print-to-string */
((C_proc3)C_fast_retrieve_symbol_proc(lf[154]))(3,*((C_word*)lf[154]+1),t2,t5);}

/* k3790 in k3787 in k3720 in k3718 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in ... */
static void C_ccall f_3791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3791,2,t0,t1);}
t2=(C_truep(C_retrieve2(lf[67],"gui"))?C_i_not(C_retrieve2(lf[68],"deploy")):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=((C_word*)((C_word*)t0)[2])[1];
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4320,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* csc.scm:1050: open-output-string */
t5=C_fast_retrieve(lf[111]);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[3];
f_3723(2,t4,t3);}}

/* map-loop164 in k1600 */
static void C_fcall f_1606(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1606,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1631,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* csc.scm:280: g170 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4214 in k4208 in quote-option in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in ... */
static void C_ccall f_4216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4216,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4147,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4159,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4162,a[2]=t5,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* string->list */
t9=C_fast_retrieve(lf[126]);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}

/* k4208 in quote-option in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in k1449 in ... */
static void C_ccall f_4210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4210,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4216,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4221,tmp=(C_word)a,a+=2,tmp);
/* csc.scm:1018: string-any */
t4=C_fast_retrieve(lf[127]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}}

/* f5424 in k1961 in k1959 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in ... */
static void C_ccall f5424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:542: exit */
t2=C_fast_retrieve(lf[13]);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k1600 */
static void C_ccall f_1601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1601,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1606,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_1606(t5,((C_word*)t0)[5],t1);}

/* k2666 in k2655 in k2643 in k2481 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in ... */
static void C_ccall f_2667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2667,2,t0,t1);}
t2=C_a_i_list1(&a,1,t1);
/* csc.scm:727: append */
t3=*((C_word*)lf[101]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],C_retrieve2(lf[86],"link-options"),t2);}

/* k2659 in k2655 in k2643 in k2481 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in ... */
static void C_ccall f_2661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(&lf[86] /* (set! link-options ...) */,t1);
t3=C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
/* csc.scm:796: loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_1796(t5,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* quote-option in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in k1449 in k1416 in ... */
static void C_ccall f_4203(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4203,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4210,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4232,tmp=(C_word)a,a+=2,tmp);
/* csc.scm:1017: string-any */
t5=C_fast_retrieve(lf[127]);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t2);}

/* k4428 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in k1449 in k1416 in ... */
static void C_ccall f_4429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4429,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4431,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4434,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
((C_proc2)C_fast_retrieve_symbol_proc(lf[141]))(2,*((C_word*)lf[141]+1),t3);}

/* f5437 in k4550 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in k1449 in k1416 in k1412 in k1389 in k4690 in k4693 in ... */
static void C_ccall f5437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:92: qs */
t2=C_fast_retrieve(lf[25]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2669 in k2643 in k2481 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in ... */
static void C_ccall f_2670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep((C_truep(C_eqp(t1,lf[349]))?C_SCHEME_TRUE:(C_truep(C_eqp(t1,lf[350]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t2=C_retrieve2(lf[1],"mingw");
t3=((C_word*)t0)[2];
f_2657(t3,(C_truep(C_retrieve2(lf[1],"mingw"))?C_SCHEME_FALSE:C_i_not(C_retrieve2(lf[3],"osx"))));}
else{
t2=((C_word*)t0)[2];
f_2657(t2,C_SCHEME_FALSE);}}

/* k4699 in k1368 in k1366 in k1364 in k1362 in k1360 in k1358 in k1356 in k1354 in k1352 */
static void C_ccall f_4700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4700,2,t0,t1);}
t2=C_eqp(t1,lf[0]);
t3=C_mutate(&lf[1] /* (set! mingw ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4697,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:69: software-version */
t5=C_fast_retrieve(lf[417]);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k4066 in k4064 in k4062 in copy-files in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in ... */
static void C_ccall f_4067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4067,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4069,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4083,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[6];
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5301,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:92: normalize-pathname */
t6=C_fast_retrieve(lf[26]);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}

/* k4068 in k4066 in k4064 in k4062 in copy-files in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in ... */
static void C_ccall f_4069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4069,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4071,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* write-char/port */
t3=C_fast_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(32),((C_word*)t0)[4]);}

/* k4062 in copy-files in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in k1449 in ... */
static void C_ccall f_4063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4063,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4065,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_retrieve2(lf[43],"windows-shell"))){
/* csc.scm:973: display */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[109],t2);}
else{
/* csc.scm:973: display */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[110],t2);}}

/* k4064 in k4062 in copy-files in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in ... */
static void C_ccall f_4065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4065,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4067,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* write-char/port */
t3=C_fast_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(32),((C_word*)t0)[4]);}

/* k4414 */
static void C_ccall f_4415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:1092: print */
t2=*((C_word*)lf[137]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3787 in k3720 in k3718 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in ... */
static void C_fcall f_3789(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3789,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3791,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3806,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3809,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3812,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=C_retrieve2(lf[45],"libchicken");
/* ##sys#string-append */
((C_proc4)C_fast_retrieve_symbol_proc(lf[113]))(4,*((C_word*)lf[113]+1),t5,C_retrieve2(lf[45],"libchicken"),lf[176]);}
else{
t2=((C_word*)t0)[3];
f_3723(2,t2,C_SCHEME_UNDEFINED);}}

/* k4094 in linker-options in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in k1449 in ... */
static void C_ccall f_4095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4095,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4101,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[94],"static"))){
t3=C_retrieve2(lf[1],"mingw");
t4=t2;
f_4101(t4,(C_truep(C_retrieve2(lf[1],"mingw"))?C_SCHEME_FALSE:C_i_not(C_retrieve2(lf[3],"osx"))));}
else{
t3=t2;
f_4101(t3,C_SCHEME_FALSE);}}

/* f5411 in k3313 in k3288 */
static void C_ccall f5411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:92: qs */
t2=C_fast_retrieve(lf[25]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2609 in k2481 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in ... */
static void C_ccall f_2611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[86] /* (set! link-options ...) */,t1);
/* csc.scm:796: loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1796(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}

/* f5416 in k3288 */
static void C_ccall f5416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:92: qs */
t2=C_fast_retrieve(lf[25]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4079 in k4070 in k4068 in k4066 in k4064 in k4062 in copy-files in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in ... */
static void C_ccall f_4080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:973: display */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,((C_word*)t0)[3]);}

/* linker-options in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in k1449 in k1416 in ... */
static void C_fcall f_4088(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4088,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4095,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4113,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:983: append */
t4=*((C_word*)lf[101]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_retrieve2(lf[84],"linking-optimization-options"),C_retrieve2(lf[86],"link-options"));}

/* k4082 in k4066 in k4064 in k4062 in copy-files in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in ... */
static void C_ccall f_4083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:973: display */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,((C_word*)t0)[3]);}

/* k3043 */
static void C_fcall f_3045(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3045,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3049,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_a_i_list1(&a,1,((C_word*)t0)[3]);
/* csc.scm:789: append */
t4=*((C_word*)lf[101]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,C_retrieve2(lf[57],"object-files"),t3);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3056,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_a_i_list1(&a,1,((C_word*)t0)[3]);
/* csc.scm:790: append */
t4=*((C_word*)lf[101]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,C_retrieve2(lf[52],"scheme-files"),t3);}}

/* k3047 in k3043 */
static void C_ccall f_3049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[57] /* (set! object-files ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1694 in k1688 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in ... */
static void C_ccall f_1695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:300: print */
t2=*((C_word*)lf[137]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* copy-files in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in k1449 in k1416 in ... */
static void C_fcall f_4056(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4056,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4063,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* csc.scm:973: open-output-string */
t5=C_fast_retrieve(lf[111]);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k4053 in k4037 in k3772 in k3754 in k3722 in k3720 in k3718 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in ... */
static void C_ccall f_4054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#string-append */
((C_proc4)C_fast_retrieve_symbol_proc(lf[113]))(4,*((C_word*)lf[113]+1),((C_word*)t0)[2],lf[167],t1);}

/* k3032 */
static void C_ccall f_3034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[53] /* (set! c-files ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1688 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in ... */
static void C_ccall f_1689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1689,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1695,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_a_i_cons(&a,2,lf[240],C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,t1,t3);
t5=C_a_i_cons(&a,2,lf[241],t4);
t6=C_a_i_cons(&a,2,t1,t5);
t7=C_a_i_cons(&a,2,lf[242],t6);
t8=C_a_i_cons(&a,2,t1,t7);
t9=C_a_i_cons(&a,2,lf[243],t8);
/* csc.scm:298: ##sys#print-to-string */
((C_proc3)C_fast_retrieve_symbol_proc(lf[154]))(3,*((C_word*)lf[154]+1),t2,t9);}

/* k4040 in k4037 in k3772 in k3754 in k3722 in k3720 in k3718 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in ... */
static void C_ccall f_4041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:961: make-pathname */
t2=C_fast_retrieve(lf[104]);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],((C_word*)t0)[3],C_retrieve2(lf[45],"libchicken"),t1);}

/* map-loop111 in k4472 */
static void C_fcall f_4478(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4478,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4503,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* csc.scm:247: g117 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4472 */
static void C_ccall f_4473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4473,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4478,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_4478(t5,((C_word*)t0)[5],t1);}

/* f5362 in map-loop662 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in ... */
static void C_ccall f5362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:92: qs */
t2=C_fast_retrieve(lf[25]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* f5369 in k1871 in k1859 in k1857 in k1855 in k1853 in k1851 in k1844 in k1842 in k1840 in k1838 in k1836 in k1834 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in ... */
static void C_ccall f5369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:92: qs */
t2=C_fast_retrieve(lf[25]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4070 in k4068 in k4066 in k4064 in k4062 in copy-files in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in ... */
static void C_ccall f_4071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4071,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4074,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4080,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[5];
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5296,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:92: normalize-pathname */
t6=C_fast_retrieve(lf[26]);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}

/* k4075 in k4072 in k4070 in k4068 in k4066 in k4064 in k4062 in copy-files in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in ... */
static void C_ccall f_4077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:972: command */
f_4283(((C_word*)t0)[2],t1);}

/* k4072 in k4070 in k4068 in k4066 in k4064 in k4062 in copy-files in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in ... */
static void C_ccall f_4074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4074,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4077,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:973: get-output-string */
t3=C_fast_retrieve(lf[108]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k2694 in k2481 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in ... */
static void C_ccall f_2696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2696,2,t0,t1);}
t2=C_mutate(&lf[87] /* (set! target-filename ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2700,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:732: append */
t4=*((C_word*)lf[101]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_retrieve2(lf[52],"scheme-files"),lf[354]);}

/* k3062 in k2951 in k2761 in k2752 in k2703 in k2701 in k2481 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in ... */
static void C_ccall f_3063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3063,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3069,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* csc.scm:793: file-exists? */
t3=C_fast_retrieve(lf[157]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k3067 in k3062 in k2951 in k2761 in k2752 in k2703 in k2701 in k2481 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in ... */
static void C_ccall f_3069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3069,2,t0,t1);}
if(C_truep(t1)){
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
/* csc.scm:796: loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1796(t4,((C_word*)t0)[5],((C_word*)((C_word*)t0)[3])[1]);}
else{
/* csc.scm:795: quit */
f_1393(((C_word*)t0)[6],lf[380],C_a_i_list(&a,1,((C_word*)t0)[7]));}}

/* k4031 in k3772 in k3754 in k3722 in k3720 in k3718 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in ... */
static void C_ccall f_4032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:969: copy-files */
f_4056(((C_word*)t0)[2],t1,((C_word*)t0)[3]);}

/* k4037 in k3772 in k3754 in k3722 in k3720 in k3718 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in ... */
static void C_ccall f_4038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4038,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4041,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[3],"osx"))){
/* csc.scm:961: make-pathname */
t3=C_fast_retrieve(lf[104]);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],t1,C_retrieve2(lf[45],"libchicken"),lf[165]);}
else{
t3=C_retrieve2(lf[4],"win");
t4=(C_truep(C_retrieve2(lf[4],"win"))?C_retrieve2(lf[4],"win"):C_retrieve2(lf[8],"cygwin"));
if(C_truep(t4)){
/* csc.scm:961: make-pathname */
t5=C_fast_retrieve(lf[104]);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[2],t1,C_retrieve2(lf[45],"libchicken"),lf[166]);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4054,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:968: number->string */
C_number_to_string(3,0,t5,C_fix((C_word)C_BINARY_VERSION));}}}

/* k4657 in k1453 in k1449 in k1416 in k1412 in k1389 in k4690 in k4693 in k4696 in k4699 in k1368 in k1366 in k1364 in k1362 in k1360 in k1358 in k1356 in k1354 in k1352 */
static void C_ccall f_4658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4658,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5462,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:92: normalize-pathname */
t3=C_fast_retrieve(lf[26]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k3054 in k3043 */
static void C_ccall f_3056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[52] /* (set! scheme-files ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4639 in k1461 in k1457 in k1453 in k1449 in k1416 in k1412 in k1389 in k4690 in k4693 in k4696 in k4699 in k1368 in k1366 in k1364 in k1362 in k1360 in k1358 in k1356 in k1354 in k1352 */
static void C_ccall f_4640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4640,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5452,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:92: normalize-pathname */
t3=C_fast_retrieve(lf[26]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k3974 in map-loop662 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in ... */
static void C_ccall f_3975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3975,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_3950(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_3950(t6,((C_word*)t0)[5],t5);}}

/* k4648 in k1457 in k1453 in k1449 in k1416 in k1412 in k1389 in k4690 in k4693 in k4696 in k4699 in k1368 in k1366 in k1364 in k1362 in k1360 in k1358 in k1356 in k1354 in k1352 */
static void C_ccall f_4649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4649,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5457,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:92: normalize-pathname */
t3=C_fast_retrieve(lf[26]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in k1449 in k1416 in k1412 in k1389 in k4690 in k4693 in k4696 in k4699 in k1368 in k1366 in k1364 in ... */
static void C_ccall f_1506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1506,2,t0,t1);}
t2=C_mutate(&lf[49] /* (set! default-linking-optimization-options ...) */,t1);
t3=C_mutate(&lf[50] /* (set! best-linking-optimization-options ...) */,C_retrieve2(lf[49],"default-linking-optimization-options"));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1511,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[22],"host-mode"))){
t5=t4;
f_1511(2,t5,C_SCHEME_END_OF_LIST);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4586,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t6=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)C_TARGET_FEATURES),C_fix(0));}}

/* k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in k1449 in k1416 in k1412 in k1389 in k4690 in k4693 in k4696 in k4699 in k1368 in k1366 in k1364 in k1362 in ... */
static void C_ccall f_1501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1501,2,t0,t1);}
t2=C_mutate(&lf[47] /* (set! default-compilation-optimization-options ...) */,t1);
t3=C_mutate(&lf[48] /* (set! best-compilation-optimization-options ...) */,C_retrieve2(lf[47],"default-compilation-optimization-options"));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1506,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4589,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[22],"host-mode"))){
/* ##sys#peek-c-string */
t6=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)C_INSTALL_LDFLAGS),C_fix(0));}
else{
/* ##sys#peek-c-string */
t6=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)C_TARGET_LDFLAGS),C_fix(0));}}

/* k3916 in k3910 in k3907 in k3861 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in ... */
static void C_ccall f_3917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3917,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3919,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* csc.scm:896: display */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[183],t2);}

/* k3918 in k3916 in k3910 in k3907 in k3861 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in ... */
static void C_ccall f_3919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3919,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3922,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3928,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3931,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:896: make-pathname */
t5=C_fast_retrieve(lf[104]);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)((C_word*)t0)[5])[1],lf[182]);}

/* k4666 in k1449 in k1416 in k1412 in k1389 in k4690 in k4693 in k4696 in k4699 in k1368 in k1366 in k1364 in k1362 in k1360 in k1358 in k1356 in k1354 in k1352 */
static void C_ccall f_4667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4667,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5467,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:92: normalize-pathname */
t3=C_fast_retrieve(lf[26]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k3910 in k3907 in k3861 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in ... */
static void C_ccall f_3911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3911,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3917,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csc.scm:896: open-output-string */
t3=C_fast_retrieve(lf[111]);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4615 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in k1449 in k1416 in k1412 in k1389 in k4690 in k4693 in k4696 in k4699 in k1368 in k1366 in k1364 in k1362 in k1360 in k1358 in ... */
static void C_ccall f_4616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:125: string-append */
t2=*((C_word*)lf[119]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[408],t1);}

/* k3907 in k3861 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in ... */
static void C_ccall f_3909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3909,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3911,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3934,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csc.scm:895: open-output-string */
t5=C_fast_retrieve(lf[111]);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k4609 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in k1449 in k1416 in k1412 in k1389 in k4690 in k4693 in k4696 in k4699 in k1368 in k1366 in k1364 in k1362 in k1360 in k1358 in ... */
static void C_ccall f_4610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:124: string-append */
t2=*((C_word*)lf[119]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[406],t1,lf[407]);}

/* k3098 in k2703 in k2701 in k2481 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in ... */
static void C_ccall f_3099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2754(t2,C_u_i_string_equal_p(lf[382],t1));}

/* k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in k1449 in k1416 in k1412 in k1389 in k4690 in k4693 in k4696 in k4699 in k1368 in k1366 in ... */
static void C_ccall f_1511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1511,2,t0,t1);}
t2=C_mutate(&lf[51] /* (set! extra-features ...) */,t1);
t3=lf[52] /* scheme-files */ =C_SCHEME_END_OF_LIST;;
t4=lf[53] /* c-files */ =C_SCHEME_END_OF_LIST;;
t5=lf[54] /* rc-files */ =C_SCHEME_END_OF_LIST;;
t6=lf[55] /* generated-c-files */ =C_SCHEME_END_OF_LIST;;
t7=lf[56] /* generated-rc-files */ =C_SCHEME_END_OF_LIST;;
t8=lf[57] /* object-files */ =C_SCHEME_END_OF_LIST;;
t9=lf[58] /* generated-object-files */ =C_SCHEME_END_OF_LIST;;
t10=lf[59] /* cpp-mode */ =C_SCHEME_FALSE;;
t11=lf[60] /* objc-mode */ =C_SCHEME_FALSE;;
t12=lf[61] /* embedded */ =C_SCHEME_FALSE;;
t13=lf[62] /* inquiry-only */ =C_SCHEME_FALSE;;
t14=lf[63] /* show-cflags */ =C_SCHEME_FALSE;;
t15=lf[64] /* show-ldflags */ =C_SCHEME_FALSE;;
t16=lf[65] /* show-libs */ =C_SCHEME_FALSE;;
t17=lf[66] /* dry-run */ =C_SCHEME_FALSE;;
t18=lf[67] /* gui */ =C_SCHEME_FALSE;;
t19=lf[68] /* deploy */ =C_SCHEME_FALSE;;
t20=lf[69] /* deployed */ =C_SCHEME_FALSE;;
t21=lf[70] /* rpath */ =C_SCHEME_FALSE;;
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1542,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[22],"host-mode"))){
/* ##sys#peek-c-string */
t23=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t23+1)))(4,t23,t22,C_mpointer(&a,(void*)C_INSTALL_MORE_STATIC_LIBS),C_fix(0));}
else{
/* ##sys#peek-c-string */
t23=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t23+1)))(4,t23,t22,C_mpointer(&a,(void*)C_TARGET_MORE_STATIC_LIBS),C_fix(0));}}

/* k3933 in k3907 in k3861 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in ... */
static void C_ccall f_3934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3934,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3936,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* csc.scm:895: display */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[185],t2);}

/* k3935 in k3933 in k3907 in k3861 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in ... */
static void C_ccall f_3936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3936,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3939,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3945,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3948,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:895: make-pathname */
t5=C_fast_retrieve(lf[104]);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)((C_word*)t0)[5])[1],lf[184]);}

/* k3937 in k3935 in k3933 in k3907 in k3861 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in ... */
static void C_ccall f_3939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3939,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3942,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:895: get-output-string */
t3=C_fast_retrieve(lf[108]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k3293 in k3290 in k3288 */
static void C_ccall f_3295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3295,2,t0,t1);}
t2=C_mutate(&lf[53] /* (set! c-files ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3299,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=C_a_i_list1(&a,1,((C_word*)t0)[3]);
/* csc.scm:831: append */
t5=*((C_word*)lf[101]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_retrieve2(lf[55],"generated-c-files"));}

/* k3290 in k3288 */
static void C_ccall f_3291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3291,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3295,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_a_i_list1(&a,1,((C_word*)t0)[3]);
/* csc.scm:830: append */
t4=*((C_word*)lf[101]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve2(lf[53],"c-files"));}

/* k3930 in k3918 in k3916 in k3910 in k3907 in k3861 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in ... */
static void C_ccall f_3931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3931,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5347,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:92: normalize-pathname */
t3=C_fast_retrieve(lf[26]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k3297 in k3293 in k3290 in k3288 */
static void C_ccall f_3299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[55] /* (set! generated-c-files ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in k1449 in k1416 in k1412 in k1389 in k4690 in k4693 in k4696 in k4699 in ... */
static void C_ccall f_1546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1546,2,t0,t1);}
t2=C_mutate(&lf[72] /* (set! extra-shared-libraries ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4548,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4551,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4554,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4557,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[22],"host-mode"))){
/* ##sys#peek-c-string */
t7=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_INSTALL_LIB_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t7=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_TARGET_LIB_HOME),C_fix(0));}}

/* k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in k1449 in k1416 in k1412 in k1389 in k4690 in k4693 in k4696 in k4699 in k1368 in ... */
static void C_ccall f_1542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1542,2,t0,t1);}
t2=C_mutate(&lf[71] /* (set! extra-libraries ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1546,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[22],"host-mode"))){
/* ##sys#peek-c-string */
t4=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_INSTALL_MORE_LIBS),C_fix(0));}
else{
/* ##sys#peek-c-string */
t4=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_TARGET_MORE_LIBS),C_fix(0));}}

/* k3923 in k3920 in k3918 in k3916 in k3910 in k3907 in k3861 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in ... */
static void C_ccall f_3925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:896: command */
f_4283(((C_word*)t0)[2],t1);}

/* k3927 in k3918 in k3916 in k3910 in k3907 in k3861 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in ... */
static void C_ccall f_3928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:896: display */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,((C_word*)t0)[3]);}

/* k4630 in k1465 in k1461 in k1457 in k1453 in k1449 in k1416 in k1412 in k1389 in k4690 in k4693 in k4696 in k4699 in k1368 in k1366 in k1364 in k1362 in k1360 in k1358 in k1356 in k1354 in k1352 in ... */
static void C_ccall f_4631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4631,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5447,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:92: normalize-pathname */
t3=C_fast_retrieve(lf[26]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* f_3286 in k1928 in k1926 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in ... */
static void C_ccall f_3286(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3286,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3289,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_i_length(C_retrieve2(lf[52],"scheme-files"));
t5=C_eqp(C_fix(1),t4);
t6=(C_truep(t5)?C_retrieve2(lf[87],"target-filename"):t2);
if(C_truep(C_retrieve2(lf[59],"cpp-mode"))){
/* csc.scm:804: pathname-replace-extension */
t7=C_fast_retrieve(lf[199]);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t3,t6,lf[216]);}
else{
if(C_truep(C_retrieve2(lf[60],"objc-mode"))){
/* csc.scm:804: pathname-replace-extension */
t7=C_fast_retrieve(lf[199]);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t3,t6,lf[217]);}
else{
/* csc.scm:804: pathname-replace-extension */
t7=C_fast_retrieve(lf[199]);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t3,t6,lf[218]);}}}

/* k3920 in k3918 in k3916 in k3910 in k3907 in k3861 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in ... */
static void C_ccall f_3922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3922,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3925,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:896: get-output-string */
t3=C_fast_retrieve(lf[108]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k3288 */
static void C_ccall f_3289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3289,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3291,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3308,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3311,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3314,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=((C_word*)t0)[3];
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5416,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:92: normalize-pathname */
t8=C_fast_retrieve(lf[26]);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t6);}

/* k2911 in k2834 in k2761 in k2752 in k2703 in k2701 in k2481 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in ... */
static void C_ccall f_2912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2912,2,t0,t1);}
t2=C_i_cdr(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2909,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* csc.scm:767: lset-difference */
t4=C_fast_retrieve(lf[363]);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,*((C_word*)lf[128]+1),t2,lf[364]);}

/* k4621 in k1469 in k1465 in k1461 in k1457 in k1453 in k1449 in k1416 in k1412 in k1389 in k4690 in k4693 in k4696 in k4699 in k1368 in k1366 in k1364 in k1362 in k1360 in k1358 in k1356 in k1354 in ... */
static void C_ccall f_4622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4622,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5442,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:92: normalize-pathname */
t3=C_fast_retrieve(lf[26]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in k1449 in k1416 in k1412 in k1389 in ... */
static void C_ccall f_1568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1568,2,t0,t1);}
t2=C_mutate(&lf[81] /* (set! builtin-compile-options ...) */,t1);
t3=lf[82] /* translation-optimization-options */ =C_SCHEME_END_OF_LIST;;
t4=C_mutate(&lf[83] /* (set! compilation-optimization-options ...) */,C_retrieve2(lf[47],"default-compilation-optimization-options"));
t5=C_mutate(&lf[84] /* (set! linking-optimization-options ...) */,C_retrieve2(lf[49],"default-linking-optimization-options"));
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1576,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4449,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[22],"host-mode"))){
/* ##sys#peek-c-string */
t8=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,C_mpointer(&a,(void*)C_INSTALL_LIB_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t8=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,C_mpointer(&a,(void*)C_TARGET_LIB_HOME),C_fix(0));}}

/* k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in k1449 in k1416 in k1412 in k1389 in k4690 in ... */
static void C_ccall f_1560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1560,2,t0,t1);}
t2=C_i_member(t1,lf[78]);
t3=(C_truep(t2)?C_SCHEME_FALSE:t1);
t4=C_mutate(&lf[79] /* (set! include-dir ...) */,t3);
t5=lf[80] /* compile-options */ =C_SCHEME_END_OF_LIST;;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1568,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4458,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[79],"include-dir"))){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4515,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:245: conc */
t9=C_fast_retrieve(lf[228]);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t8,lf[397],C_retrieve2(lf[79],"include-dir"),lf[398]);}
else{
t8=t7;
f_4458(t8,C_SCHEME_END_OF_LIST);}}

/* k4161 in k4214 in k4208 in quote-option in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in ... */
static void C_ccall f_4162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4162,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4164,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_4164(t5,((C_word*)t0)[3],t1);}

/* fold in k4161 in k4214 in k4208 in quote-option in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in ... */
static void C_fcall f_4164(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(6);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4164,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=C_i_car(t2);
if(C_truep(C_i_memq(t3,lf[117]))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4185,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=t2;
t6=C_u_i_cdr(t5);
/* csc.scm:1008: fold */
t10=t4;
t11=t6;
t1=t10;
t2=t11;
goto loop;}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4189,a[2]=t1,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_u_i_char_whitespacep(t3))){
t5=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_TRUE);
t6=t4;
f_4189(t6,t5);}
else{
t5=t4;
f_4189(t5,C_SCHEME_UNDEFINED);}}}}

/* k4194 in k4188 in fold in k4161 in k4214 in k4208 in quote-option in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in ... */
static void C_ccall f_4195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4195,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[3],t1));}

/* k1585 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in ... */
static void C_fcall f_1586(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1586,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1589,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csc.scm:279: get-environment-variable */
t3=C_fast_retrieve(lf[226]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[227]);}

/* k1588 in k1585 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in ... */
static void C_ccall f_1589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1589,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1592,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1593,tmp=(C_word)a,a+=2,tmp);
/* csc.scm:279: g159 */
t4=t3;
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t1);}
else{
/* csc.scm:265: append */
t3=*((C_word*)lf[101]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],((C_word*)t0)[3],C_SCHEME_END_OF_LIST);}}

/* k2899 in map-loop407 in k2908 in k2911 in k2834 in k2761 in k2752 in k2703 in k2701 in k2481 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in ... */
static void C_ccall f_2900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2900,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_2875(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_2875(t6,((C_word*)t0)[5],t5);}}

/* k2908 in k2911 in k2834 in k2761 in k2752 in k2703 in k2701 in k2481 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in ... */
static void C_ccall f_2909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[23],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2909,2,t0,t1);}
if(C_truep(C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2861,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2863,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2873,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2875,a[2]=t6,a[3]=t10,a[4]=t4,a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_2875(t12,t8,((C_word*)t0)[5]);}
else{
/* csc.scm:770: quit */
f_1393(((C_word*)t0)[6],lf[362],C_a_i_list(&a,1,((C_word*)t0)[7]));}}

/* k4188 in fold in k4161 in k4214 in k4208 in quote-option in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in ... */
static void C_fcall f_4189(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4189,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4195,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[4];
t4=C_u_i_cdr(t3);
/* csc.scm:1011: fold */
t5=((C_word*)((C_word*)t0)[5])[1];
f_4164(t5,t2,t4);}

/* k4184 in fold in k4161 in k4214 in k4208 in quote-option in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in ... */
static void C_ccall f_4185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:1008: cons* */
t2=C_fast_retrieve(lf[125]);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],C_make_character(92),((C_word*)t0)[3],t1);}

/* k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in k1449 in k1416 in k1412 in ... */
static void C_ccall f_1576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word ab[28],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1576,2,t0,t1);}
t2=C_mutate(&lf[85] /* (set! library-dir ...) */,t1);
t3=lf[86] /* link-options */ =C_SCHEME_END_OF_LIST;;
t4=lf[87] /* target-filename */ =C_SCHEME_FALSE;;
t5=lf[88] /* verbose */ =C_SCHEME_FALSE;;
t6=lf[89] /* keep-files */ =C_SCHEME_FALSE;;
t7=lf[90] /* translate-only */ =C_SCHEME_FALSE;;
t8=lf[91] /* compile-only */ =C_SCHEME_FALSE;;
t9=lf[92] /* to-stdout */ =C_SCHEME_FALSE;;
t10=lf[93] /* shared */ =C_SCHEME_FALSE;;
t11=lf[94] /* static */ =C_SCHEME_FALSE;;
t12=lf[95] /* static-libs */ =C_SCHEME_FALSE;;
t13=lf[96] /* required-extensions */ =C_SCHEME_END_OF_LIST;;
t14=C_mutate(&lf[97] /* (set! compiler-options ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3658,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate(&lf[102] /* (set! lib-path ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3980,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate(&lf[106] /* (set! copy-files ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4056,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate(&lf[112] /* (set! linker-options ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4088,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate(&lf[116] /* (set! linker-libraries ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4115,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate(&lf[117] /* (set! constant810 ...) */,lf[118]);
t20=C_mutate(&lf[98] /* (set! quote-option ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4203,tmp=(C_word)a,a+=2,tmp));
t21=lf[129] /* last-exit-code */ =C_SCHEME_FALSE;;
t22=C_mutate(&lf[107] /* (set! command ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4283,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate(&lf[138] /* (set! $delete-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4298,tmp=(C_word)a,a+=2,tmp));
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4429,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t25=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4437,a[2]=t24,tmp=(C_word)a,a+=3,tmp);
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4440,a[2]=t25,tmp=(C_word)a,a+=3,tmp);
t27=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4443,a[2]=t26,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:1115: get-environment-variable */
t28=C_fast_retrieve(lf[226]);
((C_proc3)(void*)(*((C_word*)t28+1)))(3,t28,t27,lf[390]);}

/* f_2958 in k2951 in k2761 in k2752 in k2703 in k2701 in k2481 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in ... */
static void C_ccall f_2958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2958,2,t0,t1);}
/* csc.scm:773: decompose-pathname */
t2=C_fast_retrieve(lf[367]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* k2951 in k2761 in k2752 in k2703 in k2701 in k2481 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in ... */
static void C_ccall f_2953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2953,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2958,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2963,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:773: ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[3],t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3063,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* ##sys#string-append */
((C_proc4)C_fast_retrieve_symbol_proc(lf[113]))(4,*((C_word*)lf[113]+1),t2,((C_word*)t0)[2],lf[381]);}}

/* k4696 in k4699 in k1368 in k1366 in k1364 in k1362 in k1360 in k1358 in k1356 in k1354 in k1352 */
static void C_ccall f_4697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4697,2,t0,t1);}
t2=C_eqp(t1,lf[2]);
t3=C_mutate(&lf[3] /* (set! osx ...) */,t2);
t4=C_mutate(&lf[4] /* (set! win ...) */,C_retrieve2(lf[1],"mingw"));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4694,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:71: software-version */
t6=C_fast_retrieve(lf[417]);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k4690 in k4693 in k4696 in k4699 in k1368 in k1366 in k1364 in k1362 in k1360 in k1358 in k1356 in k1354 in k1352 */
static void C_ccall f_4691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4691,2,t0,t1);}
t2=C_eqp(t1,lf[7]);
t3=C_mutate(&lf[8] /* (set! cygwin ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1390,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:75: software-version */
t5=C_fast_retrieve(lf[417]);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k4693 in k4696 in k4699 in k1368 in k1366 in k1364 in k1362 in k1360 in k1358 in k1356 in k1354 in k1352 */
static void C_ccall f_4694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4694,2,t0,t1);}
t2=C_eqp(t1,lf[5]);
t3=C_mutate(&lf[6] /* (set! netbsd ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4691,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:72: build-platform */
t5=C_fast_retrieve(lf[351]);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k3986 in lib-path in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in k1449 in ... */
static void C_ccall f_3987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3987,2,t0,t1);}
t2=((C_word*)t0)[2];
if(C_truep(C_retrieve2(lf[19],"chicken-prefix"))){
t3=C_a_i_list2(&a,2,C_retrieve2(lf[19],"chicken-prefix"),lf[103]);
/* csc.scm:88: make-pathname */
t4=C_fast_retrieve(lf[104]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,lf[105]);}
else{
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}}

/* k2926 in k2761 in k2752 in k2703 in k2701 in k2481 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in ... */
static void C_ccall f_2927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2836(t2,C_u_i_string_equal_p(lf[366],t1));}

/* k4121 in linker-libraries in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in k1449 in ... */
static void C_ccall f_4122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:987: string-intersperse */
t2=C_fast_retrieve(lf[100]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* lib-path in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in k1449 in k1416 in ... */
static void C_fcall f_3980(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3980,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3987,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[4],"win"))){
/* ##sys#peek-c-string */
t3=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_INSTALL_BIN_HOME),C_fix(0));}
else{
if(C_truep(C_retrieve2(lf[22],"host-mode"))){
/* ##sys#peek-c-string */
t3=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_INSTALL_LIB_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t3=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_TARGET_RUN_LIB_HOME),C_fix(0));}}}

/* k2024 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in ... */
static void C_ccall f_2025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:586: print */
t2=*((C_word*)lf[137]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4124 in linker-libraries in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in k1449 in ... */
static void C_fcall f_4125(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4125,NULL,2,t0,t1);}
t2=C_retrieve2(lf[94],"static");
if(C_truep(C_retrieve2(lf[94],"static"))){
t3=C_retrieve2(lf[94],"static");
t4=(C_truep(C_retrieve2(lf[94],"static"))?C_a_i_list1(&a,1,C_retrieve2(lf[71],"extra-libraries")):C_a_i_list1(&a,1,C_retrieve2(lf[72],"extra-shared-libraries")));
/* csc.scm:988: append */
t5=*((C_word*)lf[101]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[2],t1,t4);}
else{
t3=C_retrieve2(lf[95],"static-libs");
t4=(C_truep(C_retrieve2(lf[95],"static-libs"))?C_a_i_list1(&a,1,C_retrieve2(lf[71],"extra-libraries")):C_a_i_list1(&a,1,C_retrieve2(lf[72],"extra-shared-libraries")));
/* csc.scm:988: append */
t5=*((C_word*)lf[101]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[2],t1,t4);}}

/* k1590 in k1588 in k1585 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in ... */
static void C_ccall f_1592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:265: append */
t2=*((C_word*)lf[101]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* f_1593 in k1588 in k1585 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in ... */
static void C_ccall f_1593(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1593,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1595,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1601,a[2]=t6,a[3]=t4,a[4]=t7,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* csc.scm:281: string-split */
t9=C_fast_retrieve(lf[224]);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,t2,lf[225]);}

/* f_1595 */
static void C_ccall f_1595(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1595,3,t0,t1,t2);}
t3=*((C_word*)lf[119]+1);
/* csc.scm:281: g187 */
t4=*((C_word*)lf[119]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,lf[222],t2,lf[223]);}

/* k4681 in k1416 in k1412 in k1389 in k4690 in k4693 in k4696 in k4699 in k1368 in k1366 in k1364 in k1362 in k1360 in k1358 in k1356 in k1354 in k1352 */
static void C_ccall f_4682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4682,2,t0,t1);}
if(C_truep(C_retrieve2(lf[19],"chicken-prefix"))){
t2=C_a_i_list2(&a,2,C_retrieve2(lf[19],"chicken-prefix"),lf[413]);
/* csc.scm:88: make-pathname */
t3=C_fast_retrieve(lf[104]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,lf[414]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5839,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:92: normalize-pathname */
t3=C_fast_retrieve(lf[26]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}}

/* k2032 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in ... */
static void C_ccall f_2033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:590: exit */
t2=C_fast_retrieve(lf[13]);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k2737 in k2703 in k2701 in k2481 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in ... */
static void C_ccall f_2738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2738,2,t0,t1);}
t2=C_i_car(((C_word*)((C_word*)t0)[2])[1]);
t3=C_a_i_string_to_number(&a,2,t2,C_fix(10));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2744,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:746: t-options */
f_1722(t4,C_a_i_list(&a,2,((C_word*)t0)[6],t2));}

/* k2038 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in ... */
static void C_ccall f_2039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:589: system */
t2=C_fast_retrieve(lf[134]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4155 in k4146 in k4214 in k4208 in quote-option in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in ... */
static void C_ccall f_4156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:1013: string-append */
t2=*((C_word*)lf[119]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[120],t1,lf[121]);}

/* k4158 in k4214 in k4208 in quote-option in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in ... */
static void C_ccall f_4159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* list->string */
t2=C_fast_retrieve(lf[124]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4146 in k4214 in k4208 in quote-option in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in ... */
static void C_ccall f_4147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4147,2,t0,t1);}
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4156,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:1013: string-translate* */
t3=C_fast_retrieve(lf[122]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,lf[123]);}
else{
t2=t1;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k4004 in k3772 in k3754 in k3722 in k3720 in k3718 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in ... */
static void C_ccall f_4005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(C_i_string_equal_p(t1,lf[168]))){
/* csc.scm:958: lib-path */
f_3980(((C_word*)t0)[2]);}
else{
if(C_truep(C_retrieve2(lf[23],"cross-chicken"))){
t2=C_retrieve2(lf[22],"host-mode");
if(C_truep(C_retrieve2(lf[22],"host-mode"))){
/* csc.scm:958: lib-path */
f_3980(((C_word*)t0)[2]);}
else{
t3=t1;
t4=((C_word*)t0)[2];
f_4038(2,t4,t3);}}
else{
/* csc.scm:958: lib-path */
f_3980(((C_word*)t0)[2]);}}}

/* map-loop662 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in ... */
static void C_fcall f_3950(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3950,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3975,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5362,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:92: normalize-pathname */
t6=C_fast_retrieve(lf[26]);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* f5462 in k4657 in k1453 in k1449 in k1416 in k1412 in k1389 in k4690 in k4693 in k4696 in k4699 in k1368 in k1366 in k1364 in k1362 in k1360 in k1358 in k1356 in k1354 in k1352 */
static void C_ccall f5462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:92: qs */
t2=C_fast_retrieve(lf[25]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* f5467 in k4666 in k1449 in k1416 in k1412 in k1389 in k4690 in k4693 in k4696 in k4699 in k1368 in k1366 in k1364 in k1362 in k1360 in k1358 in k1356 in k1354 in k1352 */
static void C_ccall f5467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:92: qs */
t2=C_fast_retrieve(lf[25]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3947 in k3935 in k3933 in k3907 in k3861 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in ... */
static void C_ccall f_3948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3948,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5352,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:92: normalize-pathname */
t3=C_fast_retrieve(lf[26]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k3944 in k3935 in k3933 in k3907 in k3861 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in ... */
static void C_ccall f_3945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:895: display */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,((C_word*)t0)[3]);}

/* k3940 in k3937 in k3935 in k3933 in k3907 in k3861 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in ... */
static void C_ccall f_3942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:895: command */
f_4283(((C_word*)t0)[2],t1);}

/* f5472 in k4678 in k1416 in k1412 in k1389 in k4690 in k4693 in k4696 in k4699 in k1368 in k1366 in k1364 in k1362 in k1360 in k1358 in k1356 in k1354 in k1352 */
static void C_ccall f5472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:92: qs */
t2=C_fast_retrieve(lf[25]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2068 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in ... */
static void C_ccall f_2070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(&lf[77] /* (set! translate-options ...) */,t1);
t3=lf[94] /* static */ =C_SCHEME_TRUE;;
/* csc.scm:796: loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1796(t4,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}

/* f5442 in k4621 in k1469 in k1465 in k1461 in k1457 in k1453 in k1449 in k1416 in k1412 in k1389 in k4690 in k4693 in k4696 in k4699 in k1368 in k1366 in k1364 in k1362 in k1360 in k1358 in k1356 in ... */
static void C_ccall f5442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:92: qs */
t2=C_fast_retrieve(lf[25]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* f5447 in k4630 in k1465 in k1461 in k1457 in k1453 in k1449 in k1416 in k1412 in k1389 in k4690 in k4693 in k4696 in k4699 in k1368 in k1366 in k1364 in k1362 in k1360 in k1358 in k1356 in k1354 in ... */
static void C_ccall f5447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:92: qs */
t2=C_fast_retrieve(lf[25]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4678 in k1416 in k1412 in k1389 in k4690 in k4693 in k4696 in k4699 in k1368 in k1366 in k1364 in k1362 in k1360 in k1358 in k1356 in k1354 in k1352 */
static void C_ccall f_4679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4679,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5472,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:92: normalize-pathname */
t3=C_fast_retrieve(lf[26]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k4675 in k4672 in k1449 in k1416 in k1412 in k1389 in k4690 in k4693 in k4696 in k4699 in k1368 in k1366 in k1364 in k1362 in k1360 in k1358 in k1356 in k1354 in k1352 */
static void C_ccall f_4676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:101: make-pathname */
t2=C_fast_retrieve(lf[104]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* k4672 in k1449 in k1416 in k1412 in k1389 in k4690 in k4693 in k4696 in k4699 in k1368 in k1366 in k1364 in k1362 in k1360 in k1358 in k1356 in k1354 in k1352 */
static void C_ccall f_4673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4673,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4676,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_CHICKEN_PROGRAM),C_fix(0));}

/* k4669 in k1449 in k1416 in k1412 in k1389 in k4690 in k4693 in k4696 in k4699 in k1368 in k1366 in k1364 in k1362 in k1360 in k1358 in k1356 in k1354 in k1352 */
static void C_ccall f_4670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4670,2,t0,t1);}
if(C_truep(C_retrieve2(lf[19],"chicken-prefix"))){
t2=C_a_i_list2(&a,2,C_retrieve2(lf[19],"chicken-prefix"),lf[411]);
/* csc.scm:88: make-pathname */
t3=C_fast_retrieve(lf[104]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,lf[412]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5835,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:92: normalize-pathname */
t3=C_fast_retrieve(lf[26]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}}

/* k2079 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in ... */
static void C_ccall f_2081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(&lf[77] /* (set! translate-options ...) */,t1);
t3=lf[95] /* static-libs */ =C_SCHEME_TRUE;;
/* csc.scm:796: loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1796(t4,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}

/* f5452 in k4639 in k1461 in k1457 in k1453 in k1449 in k1416 in k1412 in k1389 in k4690 in k4693 in k4696 in k4699 in k1368 in k1366 in k1364 in k1362 in k1360 in k1358 in k1356 in k1354 in k1352 in ... */
static void C_ccall f5452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:92: qs */
t2=C_fast_retrieve(lf[25]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* f5457 in k4648 in k1457 in k1453 in k1449 in k1416 in k1412 in k1389 in k4690 in k4693 in k4696 in k4699 in k1368 in k1366 in k1364 in k1362 in k1360 in k1358 in k1356 in k1354 in k1352 */
static void C_ccall f5457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:92: qs */
t2=C_fast_retrieve(lf[25]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1842 in k1840 in k1838 in k1836 in k1834 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in ... */
static void C_ccall f_1843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1843,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1846,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* write-char/port */
t3=C_fast_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[3]);}

/* k1844 in k1842 in k1840 in k1838 in k1836 in k1834 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in ... */
static void C_ccall f_1846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1846,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1852,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:571: open-output-string */
t3=C_fast_retrieve(lf[111]);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1859 in k1857 in k1855 in k1853 in k1851 in k1844 in k1842 in k1840 in k1838 in k1836 in k1834 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in ... */
static void C_ccall f_1860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1860,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1863,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1869,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1872,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:575: string-append */
t5=*((C_word*)lf[119]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_retrieve2(lf[87],"target-filename"),lf[188]);}

/* k2743 in k2737 in k2703 in k2701 in k2481 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in ... */
static void C_ccall f_2744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
/* csc.scm:796: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1796(t4,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* k1874 in k1855 in k1853 in k1851 in k1844 in k1842 in k1840 in k1838 in k1836 in k1834 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in ... */
static void C_ccall f_1875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:571: display */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,((C_word*)t0)[3]);}

/* k1871 in k1859 in k1857 in k1855 in k1853 in k1851 in k1844 in k1842 in k1840 in k1838 in k1836 in k1834 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in ... */
static void C_ccall f_1872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1872,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5369,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:92: normalize-pathname */
t3=C_fast_retrieve(lf[26]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k2752 in k2703 in k2701 in k2481 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in ... */
static void C_fcall f_2754(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2754,NULL,2,t0,t1);}
if(C_truep(t1)){
/* csc.scm:749: t-options */
f_1722(((C_word*)t0)[3],C_a_i_list(&a,1,((C_word*)t0)[4]));}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2763,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=C_block_size(((C_word*)t0)[4]);
if(C_truep(C_fixnum_greaterp(t3,C_fix(1)))){
t4=C_subchar(((C_word*)t0)[4],C_fix(0));
t5=t2;
f_2763(t5,C_i_char_equalp(C_make_character(45),t4));}
else{
t4=t2;
f_2763(t4,C_SCHEME_FALSE);}}}

/* k1861 in k1859 in k1857 in k1855 in k1853 in k1851 in k1844 in k1842 in k1840 in k1838 in k1836 in k1834 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in ... */
static void C_ccall f_1863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1863,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1866,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:571: get-output-string */
t3=C_fast_retrieve(lf[108]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k1868 in k1859 in k1857 in k1855 in k1853 in k1851 in k1844 in k1842 in k1840 in k1838 in k1836 in k1834 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in ... */
static void C_ccall f_1869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:571: display */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,((C_word*)t0)[3]);}

/* k1864 in k1861 in k1859 in k1857 in k1855 in k1853 in k1851 in k1844 in k1842 in k1840 in k1838 in k1836 in k1834 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in ... */
static void C_ccall f_1866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:570: command */
f_4283(((C_word*)t0)[2],t1);}

/* f5296 in k4070 in k4068 in k4066 in k4064 in k4062 in copy-files in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in ... */
static void C_ccall f5296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:92: qs */
t2=C_fast_retrieve(lf[25]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2260 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in ... */
static void C_ccall f_2261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2261,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2265,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_car(((C_word*)((C_word*)t0)[2])[1]);
t4=C_a_i_list1(&a,1,t3);
/* csc.scm:642: append */
t5=*((C_word*)lf[101]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,C_retrieve2(lf[96],"required-extensions"),t4);}

/* k2266 in k2263 in k2260 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in ... */
static void C_ccall f_2267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)((C_word*)t0)[2])[1];
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,C_u_i_cdr(t2));
/* csc.scm:796: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1796(t4,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* k2263 in k2260 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in ... */
static void C_ccall f_2265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2265,2,t0,t1);}
t2=C_mutate(&lf[96] /* (set! required-extensions ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2267,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=C_i_car(((C_word*)((C_word*)t0)[2])[1]);
/* csc.scm:643: t-options */
f_1722(t3,C_a_i_list(&a,2,lf[289],t4));}

/* k2761 in k2752 in k2703 in k2701 in k2481 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in ... */
static void C_fcall f_2763(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2763,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_subchar(((C_word*)t0)[2],C_fix(1));
if(C_truep(C_i_char_equalp(C_make_character(108),t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2773,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=C_a_i_list1(&a,1,((C_word*)t0)[2]);
/* csc.scm:753: append */
t5=*((C_word*)lf[101]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,C_retrieve2(lf[86],"link-options"),t4);}
else{
t3=C_subchar(((C_word*)t0)[2],C_fix(1));
if(C_truep(C_i_char_equalp(C_make_character(76),t3))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2786,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=C_a_i_list1(&a,1,((C_word*)t0)[2]);
/* csc.scm:755: append */
t6=*((C_word*)lf[101]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,C_retrieve2(lf[86],"link-options"),t5);}
else{
t4=C_subchar(((C_word*)t0)[2],C_fix(1));
if(C_truep(C_i_char_equalp(C_make_character(73),t4))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2799,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t6=C_a_i_list1(&a,1,((C_word*)t0)[2]);
/* csc.scm:757: append */
t7=*((C_word*)lf[101]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,C_retrieve2(lf[80],"compile-options"),t6);}
else{
t5=C_subchar(((C_word*)t0)[2],C_fix(1));
if(C_truep(C_i_char_equalp(C_make_character(68),t5))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2814,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* csc.scm:759: substring */
t7=*((C_word*)lf[360]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[2],C_fix(2));}
else{
t6=C_subchar(((C_word*)t0)[2],C_fix(1));
if(C_truep(C_i_char_equalp(C_make_character(70),t6))){
if(C_truep(C_retrieve2(lf[3],"osx"))){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2827,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t8=C_a_i_list1(&a,1,((C_word*)t0)[2]);
/* csc.scm:762: append */
t9=*((C_word*)lf[101]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,C_retrieve2(lf[80],"compile-options"),t8);}
else{
/* csc.scm:796: loop */
t7=((C_word*)((C_word*)t0)[3])[1];
f_1796(t7,((C_word*)t0)[4],((C_word*)((C_word*)t0)[5])[1]);}}
else{
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2836,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t8=C_block_size(((C_word*)t0)[2]);
if(C_truep(C_fixnum_greaterp(t8,C_fix(3)))){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2927,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:763: substring */
t10=*((C_word*)lf[360]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t9,((C_word*)t0)[2],C_fix(0),C_fix(4));}
else{
t9=t7;
f_2836(t9,C_SCHEME_FALSE);}}}}}}}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2953,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* csc.scm:772: file-exists? */
t3=C_fast_retrieve(lf[157]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}}

/* k1891 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in ... */
static void C_ccall f_1892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1892,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1894,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_nullp(C_retrieve2(lf[53],"c-files")))){
t3=C_retrieve2(lf[57],"object-files");
/* csc.scm:547: last */
t4=C_fast_retrieve(lf[208]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,C_retrieve2(lf[57],"object-files"));}
else{
t3=C_retrieve2(lf[53],"c-files");
/* csc.scm:547: last */
t4=C_fast_retrieve(lf[208]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,C_retrieve2(lf[53],"c-files"));}}

/* k1893 in k1891 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in ... */
static void C_ccall f_1894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1894,2,t0,t1);}
if(C_truep(C_retrieve2(lf[87],"target-filename"))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
f_1815(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1901,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[93],"shared"))){
/* csc.scm:551: pathname-replace-extension */
t3=C_fast_retrieve(lf[199]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,C_retrieve2(lf[40],"shared-library-extension"));}
else{
/* csc.scm:552: pathname-replace-extension */
t3=C_fast_retrieve(lf[199]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,C_retrieve2(lf[38],"executable-extension"));}}}

/* k2859 in k2908 in k2911 in k2834 in k2761 in k2752 in k2703 in k2701 in k2481 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in ... */
static void C_ccall f_2861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
/* csc.scm:796: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1796(t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* k2771 in k2761 in k2752 in k2703 in k2701 in k2481 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in ... */
static void C_ccall f_2773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[86] /* (set! link-options ...) */,t1);
/* csc.scm:796: loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1796(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}

/* f_2863 in k2908 in k2911 in k2834 in k2761 in k2752 in k2703 in k2701 in k2481 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in ... */
static void C_ccall f_2863(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2863,3,t0,t1,t2);}
t3=C_a_i_string(&a,1,t2);
/* ##sys#string-append */
((C_proc4)C_fast_retrieve_symbol_proc(lf[113]))(4,*((C_word*)lf[113]+1),t1,lf[361],t3);}

/* k2703 in k2701 in k2481 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in ... */
static void C_fcall f_2704(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2704,NULL,2,t0,t1);}
t2=C_i_assq(((C_word*)t0)[2],lf[356]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2710,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:740: g391 */
t4=t3;
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[4],t2);}
else{
if(C_truep(C_i_memq(((C_word*)t0)[2],lf[357]))){
/* csc.scm:741: t-options */
f_1722(((C_word*)t0)[4],C_a_i_list(&a,1,((C_word*)t0)[6]));}
else{
if(C_truep(C_i_memq(((C_word*)t0)[2],lf[358]))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2738,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* csc.scm:743: check */
f_1730(t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1],C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2754,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[2],tmp=(C_word)a,a+=9,tmp);
t4=C_block_size(((C_word*)t0)[6]);
if(C_truep(C_fixnum_greaterp(t4,C_fix(2)))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3099,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:748: substring */
t6=*((C_word*)lf[360]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,((C_word*)t0)[6],C_fix(0),C_fix(2));}
else{
t5=t3;
f_2754(t5,C_SCHEME_FALSE);}}}}}

/* k2701 in k2481 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in ... */
static void C_fcall f_2702(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2702,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2704,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=((C_word*)t0)[2];
if(C_truep((C_truep(C_eqp(t3,lf[383]))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,lf[384]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t4=C_mutate(&lf[83] /* (set! compilation-optimization-options ...) */,C_retrieve2(lf[48],"best-compilation-optimization-options"));
t5=C_mutate(&lf[84] /* (set! linking-optimization-options ...) */,C_retrieve2(lf[50],"best-linking-optimization-options"));
t6=t2;
f_2704(t6,t5);}
else{
t4=t2;
f_2704(t4,C_SCHEME_UNDEFINED);}}

/* k2698 in k2694 in k2481 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in ... */
static void C_ccall f_2700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[52] /* (set! scheme-files ...) */,t1);
/* csc.scm:796: loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1796(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}

/* k2007 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in ... */
static void C_ccall f_2008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:584: exit */
t2=C_fast_retrieve(lf[13]);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* map-loop407 in k2908 in k2911 in k2834 in k2761 in k2752 in k2703 in k2701 in k2481 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in ... */
static void C_fcall f_2875(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2875,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2900,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* csc.scm:769: g413 */
t5=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2871 in k2908 in k2911 in k2834 in k2761 in k2752 in k2703 in k2701 in k2481 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in ... */
static void C_ccall f_2873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:769: append */
t2=*((C_word*)lf[101]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,((C_word*)((C_word*)t0)[3])[1]);}

/* f_2710 in k2703 in k2701 in k2481 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in ... */
static void C_ccall f_2710(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2710,3,t0,t1,t2);}
t3=C_i_cadr(t2);
t4=C_a_i_cons(&a,2,t3,((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k2018 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in ... */
static void C_ccall f_2019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:587: exit */
t2=C_fast_retrieve(lf[13]);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k3329 in k3325 in k3319 in k3313 in k3288 */
static void C_ccall f_3331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:814: append */
t2=*((C_word*)lf[101]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* map-loop485 in k3325 in k3319 in k3313 in k3288 */
static void C_fcall f_3333(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3333,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3358,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* csc.scm:821: g491 */
t5=C_retrieve2(lf[98],"quote-option");
f_4203(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1899 in k1893 in k1891 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in ... */
static void C_ccall f_1901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[87] /* (set! target-filename ...) */,t1);
t3=((C_word*)t0)[2];
f_1815(2,t3,t2);}

/* k3357 in map-loop485 in k3325 in k3319 in k3313 in k3288 */
static void C_ccall f_3358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3358,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_3333(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_3333(t6,((C_word*)t0)[5],t5);}}

/* f5332 in k3813 in k3811 in k3787 in k3720 in k3718 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in ... */
static void C_ccall f5332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:92: qs */
t2=C_fast_retrieve(lf[25]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* linker-libraries in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in k1449 in k1416 in ... */
static void C_fcall f_4115(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4115,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4122,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4125,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_retrieve2(lf[94],"static");
if(C_truep(C_retrieve2(lf[94],"static"))){
t5=C_retrieve2(lf[94],"static");
t6=t3;
f_4125(t6,(C_truep(C_retrieve2(lf[94],"static"))?C_retrieve2(lf[75],"library-files"):C_retrieve2(lf[76],"shared-library-files")));}
else{
t5=C_retrieve2(lf[95],"static-libs");
t6=t3;
f_4125(t6,(C_truep(C_retrieve2(lf[95],"static-libs"))?C_retrieve2(lf[75],"library-files"):C_retrieve2(lf[76],"shared-library-files")));}}

/* k1928 in k1926 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in ... */
static void C_fcall f_1929(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1929,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3286,tmp=(C_word)a,a+=2,tmp);
t3=C_retrieve2(lf[52],"scheme-files");
t4=C_i_check_list_2(C_retrieve2(lf[52],"scheme-files"),lf[151]);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3397,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3427,a[2]=t7,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_3427(t9,t5,C_retrieve2(lf[52],"scheme-files"));}

/* k1926 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in ... */
static void C_fcall f_1927(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1927,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1929,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[87],"target-filename"))){
t3=t2;
f_1929(t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1936,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[93],"shared"))){
t4=C_i_car(C_retrieve2(lf[52],"scheme-files"));
/* csc.scm:559: pathname-replace-extension */
t5=C_fast_retrieve(lf[199]);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_retrieve2(lf[40],"shared-library-extension"));}
else{
t4=C_i_car(C_retrieve2(lf[52],"scheme-files"));
/* csc.scm:560: pathname-replace-extension */
t5=C_fast_retrieve(lf[199]);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_retrieve2(lf[38],"executable-extension"));}}}

/* k4112 in linker-options in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in k1449 in ... */
static void C_ccall f_4113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:982: string-intersperse */
t2=C_fast_retrieve(lf[100]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* f5327 in k4321 in k4319 in k3790 in k3787 in k3720 in k3718 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in ... */
static void C_ccall f5327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:92: qs */
t2=C_fast_retrieve(lf[25]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3307 in k3288 */
static void C_ccall f_3308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:811: command */
f_4283(((C_word*)t0)[2],t1);}

/* k2784 in k2761 in k2752 in k2703 in k2701 in k2481 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in ... */
static void C_ccall f_2786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[86] /* (set! link-options ...) */,t1);
/* csc.scm:796: loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1796(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}

/* f5301 in k4066 in k4064 in k4062 in copy-files in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in ... */
static void C_ccall f5301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:92: qs */
t2=C_fast_retrieve(lf[25]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4099 in k4094 in linker-options in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in ... */
static void C_fcall f_4101(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* ##sys#string-append */
((C_proc4)C_fast_retrieve_symbol_proc(lf[113]))(4,*((C_word*)lf[113]+1),((C_word*)t0)[2],((C_word*)t0)[3],lf[114]);}
else{
/* ##sys#string-append */
((C_proc4)C_fast_retrieve_symbol_proc(lf[113]))(4,*((C_word*)lf[113]+1),((C_word*)t0)[2],((C_word*)t0)[3],lf[115]);}}

/* k3319 in k3313 in k3288 */
static void C_fcall f_3320(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3320,NULL,2,t0,t1);}
t2=C_fudge(C_fix(13));
t3=(C_truep(t2)?lf[211]:C_SCHEME_END_OF_LIST);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_retrieve2(lf[98],"quote-option");
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3326,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,a[5]=t7,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_retrieve2(lf[59],"cpp-mode"))){
/* csc.scm:822: append */
t10=*((C_word*)lf[101]+1);
((C_proc6)(void*)(*((C_word*)t10+1)))(6,t10,t9,C_retrieve2(lf[51],"extra-features"),C_retrieve2(lf[77],"translate-options"),lf[212],C_retrieve2(lf[82],"translation-optimization-options"));}
else{
if(C_truep(C_retrieve2(lf[60],"objc-mode"))){
/* csc.scm:822: append */
t10=*((C_word*)lf[101]+1);
((C_proc6)(void*)(*((C_word*)t10+1)))(6,t10,t9,C_retrieve2(lf[51],"extra-features"),C_retrieve2(lf[77],"translate-options"),lf[213],C_retrieve2(lf[82],"translation-optimization-options"));}
else{
/* csc.scm:822: append */
t10=*((C_word*)lf[101]+1);
((C_proc6)(void*)(*((C_word*)t10+1)))(6,t10,t9,C_retrieve2(lf[51],"extra-features"),C_retrieve2(lf[77],"translate-options"),C_SCHEME_END_OF_LIST,C_retrieve2(lf[82],"translation-optimization-options"));}}}

/* f5337 in k3718 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in ... */
static void C_ccall f5337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:92: qs */
t2=C_fast_retrieve(lf[25]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2797 in k2761 in k2752 in k2703 in k2701 in k2481 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in ... */
static void C_ccall f_2799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[80] /* (set! compile-options ...) */,t1);
/* csc.scm:796: loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1796(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}

/* k3310 in k3288 */
static void C_ccall f_3311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:812: string-intersperse */
t2=C_fast_retrieve(lf[100]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,lf[210]);}

/* check in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in k1449 in ... */
static void C_fcall f_1730(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1730,NULL,4,t1,t2,t3,t4);}
t5=C_i_length(t3);
if(C_truep(C_i_nullp(t4))){
if(C_truep(C_i_greater_or_equalp(t5,C_fix(1)))){
t6=C_SCHEME_UNDEFINED;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
/* csc.scm:514: quit */
f_1393(t1,lf[142],C_a_i_list(&a,1,t2));}}
else{
t6=C_i_car(t4);
if(C_truep(C_i_greater_or_equalp(t5,t6))){
t7=C_SCHEME_UNDEFINED;
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
/* csc.scm:514: quit */
f_1393(t1,lf[142],C_a_i_list(&a,1,t2));}}}

/* k3325 in k3319 in k3313 in k3288 */
static void C_ccall f_3326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3326,2,t0,t1);}
t2=C_i_check_list_2(t1,lf[99]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3331,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3333,a[2]=((C_word*)t0)[5],a[3]=t5,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_3333(t7,t3,t1);}

/* k1934 in k1926 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in ... */
static void C_ccall f_1936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[87] /* (set! target-filename ...) */,t1);
t3=((C_word*)t0)[2];
f_1929(t3,t2);}

/* k4330 in k4327 in k4325 in k4323 in k4321 in k4319 in k3790 in k3787 in k3720 in k3718 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in ... */
static void C_ccall f_4332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:1049: command */
f_4283(((C_word*)t0)[2],t1);}

/* k1726 in t-options in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in ... */
static void C_ccall f_1728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[77] /* (set! translate-options ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4334 in k4325 in k4323 in k4321 in k4319 in k3790 in k3787 in k3720 in k3718 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in ... */
static void C_ccall f_4335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:1050: display */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,((C_word*)t0)[3]);}

/* k4337 in k4325 in k4323 in k4321 in k4319 in k3790 in k3787 in k3720 in k3718 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in ... */
static void C_ccall f_4338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4338,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5322,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:92: normalize-pathname */
t3=C_fast_retrieve(lf[26]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k1400 in k1398 in k1396 in quit in k1389 in k4690 in k4693 in k4696 in k4699 in k1368 in k1366 in k1364 in k1362 in k1360 in k1358 in k1356 in k1354 in k1352 */
static void C_ccall f_1401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1401,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1404,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* write-char/port */
t3=C_fast_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),*((C_word*)lf[12]+1));}

/* t-options in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in k1449 in ... */
static void C_fcall f_1722(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1722,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1728,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:510: append */
t4=*((C_word*)lf[101]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_retrieve2(lf[77],"translate-options"),t2);}

/* k3316 in k3313 in k3288 */
static void C_ccall f_3317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:813: cons* */
t2=C_fast_retrieve(lf[125]);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],C_retrieve2(lf[28],"translator"),((C_word*)t0)[3],t1);}

/* k3313 in k3288 */
static void C_ccall f_3314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3314,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3317,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3320,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[92],"to-stdout"))){
t4=t3;
f_3320(t4,lf[214]);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3376,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=((C_word*)t0)[3];
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5411,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:92: normalize-pathname */
t7=C_fast_retrieve(lf[26]);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t5);}}

/* for-each-loop521 in k3395 in k1928 in k1926 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in ... */
static void C_fcall f_3407(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3407,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3416,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* csc.scm:833: g522 */
t5=C_retrieve2(lf[138],"$delete-file");
f_4298(3,t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4352 in k4350 in k4348 in k4346 in k3769 in k3757 in k3754 in k3722 in k3720 in k3718 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in ... */
static void C_ccall f_4353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4353,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4356,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4392,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* csc.scm:1059: file-exists? */
t4=C_fast_retrieve(lf[157]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t1);}

/* k4350 in k4348 in k4346 in k3769 in k3757 in k3754 in k3722 in k3720 in k3718 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in ... */
static void C_ccall f_4351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4351,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4353,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* csc.scm:1058: make-pathname */
t3=C_fast_retrieve(lf[104]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,lf[160]);}

/* k4354 in k4352 in k4350 in k4348 in k4346 in k3769 in k3757 in k3754 in k3722 in k3720 in k3718 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in ... */
static void C_ccall f_4356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4356,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4358,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:1063: make-pathname */
t3=C_fast_retrieve(lf[104]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[5],lf[158]);}

/* k1402 in k1400 in k1398 in k1396 in quit in k1389 in k4690 in k4693 in k4696 in k4699 in k1368 in k1366 in k1364 in k1362 in k1360 in k1358 in k1356 in k1354 in k1352 */
static void C_ccall f_1404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:79: exit */
t2=C_fast_retrieve(lf[13]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_fix(64));}

/* k4357 in k4354 in k4352 in k4350 in k4348 in k4346 in k3769 in k3757 in k3754 in k3722 in k3720 in k3718 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in ... */
static void C_ccall f_4358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4358,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4360,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4363,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* csc.scm:1064: file-exists? */
t4=C_fast_retrieve(lf[157]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t1);}

/* k3465 in k3452 */
static void C_ccall f_3466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:843: command */
f_4283(((C_word*)t0)[2],t1);}

/* k4340 in k4321 in k4319 in k3790 in k3787 in k3720 in k3718 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in ... */
static void C_ccall f_4341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:1050: display */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,((C_word*)t0)[3]);}

/* k4346 in k3769 in k3757 in k3754 in k3722 in k3720 in k3718 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in ... */
static void C_ccall f_4347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4347,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4349,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csc.scm:1056: make-pathname */
t3=C_fast_retrieve(lf[104]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[4],lf[162]);}

/* k4348 in k4346 in k3769 in k3757 in k3754 in k3722 in k3720 in k3718 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in ... */
static void C_ccall f_4349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4349,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4351,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csc.scm:1057: make-pathname */
t3=C_fast_retrieve(lf[104]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[5],lf[161]);}

/* k1409 in quit in k1389 in k4690 in k4693 in k4696 in k4699 in k1368 in k1366 in k1364 in k1362 in k1360 in k1358 in k1356 in k1354 in k1352 */
static void C_ccall f_1410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:77: display */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[12]+1));}

/* f5322 in k4337 in k4325 in k4323 in k4321 in k4319 in k3790 in k3787 in k3720 in k3718 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in ... */
static void C_ccall f5322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:92: qs */
t2=C_fast_retrieve(lf[25]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3454 in k3452 */
static void C_ccall f_3455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3455,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],C_retrieve2(lf[58],"generated-object-files"));
t3=C_mutate(&lf[58] /* (set! generated-object-files ...) */,t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* quotewrap in k1416 in k1412 in k1389 in k4690 in k4693 in k4696 in k4699 in k1368 in k1366 in k1364 in k1362 in k1360 in k1358 in k1356 in k1354 in k1352 */
static void C_ccall f_1440(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1440,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1447,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:92: normalize-pathname */
t4=C_fast_retrieve(lf[26]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k3452 */
static void C_ccall f_3453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3453,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3455,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3466,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_truep(C_retrieve2(lf[59],"cpp-mode"))?C_retrieve2(lf[30],"c++-compiler"):C_retrieve2(lf[29],"compiler"));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3475,a[2]=t4,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=((C_word*)t0)[4];
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5384,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:92: normalize-pathname */
t8=C_fast_retrieve(lf[26]);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t6);}

/* f_3450 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in ... */
static void C_ccall f_3450(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3450,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3453,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* csc.scm:842: pathname-replace-extension */
t4=C_fast_retrieve(lf[199]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,C_retrieve2(lf[34],"object-extension"));}

/* k1416 in k1412 in k1389 in k4690 in k4693 in k4696 in k4699 in k1368 in k1366 in k1364 in k1362 in k1360 in k1358 in k1356 in k1354 in k1352 */
static void C_ccall f_1418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1418,2,t0,t1);}
t2=C_mutate(&lf[20] /* (set! arguments ...) */,t1);
t3=C_i_member(lf[21],C_retrieve2(lf[20],"arguments"));
t4=C_mutate(&lf[22] /* (set! host-mode ...) */,t3);
t5=C_fudge(C_fix(39));
t6=C_mutate(&lf[23] /* (set! cross-chicken ...) */,t5);
t7=C_mutate(&lf[24] /* (set! quotewrap ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1440,tmp=(C_word)a,a+=2,tmp));
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1451,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4679,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4682,a[2]=t9,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[22],"host-mode"))){
/* ##sys#peek-c-string */
t11=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t10,C_mpointer(&a,(void*)C_INSTALL_SHARE_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t11=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t10,C_mpointer(&a,(void*)C_TARGET_SHARE_HOME),C_fix(0));}}

/* k1412 in k1389 in k4690 in k4693 in k4696 in k4699 in k1368 in k1366 in k1364 in k1362 in k1360 in k1358 in k1356 in k1354 in k1352 */
static void C_ccall f_1414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1414,2,t0,t1);}
t2=C_mutate(&lf[19] /* (set! chicken-prefix ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1418,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:82: command-line-arguments */
t4=C_fast_retrieve(lf[415]);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k4361 in k4357 in k4354 in k4352 in k4350 in k4348 in k4346 in k3769 in k3757 in k3754 in k3722 in k3720 in k3718 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in ... */
static void C_ccall f_4363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4363,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_3725(t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4365,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve2(lf[88],"verbose"))){
/* csc.scm:1065: print */
t3=*((C_word*)lf[137]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[156],((C_word*)t0)[6]);}
else{
t3=t2;
f_4365(2,t3,C_SCHEME_UNDEFINED);}}}

/* k4359 in k4357 in k4354 in k4352 in k4350 in k4348 in k4346 in k3769 in k3757 in k3754 in k3722 in k3720 in k3718 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in ... */
static void C_ccall f_4360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3725(t2,((C_word*)t0)[3]);}

/* k4364 in k4361 in k4357 in k4354 in k4352 in k4350 in k4348 in k4346 in k3769 in k3757 in k3754 in k3722 in k3720 in k3718 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in ... */
static void C_ccall f_4365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4365,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4370,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:1066: with-output-to-file */
t3=C_fast_retrieve(lf[155]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[4],t2);}

/* k2405 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in ... */
static void C_ccall f_2407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
/* csc.scm:796: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1796(t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* k3435 in for-each-loop465 in k1928 in k1926 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in ... */
static void C_ccall f_3436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3427(t3,((C_word*)t0)[4],t2);}

/* k1446 in quotewrap in k1416 in k1412 in k1389 in k4690 in k4693 in k4696 in k4699 in k1368 in k1366 in k1364 in k1362 in k1360 in k1358 in k1356 in k1354 in k1352 */
static void C_ccall f_1447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:92: qs */
t2=C_fast_retrieve(lf[25]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3375 in k3313 in k3288 */
static void C_ccall f_3376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3376,2,t0,t1);}
t2=((C_word*)t0)[2];
f_3320(t2,C_a_i_list(&a,2,lf[215],t1));}

/* k4301 in $delete-file in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in k1449 in ... */
static void C_ccall f_4302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(C_retrieve2(lf[66],"dry-run"))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* csc.scm:1045: delete-file */
t2=C_fast_retrieve(lf[139]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* k1449 in k1416 in k1412 in k1389 in k4690 in k4693 in k4696 in k4699 in k1368 in k1366 in k1364 in k1362 in k1360 in k1358 in k1356 in k1354 in k1352 */
static void C_ccall f_1451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1451,2,t0,t1);}
t2=C_mutate(&lf[27] /* (set! home ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1455,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4667,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4670,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4673,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t7=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_INSTALL_BIN_HOME),C_fix(0));}

/* k2425 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in ... */
static void C_ccall f_2427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
/* csc.scm:796: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1796(t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* k1465 in k1461 in k1457 in k1453 in k1449 in k1416 in k1412 in k1389 in k4690 in k4693 in k4696 in k4699 in k1368 in k1366 in k1364 in k1362 in k1360 in k1358 in k1356 in k1354 in k1352 */
static void C_ccall f_1467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1467,2,t0,t1);}
t2=C_mutate(&lf[31] /* (set! rc-compiler ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1471,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4631,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[22],"host-mode"))){
/* ##sys#peek-c-string */
t5=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_CC),C_fix(0));}
else{
/* ##sys#peek-c-string */
t5=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_CC),C_fix(0));}}

/* k3395 in k1928 in k1926 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in ... */
static void C_ccall f_3397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3397,2,t0,t1);}
if(C_truep(C_retrieve2(lf[89],"keep-files"))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
f_1815(2,t3,t2);}
else{
t2=C_retrieve2(lf[138],"$delete-file");
t3=C_i_check_list_2(C_SCHEME_END_OF_LIST,lf[151]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3407,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_3407(t7,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}}

/* k2435 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in ... */
static void C_ccall f_2437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
/* csc.scm:796: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1796(t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* k1453 in k1449 in k1416 in k1412 in k1389 in k4690 in k4693 in k4696 in k4699 in k1368 in k1366 in k1364 in k1362 in k1360 in k1358 in k1356 in k1354 in k1352 */
static void C_ccall f_1455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1455,2,t0,t1);}
t2=C_mutate(&lf[28] /* (set! translator ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1459,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4658,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[22],"host-mode"))){
/* ##sys#peek-c-string */
t5=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_CC),C_fix(0));}
else{
/* ##sys#peek-c-string */
t5=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_CC),C_fix(0));}}

/* k1457 in k1453 in k1449 in k1416 in k1412 in k1389 in k4690 in k4693 in k4696 in k4699 in k1368 in k1366 in k1364 in k1362 in k1360 in k1358 in k1356 in k1354 in k1352 */
static void C_ccall f_1459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1459,2,t0,t1);}
t2=C_mutate(&lf[29] /* (set! compiler ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1463,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4649,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[22],"host-mode"))){
/* ##sys#peek-c-string */
t5=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_CXX),C_fix(0));}
else{
/* ##sys#peek-c-string */
t5=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_CXX),C_fix(0));}}

/* k4325 in k4323 in k4321 in k4319 in k3790 in k3787 in k3720 in k3718 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in ... */
static void C_ccall f_4326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4326,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4329,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4335,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4338,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:1052: make-pathname */
t5=C_fast_retrieve(lf[104]);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_retrieve2(lf[27],"home"),lf[170]);}

/* k4323 in k4321 in k4319 in k3790 in k3787 in k3720 in k3718 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in ... */
static void C_ccall f_4324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4324,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4326,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* write-char/port */
t3=C_fast_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(32),((C_word*)t0)[4]);}

/* k4321 in k4319 in k3790 in k3787 in k3720 in k3718 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in ... */
static void C_ccall f_4322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4322,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4324,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4341,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5327,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:92: normalize-pathname */
t5=C_fast_retrieve(lf[26]);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[5]);}

/* k4319 in k3790 in k3787 in k3720 in k3718 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in ... */
static void C_ccall f_4320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4320,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4322,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* csc.scm:1050: display */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[171],t2);}

/* k3480 in k3477 in k3474 in k3452 */
static void C_fcall f_3481(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3481,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3484,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* csc.scm:853: compiler-options */
f_3658(t2);}

/* k3483 in k3480 in k3477 in k3474 in k3452 */
static void C_ccall f_3484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3484,2,t0,t1);}
t2=C_a_i_list6(&a,6,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],lf[194],((C_word*)t0)[5],t1);
/* csc.scm:844: string-intersperse */
t3=C_fast_retrieve(lf[100]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[6],t2);}

/* shared-build in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in k1449 in ... */
static void C_fcall f_1755(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1755,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1761,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csc.scm:517: cons* */
t4=C_fast_retrieve(lf[125]);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[147],lf[148],C_retrieve2(lf[77],"translate-options"));}

/* k4327 in k4325 in k4323 in k4321 in k4319 in k3790 in k3787 in k3720 in k3718 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in ... */
static void C_ccall f_4329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4329,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4332,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:1050: get-output-string */
t3=C_fast_retrieve(lf[108]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k1469 in k1465 in k1461 in k1457 in k1453 in k1449 in k1416 in k1412 in k1389 in k4690 in k4693 in k4696 in k4699 in k1368 in k1366 in k1364 in k1362 in k1360 in k1358 in k1356 in k1354 in k1352 in ... */
static void C_ccall f_1471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1471,2,t0,t1);}
t2=C_mutate(&lf[32] /* (set! linker ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1475,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4622,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[22],"host-mode"))){
/* ##sys#peek-c-string */
t5=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_CXX),C_fix(0));}
else{
/* ##sys#peek-c-string */
t5=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_CXX),C_fix(0));}}

/* k2445 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in ... */
static void C_ccall f_2447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
/* csc.scm:796: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1796(t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in k1449 in k1416 in k1412 in k1389 in k4690 in k4693 in k4696 in k4699 in k1368 in k1366 in k1364 in k1362 in k1360 in k1358 in k1356 in ... */
static void C_fcall f_1487(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1487,NULL,2,t0,t1);}
t2=C_mutate(&lf[42] /* (set! pic-options ...) */,t1);
t3=C_mutate(&lf[43] /* (set! windows-shell ...) */,C_mk_bool(C_WINDOWS_SHELL));
t4=lf[44] /* generate-manifest */ =C_SCHEME_FALSE;;
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1493,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[8],"cygwin"))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4610,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t7=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_INSTALL_LIB_NAME),C_fix(0));}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4616,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t7=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_INSTALL_LIB_NAME),C_fix(0));}}

/* k3474 in k3452 */
static void C_ccall f_3475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3475,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3478,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3494,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=((C_word*)t0)[4];
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5379,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:92: normalize-pathname */
t6=C_fast_retrieve(lf[26]);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}

/* k3477 in k3474 in k3452 */
static void C_ccall f_3478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3478,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3481,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve2(lf[59],"cpp-mode"))){
t3=C_i_string_equal_p(lf[195],C_retrieve2(lf[30],"c++-compiler"));
t4=t2;
f_3481(t4,(C_truep(t3)?lf[196]:lf[197]));}
else{
t3=t2;
f_3481(t3,lf[197]);}}

/* k3805 in k3787 in k3720 in k3718 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in ... */
static void C_ccall f_3806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:918: command */
f_4283(((C_word*)t0)[2],t1);}

/* k3808 in k3787 in k3720 in k3718 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in ... */
static void C_ccall f_3809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:919: string-append */
t2=*((C_word*)lf[119]+1);
((C_proc8)(void*)(*((C_word*)t2+1)))(8,t2,((C_word*)t0)[2],lf[172],C_retrieve2(lf[45],"libchicken"),lf[173],t1,lf[174],((C_word*)((C_word*)t0)[3])[1]);}

/* k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in k1449 in k1416 in k1412 in k1389 in k4690 in k4693 in k4696 in k4699 in k1368 in k1366 in k1364 in k1362 in k1360 in k1358 in k1356 in k1354 in ... */
static void C_ccall f_1475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1475,2,t0,t1);}
t2=C_mutate(&lf[33] /* (set! c++-linker ...) */,t1);
t3=C_mutate(&lf[34] /* (set! object-extension ...) */,lf[35]);
t4=C_mutate(&lf[36] /* (set! library-extension ...) */,lf[37]);
t5=C_mutate(&lf[38] /* (set! executable-extension ...) */,lf[39]);
t6=C_mutate(&lf[40] /* (set! shared-library-extension ...) */,C_fast_retrieve(lf[41]));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1487,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t8=C_retrieve2(lf[1],"mingw");
if(C_truep(C_retrieve2(lf[1],"mingw"))){
t9=C_retrieve2(lf[1],"mingw");
t10=t7;
f_1487(t10,(C_truep(C_retrieve2(lf[1],"mingw"))?lf[409]:lf[410]));}
else{
t9=C_retrieve2(lf[8],"cygwin");
t10=t7;
f_1487(t10,(C_truep(C_retrieve2(lf[8],"cygwin"))?lf[409]:lf[410]));}}

/* use-private-repository in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in k1449 in ... */
static C_word C_fcall f_1778(C_word *a){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_stack_overflow_check;
t1=C_a_i_cons(&a,2,lf[149],C_retrieve2(lf[80],"compile-options"));
t2=C_mutate(&lf[80] /* (set! compile-options ...) */,t1);
if(C_truep(C_retrieve2(lf[3],"osx"))){
t3=C_a_i_cons(&a,2,lf[150],C_retrieve2(lf[86],"link-options"));
t4=C_mutate(&lf[86] /* (set! link-options ...) */,t3);
return(t4);}
else{
t3=C_SCHEME_UNDEFINED;
return(t3);}}

/* k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in k1449 in k1416 in k1412 in k1389 in k4690 in k4693 in k4696 in k4699 in k1368 in k1366 in k1364 in k1362 in k1360 in k1358 in ... */
static void C_ccall f_1493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1493,2,t0,t1);}
t2=C_mutate(&lf[45] /* (set! libchicken ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1497,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:128: string-append */
t4=*((C_word*)lf[119]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,C_retrieve2(lf[45],"libchicken"),lf[405],C_retrieve2(lf[36],"library-extension"));}

/* k2465 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in ... */
static void C_ccall f_2467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
/* csc.scm:796: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1796(t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* k2138 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in ... */
static void C_ccall f_2139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:613: exit */
t2=C_fast_retrieve(lf[13]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_fix(0));}

/* k2395 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in ... */
static void C_ccall f_2397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
/* csc.scm:796: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1796(t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* k4376 */
static void C_ccall f_4377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:1067: g895 */
t2=*((C_word*)lf[137]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1763 in k1759 in shared-build in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in ... */
static void C_ccall f_1765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1765,2,t0,t1);}
t2=C_mutate(&lf[80] /* (set! compile-options ...) */,t1);
t3=(C_truep(C_retrieve2(lf[3],"osx"))?(C_truep(((C_word*)t0)[2])?C_a_i_cons(&a,2,lf[143],C_retrieve2(lf[86],"link-options")):C_a_i_cons(&a,2,lf[144],C_retrieve2(lf[86],"link-options"))):C_a_i_cons(&a,2,lf[145],C_retrieve2(lf[86],"link-options")));
t4=C_mutate(&lf[86] /* (set! link-options ...) */,t3);
t5=lf[93] /* shared */ =C_SCHEME_TRUE;;
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* f_4370 in k4364 in k4361 in k4357 in k4354 in k4352 in k4350 in k4348 in k4346 in k3769 in k3757 in k3754 in k3722 in k3720 in k3718 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in ... */
static void C_ccall f_4370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4370,2,t0,t1);}
t2=*((C_word*)lf[137]+1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4377,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=C_a_i_cons(&a,2,lf[152],C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,((C_word*)t0)[2],t4);
t6=C_a_i_cons(&a,2,lf[153],t5);
/* csc.scm:1054: ##sys#print-to-string */
((C_proc3)C_fast_retrieve_symbol_proc(lf[154]))(3,*((C_word*)lf[154]+1),t3,t6);}

/* k1759 in shared-build in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in ... */
static void C_ccall f_1761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1761,2,t0,t1);}
t2=C_mutate(&lf[77] /* (set! translate-options ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1765,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csc.scm:518: append */
t4=*((C_word*)lf[101]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,C_retrieve2(lf[42],"pic-options"),lf[146],C_retrieve2(lf[80],"compile-options"));}

/* k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in k1449 in k1416 in k1412 in k1389 in k4690 in k4693 in k4696 in k4699 in k1368 in k1366 in k1364 in k1362 in k1360 in ... */
static void C_ccall f_1497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1497,2,t0,t1);}
t2=C_mutate(&lf[46] /* (set! default-library ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1501,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4598,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[22],"host-mode"))){
/* ##sys#peek-c-string */
t5=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_CFLAGS),C_fix(0));}
else{
/* ##sys#peek-c-string */
t5=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_CFLAGS),C_fix(0));}}

/* k2314 in k2318 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in ... */
static void C_ccall f_2316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[86] /* (set! link-options ...) */,t1);
/* csc.scm:796: loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1796(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}

/* k2481 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in ... */
static void C_fcall f_2483(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2483,NULL,2,t0,t1);}
if(C_truep(t1)){
/* csc.scm:690: shared-build */
f_1755(((C_word*)t0)[3],C_SCHEME_FALSE);}
else{
t2=C_eqp(((C_word*)t0)[4],lf[335]);
t3=(C_truep(t2)?t2:C_eqp(((C_word*)t0)[4],lf[336]));
if(C_truep(t3)){
/* csc.scm:692: shared-build */
f_1755(((C_word*)t0)[3],C_SCHEME_TRUE);}
else{
t4=C_eqp(((C_word*)t0)[4],lf[337]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2505,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:694: check */
f_1730(t5,((C_word*)t0)[9],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t5=C_eqp(((C_word*)t0)[4],lf[338]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2521,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:698: check */
f_1730(t6,((C_word*)t0)[9],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t6=C_eqp(((C_word*)t0)[4],lf[339]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2537,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:702: check */
f_1730(t7,((C_word*)t0)[9],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t7=C_eqp(((C_word*)t0)[4],lf[340]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2553,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:706: check */
f_1730(t8,((C_word*)t0)[9],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t8=C_eqp(((C_word*)t0)[4],lf[341]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2569,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:710: check */
f_1730(t9,((C_word*)t0)[9],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t9=C_eqp(((C_word*)t0)[4],lf[343]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2587,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:713: check */
f_1730(t10,((C_word*)t0)[9],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t10=C_eqp(((C_word*)t0)[4],lf[344]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2611,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t12=C_a_i_list1(&a,1,lf[345]);
/* csc.scm:717: append */
t13=*((C_word*)lf[101]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t11,C_retrieve2(lf[86],"link-options"),t12);}
else{
t11=C_eqp(((C_word*)t0)[4],lf[346]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2622,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:719: check */
f_1730(t12,((C_word*)t0)[9],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t12=C_eqp(((C_word*)t0)[4],lf[347]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2644,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:723: check */
f_1730(t13,((C_word*)t0)[9],((C_word*)((C_word*)t0)[5])[1],C_SCHEME_END_OF_LIST);}
else{
t13=C_eqp(((C_word*)t0)[4],lf[352]);
if(C_truep(t13)){
/* csc.scm:796: loop */
t14=((C_word*)((C_word*)t0)[6])[1];
f_1796(t14,((C_word*)t0)[7],((C_word*)((C_word*)t0)[5])[1]);}
else{
t14=C_eqp(((C_word*)t0)[4],lf[353]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2696,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:731: make-pathname */
t16=C_fast_retrieve(lf[104]);
((C_proc5)(void*)(*((C_word*)t16+1)))(5,t16,t15,C_SCHEME_FALSE,lf[355],C_retrieve2(lf[38],"executable-extension"));}
else{
t15=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2702,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t16=C_eqp(((C_word*)t0)[9],lf[385]);
if(C_truep(t16)){
t17=lf[92] /* to-stdout */ =C_SCHEME_TRUE;;
t18=lf[90] /* translate-only */ =C_SCHEME_TRUE;;
t19=t15;
f_2702(t19,t18);}
else{
t17=t15;
f_2702(t17,C_SCHEME_UNDEFINED);}}}}}}}}}}}}}}}

/* k2318 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in ... */
static void C_ccall f_2319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2319,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_retrieve2(lf[57],"object-files"));
t3=C_mutate(&lf[57] /* (set! object-files ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2316,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:659: cons* */
t5=C_fast_retrieve(lf[125]);
((C_proc7)(void*)(*((C_word*)t5+1)))(7,t5,t4,lf[294],lf[295],lf[296],lf[297],C_retrieve2(lf[86],"link-options"));}

/* k4397 in k4390 in k4352 in k4350 in k4348 in k4346 in k3769 in k3757 in k3754 in k3722 in k3720 in k3718 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in ... */
static void C_ccall f_4398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:1060: copy-files */
f_4056(((C_word*)t0)[2],t1,((C_word*)t0)[3]);}

/* k4390 in k4352 in k4350 in k4348 in k4346 in k3769 in k3757 in k3754 in k3722 in k3720 in k3718 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in ... */
static void C_ccall f_4392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4392,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
f_4356(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4398,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csc.scm:1061: make-pathname */
t3=C_fast_retrieve(lf[104]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_retrieve2(lf[27],"home"),lf[159]);}}

/* k3848 in k3718 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in ... */
static void C_ccall f_3849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3849,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3852,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:915: linker-options */
f_4088(t2);}

/* k1461 in k1457 in k1453 in k1449 in k1416 in k1412 in k1389 in k4690 in k4693 in k4696 in k4699 in k1368 in k1366 in k1364 in k1362 in k1360 in k1358 in k1356 in k1354 in k1352 */
static void C_ccall f_1463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1463,2,t0,t1);}
t2=C_mutate(&lf[30] /* (set! c++-compiler ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1467,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4640,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[22],"host-mode"))){
/* ##sys#peek-c-string */
t5=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_RC_COMPILER),C_fix(0));}
else{
/* ##sys#peek-c-string */
t5=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_RC_COMPILER),C_fix(0));}}

/* k3842 in k3718 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in ... */
static void C_ccall f_3843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:910: cons* */
t2=C_fast_retrieve(lf[125]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* k2321 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in ... */
static void C_ccall f_2322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:654: make-pathname */
t2=C_fast_retrieve(lf[104]);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,lf[298],C_retrieve2(lf[34],"object-extension"));}

/* k2415 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in ... */
static void C_ccall f_2417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
/* csc.scm:796: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1796(t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* k2127 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in ... */
static void C_ccall f_2128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:612: exit */
t2=C_fast_retrieve(lf[13]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_fix(0));}

/* for-each-loop465 in k1928 in k1926 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in ... */
static void C_fcall f_3427(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3427,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3436,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* csc.scm:801: g466 */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3836 in k3718 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in ... */
static void C_ccall f_3837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:909: string-intersperse */
t2=C_fast_retrieve(lf[100]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3833 in k3718 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in ... */
static void C_ccall f_3834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:908: command */
f_4283(((C_word*)t0)[2],t1);}

/* k2172 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in ... */
static void C_ccall f_2174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2174,2,t0,t1);}
t2=C_mutate(&lf[80] /* (set! compile-options ...) */,t1);
t3=C_a_i_cons(&a,2,lf[268],C_retrieve2(lf[86],"link-options"));
t4=C_mutate(&lf[86] /* (set! link-options ...) */,t3);
t5=((C_word*)t0)[2];
f_2160(t5,t4);}

/* k3415 in for-each-loop521 in k3395 in k1928 in k1926 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in ... */
static void C_ccall f_3416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3407(t3,((C_word*)t0)[4],t2);}

/* k3823 in k3811 in k3787 in k3720 in k3718 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in ... */
static void C_ccall f_3824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:925: make-pathname */
t2=C_fast_retrieve(lf[104]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,((C_word*)t0)[3]);}

/* k3813 in k3811 in k3787 in k3720 in k3718 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in ... */
static void C_ccall f_3815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3815,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5332,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:92: normalize-pathname */
t3=C_fast_retrieve(lf[26]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k3811 in k3787 in k3720 in k3718 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in ... */
static void C_ccall f_3812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3812,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3815,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[69],"deployed"))){
/* csc.scm:924: make-pathname */
t3=C_fast_retrieve(lf[104]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[175],t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3824,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csc.scm:926: lib-path */
f_3980(t3);}}

/* k2455 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in ... */
static void C_ccall f_2457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
/* csc.scm:796: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1796(t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* k2159 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in ... */
static void C_fcall f_2160(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2160,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2162,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:621: t-options */
f_1722(t2,C_a_i_list(&a,1,lf[267]));}

/* k2161 in k2159 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in ... */
static void C_ccall f_2162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(C_retrieve2(lf[88],"verbose"))){
t2=lf[88] /* verbose */ =C_fix(2);;
/* csc.scm:796: loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1796(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}
else{
t2=lf[88] /* verbose */ =C_SCHEME_TRUE;;
/* csc.scm:796: loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1796(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}}

/* f5831 in k4553 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in k1449 in k1416 in k1412 in k1389 in k4690 in k4693 in ... */
static void C_ccall f5831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:92: qs */
t2=C_fast_retrieve(lf[25]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* f5839 in k4681 in k1416 in k1412 in k1389 in k4690 in k4693 in k4696 in k4699 in k1368 in k1366 in k1364 in k1362 in k1360 in k1358 in k1356 in k1354 in k1352 */
static void C_ccall f5839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:92: qs */
t2=C_fast_retrieve(lf[25]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* f5835 in k4669 in k1449 in k1416 in k1412 in k1389 in k4690 in k4693 in k4696 in k4699 in k1368 in k1366 in k1364 in k1362 in k1360 in k1358 in k1356 in k1354 in k1352 */
static void C_ccall f5835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:92: qs */
t2=C_fast_retrieve(lf[25]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* for-each-loop608 in k3542 in k3534 in k3530 in k3500 in k3497 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in ... */
static void C_fcall f_3551(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3551,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3560,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* csc.scm:874: g609 */
t5=C_retrieve2(lf[138],"$delete-file");
f_4298(3,t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3542 in k3534 in k3530 in k3500 in k3497 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in ... */
static void C_ccall f_3544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3544,2,t0,t1);}
t2=C_retrieve2(lf[138],"$delete-file");
t3=C_retrieve2(lf[56],"generated-rc-files");
t4=C_i_check_list_2(C_retrieve2(lf[56],"generated-rc-files"),lf[151]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3551,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_3551(t8,((C_word*)t0)[2],C_retrieve2(lf[56],"generated-rc-files"));}

/* k2385 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in ... */
static void C_ccall f_2387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
/* csc.scm:796: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1796(t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in k1449 in ... */
static void C_fcall f_1796(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1796,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1807,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csc.scm:534: append */
t4=*((C_word*)lf[101]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_retrieve2(lf[80],"compile-options"),C_retrieve2(lf[81],"builtin-compile-options"));}
else{
t3=C_i_car(t2);
t4=t2;
t5=C_u_i_cdr(t4);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1995,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t6,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[2],a[8]=((C_word*)t0)[6],a[9]=t3,tmp=(C_word)a,a+=10,tmp);
/* csc.scm:580: string->symbol */
t8=*((C_word*)lf[388]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t3);}}

/* f5389 in k3523 in k3504 */
static void C_ccall f5389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:92: qs */
t2=C_fast_retrieve(lf[25]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* f5384 in k3452 */
static void C_ccall f5384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:92: qs */
t2=C_fast_retrieve(lf[25]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3559 in for-each-loop608 in k3542 in k3534 in k3530 in k3500 in k3497 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in ... */
static void C_ccall f_3560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3551(t3,((C_word*)t0)[4],t2);}

/* f5394 in k3504 */
static void C_ccall f5394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:92: qs */
t2=C_fast_retrieve(lf[25]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3517 in k3504 */
static void C_ccall f_3518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:865: command */
f_4283(((C_word*)t0)[2],t1);}

/* k3497 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in ... */
static void C_ccall f_3499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3499,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3501,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3615,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[44],"generate-manifest"))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3636,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:857: software-type */
t5=C_fast_retrieve(lf[207]);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t3;
f_3615(t4,C_SCHEME_FALSE);}}

/* k3493 in k3474 in k3452 */
static void C_ccall f_3494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#string-append */
((C_proc4)C_fast_retrieve_symbol_proc(lf[113]))(4,*((C_word*)lf[113]+1),((C_word*)t0)[2],lf[198],t1);}

/* k3506 in k3504 */
static void C_ccall f_3507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3507,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],C_retrieve2(lf[58],"generated-object-files"));
t3=C_mutate(&lf[58] /* (set! generated-object-files ...) */,t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k3504 */
static void C_ccall f_3505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3505,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3507,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3518,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3524,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=((C_word*)t0)[4];
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5394,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:92: normalize-pathname */
t7=C_fast_retrieve(lf[26]);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t5);}

/* k2344 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in ... */
static void C_ccall f_2345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2345,2,t0,t1);}
if(C_truep(C_retrieve2(lf[3],"osx"))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2355,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_i_car(((C_word*)((C_word*)t0)[2])[1]);
/* csc.scm:669: cons* */
t4=C_fast_retrieve(lf[125]);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,lf[302],t3,C_retrieve2(lf[86],"link-options"));}
else{
t2=C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
/* csc.scm:796: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1796(t4,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}}

/* k3500 in k3497 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in ... */
static void C_fcall f_3501(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3501,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3502,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_retrieve2(lf[54],"rc-files");
t4=C_i_check_list_2(C_retrieve2(lf[54],"rc-files"),lf[151]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3532,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3594,a[2]=t7,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_3594(t9,t5,C_retrieve2(lf[54],"rc-files"));}

/* f_3502 in k3500 in k3497 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in ... */
static void C_ccall f_3502(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3502,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3505,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* csc.scm:864: string-append */
t4=*((C_word*)lf[119]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,t2,lf[200],C_retrieve2(lf[34],"object-extension"));}

/* k2972 */
static void C_ccall f_2974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[52] /* (set! scheme-files ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* f5374 in k1855 in k1853 in k1851 in k1844 in k1842 in k1840 in k1838 in k1836 in k1834 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in ... */
static void C_ccall f5374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:92: qs */
t2=C_fast_retrieve(lf[25]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* f5379 in k3474 in k3452 */
static void C_ccall f5379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:92: qs */
t2=C_fast_retrieve(lf[25]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3534 in k3530 in k3500 in k3497 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in ... */
static void C_ccall f_3536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3536,2,t0,t1);}
t2=C_mutate(&lf[57] /* (set! object-files ...) */,t1);
if(C_truep(C_retrieve2(lf[89],"keep-files"))){
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[2];
f_1822(2,t4,t3);}
else{
t3=C_retrieve2(lf[138],"$delete-file");
t4=C_retrieve2(lf[55],"generated-c-files");
t5=C_i_check_list_2(C_retrieve2(lf[55],"generated-c-files"),lf[151]);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3544,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3571,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t10=((C_word*)t8)[1];
f_3571(t10,t6,C_retrieve2(lf[55],"generated-c-files"));}}

/* k2353 in k2344 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in ... */
static void C_ccall f_2355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(&lf[86] /* (set! link-options ...) */,t1);
t3=C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
/* csc.scm:796: loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_1796(t5,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* k2116 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in ... */
static void C_ccall f_2117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:611: exit */
t2=C_fast_retrieve(lf[13]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_fix(0));}

/* k3530 in k3500 in k3497 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in ... */
static void C_ccall f_3532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3532,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3536,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3592,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:871: reverse */
t4=*((C_word*)lf[201]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)((C_word*)t0)[3])[1]);}

/* k4261 in k4246 in k4244 in k4242 in command in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in ... */
static void C_ccall f_4262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4262,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4264,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:1033: write */
t3=*((C_word*)lf[132]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[5],((C_word*)t0)[3]);}

/* f5342 in k3867 in k3864 in k3861 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in ... */
static void C_ccall f5342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:92: qs */
t2=C_fast_retrieve(lf[25]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4267 in k4265 in k4263 in k4261 in k4246 in k4244 in k4242 in command in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in ... */
static void C_ccall f_4268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=C_fast_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(10),((C_word*)t0)[3]);}

/* f5347 in k3930 in k3918 in k3916 in k3910 in k3907 in k3861 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in ... */
static void C_ccall f5347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:92: qs */
t2=C_fast_retrieve(lf[25]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4265 in k4263 in k4261 in k4246 in k4244 in k4242 in command in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in ... */
static void C_ccall f_4266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4266,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4268,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csc.scm:1033: display */
t3=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[4],((C_word*)t0)[3]);}

/* k4263 in k4261 in k4246 in k4244 in k4242 in command in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in ... */
static void C_ccall f_4264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4264,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4266,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:1033: display */
t3=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[131],((C_word*)t0)[3]);}

/* k3526 in k3523 in k3504 */
static void C_ccall f_3527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3527,2,t0,t1);}
t2=C_a_i_list3(&a,3,C_retrieve2(lf[31],"rc-compiler"),((C_word*)t0)[2],t1);
/* csc.scm:866: string-intersperse */
t3=C_fast_retrieve(lf[100]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[3],t2);}

/* k3523 in k3504 */
static void C_ccall f_3524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3524,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3527,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[3];
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5389,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:92: normalize-pathname */
t5=C_fast_retrieve(lf[26]);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* k2367 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in ... */
static void C_ccall f_2368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=C_i_car(((C_word*)((C_word*)t0)[2])[1]);
t3=C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=C_mutate(&lf[87] /* (set! target-filename ...) */,t2);
/* csc.scm:796: loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_1796(t6,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* f5352 in k3947 in k3935 in k3933 in k3907 in k3861 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in ... */
static void C_ccall f5352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:92: qs */
t2=C_fast_retrieve(lf[25]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* $delete-file in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in k1449 in k1416 in ... */
static void C_ccall f_4298(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4298,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4302,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[88],"verbose"))){
/* csc.scm:1044: print */
t4=*((C_word*)lf[137]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[140],t2);}
else{
if(C_truep(C_retrieve2(lf[66],"dry-run"))){
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
/* csc.scm:1045: delete-file */
t4=C_fast_retrieve(lf[139]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t2);}}}

/* f5357 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in ... */
static void C_ccall f5357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:92: qs */
t2=C_fast_retrieve(lf[25]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* f_2963 in k2951 in k2761 in k2752 in k2703 in k2701 in k2481 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in ... */
static void C_ccall f_2963(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2963,5,t0,t1,t2,t3,t4);}
t5=t4;
if(C_truep(t5)){
t6=t4;
if(C_truep((C_truep(C_i_equalp(t6,lf[368]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t6,lf[369]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2987,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t8=C_a_i_list1(&a,1,((C_word*)t0)[2]);
/* csc.scm:777: append */
t9=*((C_word*)lf[101]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,C_retrieve2(lf[53],"c-files"),t8);}
else{
if(C_truep(C_i_string_ci_equal_p(t4,lf[370]))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3000,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t8=C_a_i_list1(&a,1,((C_word*)t0)[2]);
/* csc.scm:779: append */
t9=*((C_word*)lf[101]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,C_retrieve2(lf[54],"rc-files"),t8);}
else{
t7=t4;
if(C_truep((C_truep(C_i_equalp(t7,lf[371]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t7,lf[372]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t7,lf[373]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t7,lf[374]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t7,lf[375]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))))){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3011,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[3],"osx"))){
t9=C_a_i_cons(&a,2,lf[376],C_retrieve2(lf[80],"compile-options"));
t10=C_mutate(&lf[80] /* (set! compile-options ...) */,t9);
t11=t8;
f_3011(t11,t10);}
else{
t9=t8;
f_3011(t9,C_SCHEME_UNDEFINED);}}
else{
t8=t4;
if(C_truep((C_truep(C_i_equalp(t8,lf[377]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t8,lf[378]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t8,lf[379]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))){
t9=lf[60] /* objc-mode */ =C_SCHEME_TRUE;;
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3034,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t11=C_a_i_list1(&a,1,((C_word*)t0)[2]);
/* csc.scm:786: append */
t12=*((C_word*)lf[101]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t10,C_retrieve2(lf[53],"c-files"),t11);}
else{
t9=C_retrieve2(lf[34],"object-extension");
t10=C_u_i_string_equal_p(t4,C_retrieve2(lf[34],"object-extension"));
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3045,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t10)){
t12=t11;
f_3045(t12,t10);}
else{
t12=C_retrieve2(lf[36],"library-extension");
t13=t11;
f_3045(t13,C_u_i_string_equal_p(t4,C_retrieve2(lf[36],"library-extension")));}}}}}}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2974,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t7=C_a_i_list1(&a,1,((C_word*)t0)[2]);
/* csc.scm:775: append */
t8=*((C_word*)lf[101]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,C_retrieve2(lf[52],"scheme-files"),t7);}}

/* k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in k1449 in k1416 in k1412 in k1389 in k4690 in k4693 in ... */
static void C_ccall f_4536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4536,2,t0,t1);}
t2=C_a_i_list1(&a,1,t1);
t3=C_mutate(&lf[74] /* (set! default-shared-library-files ...) */,t2);
t4=C_mutate(&lf[75] /* (set! library-files ...) */,C_retrieve2(lf[73],"default-library-files"));
t5=C_mutate(&lf[76] /* (set! shared-library-files ...) */,C_retrieve2(lf[74],"default-shared-library-files"));
t6=lf[77] /* translate-options */ =C_SCHEME_END_OF_LIST;;
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1560,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4524,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:236: make-pathname */
t9=C_fast_retrieve(lf[104]);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,lf[400],lf[401]);}

/* k4538 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in k1449 in k1416 in k1412 in k1389 in k4690 in k4693 in ... */
static void C_ccall f_4539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:227: string-append */
t2=*((C_word*)lf[119]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[402],t1);}

/* command in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in k1449 in k1416 in ... */
static void C_fcall f_4283(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4283,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4243,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[88],"verbose"))){
/* csc.scm:1027: print */
t4=*((C_word*)lf[137]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}
else{
t4=t3;
f_4243(2,t4,C_SCHEME_UNDEFINED);}}

/* k2105 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in ... */
static void C_ccall f_2106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:610: exit */
t2=C_fast_retrieve(lf[13]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_fix(0));}

/* compiler-options in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in k1449 in k1416 in ... */
static void C_fcall f_3658(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3658,NULL,1,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_retrieve2(lf[98],"quote-option");
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3665,a[2]=t1,a[3]=t5,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t8=C_retrieve2(lf[94],"static");
t9=(C_truep(C_retrieve2(lf[94],"static"))?C_retrieve2(lf[94],"static"):C_retrieve2(lf[95],"static-libs"));
if(C_truep(t9)){
/* csc.scm:879: append */
t10=*((C_word*)lf[101]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t7,C_SCHEME_END_OF_LIST,C_retrieve2(lf[83],"compilation-optimization-options"),C_retrieve2(lf[80],"compile-options"));}
else{
/* csc.scm:879: append */
t10=*((C_word*)lf[101]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t7,C_SCHEME_END_OF_LIST,C_retrieve2(lf[83],"compilation-optimization-options"),C_retrieve2(lf[80],"compile-options"));}}

/* k4559 in k4556 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in k1449 in k1416 in k1412 in k1389 in k4690 in k4693 in ... */
static void C_ccall f_4560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:222: string-append */
t2=*((C_word*)lf[119]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* f_4232 in quote-option in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in k1449 in ... */
static void C_ccall f_4232(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4232,3,t0,t1,t2);}
t3=*((C_word*)lf[128]+1);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_i_char_equalp(C_make_character(34),t2));}

/* k2985 */
static void C_ccall f_2987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[53] /* (set! c-files ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4550 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in k1449 in k1416 in k1412 in k1389 in k4690 in k4693 in k4696 in ... */
static void C_ccall f_4551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4551,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5437,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:92: normalize-pathname */
t3=C_fast_retrieve(lf[26]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k4553 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in k1449 in k1416 in k1412 in k1389 in k4690 in k4693 in k4696 in ... */
static void C_ccall f_4554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4554,2,t0,t1);}
t2=C_retrieve2(lf[46],"default-library");
if(C_truep(C_retrieve2(lf[19],"chicken-prefix"))){
t3=C_a_i_list2(&a,2,C_retrieve2(lf[19],"chicken-prefix"),lf[403]);
/* csc.scm:88: make-pathname */
t4=C_fast_retrieve(lf[104]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t3,C_retrieve2(lf[46],"default-library"));}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5831,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:92: normalize-pathname */
t4=C_fast_retrieve(lf[26]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t1);}}

/* k4556 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in k1449 in k1416 in k1412 in k1389 in k4690 in k4693 in k4696 in ... */
static void C_ccall f_4557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4557,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4560,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=C_retrieve2(lf[46],"default-library");
/* ##sys#string-append */
((C_proc4)C_fast_retrieve_symbol_proc(lf[113]))(4,*((C_word*)lf[113]+1),t2,lf[404],C_retrieve2(lf[46],"default-library"));}

/* f_4221 in k4208 in quote-option in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in ... */
static void C_ccall f_4221(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4221,3,t0,t1,t2);}
t3=C_u_i_char_whitespacep(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t3:C_i_memq(t2,lf[117])));}

/* k3635 in k3497 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in ... */
static void C_ccall f_3636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3615(t2,C_eqp(lf[206],t1));}

/* k1963 in k1961 in k1959 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in ... */
static void C_ccall f_1964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1964,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1966,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:541: newline */
t3=*((C_word*)lf[220]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* for-each-loop541 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in ... */
static void C_fcall f_3638(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3638,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3647,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* csc.scm:838: g542 */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1961 in k1959 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in ... */
static void C_ccall f_1962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1962,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1964,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[65],"show-libs"))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1975,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:540: linker-libraries */
f_4115(t3);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5424,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:541: newline */
t4=*((C_word*)lf[220]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1965 in k1963 in k1961 in k1959 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in ... */
static void C_ccall f_1966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:542: exit */
t2=C_fast_retrieve(lf[13]);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in ... */
static void C_ccall f_1811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1811,2,t0,t1);}
t2=C_mutate(&lf[86] /* (set! link-options ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1813,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[62],"inquiry-only"))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1960,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[63],"show-cflags"))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1987,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:538: compiler-options */
f_3658(t5);}
else{
t5=t4;
f_1960(2,t5,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_1813(2,t4,C_SCHEME_UNDEFINED);}}

/* k1959 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in ... */
static void C_ccall f_1960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1960,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1962,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[64],"show-ldflags"))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1981,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:539: linker-options */
f_4088(t3);}
else{
t3=t2;
f_1962(2,t3,C_SCHEME_UNDEFINED);}}

/* k3629 in k3616 in k3613 in k3497 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in ... */
static void C_ccall f_3630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3630,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4404,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve2(lf[88],"verbose"))){
/* csc.scm:1089: print */
t4=*((C_word*)lf[137]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[204],t2);}
else{
t4=t3;
f_4404(2,t4,C_SCHEME_UNDEFINED);}}

/* k3591 in k3530 in k3500 in k3497 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in ... */
static void C_ccall f_3592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:871: append */
t2=*((C_word*)lf[101]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_retrieve2(lf[57],"object-files"));}

/* for-each-loop570 in k3500 in k3497 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in ... */
static void C_fcall f_3594(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3594,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3603,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* csc.scm:862: g571 */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3664 in compiler-options in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in k1449 in ... */
static void C_ccall f_3665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3665,2,t0,t1);}
t2=C_i_check_list_2(t1,lf[99]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3670,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3672,a[2]=((C_word*)t0)[3],a[3]=t5,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_3672(t7,t3,t1);}

/* k4242 in command in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in k1449 in ... */
static void C_ccall f_4243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4243,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4245,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[43],"windows-shell"))){
/* csc.scm:1029: string-append */
t3=*((C_word*)lf[119]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[135],((C_word*)t0)[3],lf[136]);}
else{
t3=t2;
f_4245(2,t3,((C_word*)t0)[3]);}}

/* k4244 in k4242 in command in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in ... */
static void C_ccall f_4245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4245,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4247,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[66],"dry-run"))){
t3=t2;
f_4247(2,t3,C_fix(0));}
else{
/* csc.scm:1031: system */
t3=C_fast_retrieve(lf[134]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}}

/* k4246 in k4244 in k4242 in command in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in ... */
static void C_ccall f_4247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4247,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4249,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=t1;
t4=C_eqp(t3,C_fix(0));
if(C_truep(t4)){
t5=t2;
f_4249(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=*((C_word*)lf[130]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4262,a[2]=t2,a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* csc.scm:1033: display */
t7=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,lf[133],*((C_word*)lf[130]+1));}}

/* k4248 in k4246 in k4244 in k4242 in command in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in ... */
static void C_ccall f_4249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
t2=((C_word*)t0)[2];
t3=C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=lf[129] /* last-exit-code */ =C_fix(0);;
t5=C_retrieve2(lf[129],"last-exit-code");
if(C_truep(C_i_zerop(C_retrieve2(lf[129],"last-exit-code")))){
t6=C_SCHEME_UNDEFINED;
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
/* csc.scm:1040: exit */
t6=C_fast_retrieve(lf[13]);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,((C_word*)t0)[3],C_retrieve2(lf[129],"last-exit-code"));}}
else{
t4=lf[129] /* last-exit-code */ =C_fix(1);;
t5=C_retrieve2(lf[129],"last-exit-code");
if(C_truep(C_i_zerop(C_retrieve2(lf[129],"last-exit-code")))){
t6=C_SCHEME_UNDEFINED;
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
/* csc.scm:1040: exit */
t6=C_fast_retrieve(lf[13]);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,((C_word*)t0)[3],C_retrieve2(lf[129],"last-exit-code"));}}}

/* k3579 in for-each-loop591 in k3534 in k3530 in k3500 in k3497 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in ... */
static void C_ccall f_3580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3571(t3,((C_word*)t0)[4],t2);}

/* k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in ... */
static void C_fcall f_1817(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1817,NULL,2,t0,t1);}
if(C_truep(C_retrieve2(lf[90],"translate-only"))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1822,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3450,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=C_retrieve2(lf[53],"c-files");
t7=C_i_check_list_2(C_retrieve2(lf[53],"c-files"),lf[151]);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3499,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3638,a[2]=t10,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t12=((C_word*)t10)[1];
f_3638(t12,t8,C_retrieve2(lf[53],"c-files"));}}

/* k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in ... */
static void C_ccall f_1813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1813,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1815,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(C_retrieve2(lf[52],"scheme-files")))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1892,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_nullp(C_retrieve2(lf[53],"c-files")))){
if(C_truep(C_i_nullp(C_retrieve2(lf[57],"object-files")))){
/* csc.scm:546: quit */
f_1393(t3,lf[209],C_SCHEME_END_OF_LIST);}
else{
t4=t3;
f_1892(2,t4,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_1892(2,t4,C_SCHEME_UNDEFINED);}}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1927,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_truep(C_retrieve2(lf[93],"shared"))?C_i_not(C_retrieve2(lf[61],"embedded")):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=C_a_i_cons(&a,2,lf[219],C_retrieve2(lf[77],"translate-options"));
t6=C_mutate(&lf[77] /* (set! translate-options ...) */,t5);
t7=t3;
f_1927(t7,t6);}
else{
t5=t3;
f_1927(t5,C_SCHEME_UNDEFINED);}}}

/* k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in ... */
static void C_ccall f_1815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1815,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1817,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[68],"deploy"))){
t3=C_retrieve2(lf[93],"shared");
t4=t2;
f_1817(t4,(C_truep(C_retrieve2(lf[93],"shared"))?C_SCHEME_UNDEFINED:f_1778(C_a_i(&a,6))));}
else{
t3=t2;
f_1817(t3,C_SCHEME_UNDEFINED);}}

/* k3616 in k3613 in k3497 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in ... */
static void C_ccall f_3617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3617,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3619,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3630,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csc.scm:859: pathname-file */
t4=C_fast_retrieve(lf[164]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,C_retrieve2(lf[87],"target-filename"));}

/* k3618 in k3616 in k3613 in k3497 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in ... */
static void C_ccall f_3619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3619,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[2],C_retrieve2(lf[54],"rc-files"));
t3=C_mutate(&lf[54] /* (set! rc-files ...) */,t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[2],C_retrieve2(lf[56],"generated-rc-files"));
t5=C_mutate(&lf[56] /* (set! generated-rc-files ...) */,t4);
t6=((C_word*)t0)[3];
f_3501(t6,t5);}

/* k4523 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in k1449 in k1416 in k1412 in k1389 in k4690 in ... */
static void C_ccall f_4524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4524,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4527,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[22],"host-mode"))){
/* ##sys#peek-c-string */
t3=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_INSTALL_INCLUDE_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t3=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_TARGET_INCLUDE_HOME),C_fix(0));}}

/* k3613 in k3497 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in ... */
static void C_fcall f_3615(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3615,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3617,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:858: pathname-replace-extension */
t3=C_fast_retrieve(lf[199]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_retrieve2(lf[87],"target-filename"),lf[205]);}
else{
t2=((C_word*)t0)[2];
f_3501(t2,C_SCHEME_UNDEFINED);}}

/* k1986 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in ... */
static void C_ccall f_1987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:538: print* */
t2=*((C_word*)lf[221]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_make_character(32));}

/* k1980 in k1959 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in ... */
static void C_ccall f_1981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:539: print* */
t2=*((C_word*)lf[221]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_make_character(32));}

/* k4526 in k4523 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in k1449 in k1416 in k1412 in k1389 in ... */
static void C_ccall f_4527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4527,2,t0,t1);}
t2=((C_word*)t0)[2];
if(C_truep(C_retrieve2(lf[19],"chicken-prefix"))){
t3=C_a_i_list2(&a,2,C_retrieve2(lf[19],"chicken-prefix"),t2);
/* csc.scm:88: make-pathname */
t4=C_fast_retrieve(lf[104]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[3],t3,lf[399]);}
else{
t3=((C_word*)t0)[3];
f_1560(2,t3,t1);}}

/* k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in ... */
static void C_ccall f_1807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1807,2,t0,t1);}
t2=C_mutate(&lf[80] /* (set! compile-options ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1811,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1990,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1586,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[9],"elf"))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1643,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:268: conc */
t7=C_fast_retrieve(lf[228]);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,lf[234],C_retrieve2(lf[85],"library-dir"),lf[235]);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1673,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:278: conc */
t7=C_fast_retrieve(lf[228]);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,lf[236],C_retrieve2(lf[85],"library-dir"),lf[237]);}}

/* k3646 in for-each-loop541 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in ... */
static void C_ccall f_3647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3638(t3,((C_word*)t0)[4],t2);}

/* k4514 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in k1449 in k1416 in k1412 in k1389 in ... */
static void C_ccall f_4515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4515,2,t0,t1);}
t2=((C_word*)t0)[2];
f_4458(t2,C_a_i_list1(&a,1,t1));}

/* k1974 in k1961 in k1959 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in ... */
static void C_ccall f_1975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:540: print* */
t2=*((C_word*)lf[221]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_make_character(32));}

/* k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in ... */
static void C_ccall f_1822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1822,2,t0,t1);}
if(C_truep(C_retrieve2(lf[91],"compile-only"))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1827,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_member(C_retrieve2(lf[87],"target-filename"),C_retrieve2(lf[52],"scheme-files")))){
t3=*((C_word*)lf[130]+1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1835,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* csc.scm:568: display */
t5=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,lf[193],*((C_word*)lf[130]+1));}
else{
t3=t2;
f_1827(2,t3,C_SCHEME_UNDEFINED);}}}

/* k1838 in k1836 in k1834 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in ... */
static void C_ccall f_1839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1839,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1841,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csc.scm:568: display */
t3=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_retrieve2(lf[87],"target-filename"),((C_word*)t0)[3]);}

/* k3880 in k3877 in k3871 in k3867 in k3864 in k3861 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in ... */
static void C_ccall f_3881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:907: create-directory */
t2=C_fast_retrieve(lf[178]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1]);}

/* k1836 in k1834 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in ... */
static void C_ccall f_1837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1837,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1839,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csc.scm:568: display */
t3=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[192],((C_word*)t0)[3]);}

/* k1834 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in ... */
static void C_ccall f_1835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1835,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1837,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csc.scm:568: display */
t3=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_retrieve2(lf[87],"target-filename"),((C_word*)t0)[3]);}

/* k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in k1449 in k1416 in k1412 in k1389 in k4690 in k4693 in k4696 in ... */
static void C_ccall f_4548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4548,2,t0,t1);}
t2=C_a_i_list1(&a,1,t1);
t3=C_mutate(&lf[73] /* (set! default-library-files ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4536,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4539,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[22],"host-mode"))){
/* ##sys#peek-c-string */
t6=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)C_INSTALL_LIB_NAME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t6=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)C_TARGET_LIB_NAME),C_fix(0));}}

/* k3877 in k3871 in k3867 in k3864 in k3861 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in ... */
static void C_ccall f_3879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3879,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
f_3719(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3881,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[88],"verbose"))){
/* csc.scm:906: print */
t3=*((C_word*)lf[137]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[179],((C_word*)((C_word*)t0)[3])[1]);}
else{
/* csc.scm:907: create-directory */
t3=C_fast_retrieve(lf[178]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1]);}}}

/* k3871 in k3867 in k3864 in k3861 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in ... */
static void C_ccall f_3873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3873,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3879,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csc.scm:904: directory-exists? */
t4=C_fast_retrieve(lf[180]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)((C_word*)t0)[4])[1]);}

/* k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in ... */
static void C_ccall f_1827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1827,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_retrieve2(lf[24],"quotewrap");
t8=C_retrieve2(lf[57],"object-files");
t9=C_i_check_list_2(C_retrieve2(lf[57],"object-files"),lf[99]);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3715,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3950,a[2]=t6,a[3]=t12,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t14=((C_word*)t12)[1];
f_3950(t14,t10,C_retrieve2(lf[57],"object-files"));}

/* k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in ... */
static void C_ccall f_1995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1995,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1998,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=C_eqp(t2,lf[238]);
t5=(C_truep(t4)?t4:C_eqp(t2,lf[239]));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2008,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1689,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t8=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,C_mpointer(&a,(void*)C_CSC_PROGRAM),C_fix(0));}
else{
t6=C_eqp(t2,lf[244]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2019,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2025,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:586: chicken-version */
t9=C_fast_retrieve(lf[245]);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t7=C_eqp(t2,lf[246]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2033,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2039,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:589: sprintf */
t10=*((C_word*)lf[247]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,C_retrieve2(lf[28],"translator"),lf[248]);}
else{
t8=C_eqp(t2,lf[249]);
if(C_truep(t8)){
t9=lf[59] /* cpp-mode */ =C_SCHEME_TRUE;;
if(C_truep(C_retrieve2(lf[3],"osx"))){
t10=C_a_i_cons(&a,2,lf[250],C_retrieve2(lf[80],"compile-options"));
t11=C_mutate(&lf[80] /* (set! compile-options ...) */,t10);
/* csc.scm:796: loop */
t12=((C_word*)((C_word*)t0)[2])[1];
f_1796(t12,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}
else{
/* csc.scm:796: loop */
t10=((C_word*)((C_word*)t0)[2])[1];
f_1796(t10,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}}
else{
t9=C_eqp(t2,lf[251]);
if(C_truep(t9)){
t10=lf[60] /* objc-mode */ =C_SCHEME_TRUE;;
/* csc.scm:796: loop */
t11=((C_word*)((C_word*)t0)[2])[1];
f_1796(t11,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}
else{
t10=C_eqp(t2,lf[252]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2070,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:598: cons* */
t12=C_fast_retrieve(lf[125]);
((C_proc5)(void*)(*((C_word*)t12+1)))(5,t12,t11,lf[253],lf[254],C_retrieve2(lf[77],"translate-options"));}
else{
t11=C_eqp(t2,lf[255]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2081,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:602: cons* */
t13=C_fast_retrieve(lf[125]);
((C_proc5)(void*)(*((C_word*)t13+1)))(5,t13,t12,lf[256],lf[257],C_retrieve2(lf[77],"translate-options"));}
else{
t12=C_eqp(t2,lf[258]);
if(C_truep(t12)){
t13=lf[62] /* inquiry-only */ =C_SCHEME_TRUE;;
t14=lf[63] /* show-cflags */ =C_SCHEME_TRUE;;
/* csc.scm:796: loop */
t15=((C_word*)((C_word*)t0)[2])[1];
f_1796(t15,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}
else{
t13=C_eqp(t2,lf[259]);
if(C_truep(t13)){
t14=lf[62] /* inquiry-only */ =C_SCHEME_TRUE;;
t15=lf[64] /* show-ldflags */ =C_SCHEME_TRUE;;
/* csc.scm:796: loop */
t16=((C_word*)((C_word*)t0)[2])[1];
f_1796(t16,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}
else{
t14=C_eqp(t2,lf[260]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2106,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:610: print */
t16=*((C_word*)lf[137]+1);
((C_proc3)(void*)(*((C_word*)t16+1)))(3,t16,t15,C_retrieve2(lf[29],"compiler"));}
else{
t15=C_eqp(t2,lf[261]);
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2117,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:611: print */
t17=*((C_word*)lf[137]+1);
((C_proc3)(void*)(*((C_word*)t17+1)))(3,t17,t16,C_retrieve2(lf[30],"c++-compiler"));}
else{
t16=C_eqp(t2,lf[262]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2128,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:612: print */
t18=*((C_word*)lf[137]+1);
((C_proc3)(void*)(*((C_word*)t18+1)))(3,t18,t17,C_retrieve2(lf[32],"linker"));}
else{
t17=C_eqp(t2,lf[263]);
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2139,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:613: print */
t19=*((C_word*)lf[137]+1);
((C_proc3)(void*)(*((C_word*)t19+1)))(3,t19,t18,C_retrieve2(lf[27],"home"));}
else{
t18=C_eqp(t2,lf[264]);
if(C_truep(t18)){
t19=lf[62] /* inquiry-only */ =C_SCHEME_TRUE;;
t20=lf[65] /* show-libs */ =C_SCHEME_TRUE;;
/* csc.scm:796: loop */
t21=((C_word*)((C_word*)t0)[2])[1];
f_1796(t21,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}
else{
t19=C_eqp(t2,lf[265]);
t20=(C_truep(t19)?t19:C_eqp(t2,lf[266]));
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2160,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_numberp(C_retrieve2(lf[88],"verbose")))){
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2174,a[2]=t21,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:619: cons* */
t23=C_fast_retrieve(lf[125]);
((C_proc5)(void*)(*((C_word*)t23+1)))(5,t23,t22,lf[269],lf[270],C_retrieve2(lf[80],"compile-options"));}
else{
t22=t21;
f_2160(t22,C_SCHEME_UNDEFINED);}}
else{
t21=C_eqp(t2,lf[271]);
t22=(C_truep(t21)?t21:C_eqp(t2,lf[272]));
if(C_truep(t22)){
t23=C_a_i_cons(&a,2,lf[273],C_retrieve2(lf[80],"compile-options"));
t24=C_mutate(&lf[80] /* (set! compile-options ...) */,t23);
/* csc.scm:627: t-options */
f_1722(t3,C_a_i_list(&a,1,lf[274]));}
else{
t23=C_eqp(t2,lf[275]);
t24=(C_truep(t23)?t23:C_eqp(t2,lf[276]));
if(C_truep(t24)){
t25=lf[90] /* translate-only */ =C_SCHEME_TRUE;;
/* csc.scm:630: t-options */
f_1722(t3,C_a_i_list(&a,1,lf[277]));}
else{
t25=C_eqp(t2,lf[278]);
t26=(C_truep(t25)?t25:C_eqp(t2,lf[279]));
if(C_truep(t26)){
t27=lf[90] /* translate-only */ =C_SCHEME_TRUE;;
/* csc.scm:633: t-options */
f_1722(t3,C_a_i_list(&a,1,lf[280]));}
else{
t27=C_eqp(t2,lf[281]);
if(C_truep(t27)){
t28=lf[89] /* keep-files */ =C_SCHEME_TRUE;;
/* csc.scm:796: loop */
t29=((C_word*)((C_word*)t0)[2])[1];
f_1796(t29,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}
else{
t28=C_eqp(t2,lf[282]);
if(C_truep(t28)){
t29=lf[91] /* compile-only */ =C_SCHEME_TRUE;;
/* csc.scm:796: loop */
t30=((C_word*)((C_word*)t0)[2])[1];
f_1796(t30,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}
else{
t29=C_eqp(t2,lf[283]);
if(C_truep(t29)){
t30=lf[90] /* translate-only */ =C_SCHEME_TRUE;;
/* csc.scm:796: loop */
t31=((C_word*)((C_word*)t0)[2])[1];
f_1796(t31,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}
else{
t30=C_eqp(t2,lf[284]);
t31=(C_truep(t30)?t30:C_eqp(t2,lf[285]));
if(C_truep(t31)){
t32=lf[61] /* embedded */ =C_SCHEME_TRUE;;
t33=C_a_i_cons(&a,2,lf[286],C_retrieve2(lf[80],"compile-options"));
t34=C_mutate(&lf[80] /* (set! compile-options ...) */,t33);
/* csc.scm:796: loop */
t35=((C_word*)((C_word*)t0)[2])[1];
f_1796(t35,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}
else{
t32=C_eqp(t2,lf[287]);
t33=(C_truep(t32)?t32:C_eqp(t2,lf[288]));
if(C_truep(t33)){
t34=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2261,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csc.scm:641: check */
f_1730(t34,t1,((C_word*)((C_word*)t0)[4])[1],C_SCHEME_END_OF_LIST);}
else{
t34=C_eqp(t2,lf[290]);
if(C_truep(t34)){
t35=f_1778(C_a_i(&a,6));
/* csc.scm:796: loop */
t36=((C_word*)((C_word*)t0)[2])[1];
f_1796(t36,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}
else{
t35=C_eqp(t2,lf[291]);
if(C_truep(t35)){
t36=lf[44] /* generate-manifest */ =C_SCHEME_TRUE;;
/* csc.scm:796: loop */
t37=((C_word*)((C_word*)t0)[2])[1];
f_1796(t37,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}
else{
t36=C_eqp(t2,lf[292]);
if(C_truep(t36)){
t37=lf[67] /* gui */ =C_SCHEME_TRUE;;
t38=C_a_i_cons(&a,2,lf[293],C_retrieve2(lf[80],"compile-options"));
t39=C_mutate(&lf[80] /* (set! compile-options ...) */,t38);
if(C_truep(C_retrieve2(lf[1],"mingw"))){
t40=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2319,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t41=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2322,a[2]=t40,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t42=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t42+1)))(4,t42,t41,C_mpointer(&a,(void*)C_INSTALL_SHARE_HOME),C_fix(0));}
else{
/* csc.scm:796: loop */
t40=((C_word*)((C_word*)t0)[2])[1];
f_1796(t40,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}}
else{
t37=C_eqp(t2,lf[299]);
if(C_truep(t37)){
t38=lf[68] /* deploy */ =C_SCHEME_TRUE;;
t39=lf[69] /* deployed */ =C_SCHEME_TRUE;;
/* csc.scm:796: loop */
t40=((C_word*)((C_word*)t0)[2])[1];
f_1796(t40,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}
else{
t38=C_eqp(t2,lf[300]);
if(C_truep(t38)){
t39=lf[69] /* deployed */ =C_SCHEME_TRUE;;
/* csc.scm:796: loop */
t40=((C_word*)((C_word*)t0)[2])[1];
f_1796(t40,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}
else{
t39=C_eqp(t2,lf[301]);
if(C_truep(t39)){
t40=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2345,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:667: check */
f_1730(t40,t1,((C_word*)((C_word*)t0)[4])[1],C_SCHEME_END_OF_LIST);}
else{
t40=C_eqp(t2,lf[303]);
t41=(C_truep(t40)?t40:C_eqp(t2,lf[304]));
if(C_truep(t41)){
t42=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2368,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:672: check */
f_1730(t42,t1,((C_word*)((C_word*)t0)[4])[1],C_SCHEME_END_OF_LIST);}
else{
t42=C_eqp(t2,lf[305]);
t43=(C_truep(t42)?t42:C_eqp(t2,lf[306]));
if(C_truep(t43)){
t44=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2387,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:676: cons* */
t45=C_fast_retrieve(lf[125]);
((C_proc5)(void*)(*((C_word*)t45+1)))(5,t45,t44,lf[307],lf[308],((C_word*)((C_word*)t0)[4])[1]);}
else{
t44=C_eqp(t2,lf[309]);
if(C_truep(t44)){
t45=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2397,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:677: cons* */
t46=C_fast_retrieve(lf[125]);
((C_proc5)(void*)(*((C_word*)t46+1)))(5,t46,t45,lf[310],lf[311],((C_word*)((C_word*)t0)[4])[1]);}
else{
t45=C_eqp(t2,lf[312]);
if(C_truep(t45)){
t46=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2407,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:678: cons* */
t47=C_fast_retrieve(lf[125]);
((C_proc5)(void*)(*((C_word*)t47+1)))(5,t47,t46,lf[313],lf[314],((C_word*)((C_word*)t0)[4])[1]);}
else{
t46=C_eqp(t2,lf[315]);
if(C_truep(t46)){
t47=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2417,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:679: cons* */
t48=C_fast_retrieve(lf[125]);
((C_proc5)(void*)(*((C_word*)t48+1)))(5,t48,t47,lf[316],lf[317],((C_word*)((C_word*)t0)[4])[1]);}
else{
t47=C_eqp(t2,lf[318]);
if(C_truep(t47)){
t48=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2427,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:680: cons* */
t49=C_fast_retrieve(lf[125]);
((C_proc5)(void*)(*((C_word*)t49+1)))(5,t49,t48,lf[319],lf[320],((C_word*)((C_word*)t0)[4])[1]);}
else{
t48=C_eqp(t2,lf[321]);
if(C_truep(t48)){
t49=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2437,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:682: cons* */
t50=C_fast_retrieve(lf[125]);
((C_proc5)(void*)(*((C_word*)t50+1)))(5,t50,t49,lf[322],lf[323],((C_word*)((C_word*)t0)[4])[1]);}
else{
t49=C_eqp(t2,lf[324]);
if(C_truep(t49)){
t50=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2447,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:683: cons* */
t51=C_fast_retrieve(lf[125]);
((C_proc5)(void*)(*((C_word*)t51+1)))(5,t51,t50,lf[325],lf[326],((C_word*)((C_word*)t0)[4])[1]);}
else{
t50=C_eqp(t2,lf[327]);
if(C_truep(t50)){
t51=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2457,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:684: cons* */
t52=C_fast_retrieve(lf[125]);
((C_proc5)(void*)(*((C_word*)t52+1)))(5,t52,t51,lf[328],lf[329],((C_word*)((C_word*)t0)[4])[1]);}
else{
t51=C_eqp(t2,lf[330]);
if(C_truep(t51)){
t52=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2467,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:685: cons* */
t53=C_fast_retrieve(lf[125]);
((C_proc5)(void*)(*((C_word*)t53+1)))(5,t53,t52,lf[331],lf[332],((C_word*)((C_word*)t0)[4])[1]);}
else{
t52=C_eqp(t2,lf[333]);
if(C_truep(t52)){
t53=lf[88] /* verbose */ =C_SCHEME_TRUE;;
t54=lf[66] /* dry-run */ =C_SCHEME_TRUE;;
/* csc.scm:796: loop */
t55=((C_word*)((C_word*)t0)[2])[1];
f_1796(t55,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}
else{
t53=C_eqp(t2,lf[334]);
t54=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2483,a[2]=((C_word*)t0)[8],a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[6],a[9]=t1,a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
if(C_truep(t53)){
t55=t54;
f_2483(t55,t53);}
else{
t55=C_eqp(t2,lf[386]);
t56=t54;
f_2483(t56,(C_truep(t55)?t55:C_eqp(t2,lf[387])));}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k1996 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in ... */
static void C_ccall f_1998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:796: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_1796(t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}

/* k1840 in k1838 in k1836 in k1834 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in ... */
static void C_ccall f_1841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1841,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1843,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csc.scm:568: display */
t3=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[191],((C_word*)t0)[3]);}

/* k1989 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in ... */
static void C_ccall f_1990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:535: append */
t2=*((C_word*)lf[101]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[86],"link-options"),t1);}

/* k1630 in map-loop164 in k1600 */
static void C_ccall f_1631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1631,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_1606(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_1606(t6,((C_word*)t0)[5],t5);}}

/* k2813 in k2761 in k2752 in k2703 in k2701 in k2481 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in ... */
static void C_ccall f_2814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2814,2,t0,t1);}
/* csc.scm:759: t-options */
f_1722(((C_word*)t0)[3],C_a_i_list(&a,2,lf[359],t1));}

/* k3867 in k3864 in k3861 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in ... */
static void C_ccall f_3869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3869,2,t0,t1);}
t2=C_mutate(&lf[87] /* (set! target-filename ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3873,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=C_retrieve2(lf[87],"target-filename");
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5342,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:92: normalize-pathname */
t6=C_fast_retrieve(lf[26]);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,C_retrieve2(lf[87],"target-filename"));}

/* k3864 in k3861 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in ... */
static void C_ccall f_3865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3865,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3869,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3890,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_truep(C_retrieve2(lf[3],"osx"))?C_retrieve2(lf[67],"gui"):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3899,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:901: pathname-file */
t6=C_fast_retrieve(lf[164]);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,C_retrieve2(lf[87],"target-filename"));}
else{
/* csc.scm:902: pathname-file */
t5=C_fast_retrieve(lf[164]);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,C_retrieve2(lf[87],"target-filename"));}}

/* k3861 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in ... */
static void C_ccall f_3863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3863,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3865,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(C_truep(C_retrieve2(lf[3],"osx"))?C_retrieve2(lf[67],"gui"):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3909,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* csc.scm:894: make-pathname */
t6=C_fast_retrieve(lf[104]);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,C_SCHEME_FALSE,((C_word*)((C_word*)t0)[2])[1],lf[186]);}
else{
t5=t3;
f_3865(2,t5,C_SCHEME_UNDEFINED);}}

/* k1851 in k1844 in k1842 in k1840 in k1838 in k1836 in k1834 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in ... */
static void C_ccall f_1852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1852,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1854,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve2(lf[43],"windows-shell"))){
/* csc.scm:571: display */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[189],t2);}
else{
/* csc.scm:571: display */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[190],t2);}}

/* k1853 in k1851 in k1844 in k1842 in k1840 in k1838 in k1836 in k1834 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in ... */
static void C_ccall f_1854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1854,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1856,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* write-char/port */
t3=C_fast_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(32),((C_word*)t0)[4]);}

/* k1855 in k1853 in k1851 in k1844 in k1842 in k1840 in k1838 in k1836 in k1834 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in ... */
static void C_ccall f_1856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1856,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1858,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1875,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=C_retrieve2(lf[87],"target-filename");
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5374,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:92: normalize-pathname */
t6=C_fast_retrieve(lf[26]);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,C_retrieve2(lf[87],"target-filename"));}

/* k1857 in k1855 in k1853 in k1851 in k1844 in k1842 in k1840 in k1838 in k1836 in k1834 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in ... */
static void C_ccall f_1858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1858,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1860,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* write-char/port */
t3=C_fast_retrieve(lf[14]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(32),((C_word*)t0)[4]);}

/* k3858 in k3718 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in ... */
static void C_ccall f_3859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#string-append */
((C_proc4)C_fast_retrieve_symbol_proc(lf[113]))(4,*((C_word*)lf[113]+1),((C_word*)t0)[2],lf[177],t1);}

/* k3854 in k3851 in k3848 in k3718 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in ... */
static void C_ccall f_3855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3855,2,t0,t1);}
t2=C_a_i_list3(&a,3,((C_word*)t0)[2],((C_word*)t0)[3],t1);
/* csc.scm:912: append */
t3=*((C_word*)lf[101]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[4],((C_word*)t0)[5],t2);}

/* k2998 */
static void C_ccall f_3000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[54] /* (set! rc-files ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2825 in k2761 in k2752 in k2703 in k2701 in k2481 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in ... */
static void C_ccall f_2827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[80] /* (set! compile-options ...) */,t1);
/* csc.scm:796: loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1796(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}

/* for-each-loop591 in k3534 in k3530 in k3500 in k3497 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in ... */
static void C_fcall f_3571(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3571,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3580,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* csc.scm:873: g592 */
t5=C_retrieve2(lf[138],"$delete-file");
f_4298(3,t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3722 in k3720 in k3718 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in ... */
static void C_ccall f_3723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3723,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3725,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3756,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[68],"deploy"))){
t4=C_retrieve2(lf[94],"static");
if(C_truep(C_retrieve2(lf[94],"static"))){
t5=C_retrieve2(lf[94],"static");
t6=C_retrieve2(lf[94],"static");
t7=t3;
f_3756(t7,C_i_not(C_retrieve2(lf[94],"static")));}
else{
t5=C_retrieve2(lf[95],"static-libs");
t6=C_retrieve2(lf[95],"static-libs");
t7=t3;
f_3756(t7,C_i_not(C_retrieve2(lf[95],"static-libs")));}}
else{
t4=t3;
f_3756(t4,C_SCHEME_FALSE);}}

/* k3720 in k3718 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in ... */
static void C_ccall f_3721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3721,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3723,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3789,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[3],"osx"))){
t4=C_i_not(C_retrieve2(lf[23],"cross-chicken"));
if(C_truep(t4)){
t5=t3;
f_3789(t5,t4);}
else{
t5=C_retrieve2(lf[22],"host-mode");
t6=t3;
f_3789(t6,C_retrieve2(lf[22],"host-mode"));}}
else{
t4=t3;
f_3789(t4,C_SCHEME_FALSE);}}

/* k3851 in k3848 in k3718 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in ... */
static void C_ccall f_3852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3852,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3855,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csc.scm:916: linker-libraries */
f_4115(t2);}

/* k3602 in for-each-loop570 in k3500 in k3497 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in ... */
static void C_ccall f_3603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3594(t3,((C_word*)t0)[4],t2);}

/* for-each-loop744 in k3724 in k3722 in k3720 in k3718 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in ... */
static void C_fcall f_3735(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3735,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3744,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* csc.scm:941: g745 */
t5=C_retrieve2(lf[138],"$delete-file");
f_4298(3,t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2834 in k2761 in k2752 in k2703 in k2701 in k2481 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in ... */
static void C_fcall f_2836(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2836,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2840,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_a_i_list1(&a,1,((C_word*)t0)[5]);
/* csc.scm:764: append */
t4=*((C_word*)lf[101]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,C_retrieve2(lf[86],"link-options"),t3);}
else{
t2=C_block_size(((C_word*)t0)[5]);
if(C_truep(C_fixnum_greaterp(t2,C_fix(2)))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2912,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* string->list */
t4=C_fast_retrieve(lf[126]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[5]);}
else{
/* csc.scm:771: quit */
f_1393(((C_word*)t0)[6],lf[365],C_a_i_list(&a,1,((C_word*)t0)[7]));}}}

/* k4502 in map-loop111 in k4472 */
static void C_ccall f_4503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4503,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4478(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_4478(t6,((C_word*)t0)[5],t5);}}

/* k3724 in k3722 in k3720 in k3718 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in ... */
static void C_fcall f_3725(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3725,NULL,2,t0,t1);}
if(C_truep(C_retrieve2(lf[89],"keep-files"))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=C_retrieve2(lf[138],"$delete-file");
t3=C_retrieve2(lf[58],"generated-object-files");
t4=C_i_check_list_2(C_retrieve2(lf[58],"generated-object-files"),lf[151]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3735,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_3735(t8,((C_word*)t0)[2],C_retrieve2(lf[58],"generated-object-files"));}}

/* k2838 in k2834 in k2761 in k2752 in k2703 in k2701 in k2481 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in ... */
static void C_ccall f_2840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[86] /* (set! link-options ...) */,t1);
/* csc.scm:796: loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1796(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1]);}

/* k2624 in k2621 in k2481 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in ... */
static void C_ccall f_2626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(&lf[86] /* (set! link-options ...) */,t1);
t3=C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
/* csc.scm:796: loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_1796(t5,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* k2621 in k2481 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in ... */
static void C_ccall f_2622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2622,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2626,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2633,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_i_car(((C_word*)((C_word*)t0)[2])[1]);
/* csc.scm:720: string-split */
t5=C_fast_retrieve(lf[224]);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2812)){
C_save(t1);
C_rereclaim2(2812*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,418);
lf[0]=C_h_intern(&lf[0],7,"mingw32");
lf[2]=C_h_intern(&lf[2],6,"macosx");
lf[5]=C_h_intern(&lf[5],6,"netbsd");
lf[7]=C_h_intern(&lf[7],6,"cygwin");
lf[10]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005linux\376\003\000\000\002\376\001\000\000\006netbsd\376\003\000\000\002\376\001\000\000\007freebsd\376\003\000\000\002\376\001\000\000\007solaris\376\003\000\000\002\376\001\000\000\007openb"
"sd\376\377\016");
lf[12]=C_h_intern(&lf[12],18,"\003sysstandard-error");
lf[13]=C_h_intern(&lf[13],4,"exit");
lf[14]=C_h_intern(&lf[14],19,"\003syswrite-char/port");
lf[15]=C_h_intern(&lf[15],7,"fprintf");
lf[16]=C_h_intern(&lf[16],7,"display");
lf[17]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[18]=C_h_intern(&lf[18],17,"\003syspeek-c-string");
lf[21]=C_decode_literal(C_heaptop,"\376B\000\000\005-host");
lf[25]=C_h_intern(&lf[25],2,"qs");
lf[26]=C_h_intern(&lf[26],18,"normalize-pathname");
lf[35]=C_decode_literal(C_heaptop,"\376B\000\000\001o");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[41]=C_h_intern(&lf[41],26,"\003sysload-dynamic-extension");
lf[78]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\014/usr/include\376\003\000\000\002\376B\000\000\000\376\377\016");
lf[99]=C_h_intern(&lf[99],3,"map");
lf[100]=C_h_intern(&lf[100],18,"string-intersperse");
lf[101]=C_h_intern(&lf[101],6,"append");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[104]=C_h_intern(&lf[104],13,"make-pathname");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[108]=C_h_intern(&lf[108],17,"get-output-string");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\007copy /Y");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000\002cp");
lf[111]=C_h_intern(&lf[111],18,"open-output-string");
lf[113]=C_h_intern(&lf[113],17,"\003sysstring-append");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\010 -static");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[118]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000#\376\377\016");
lf[119]=C_h_intern(&lf[119],13,"string-append");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[122]=C_h_intern(&lf[122],17,"string-translate\052");
lf[123]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376B\000\000\001\042\376B\000\000\002\134\042\376\377\016");
lf[124]=C_h_intern(&lf[124],16,"\003syslist->string");
lf[125]=C_h_intern(&lf[125],5,"cons\052");
lf[126]=C_h_intern(&lf[126],16,"\003sysstring->list");
lf[127]=C_h_intern(&lf[127],10,"string-any");
lf[128]=C_h_intern(&lf[128],6,"char=\077");
lf[130]=C_h_intern(&lf[130],19,"\003sysstandard-output");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[132]=C_h_intern(&lf[132],5,"write");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000;\012Error: shell command terminated with non-zero exit status ");
lf[134]=C_h_intern(&lf[134],6,"system");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[137]=C_h_intern(&lf[137],5,"print");
lf[139]=C_h_intern(&lf[139],11,"delete-file");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\003rm ");
lf[141]=C_h_intern(&lf[141],25,"\003sysimplicit-exit-handler");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000#not enough arguments to option `~A\047");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\013-dynamiclib");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000\007-bundle");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000\007-shared");
lf[146]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\012-DC_SHARED\376\377\016");
lf[147]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000\026chicken-compile-shared");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\026-DC_PRIVATE_REPOSITORY");
lf[150]=C_decode_literal(C_heaptop,"\376B\000\000\031-framework CoreFoundation");
lf[151]=C_h_intern(&lf[151],8,"for-each");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\032</string>\012</dict>\012</plist>");
lf[153]=C_decode_literal(C_heaptop,"\376B\000\001\262<\077xml version=\0421.0\042 encoding=\042UTF-8\042\077>\012<!DOCTYPE plist SYSTEM \042file://local"
"host/System/Library/DTDs/PropertyList.dtd\042>\012<plist version=\0420.9\042>\012<dict>\012\011<key>C"
"FBundlePackageType</key>\012\011<string>APPL</string>\012\011<key>CFBundleIconFile</key>\012\011<s"
"tring>CHICKEN.icns</string>\012        <key>CFBundleGetInfoString</key>\012\011<string>Cr"
"eated by CHICKEN</string>\012\011<key>CFBundleSignature</key>\012\011<string>\077\077\077\077</string>\012\011"
"<key>CFBundleExecutable</key>\012\011<string>");
lf[154]=C_h_intern(&lf[154],19,"\003sysprint-to-string");
lf[155]=C_h_intern(&lf[155],19,"with-output-to-file");
lf[156]=C_decode_literal(C_heaptop,"\376B\000\000\013generating ");
lf[157]=C_h_intern(&lf[157],12,"file-exists\077");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000\012Info.plist");
lf[159]=C_decode_literal(C_heaptop,"\376B\000\000\024chicken/CHICKEN.icns");
lf[160]=C_decode_literal(C_heaptop,"\376B\000\000\014CHICKEN.icns");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\022Contents/Resources");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000\016Contents/MacOS");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000\010Contents");
lf[164]=C_h_intern(&lf[164],13,"pathname-file");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000\005dylib");
lf[166]=C_decode_literal(C_heaptop,"\376B\000\000\003dll");
lf[167]=C_decode_literal(C_heaptop,"\376B\000\000\003so.");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[169]=C_decode_literal(C_heaptop,"\376B\000\000\016Contents/MacOS");
lf[170]=C_decode_literal(C_heaptop,"\376B\000\000\005mac.r");
lf[171]=C_decode_literal(C_heaptop,"\376B\000\000 /Developer/Tools/Rez -t APPL -o ");
lf[172]=C_decode_literal(C_heaptop,"\376B\000\000\032install_name_tool -change ");
lf[173]=C_decode_literal(C_heaptop,"\376B\000\000\007.dylib ");
lf[174]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[175]=C_decode_literal(C_heaptop,"\376B\000\000\020@executable_path");
lf[176]=C_decode_literal(C_heaptop,"\376B\000\000\006.dylib");
lf[177]=C_decode_literal(C_heaptop,"\376B\000\000\003-o ");
lf[178]=C_h_intern(&lf[178],16,"create-directory");
lf[179]=C_decode_literal(C_heaptop,"\376B\000\000\006mkdir ");
lf[180]=C_h_intern(&lf[180],17,"directory-exists\077");
lf[181]=C_decode_literal(C_heaptop,"\376B\000\000\017Contents/MacOS/");
lf[182]=C_decode_literal(C_heaptop,"\376B\000\000\022Contents/Resources");
lf[183]=C_decode_literal(C_heaptop,"\376B\000\000\011mkdir -p ");
lf[184]=C_decode_literal(C_heaptop,"\376B\000\000\016Contents/MacOS");
lf[185]=C_decode_literal(C_heaptop,"\376B\000\000\011mkdir -p ");
lf[186]=C_decode_literal(C_heaptop,"\376B\000\000\003app");
lf[187]=C_h_intern(&lf[187],24,"pathname-strip-extension");
lf[188]=C_decode_literal(C_heaptop,"\376B\000\000\004.old");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000\004move");
lf[190]=C_decode_literal(C_heaptop,"\376B\000\000\002mv");
lf[191]=C_decode_literal(C_heaptop,"\376B\000\000\005.old\047");
lf[192]=C_decode_literal(C_heaptop,"\376B\000\000\030\047 - renaming source to `");
lf[193]=C_decode_literal(C_heaptop,"\376B\000\0001Warning: output file will overwrite source file `");
lf[194]=C_decode_literal(C_heaptop,"\376B\000\000\002-c");
lf[195]=C_decode_literal(C_heaptop,"\376B\000\000\003g++");
lf[196]=C_decode_literal(C_heaptop,"\376B\000\000\022-Wno-write-strings");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[198]=C_decode_literal(C_heaptop,"\376B\000\000\003-o ");
lf[199]=C_h_intern(&lf[199],26,"pathname-replace-extension");
lf[200]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[201]=C_h_intern(&lf[201],7,"reverse");
lf[202]=C_decode_literal(C_heaptop,"\376B\000\001\232\042\042 type=\042\042win32\042\042/>\134r\134n\042\012  \042  <ms_asmv2:trustInfo xmlns:ms_asmv2=\042\042urn:sche"
"mas-microsoft-com:asm.v2\042\042>\134r\134n\042\012  \042    <ms_asmv2:security>\134r\134n\042\012  \042      <ms_as"
"mv2:requestedPrivileges>\134r\134n\042\012  \042        <ms_asmv2:requestedExecutionLevel level"
"=\042\042asInvoker\042\042 uiAccess=\042\042false\042\042/>\134r\134n\042\012  \042      </ms_asmv2:requestedPrivileges"
">\134r\134n\042\012  \042    </ms_asmv2:security>\134r\134n\042\012  \042  </ms_asmv2:trustInfo>\134r\134n\042\012  \042</ass"
"embly>\134r\134n\042\012END");
lf[203]=C_decode_literal(C_heaptop,"\376B\000\001\0031 24 MOVEABLE PURE\012BEGIN\012  \042<\077xml version=\042\0421.0\042\042 encoding=\042\042UTF-8\042\042 standa"
"lone=\042\042yes\042\042\077>\134r\134n\042\012  \042<assembly xmlns=\042\042urn:schemas-microsoft-com:asm.v1\042\042 mani"
"festVersion=\042\0421.0\042\042>\134r\134n\042\012  \042  <assemblyIdentity version=\042\0421.0.0.0\042\042 processorAr"
"chitecture=\042\042\052\042\042 name=\042\042");
lf[204]=C_decode_literal(C_heaptop,"\376B\000\000\013generating ");
lf[205]=C_decode_literal(C_heaptop,"\376B\000\000\002rc");
lf[206]=C_h_intern(&lf[206],7,"windows");
lf[207]=C_h_intern(&lf[207],13,"software-type");
lf[208]=C_h_intern(&lf[208],4,"last");
lf[209]=C_decode_literal(C_heaptop,"\376B\000\000\031no source files specified");
lf[210]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[211]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\003-:d\376\377\016");
lf[212]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\010-feature\376\003\000\000\002\376B\000\000\025chicken-scheme-to-c++\376\377\016");
lf[213]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\010-feature\376\003\000\000\002\376B\000\000\026chicken-scheme-to-objc\376\377\016");
lf[214]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\012-to-stdout\376\377\016");
lf[215]=C_decode_literal(C_heaptop,"\376B\000\000\014-output-file");
lf[216]=C_decode_literal(C_heaptop,"\376B\000\000\003cpp");
lf[217]=C_decode_literal(C_heaptop,"\376B\000\000\001m");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000\001c");
lf[219]=C_decode_literal(C_heaptop,"\376B\000\000\010-dynamic");
lf[220]=C_h_intern(&lf[220],7,"newline");
lf[221]=C_h_intern(&lf[221],6,"print\052");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\003-L\042");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[224]=C_h_intern(&lf[224],12,"string-split");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000\002:;");
lf[226]=C_h_intern(&lf[226],24,"get-environment-variable");
lf[227]=C_decode_literal(C_heaptop,"\376B\000\000\026CHICKEN_C_LIBRARY_PATH");
lf[228]=C_h_intern(&lf[228],4,"conc");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000\010 -Wl,-R\042");
lf[230]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[231]=C_decode_literal(C_heaptop,"\376B\000\000\010\134$ORIGIN");
lf[232]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[234]=C_decode_literal(C_heaptop,"\376B\000\000\003-L\042");
lf[235]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000\003-L\042");
lf[237]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[238]=C_h_intern(&lf[238],5,"-help");
lf[239]=C_h_intern(&lf[239],6,"--help");
lf[240]=C_decode_literal(C_heaptop,"\376B\000\000\003\047.\012");
lf[241]=C_decode_literal(C_heaptop,"\376B\000({\047 is a driver program for the CHICKEN compiler. Files given on the\012  comman"
"d line are translated, compiled or linked as needed.\012\012  FILENAME is a Scheme sou"
"rce file name with optional extension or a\012  C/C++/Objective-C source, object or"
" library file name with extension. OPTION\012  may be one of the following:\012\012  Gene"
"ral options:\012\012    -h  -help                      display this text and exit\012    "
"-v  -verbose                   show compiler notes and tool-invocations\012    -vv "
"                           display information about translation\012               "
"                     progress\012    -vvv                           display informa"
"tion about all compilation\012                                    stages\012    -versi"
"on                       display Scheme compiler version and exit\012    -release  "
"                     display release number and exit\012\012  File and pathname option"
"s:\012\012    -o -output-file FILENAME       specifies target executable name\012    -I -"
"include-path PATHNAME      specifies alternative path for included\012             "
"                       files\012    -to-stdout                     write compiler t"
"o stdout (implies -t)\012    -s -shared -dynamic            generate dynamically lo"
"adable shared object\012                                    file\012\012  Language option"
"s:\012\012    -D  -DSYMBOL  -feature SYMBOL  register feature identifier\012    -no-featu"
"re SYMBOL             disable builtin feature identifier\012    -c++               "
"            compile via a C++ source file (.cpp) \012    -objc                     "
"     compile via Objective-C source file (.m)\012\012  Syntax related options:\012\012    -i"
" -case-insensitive           don\047t preserve case of read symbols    \012    -K -key"
"word-style STYLE        enable alternative keyword-syntax\012                      "
"              (prefix, suffix or none)\012       -no-parentheses-synonyms    disabl"
"es list delimiter synonyms\012       -no-symbol-escape           disables support f"
"or escaped symbols\012       -r5rs-syntax                disables the Chicken exten"
"sions to\012                                    R5RS syntax\012    -compile-syntax    "
"            macros are made available at run-time\012    -j -emit-import-library MO"
"DULE write compile-time module information into\012                                "
"    separate file\012    -J -emit-all-import-libraries  emit import-libraries for a"
"ll defined modules\012    -no-module-registration        do not generate module reg"
"istration code\012    -no-compiler-syntax            disable expansion of compiler-"
"macros\012    -M -module                     wrap compiled code into implicit modul"
"e\012\012  Translation options:\012\012    -x  -explicit-use              do not use units `"
"library\047 and `eval\047 by\012                                    default\012    -P  -chec"
"k-syntax              stop compilation after macro-expansion\012    -A  -analyze-on"
"ly              stop compilation after first analysis pass\012\012  Debugging options:"
"\012\012    -w  -no-warnings               disable warnings\012    -d0 -d1 -d2 -debug-lev"
"el NUMBER\012                                   set level of available debugging in"
"formation\012    -no-trace                      disable rudimentary debugging infor"
"mation\012    -profile                       executable emits profiling information"
" \012    -accumulate-profile            executable emits profiling information in\012 "
"                                   append mode\012    -profile-name FILENAME       "
"  name of the generated profile information\012                                    "
"file\012    -S  -scrutinize                perform local flow analysis\012    -types F"
"ILENAME                load additional type database\012\012  Optimization options:\012\012 "
"   -O -O0 -O1 -O2 -O3 -O4 -O5 -optimize-level NUMBER\012                           "
"        enable certain sets of optimization options\012    -optimize-leaf-routines "
"       enable leaf routine optimization\012    -no-usual-integrations         stand"
"ard procedures may be redefined\012    -u  -unsafe                    disable safet"
"y checks\012    -local                         assume globals are only modified in "
"current\012                                    file\012    -b  -block                 "
"    enable block-compilation\012    -disable-interrupts            disable interrup"
"ts in compiled code\012    -f  -fixnum-arithmetic         assume all numbers are fi"
"xnums\012    -disable-stack-overflow-checks disables detection of stack-overflows\012 "
"   -inline                        enable inlining\012    -inline-limit LIMIT       "
"     set inlining threshold\012    -inline-global                 enable cross-modu"
"le inlining\012    -specialize                    perform type-based specialization"
" of primitive calls\012    -n -emit-inline-file FILENAME  generate file with global"
"ly inlinable\012                                    procedures (implies -inline -lo"
"cal)\012    -consult-inline-file FILENAME  explicitly load inline file\012    -emit-ty"
"pe-file FILENAME       write type-declaration information into file\012    -no-argc"
"-checks                disable argument count checks\012    -no-bound-checks       "
"        disable bound variable checks\012    -no-procedure-checks           disable"
" procedure call checks\012    -no-procedure-checks-for-usual-bindings\012             "
"                      disable procedure call checks only for usual\012             "
"                       bindings\012    -no-procedure-checks-for-toplevel-bindings\012 "
"                                  disable procedure call checks for toplevel\012   "
"                                 bindings\012    -strict-types                  ass"
"ume variable do not change their type\012    -clustering                    combine"
" groups of local procedures into dispatch\012                                     l"
"oop\012\012  Configuration options:\012\012    -unit NAME                     compile file a"
"s a library unit\012    -uses NAME                     declare library unit as used"
".\012    -heap-size NUMBER              specifies heap-size of compiled executable\012"
"    -nursery NUMBER  -stack-size NUMBER\012                                   speci"
"fies nursery size of compiled\012                                   executable\012    "
"-X -extend FILENAME            load file before compilation commences\012    -prelu"
"de EXPRESSION            add expression to beginning of source file\012    -postlud"
"e EXPRESSION           add expression to end of source file\012    -prologue FILENA"
"ME             include file before main source file\012    -epilogue FILENAME      "
"       include file after main source file\012\012    -e  -embedded                  c"
"ompile as embedded\012                                    (don\047t generate `main()\047)"
"\012    -gui                           compile as GUI application\012    -R  -require-"
"extension NAME    require extension and import in compiled\012                     "
"               code\012    -dll -library                  compile multiple units in"
"to a dynamic\012                                    library\012    -deploy            "
"            deploy self-contained application bundle\012\012  Options to other passes:"
"\012\012    -C OPTION                      pass option to C compiler\012    -L OPTION    "
"                  pass option to linker\012    -I<DIR>                        pass "
"\134\042-I<DIR>\134\042 to C compiler\012                                    (add include path)"
"\012    -L<DIR>                        pass \134\042-L<DIR>\134\042 to linker\012                 "
"                   (add library path)\012    -k                             keep in"
"termediate files\012    -c                             stop after compilation to ob"
"ject files\012    -t                             stop after translation to C\012    -c"
"c COMPILER                   select other C compiler than the default\012    -cxx C"
"OMPILER                  select other C++ compiler than the default\012    -ld COMP"
"ILER                   select other linker than the default \012    -lLIBNAME      "
"                link with given library\012                                    (`li"
"bLIBNAME\047 on UNIX,\012                                     `LIBNAME.lib\047 on Windows"
")\012    -static-libs                   link with static CHICKEN libraries\012    -sta"
"tic                        generate completely statically linked\012               "
"                     executable\012    -F<DIR>                        pass \134\042-F<DIR"
">\134\042 to C compiler\012                                    (add framework header path"
" on Mac OS X)\012    -framework NAME                passed to linker on Mac OS X\012  "
"  -rpath PATHNAME                add directory to runtime library search path\012  "
"  -Wl,...                        pass linker options\012    -strip                 "
"        strip resulting binary\012\012  Inquiry options:\012\012    -home                   "
"       show home-directory (where support files go)\012    -cflags                 "
"       show required C-compiler flags and exit\012    -ldflags                     "
"  show required linker flags and exit\012    -libs                          show re"
"quired libraries and exit\012    -cc-name                       show name of defaul"
"t C compiler used\012    -cxx-name                      show name of default C++ co"
"mpiler used\012    -ld-name                       show name of default linker used\012"
"    -dry-run                       just show commands executed, don\047t run them\012 "
"                                   (implies `-v\047)\012\012  Obscure options:\012\012    -debu"
"g MODES                   display debugging output for the given modes\012    -comp"
"iler PATHNAME             use other compiler than default `chicken\047\012    -raw    "
"                       do not generate implicit init- and exit code\012    -emit-ex"
"ternal-prototypes-first\012                                   emit prototypes for c"
"allbacks before foreign\012                                    declarations\012    -ig"
"nore-repository             do not refer to repository for extensions\012    -keep-"
"shadowed-macros          do not remove shadowed macro\012    -host                 "
"         compile for host when configured for\012                                  "
"  cross-compiling\012    -private-repository            load extensions from execut"
"able path\012    -deployed                      compile support file to be used fro"
"m a deployed \012                                    executable\012    -no-elevation  "
"                embed manifest on Windows to supress elevation\012                 "
"                   warnings for programs named `install\047 or `setup\047\012\012  Options c"
"an be collapsed if unambiguous, so\012\012    -vkfO\012\012  is the same as\012\012    -v -k -fixn"
"um-arithmetic -optimize\012\012  The contents of the environment variable CSC_OPTIONS "
"are implicitly passed to\012  every invocation of `");
lf[242]=C_decode_literal(C_heaptop,"\376B\000\000\033 FILENAME | OPTION ...\012\012  `");
lf[243]=C_decode_literal(C_heaptop,"\376B\000\000\007Usage: ");
lf[244]=C_h_intern(&lf[244],8,"-release");
lf[245]=C_h_intern(&lf[245],15,"chicken-version");
lf[246]=C_h_intern(&lf[246],8,"-version");
lf[247]=C_h_intern(&lf[247],7,"sprintf");
lf[248]=C_decode_literal(C_heaptop,"\376B\000\000\011 -version");
lf[249]=C_h_intern(&lf[249],4,"-c++");
lf[250]=C_decode_literal(C_heaptop,"\376B\000\000\017-no-cpp-precomp");
lf[251]=C_h_intern(&lf[251],5,"-objc");
lf[252]=C_h_intern(&lf[252],7,"-static");
lf[253]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[254]=C_decode_literal(C_heaptop,"\376B\000\000\026chicken-compile-static");
lf[255]=C_h_intern(&lf[255],12,"-static-libs");
lf[256]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[257]=C_decode_literal(C_heaptop,"\376B\000\000\026chicken-compile-static");
lf[258]=C_h_intern(&lf[258],7,"-cflags");
lf[259]=C_h_intern(&lf[259],8,"-ldflags");
lf[260]=C_h_intern(&lf[260],8,"-cc-name");
lf[261]=C_h_intern(&lf[261],9,"-cxx-name");
lf[262]=C_h_intern(&lf[262],8,"-ld-name");
lf[263]=C_h_intern(&lf[263],5,"-home");
lf[264]=C_h_intern(&lf[264],5,"-libs");
lf[265]=C_h_intern(&lf[265],2,"-v");
lf[266]=C_h_intern(&lf[266],8,"-verbose");
lf[267]=C_decode_literal(C_heaptop,"\376B\000\000\010-verbose");
lf[268]=C_decode_literal(C_heaptop,"\376B\000\000\002-v");
lf[269]=C_decode_literal(C_heaptop,"\376B\000\000\002-v");
lf[270]=C_decode_literal(C_heaptop,"\376B\000\000\002-Q");
lf[271]=C_h_intern(&lf[271],2,"-w");
lf[272]=C_h_intern(&lf[272],12,"-no-warnings");
lf[273]=C_decode_literal(C_heaptop,"\376B\000\000\002-w");
lf[274]=C_decode_literal(C_heaptop,"\376B\000\000\014-no-warnings");
lf[275]=C_h_intern(&lf[275],2,"-A");
lf[276]=C_h_intern(&lf[276],13,"-analyze-only");
lf[277]=C_decode_literal(C_heaptop,"\376B\000\000\015-analyze-only");
lf[278]=C_h_intern(&lf[278],2,"-P");
lf[279]=C_h_intern(&lf[279],13,"-check-syntax");
lf[280]=C_decode_literal(C_heaptop,"\376B\000\000\015-check-syntax");
lf[281]=C_h_intern(&lf[281],2,"-k");
lf[282]=C_h_intern(&lf[282],2,"-c");
lf[283]=C_h_intern(&lf[283],2,"-t");
lf[284]=C_h_intern(&lf[284],2,"-e");
lf[285]=C_h_intern(&lf[285],9,"-embedded");
lf[286]=C_decode_literal(C_heaptop,"\376B\000\000\014-DC_EMBEDDED");
lf[287]=C_h_intern(&lf[287],18,"-require-extension");
lf[288]=C_h_intern(&lf[288],2,"-R");
lf[289]=C_decode_literal(C_heaptop,"\376B\000\000\022-require-extension");
lf[290]=C_h_intern(&lf[290],19,"-private-repository");
lf[291]=C_h_intern(&lf[291],13,"-no-elevation");
lf[292]=C_h_intern(&lf[292],4,"-gui");
lf[293]=C_decode_literal(C_heaptop,"\376B\000\000\007-DC_GUI");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\012-lkernel32");
lf[295]=C_decode_literal(C_heaptop,"\376B\000\000\010-luser32");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\000\007-lgdi32");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\011-mwindows");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000\012chicken.rc");
lf[299]=C_h_intern(&lf[299],7,"-deploy");
lf[300]=C_h_intern(&lf[300],9,"-deployed");
lf[301]=C_h_intern(&lf[301],10,"-framework");
lf[302]=C_decode_literal(C_heaptop,"\376B\000\000\012-framework");
lf[303]=C_h_intern(&lf[303],2,"-o");
lf[304]=C_h_intern(&lf[304],12,"-output-file");
lf[305]=C_h_intern(&lf[305],2,"-O");
lf[306]=C_h_intern(&lf[306],3,"-O1");
lf[307]=C_decode_literal(C_heaptop,"\376B\000\000\017-optimize-level");
lf[308]=C_decode_literal(C_heaptop,"\376B\000\000\0011");
lf[309]=C_h_intern(&lf[309],3,"-O0");
lf[310]=C_decode_literal(C_heaptop,"\376B\000\000\017-optimize-level");
lf[311]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[312]=C_h_intern(&lf[312],3,"-O2");
lf[313]=C_decode_literal(C_heaptop,"\376B\000\000\017-optimize-level");
lf[314]=C_decode_literal(C_heaptop,"\376B\000\000\0012");
lf[315]=C_h_intern(&lf[315],3,"-O3");
lf[316]=C_decode_literal(C_heaptop,"\376B\000\000\017-optimize-level");
lf[317]=C_decode_literal(C_heaptop,"\376B\000\000\0013");
lf[318]=C_h_intern(&lf[318],3,"-O4");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000\017-optimize-level");
lf[320]=C_decode_literal(C_heaptop,"\376B\000\000\0014");
lf[321]=C_h_intern(&lf[321],3,"-O5");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000\017-optimize-level");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000\0015");
lf[324]=C_h_intern(&lf[324],3,"-d0");
lf[325]=C_decode_literal(C_heaptop,"\376B\000\000\014-debug-level");
lf[326]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[327]=C_h_intern(&lf[327],3,"-d1");
lf[328]=C_decode_literal(C_heaptop,"\376B\000\000\014-debug-level");
lf[329]=C_decode_literal(C_heaptop,"\376B\000\000\0011");
lf[330]=C_h_intern(&lf[330],3,"-d2");
lf[331]=C_decode_literal(C_heaptop,"\376B\000\000\014-debug-level");
lf[332]=C_decode_literal(C_heaptop,"\376B\000\000\0012");
lf[333]=C_h_intern(&lf[333],8,"-dry-run");
lf[334]=C_h_intern(&lf[334],2,"-s");
lf[335]=C_h_intern(&lf[335],4,"-dll");
lf[336]=C_h_intern(&lf[336],8,"-library");
lf[337]=C_h_intern(&lf[337],9,"-compiler");
lf[338]=C_h_intern(&lf[338],3,"-cc");
lf[339]=C_h_intern(&lf[339],4,"-cxx");
lf[340]=C_h_intern(&lf[340],3,"-ld");
lf[341]=C_h_intern(&lf[341],2,"-I");
lf[342]=C_decode_literal(C_heaptop,"\376B\000\000\015-include-path");
lf[343]=C_h_intern(&lf[343],2,"-C");
lf[344]=C_h_intern(&lf[344],6,"-strip");
lf[345]=C_decode_literal(C_heaptop,"\376B\000\000\002-s");
lf[346]=C_h_intern(&lf[346],2,"-L");
lf[347]=C_h_intern(&lf[347],6,"-rpath");
lf[348]=C_decode_literal(C_heaptop,"\376B\000\000\006-Wl,-R");
lf[349]=C_h_intern(&lf[349],3,"gnu");
lf[350]=C_h_intern(&lf[350],5,"clang");
lf[351]=C_h_intern(&lf[351],14,"build-platform");
lf[352]=C_h_intern(&lf[352],5,"-host");
lf[353]=C_h_intern(&lf[353],1,"-");
lf[354]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\001-\376\377\016");
lf[355]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[356]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-h\376\003\000\000\002\376B\000\000\005-help\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-s\376\003\000\000\002\376B\000\000\007-shared\376\377\016\376\003\000\000\002\376\003\000"
"\000\002\376\001\000\000\002-S\376\003\000\000\002\376B\000\000\013-scrutinize\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-M\376\003\000\000\002\376B\000\000\007-module\376\377\016\376\003\000\000\002\376\003\000\000\002"
"\376\001\000\000\002-P\376\003\000\000\002\376B\000\000\015-check-syntax\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-V\376\003\000\000\002\376B\000\000\010-version\376\377\016\376\003\000\000\002\376\003\000\000"
"\002\376\001\000\000\002-f\376\003\000\000\002\376B\000\000\022-fixnum-arithmetic\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-D\376\003\000\000\002\376B\000\000\010-feature\376\377\016\376\003\000"
"\000\002\376\003\000\000\002\376\001\000\000\002-i\376\003\000\000\002\376B\000\000\021-case-insensitive\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-K\376\003\000\000\002\376B\000\000\016-keyword-"
"style\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-X\376\003\000\000\002\376B\000\000\007-extend\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-J\376\003\000\000\002\376B\000\000\032-emit-al"
"l-import-libraries\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-x\376\003\000\000\002\376B\000\000\015-explicit-use\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-"
"u\376\003\000\000\002\376B\000\000\007-unsafe\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-j\376\003\000\000\002\376B\000\000\024-emit-import-library\376\377\016\376\003\000\000\002\376\003\000\000"
"\002\376\001\000\000\002-n\376\003\000\000\002\376B\000\000\021-emit-inline-file\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-b\376\003\000\000\002\376B\000\000\006-block\376\377\016\376\377\016");
lf[357]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\015-explicit-use\376\003\000\000\002\376\001\000\000\011-no-trace\376\003\000\000\002\376\001\000\000\014-no-warnings\376\003\000\000\002\376\001\000\000\026-no-us"
"ual-integrations\376\003\000\000\002\376\001\000\000\027-optimize-leaf-routines\376\003\000\000\002\376\001\000\000\007-unsafe\376\003\000\000\002\376\001\000\000\006-blo"
"ck\376\003\000\000\002\376\001\000\000\023-disable-interrupts\376\003\000\000\002\376\001\000\000\022-fixnum-arithmetic\376\003\000\000\002\376\001\000\000\012-to-stdout\376"
"\003\000\000\002\376\001\000\000\010-profile\376\003\000\000\002\376\001\000\000\004-raw\376\003\000\000\002\376\001\000\000\023-accumulate-profile\376\003\000\000\002\376\001\000\000\015-check-syn"
"tax\376\003\000\000\002\376\001\000\000\021-case-insensitive\376\003\000\000\002\376\001\000\000\007-shared\376\003\000\000\002\376\001\000\000\017-compile-syntax\376\003\000\000\002\376\001\000"
"\000\017-no-lambda-info\376\003\000\000\002\376\001\000\000\010-dynamic\376\003\000\000\002\376\001\000\000\036-disable-stack-overflow-checks\376\003\000\000\002"
"\376\001\000\000\006-local\376\003\000\000\002\376\001\000\000\037-emit-external-prototypes-first\376\003\000\000\002\376\001\000\000\007-inline\376\003\000\000\002\376\001\000\000\010-"
"release\376\003\000\000\002\376\001\000\000\013-scrutinize\376\003\000\000\002\376\001\000\000\015-analyze-only\376\003\000\000\002\376\001\000\000\025-keep-shadowed-macr"
"os\376\003\000\000\002\376\001\000\000\016-inline-global\376\003\000\000\002\376\001\000\000\022-ignore-repository\376\003\000\000\002\376\001\000\000\021-no-symbol-escap"
"e\376\003\000\000\002\376\001\000\000\030-no-parentheses-synonyms\376\003\000\000\002\376\001\000\000\014-r5rs-syntax\376\003\000\000\002\376\001\000\000\017-no-argc-chec"
"ks\376\003\000\000\002\376\001\000\000\020-no-bound-checks\376\003\000\000\002\376\001\000\000\024-no-procedure-checks\376\003\000\000\002\376\001\000\000\023-no-compiler"
"-syntax\376\003\000\000\002\376\001\000\000\032-emit-all-import-libraries\376\003\000\000\002\376\001\000\000\013-setup-mode\376\003\000\000\002\376\001\000\000\015-no-el"
"evation\376\003\000\000\002\376\001\000\000\027-no-module-registration\376\003\000\000\002\376\001\000\000\047-no-procedure-checks-for-usual"
"-bindings\376\003\000\000\002\376\001\000\000\007-module\376\003\000\000\002\376\001\000\000\013-specialize\376\003\000\000\002\376\001\000\000\015-strict-types\376\003\000\000\002\376\001\000\000\013"
"-clustering\376\003\000\000\002\376\001\000\000\014-lambda-lift\376\003\000\000\002\376\001\000\000\011-unboxing\376\003\000\000\002\376\001\000\000\052-no-procedure-chec"
"ks-for-toplevel-bindings\376\377\016");
lf[358]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006-debug\376\003\000\000\002\376\001\000\000\012-heap-size\376\003\000\000\002\376\001\000\000\010-nursery\376\003\000\000\002\376\001\000\000\013-stack-size\376\003\000\000\002"
"\376\001\000\000\011-compiler\376\003\000\000\002\376\001\000\000\005-unit\376\003\000\000\002\376\001\000\000\005-uses\376\003\000\000\002\376\001\000\000\016-keyword-style\376\003\000\000\002\376\001\000\000\017-o"
"ptimize-level\376\003\000\000\002\376\001\000\000\015-include-path\376\003\000\000\002\376\001\000\000\016-database-size\376\003\000\000\002\376\001\000\000\007-extend\376\003\000"
"\000\002\376\001\000\000\010-prelude\376\003\000\000\002\376\001\000\000\011-postlude\376\003\000\000\002\376\001\000\000\011-prologue\376\003\000\000\002\376\001\000\000\011-epilogue\376\003\000\000\002\376\001\000"
"\000\015-inline-limit\376\003\000\000\002\376\001\000\000\015-profile-name\376\003\000\000\002\376\001\000\000\021-emit-inline-file\376\003\000\000\002\376\001\000\000\006-type"
"s\376\003\000\000\002\376\001\000\000\017-emit-type-file\376\003\000\000\002\376\001\000\000\010-feature\376\003\000\000\002\376\001\000\000\014-debug-level\376\003\000\000\002\376\001\000\000\014-hea"
"p-growth\376\003\000\000\002\376\001\000\000\017-heap-shrinkage\376\003\000\000\002\376\001\000\000\022-heap-initial-size\376\003\000\000\002\376\001\000\000\024-consult-"
"inline-file\376\003\000\000\002\376\001\000\000\024-emit-import-library\376\003\000\000\002\376\001\000\000\013-no-feature\376\377\016");
lf[359]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[360]=C_h_intern(&lf[360],9,"substring");
lf[361]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[362]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid option `~A\047");
lf[363]=C_h_intern(&lf[363],15,"lset-difference");
lf[364]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000P\376\003\000\000\002\376\377\012\000\000H\376\003\000\000\002\376\377\012\000\000h\376\003\000\000\002\376\377\012\000\000s\376\003\000\000\002\376\377\012\000\000f\376\003\000\000\002\376\377\012\000\000i\376\003\000\000\002\376\377\012\000\000E\376\003\000"
"\000\002\376\377\012\000\000N\376\003\000\000\002\376\377\012\000\000x\376\003\000\000\002\376\377\012\000\000u\376\003\000\000\002\376\377\012\000\000b\376\003\000\000\002\376\377\012\000\000v\376\003\000\000\002\376\377\012\000\000w\376\003\000\000\002\376\377\012\000\000A\376\003\000\000\002\376"
"\377\012\000\000O\376\003\000\000\002\376\377\012\000\000e\376\003\000\000\002\376\377\012\000\000W\376\003\000\000\002\376\377\012\000\000k\376\003\000\000\002\376\377\012\000\000c\376\003\000\000\002\376\377\012\000\000t\376\003\000\000\002\376\377\012\000\000g\376\003\000\000\002\376\377\012\000"
"\000S\376\003\000\000\002\376\377\012\000\000J\376\003\000\000\002\376\377\012\000\000M\376\377\016");
lf[365]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid option `~A\047");
lf[366]=C_decode_literal(C_heaptop,"\376B\000\000\004-Wl,");
lf[367]=C_h_intern(&lf[367],18,"decompose-pathname");
lf[368]=C_decode_literal(C_heaptop,"\376B\000\000\001h");
lf[369]=C_decode_literal(C_heaptop,"\376B\000\000\001c");
lf[370]=C_decode_literal(C_heaptop,"\376B\000\000\002rc");
lf[371]=C_decode_literal(C_heaptop,"\376B\000\000\003cpp");
lf[372]=C_decode_literal(C_heaptop,"\376B\000\000\001C");
lf[373]=C_decode_literal(C_heaptop,"\376B\000\000\002cc");
lf[374]=C_decode_literal(C_heaptop,"\376B\000\000\003cxx");
lf[375]=C_decode_literal(C_heaptop,"\376B\000\000\003hpp");
lf[376]=C_decode_literal(C_heaptop,"\376B\000\000\017-no-cpp-precomp");
lf[377]=C_decode_literal(C_heaptop,"\376B\000\000\001m");
lf[378]=C_decode_literal(C_heaptop,"\376B\000\000\001M");
lf[379]=C_decode_literal(C_heaptop,"\376B\000\000\002mm");
lf[380]=C_decode_literal(C_heaptop,"\376B\000\000\030file `~A\047 does not exist");
lf[381]=C_decode_literal(C_heaptop,"\376B\000\000\004.scm");
lf[382]=C_decode_literal(C_heaptop,"\376B\000\000\002-:");
lf[383]=C_h_intern(&lf[383],15,"-optimize-level");
lf[384]=C_h_intern(&lf[384],15,"-benchmark-mode");
lf[385]=C_h_intern(&lf[385],10,"-to-stdout");
lf[386]=C_h_intern(&lf[386],7,"-shared");
lf[387]=C_h_intern(&lf[387],8,"-dynamic");
lf[388]=C_h_intern(&lf[388],14,"string->symbol");
lf[389]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[390]=C_decode_literal(C_heaptop,"\376B\000\000\013CSC_OPTIONS");
lf[391]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[392]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[393]=C_decode_literal(C_heaptop,"\376B\000\000\003-I\042");
lf[394]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[395]=C_decode_literal(C_heaptop,"\376B\000\000\002:;");
lf[396]=C_decode_literal(C_heaptop,"\376B\000\000\026CHICKEN_C_INCLUDE_PATH");
lf[397]=C_decode_literal(C_heaptop,"\376B\000\000\003-I\042");
lf[398]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[399]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[400]=C_decode_literal(C_heaptop,"\376B\000\000\007include");
lf[401]=C_decode_literal(C_heaptop,"\376B\000\000\007chicken");
lf[402]=C_decode_literal(C_heaptop,"\376B\000\000\002-l");
lf[403]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[404]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[405]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[406]=C_decode_literal(C_heaptop,"\376B\000\000\003cyg");
lf[407]=C_decode_literal(C_heaptop,"\376B\000\000\002-0");
lf[408]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[409]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\005-DPIC\376\377\016");
lf[410]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\005-fPIC\376\003\000\000\002\376B\000\000\005-DPIC\376\377\016");
lf[411]=C_decode_literal(C_heaptop,"\376B\000\000\003bin");
lf[412]=C_decode_literal(C_heaptop,"\376B\000\000\007chicken");
lf[413]=C_decode_literal(C_heaptop,"\376B\000\000\005share");
lf[414]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[415]=C_h_intern(&lf[415],22,"command-line-arguments");
lf[416]=C_decode_literal(C_heaptop,"\376B\000\000\016CHICKEN_PREFIX");
lf[417]=C_h_intern(&lf[417],16,"software-version");
C_register_lf2(lf,418,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1353,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3757 in k3754 in k3722 in k3720 in k3718 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in ... */
static void C_ccall f_3758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3758,2,t0,t1);}
t2=(C_truep(C_retrieve2(lf[3],"osx"))?C_retrieve2(lf[67],"gui"):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3770,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csc.scm:939: pathname-file */
t4=C_fast_retrieve(lf[164]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,C_retrieve2(lf[87],"target-filename"));}
else{
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[3];
f_3725(t4,t3);}}

/* k3754 in k3722 in k3720 in k3718 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in ... */
static void C_fcall f_3756(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3756,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3758,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3773,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[3],"osx"))){
t4=C_retrieve2(lf[67],"gui");
if(C_truep(C_retrieve2(lf[67],"gui"))){
/* csc.scm:935: make-pathname */
t5=C_fast_retrieve(lf[104]);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)((C_word*)t0)[2])[1],lf[169]);}
else{
t5=t3;
f_3773(2,t5,((C_word*)((C_word*)t0)[2])[1]);}}
else{
t4=t3;
f_3773(2,t4,((C_word*)((C_word*)t0)[2])[1]);}}
else{
t2=((C_word*)t0)[3];
f_3725(t2,C_SCHEME_UNDEFINED);}}

/* k2632 in k2621 in k2481 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in ... */
static void C_ccall f_2633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:720: append */
t2=*((C_word*)lf[101]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[86],"link-options"),t1);}

/* k3769 in k3757 in k3754 in k3722 in k3720 in k3718 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in ... */
static void C_ccall f_3770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3770,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[2])[1];
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4347,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* csc.scm:1055: make-pathname */
t4=C_fast_retrieve(lf[104]);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[163]);}

/* k3696 in map-loop631 in k3664 in compiler-options in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in ... */
static void C_ccall f_3697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3697,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[2])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_3672(t6,((C_word*)t0)[5],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=((C_word*)((C_word*)t0)[4])[1];
f_3672(t6,((C_word*)t0)[5],t5);}}

/* k3743 in for-each-loop744 in k3724 in k3722 in k3720 in k3718 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in ... */
static void C_ccall f_3744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3735(t3,((C_word*)t0)[4],t2);}

/* k3898 in k3864 in k3861 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in ... */
static void C_ccall f_3899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:901: string-append */
t2=*((C_word*)lf[119]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[181],t1);}

/* k3889 in k3864 in k3861 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in ... */
static void C_ccall f_3890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:898: make-pathname */
t2=C_fast_retrieve(lf[104]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1],t1);}

/* k4597 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in k1449 in k1416 in k1412 in k1389 in k4690 in k4693 in k4696 in k4699 in k1368 in k1366 in k1364 in k1362 in ... */
static void C_ccall f_4598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:130: string-split */
t2=C_fast_retrieve(lf[224]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2504 in k2481 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in ... */
static void C_ccall f_2505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=C_i_car(((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate(&lf[28] /* (set! translator ...) */,t2);
t4=C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
/* csc.scm:796: loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_1796(t6,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* k2597 in k2586 in k2481 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in ... */
static void C_ccall f_2598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:714: append */
t2=*((C_word*)lf[101]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve2(lf[80],"compile-options"),t1);}

/* k2589 in k2586 in k2481 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in ... */
static void C_ccall f_2591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(&lf[80] /* (set! compile-options ...) */,t1);
t3=C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
/* csc.scm:796: loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_1796(t5,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* map-loop631 in k3664 in compiler-options in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in ... */
static void C_fcall f_3672(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3672,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3697,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* csc.scm:878: g637 */
t5=C_retrieve2(lf[98],"quote-option");
f_4203(3,t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3668 in k3664 in compiler-options in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in ... */
static void C_ccall f_3670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:877: string-intersperse */
t2=C_fast_retrieve(lf[100]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in ... */
static void C_ccall f_3715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3715,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3717,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=C_retrieve2(lf[87],"target-filename");
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5357,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:92: normalize-pathname */
t5=C_fast_retrieve(lf[26]);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,C_retrieve2(lf[87],"target-filename"));}

/* k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in ... */
static void C_ccall f_3717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3717,2,t0,t1);}
t2=(*a=C_VECTOR_TYPE|1,a[1]=t1,tmp=(C_word)a,a+=2,tmp);
t3=C_SCHEME_FALSE;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3719,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve2(lf[68],"deploy"))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3863,a[2]=t4,a[3]=t2,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* csc.scm:892: pathname-strip-extension */
t7=C_fast_retrieve(lf[187]);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,C_retrieve2(lf[87],"target-filename"));}
else{
t6=t5;
f_3719(2,t6,C_SCHEME_UNDEFINED);}}

/* k3718 in k3716 in k3713 in k1826 in k1821 in k1816 in k1814 in k1812 in k1809 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in ... */
static void C_ccall f_3719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3719,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3721,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3834,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3837,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_truep(C_retrieve2(lf[59],"cpp-mode"))?C_retrieve2(lf[33],"c++-linker"):C_retrieve2(lf[32],"linker"));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3843,a[2]=t4,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3849,a[2]=t6,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3859,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=C_retrieve2(lf[87],"target-filename");
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5337,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:92: normalize-pathname */
t11=C_fast_retrieve(lf[26]);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t10,C_retrieve2(lf[87],"target-filename"));}

/* k3010 */
static void C_fcall f_3011(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3011,NULL,2,t0,t1);}
t2=lf[59] /* cpp-mode */ =C_SCHEME_TRUE;;
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3016,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=C_a_i_list1(&a,1,((C_word*)t0)[3]);
/* csc.scm:783: append */
t5=*((C_word*)lf[101]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,C_retrieve2(lf[53],"c-files"),t4);}

/* k2520 in k2481 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in ... */
static void C_ccall f_2521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=C_i_car(((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate(&lf[29] /* (set! compiler ...) */,t2);
t4=C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
/* csc.scm:796: loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_1796(t6,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* k3014 in k3010 */
static void C_ccall f_3016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[53] /* (set! c-files ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2536 in k2481 in k1994 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in ... */
static void C_ccall f_2537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=C_i_car(((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate(&lf[30] /* (set! c++-compiler ...) */,t2);
t4=C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
/* csc.scm:796: loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_1796(t6,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);}

/* quit in k1389 in k4690 in k4693 in k4696 in k4699 in k1368 in k1366 in k1364 in k1362 in k1360 in k1358 in k1356 in k1354 in k1352 */
static void C_fcall f_1393(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1393,NULL,3,t1,t2,t3);}
t4=*((C_word*)lf[12]+1);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1397,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1410,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t7=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_CSC_PROGRAM),C_fix(0));}

/* k1389 in k4690 in k4693 in k4696 in k4699 in k1368 in k1366 in k1364 in k1362 in k1360 in k1358 in k1356 in k1354 in k1352 */
static void C_ccall f_1390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1390,2,t0,t1);}
t2=C_mutate(&lf[9] /* (set! elf ...) */,C_u_i_memq(t1,lf[10]));
t3=C_mutate(&lf[11] /* (set! quit ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1393,tmp=(C_word)a,a+=2,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1414,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:81: get-environment-variable */
t5=C_fast_retrieve(lf[226]);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[416]);}

/* k1657 in k1642 in k1805 in loop in k4436 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in ... */
static void C_ccall f_1658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1658,2,t0,t1);}
if(C_truep(C_retrieve2(lf[19],"chicken-prefix"))){
t2=C_a_i_list2(&a,2,C_retrieve2(lf[19],"chicken-prefix"),lf[232]);
/* csc.scm:88: make-pathname */
t3=C_fast_retrieve(lf[104]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,lf[233]);}
else{
/* csc.scm:269: conc */
t2=C_fast_retrieve(lf[228]);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[229],t1,lf[230]);}}

/* k1398 in k1396 in quit in k1389 in k4690 in k4693 in k4696 in k4699 in k1368 in k1366 in k1364 in k1362 in k1360 in k1358 in k1356 in k1354 in k1352 */
static void C_ccall f_1399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1399,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1401,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_apply(6,0,t2,*((C_word*)lf[15]+1),*((C_word*)lf[12]+1),((C_word*)t0)[3],((C_word*)t0)[4]);}

/* k1396 in quit in k1389 in k4690 in k4693 in k4696 in k4699 in k1368 in k1366 in k1364 in k1362 in k1360 in k1358 in k1356 in k1354 in k1352 */
static void C_ccall f_1397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1397,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1399,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:77: display */
t3=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[17],*((C_word*)lf[12]+1));}

/* k4439 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in k1449 in k1416 in ... */
static void C_ccall f_4440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:1114: append */
t2=*((C_word*)lf[101]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_retrieve2(lf[20],"arguments"));}

/* k4442 in k1574 in k1566 in k1559 in k4535 in k4547 in k1544 in k1540 in k1509 in k1504 in k1499 in k1495 in k1491 in k1485 in k1473 in k1469 in k1465 in k1461 in k1457 in k1453 in k1449 in k1416 in ... */
static void C_ccall f_4443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=t1;
/* csc.scm:1115: string-split */
t3=C_fast_retrieve(lf[224]);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}
else{
/* csc.scm:1115: string-split */
t2=C_fast_retrieve(lf[224]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[389]);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[450] = {
{"f_4449:csc_2escm",(void*)f_4449},
{"f_4589:csc_2escm",(void*)f_4589},
{"f_4586:csc_2escm",(void*)f_4586},
{"f_1643:csc_2escm",(void*)f_1643},
{"f_1649:csc_2escm",(void*)f_1649},
{"f_1646:csc_2escm",(void*)f_1646},
{"f_4431:csc_2escm",(void*)f_4431},
{"f_4434:csc_2escm",(void*)f_4434},
{"f_4437:csc_2escm",(void*)f_4437},
{"f_2553:csc_2escm",(void*)f_2553},
{"f_1673:csc_2escm",(void*)f_1673},
{"f_4461:csc_2escm",(void*)f_4461},
{"f_4467:csc_2escm",(void*)f_4467},
{"f_4464:csc_2escm",(void*)f_4464},
{"f_4465:csc_2escm",(void*)f_4465},
{"f_2569:csc_2escm",(void*)f_2569},
{"f_1367:csc_2escm",(void*)f_1367},
{"f_1365:csc_2escm",(void*)f_1365},
{"f_1369:csc_2escm",(void*)f_1369},
{"f_1363:csc_2escm",(void*)f_1363},
{"f_1361:csc_2escm",(void*)f_1361},
{"f_2573:csc_2escm",(void*)f_2573},
{"f_4458:csc_2escm",(void*)f_4458},
{"f_2644:csc_2escm",(void*)f_2644},
{"f_1357:csc_2escm",(void*)f_1357},
{"f_1355:csc_2escm",(void*)f_1355},
{"f_1359:csc_2escm",(void*)f_1359},
{"f_1353:csc_2escm",(void*)f_1353},
{"f_3773:csc_2escm",(void*)f_3773},
{"f_4404:csc_2escm",(void*)f_4404},
{"f_2587:csc_2escm",(void*)f_2587},
{"f_2657:csc_2escm",(void*)f_2657},
{"f_4409:csc_2escm",(void*)f_4409},
{"f_3791:csc_2escm",(void*)f_3791},
{"f_1606:csc_2escm",(void*)f_1606},
{"f_4216:csc_2escm",(void*)f_4216},
{"f_4210:csc_2escm",(void*)f_4210},
{"f5424:csc_2escm",(void*)f5424},
{"f_1601:csc_2escm",(void*)f_1601},
{"f_2667:csc_2escm",(void*)f_2667},
{"f_2661:csc_2escm",(void*)f_2661},
{"f_4203:csc_2escm",(void*)f_4203},
{"f_4429:csc_2escm",(void*)f_4429},
{"f5437:csc_2escm",(void*)f5437},
{"f_2670:csc_2escm",(void*)f_2670},
{"f_4700:csc_2escm",(void*)f_4700},
{"f_4067:csc_2escm",(void*)f_4067},
{"f_4069:csc_2escm",(void*)f_4069},
{"f_4063:csc_2escm",(void*)f_4063},
{"f_4065:csc_2escm",(void*)f_4065},
{"f_4415:csc_2escm",(void*)f_4415},
{"f_3789:csc_2escm",(void*)f_3789},
{"f_4095:csc_2escm",(void*)f_4095},
{"f5411:csc_2escm",(void*)f5411},
{"f_2611:csc_2escm",(void*)f_2611},
{"f5416:csc_2escm",(void*)f5416},
{"f_4080:csc_2escm",(void*)f_4080},
{"f_4088:csc_2escm",(void*)f_4088},
{"f_4083:csc_2escm",(void*)f_4083},
{"f_3045:csc_2escm",(void*)f_3045},
{"f_3049:csc_2escm",(void*)f_3049},
{"f_1695:csc_2escm",(void*)f_1695},
{"f_4056:csc_2escm",(void*)f_4056},
{"f_4054:csc_2escm",(void*)f_4054},
{"f_3034:csc_2escm",(void*)f_3034},
{"f_1689:csc_2escm",(void*)f_1689},
{"f_4041:csc_2escm",(void*)f_4041},
{"f_4478:csc_2escm",(void*)f_4478},
{"f_4473:csc_2escm",(void*)f_4473},
{"f5362:csc_2escm",(void*)f5362},
{"f5369:csc_2escm",(void*)f5369},
{"f_4071:csc_2escm",(void*)f_4071},
{"f_4077:csc_2escm",(void*)f_4077},
{"f_4074:csc_2escm",(void*)f_4074},
{"f_2696:csc_2escm",(void*)f_2696},
{"f_3063:csc_2escm",(void*)f_3063},
{"f_3069:csc_2escm",(void*)f_3069},
{"f_4032:csc_2escm",(void*)f_4032},
{"f_4038:csc_2escm",(void*)f_4038},
{"f_4658:csc_2escm",(void*)f_4658},
{"f_3056:csc_2escm",(void*)f_3056},
{"f_4640:csc_2escm",(void*)f_4640},
{"f_3975:csc_2escm",(void*)f_3975},
{"f_4649:csc_2escm",(void*)f_4649},
{"f_1506:csc_2escm",(void*)f_1506},
{"f_1501:csc_2escm",(void*)f_1501},
{"f_3917:csc_2escm",(void*)f_3917},
{"f_3919:csc_2escm",(void*)f_3919},
{"f_4667:csc_2escm",(void*)f_4667},
{"f_3911:csc_2escm",(void*)f_3911},
{"f_4616:csc_2escm",(void*)f_4616},
{"f_3909:csc_2escm",(void*)f_3909},
{"f_4610:csc_2escm",(void*)f_4610},
{"f_3099:csc_2escm",(void*)f_3099},
{"f_1511:csc_2escm",(void*)f_1511},
{"f_3934:csc_2escm",(void*)f_3934},
{"f_3936:csc_2escm",(void*)f_3936},
{"f_3939:csc_2escm",(void*)f_3939},
{"f_3295:csc_2escm",(void*)f_3295},
{"f_3291:csc_2escm",(void*)f_3291},
{"f_3931:csc_2escm",(void*)f_3931},
{"f_3299:csc_2escm",(void*)f_3299},
{"f_1546:csc_2escm",(void*)f_1546},
{"f_1542:csc_2escm",(void*)f_1542},
{"f_3925:csc_2escm",(void*)f_3925},
{"f_3928:csc_2escm",(void*)f_3928},
{"f_4631:csc_2escm",(void*)f_4631},
{"f_3286:csc_2escm",(void*)f_3286},
{"f_3922:csc_2escm",(void*)f_3922},
{"f_3289:csc_2escm",(void*)f_3289},
{"f_2912:csc_2escm",(void*)f_2912},
{"f_4622:csc_2escm",(void*)f_4622},
{"f_1568:csc_2escm",(void*)f_1568},
{"f_1560:csc_2escm",(void*)f_1560},
{"f_4162:csc_2escm",(void*)f_4162},
{"f_4164:csc_2escm",(void*)f_4164},
{"f_4195:csc_2escm",(void*)f_4195},
{"f_1586:csc_2escm",(void*)f_1586},
{"f_1589:csc_2escm",(void*)f_1589},
{"f_2900:csc_2escm",(void*)f_2900},
{"f_2909:csc_2escm",(void*)f_2909},
{"f_4189:csc_2escm",(void*)f_4189},
{"f_4185:csc_2escm",(void*)f_4185},
{"f_1576:csc_2escm",(void*)f_1576},
{"f_2958:csc_2escm",(void*)f_2958},
{"f_2953:csc_2escm",(void*)f_2953},
{"f_4697:csc_2escm",(void*)f_4697},
{"f_4691:csc_2escm",(void*)f_4691},
{"f_4694:csc_2escm",(void*)f_4694},
{"f_3987:csc_2escm",(void*)f_3987},
{"f_2927:csc_2escm",(void*)f_2927},
{"f_4122:csc_2escm",(void*)f_4122},
{"f_3980:csc_2escm",(void*)f_3980},
{"f_2025:csc_2escm",(void*)f_2025},
{"f_4125:csc_2escm",(void*)f_4125},
{"f_1592:csc_2escm",(void*)f_1592},
{"f_1593:csc_2escm",(void*)f_1593},
{"f_1595:csc_2escm",(void*)f_1595},
{"f_4682:csc_2escm",(void*)f_4682},
{"f_2033:csc_2escm",(void*)f_2033},
{"f_2738:csc_2escm",(void*)f_2738},
{"f_2039:csc_2escm",(void*)f_2039},
{"f_4156:csc_2escm",(void*)f_4156},
{"f_4159:csc_2escm",(void*)f_4159},
{"f_4147:csc_2escm",(void*)f_4147},
{"f_4005:csc_2escm",(void*)f_4005},
{"f_3950:csc_2escm",(void*)f_3950},
{"f5462:csc_2escm",(void*)f5462},
{"f5467:csc_2escm",(void*)f5467},
{"f_3948:csc_2escm",(void*)f_3948},
{"f_3945:csc_2escm",(void*)f_3945},
{"f_3942:csc_2escm",(void*)f_3942},
{"f5472:csc_2escm",(void*)f5472},
{"f_2070:csc_2escm",(void*)f_2070},
{"f5442:csc_2escm",(void*)f5442},
{"f5447:csc_2escm",(void*)f5447},
{"f_4679:csc_2escm",(void*)f_4679},
{"f_4676:csc_2escm",(void*)f_4676},
{"f_4673:csc_2escm",(void*)f_4673},
{"f_4670:csc_2escm",(void*)f_4670},
{"f_2081:csc_2escm",(void*)f_2081},
{"f5452:csc_2escm",(void*)f5452},
{"f5457:csc_2escm",(void*)f5457},
{"f_1843:csc_2escm",(void*)f_1843},
{"f_1846:csc_2escm",(void*)f_1846},
{"f_1860:csc_2escm",(void*)f_1860},
{"f_2744:csc_2escm",(void*)f_2744},
{"f_1875:csc_2escm",(void*)f_1875},
{"f_1872:csc_2escm",(void*)f_1872},
{"f_2754:csc_2escm",(void*)f_2754},
{"f_1863:csc_2escm",(void*)f_1863},
{"f_1869:csc_2escm",(void*)f_1869},
{"f_1866:csc_2escm",(void*)f_1866},
{"f5296:csc_2escm",(void*)f5296},
{"f_2261:csc_2escm",(void*)f_2261},
{"f_2267:csc_2escm",(void*)f_2267},
{"f_2265:csc_2escm",(void*)f_2265},
{"f_2763:csc_2escm",(void*)f_2763},
{"f_1892:csc_2escm",(void*)f_1892},
{"f_1894:csc_2escm",(void*)f_1894},
{"f_2861:csc_2escm",(void*)f_2861},
{"f_2773:csc_2escm",(void*)f_2773},
{"f_2863:csc_2escm",(void*)f_2863},
{"f_2704:csc_2escm",(void*)f_2704},
{"f_2702:csc_2escm",(void*)f_2702},
{"f_2700:csc_2escm",(void*)f_2700},
{"f_2008:csc_2escm",(void*)f_2008},
{"f_2875:csc_2escm",(void*)f_2875},
{"f_2873:csc_2escm",(void*)f_2873},
{"f_2710:csc_2escm",(void*)f_2710},
{"f_2019:csc_2escm",(void*)f_2019},
{"f_3331:csc_2escm",(void*)f_3331},
{"f_3333:csc_2escm",(void*)f_3333},
{"f_1901:csc_2escm",(void*)f_1901},
{"f_3358:csc_2escm",(void*)f_3358},
{"f5332:csc_2escm",(void*)f5332},
{"f_4115:csc_2escm",(void*)f_4115},
{"f_1929:csc_2escm",(void*)f_1929},
{"f_1927:csc_2escm",(void*)f_1927},
{"f_4113:csc_2escm",(void*)f_4113},
{"f5327:csc_2escm",(void*)f5327},
{"f_3308:csc_2escm",(void*)f_3308},
{"f_2786:csc_2escm",(void*)f_2786},
{"f5301:csc_2escm",(void*)f5301},
{"f_4101:csc_2escm",(void*)f_4101},
{"f_3320:csc_2escm",(void*)f_3320},
{"f5337:csc_2escm",(void*)f5337},
{"f_2799:csc_2escm",(void*)f_2799},
{"f_3311:csc_2escm",(void*)f_3311},
{"f_1730:csc_2escm",(void*)f_1730},
{"f_3326:csc_2escm",(void*)f_3326},
{"f_1936:csc_2escm",(void*)f_1936},
{"f_4332:csc_2escm",(void*)f_4332},
{"f_1728:csc_2escm",(void*)f_1728},
{"f_4335:csc_2escm",(void*)f_4335},
{"f_4338:csc_2escm",(void*)f_4338},
{"f_1401:csc_2escm",(void*)f_1401},
{"f_1722:csc_2escm",(void*)f_1722},
{"f_3317:csc_2escm",(void*)f_3317},
{"f_3314:csc_2escm",(void*)f_3314},
{"f_3407:csc_2escm",(void*)f_3407},
{"f_4353:csc_2escm",(void*)f_4353},
{"f_4351:csc_2escm",(void*)f_4351},
{"f_4356:csc_2escm",(void*)f_4356},
{"f_1404:csc_2escm",(void*)f_1404},
{"f_4358:csc_2escm",(void*)f_4358},
{"f_3466:csc_2escm",(void*)f_3466},
{"f_4341:csc_2escm",(void*)f_4341},
{"f_4347:csc_2escm",(void*)f_4347},
{"f_4349:csc_2escm",(void*)f_4349},
{"f_1410:csc_2escm",(void*)f_1410},
{"f5322:csc_2escm",(void*)f5322},
{"f_3455:csc_2escm",(void*)f_3455},
{"f_1440:csc_2escm",(void*)f_1440},
{"f_3453:csc_2escm",(void*)f_3453},
{"f_3450:csc_2escm",(void*)f_3450},
{"f_1418:csc_2escm",(void*)f_1418},
{"f_1414:csc_2escm",(void*)f_1414},
{"f_4363:csc_2escm",(void*)f_4363},
{"f_4360:csc_2escm",(void*)f_4360},
{"f_4365:csc_2escm",(void*)f_4365},
{"f_2407:csc_2escm",(void*)f_2407},
{"f_3436:csc_2escm",(void*)f_3436},
{"f_1447:csc_2escm",(void*)f_1447},
{"f_3376:csc_2escm",(void*)f_3376},
{"f_4302:csc_2escm",(void*)f_4302},
{"f_1451:csc_2escm",(void*)f_1451},
{"f_2427:csc_2escm",(void*)f_2427},
{"f_1467:csc_2escm",(void*)f_1467},
{"f_3397:csc_2escm",(void*)f_3397},
{"f_2437:csc_2escm",(void*)f_2437},
{"f_1455:csc_2escm",(void*)f_1455},
{"f_1459:csc_2escm",(void*)f_1459},
{"f_4326:csc_2escm",(void*)f_4326},
{"f_4324:csc_2escm",(void*)f_4324},
{"f_4322:csc_2escm",(void*)f_4322},
{"f_4320:csc_2escm",(void*)f_4320},
{"f_3481:csc_2escm",(void*)f_3481},
{"f_3484:csc_2escm",(void*)f_3484},
{"f_1755:csc_2escm",(void*)f_1755},
{"f_4329:csc_2escm",(void*)f_4329},
{"f_1471:csc_2escm",(void*)f_1471},
{"f_2447:csc_2escm",(void*)f_2447},
{"f_1487:csc_2escm",(void*)f_1487},
{"f_3475:csc_2escm",(void*)f_3475},
{"f_3478:csc_2escm",(void*)f_3478},
{"f_3806:csc_2escm",(void*)f_3806},
{"f_3809:csc_2escm",(void*)f_3809},
{"f_1475:csc_2escm",(void*)f_1475},
{"f_1778:csc_2escm",(void*)f_1778},
{"f_1493:csc_2escm",(void*)f_1493},
{"f_2467:csc_2escm",(void*)f_2467},
{"f_2139:csc_2escm",(void*)f_2139},
{"f_2397:csc_2escm",(void*)f_2397},
{"f_4377:csc_2escm",(void*)f_4377},
{"f_1765:csc_2escm",(void*)f_1765},
{"f_4370:csc_2escm",(void*)f_4370},
{"f_1761:csc_2escm",(void*)f_1761},
{"f_1497:csc_2escm",(void*)f_1497},
{"f_2316:csc_2escm",(void*)f_2316},
{"f_2483:csc_2escm",(void*)f_2483},
{"f_2319:csc_2escm",(void*)f_2319},
{"f_4398:csc_2escm",(void*)f_4398},
{"f_4392:csc_2escm",(void*)f_4392},
{"f_3849:csc_2escm",(void*)f_3849},
{"f_1463:csc_2escm",(void*)f_1463},
{"f_3843:csc_2escm",(void*)f_3843},
{"f_2322:csc_2escm",(void*)f_2322},
{"f_2417:csc_2escm",(void*)f_2417},
{"f_2128:csc_2escm",(void*)f_2128},
{"f_3427:csc_2escm",(void*)f_3427},
{"f_3837:csc_2escm",(void*)f_3837},
{"f_3834:csc_2escm",(void*)f_3834},
{"f_2174:csc_2escm",(void*)f_2174},
{"f_3416:csc_2escm",(void*)f_3416},
{"f_3824:csc_2escm",(void*)f_3824},
{"f_3815:csc_2escm",(void*)f_3815},
{"f_3812:csc_2escm",(void*)f_3812},
{"f_2457:csc_2escm",(void*)f_2457},
{"f_2160:csc_2escm",(void*)f_2160},
{"f_2162:csc_2escm",(void*)f_2162},
{"f5831:csc_2escm",(void*)f5831},
{"f5839:csc_2escm",(void*)f5839},
{"f5835:csc_2escm",(void*)f5835},
{"f_3551:csc_2escm",(void*)f_3551},
{"f_3544:csc_2escm",(void*)f_3544},
{"f_2387:csc_2escm",(void*)f_2387},
{"f_1796:csc_2escm",(void*)f_1796},
{"f5389:csc_2escm",(void*)f5389},
{"f5384:csc_2escm",(void*)f5384},
{"f_3560:csc_2escm",(void*)f_3560},
{"f5394:csc_2escm",(void*)f5394},
{"f_3518:csc_2escm",(void*)f_3518},
{"f_3499:csc_2escm",(void*)f_3499},
{"f_3494:csc_2escm",(void*)f_3494},
{"f_3507:csc_2escm",(void*)f_3507},
{"f_3505:csc_2escm",(void*)f_3505},
{"f_2345:csc_2escm",(void*)f_2345},
{"f_3501:csc_2escm",(void*)f_3501},
{"f_3502:csc_2escm",(void*)f_3502},
{"f_2974:csc_2escm",(void*)f_2974},
{"f5374:csc_2escm",(void*)f5374},
{"f5379:csc_2escm",(void*)f5379},
{"f_3536:csc_2escm",(void*)f_3536},
{"f_2355:csc_2escm",(void*)f_2355},
{"f_2117:csc_2escm",(void*)f_2117},
{"f_3532:csc_2escm",(void*)f_3532},
{"f_4262:csc_2escm",(void*)f_4262},
{"f5342:csc_2escm",(void*)f5342},
{"f_4268:csc_2escm",(void*)f_4268},
{"f5347:csc_2escm",(void*)f5347},
{"f_4266:csc_2escm",(void*)f_4266},
{"f_4264:csc_2escm",(void*)f_4264},
{"f_3527:csc_2escm",(void*)f_3527},
{"f_3524:csc_2escm",(void*)f_3524},
{"f_2368:csc_2escm",(void*)f_2368},
{"f5352:csc_2escm",(void*)f5352},
{"f_4298:csc_2escm",(void*)f_4298},
{"f5357:csc_2escm",(void*)f5357},
{"f_2963:csc_2escm",(void*)f_2963},
{"f_4536:csc_2escm",(void*)f_4536},
{"f_4539:csc_2escm",(void*)f_4539},
{"f_4283:csc_2escm",(void*)f_4283},
{"f_2106:csc_2escm",(void*)f_2106},
{"f_3658:csc_2escm",(void*)f_3658},
{"f_4560:csc_2escm",(void*)f_4560},
{"f_4232:csc_2escm",(void*)f_4232},
{"f_2987:csc_2escm",(void*)f_2987},
{"f_4551:csc_2escm",(void*)f_4551},
{"f_4554:csc_2escm",(void*)f_4554},
{"f_4557:csc_2escm",(void*)f_4557},
{"f_4221:csc_2escm",(void*)f_4221},
{"f_3636:csc_2escm",(void*)f_3636},
{"f_1964:csc_2escm",(void*)f_1964},
{"f_3638:csc_2escm",(void*)f_3638},
{"f_1962:csc_2escm",(void*)f_1962},
{"f_1966:csc_2escm",(void*)f_1966},
{"f_1811:csc_2escm",(void*)f_1811},
{"f_1960:csc_2escm",(void*)f_1960},
{"f_3630:csc_2escm",(void*)f_3630},
{"f_3592:csc_2escm",(void*)f_3592},
{"f_3594:csc_2escm",(void*)f_3594},
{"f_3665:csc_2escm",(void*)f_3665},
{"f_4243:csc_2escm",(void*)f_4243},
{"f_4245:csc_2escm",(void*)f_4245},
{"f_4247:csc_2escm",(void*)f_4247},
{"f_4249:csc_2escm",(void*)f_4249},
{"f_3580:csc_2escm",(void*)f_3580},
{"f_1817:csc_2escm",(void*)f_1817},
{"f_1813:csc_2escm",(void*)f_1813},
{"f_1815:csc_2escm",(void*)f_1815},
{"f_3617:csc_2escm",(void*)f_3617},
{"f_3619:csc_2escm",(void*)f_3619},
{"f_4524:csc_2escm",(void*)f_4524},
{"f_3615:csc_2escm",(void*)f_3615},
{"f_1987:csc_2escm",(void*)f_1987},
{"f_1981:csc_2escm",(void*)f_1981},
{"f_4527:csc_2escm",(void*)f_4527},
{"f_1807:csc_2escm",(void*)f_1807},
{"f_3647:csc_2escm",(void*)f_3647},
{"f_4515:csc_2escm",(void*)f_4515},
{"f_1975:csc_2escm",(void*)f_1975},
{"f_1822:csc_2escm",(void*)f_1822},
{"f_1839:csc_2escm",(void*)f_1839},
{"f_3881:csc_2escm",(void*)f_3881},
{"f_1837:csc_2escm",(void*)f_1837},
{"f_1835:csc_2escm",(void*)f_1835},
{"f_4548:csc_2escm",(void*)f_4548},
{"f_3879:csc_2escm",(void*)f_3879},
{"f_3873:csc_2escm",(void*)f_3873},
{"f_1827:csc_2escm",(void*)f_1827},
{"f_1995:csc_2escm",(void*)f_1995},
{"f_1998:csc_2escm",(void*)f_1998},
{"f_1841:csc_2escm",(void*)f_1841},
{"f_1990:csc_2escm",(void*)f_1990},
{"f_1631:csc_2escm",(void*)f_1631},
{"f_2814:csc_2escm",(void*)f_2814},
{"f_3869:csc_2escm",(void*)f_3869},
{"f_3865:csc_2escm",(void*)f_3865},
{"f_3863:csc_2escm",(void*)f_3863},
{"f_1852:csc_2escm",(void*)f_1852},
{"f_1854:csc_2escm",(void*)f_1854},
{"f_1856:csc_2escm",(void*)f_1856},
{"f_1858:csc_2escm",(void*)f_1858},
{"f_3859:csc_2escm",(void*)f_3859},
{"f_3855:csc_2escm",(void*)f_3855},
{"f_3000:csc_2escm",(void*)f_3000},
{"f_2827:csc_2escm",(void*)f_2827},
{"f_3571:csc_2escm",(void*)f_3571},
{"f_3723:csc_2escm",(void*)f_3723},
{"f_3721:csc_2escm",(void*)f_3721},
{"f_3852:csc_2escm",(void*)f_3852},
{"f_3603:csc_2escm",(void*)f_3603},
{"f_3735:csc_2escm",(void*)f_3735},
{"f_2836:csc_2escm",(void*)f_2836},
{"f_4503:csc_2escm",(void*)f_4503},
{"f_3725:csc_2escm",(void*)f_3725},
{"f_2840:csc_2escm",(void*)f_2840},
{"f_2626:csc_2escm",(void*)f_2626},
{"f_2622:csc_2escm",(void*)f_2622},
{"toplevel:csc_2escm",(void*)C_toplevel},
{"f_3758:csc_2escm",(void*)f_3758},
{"f_3756:csc_2escm",(void*)f_3756},
{"f_2633:csc_2escm",(void*)f_2633},
{"f_3770:csc_2escm",(void*)f_3770},
{"f_3697:csc_2escm",(void*)f_3697},
{"f_3744:csc_2escm",(void*)f_3744},
{"f_3899:csc_2escm",(void*)f_3899},
{"f_3890:csc_2escm",(void*)f_3890},
{"f_4598:csc_2escm",(void*)f_4598},
{"f_2505:csc_2escm",(void*)f_2505},
{"f_2598:csc_2escm",(void*)f_2598},
{"f_2591:csc_2escm",(void*)f_2591},
{"f_3672:csc_2escm",(void*)f_3672},
{"f_3670:csc_2escm",(void*)f_3670},
{"f_3715:csc_2escm",(void*)f_3715},
{"f_3717:csc_2escm",(void*)f_3717},
{"f_3719:csc_2escm",(void*)f_3719},
{"f_3011:csc_2escm",(void*)f_3011},
{"f_2521:csc_2escm",(void*)f_2521},
{"f_3016:csc_2escm",(void*)f_3016},
{"f_2537:csc_2escm",(void*)f_2537},
{"f_1393:csc_2escm",(void*)f_1393},
{"f_1390:csc_2escm",(void*)f_1390},
{"f_1658:csc_2escm",(void*)f_1658},
{"f_1399:csc_2escm",(void*)f_1399},
{"f_1397:csc_2escm",(void*)f_1397},
{"f_4440:csc_2escm",(void*)f_4440},
{"f_4443:csc_2escm",(void*)f_4443},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}

/*
S|applied compiler syntax:
S|  for-each		7
S|  sprintf		5
S|  printf		2
S|  map		6
S|  fprintf		1
o|eliminated procedure checks: 76 
o|specializations:
o|  2 (zero? fixnum)
o|  1 (= fixnum fixnum)
o|  6 (string-ref string fixnum)
o|  4 (string=? string string)
o|  4 (> fixnum fixnum)
o|  4 (string-length string)
o|  65 (eqv? (not float) *)
o|  4 (cdr pair)
o|  3 (##sys#check-list (or pair list) *)
o|  8 (string-append string string)
o|  1 (current-error-port)
o|  3 (memq * list)
o|Removed `not' forms: 5 
o|substituted constant variable: a1391 
o|merged explicitly consed rest parameter: args8 
o|inlining procedure: k1431 
o|inlining procedure: k1431 
o|substituted constant variable: default-translation-optimization-options 
o|inlining procedure: k3675 
o|inlining procedure: k3675 
o|inlining procedure: k3702 
o|inlining procedure: k3702 
o|substituted constant variable: nonstatic-compilation-options 
o|propagated global variable: a37014706 nonstatic-compilation-options 
o|propagated global variable: tmp648650 static 
o|propagated global variable: tmp648650 static 
o|inlining procedure: k3986 
o|inlining procedure: k3986 
o|inlining procedure: k4085 
o|inlining procedure: k4085 
o|inlining procedure: k4097 
o|inlining procedure: k4097 
o|contracted procedure: k4105 
o|propagated global variable: r4106 mingw 
o|inlining procedure: k4102 
o|inlining procedure: k4102 
o|inlining procedure: k4127 
o|inlining procedure: k4127 
o|propagated global variable: tmp804806 static 
o|propagated global variable: tmp804806 static 
o|propagated global variable: tmp801803 static 
o|inlining procedure: k4138 
o|propagated global variable: tmp801803 static 
o|inlining procedure: k4138 
o|propagated global variable: r41394718 static-libs 
o|inlining procedure: k4206 
o|inlining procedure: k4206 
o|contracted procedure: "(csc.scm:1021) cleanup" 
o|inlining procedure: k4148 
o|inlining procedure: k4148 
o|inlining procedure: k4167 
o|inlining procedure: k4167 
o|inlining procedure: k4225 
o|inlining procedure: k4225 
o|inlining procedure: k4286 
o|inlining procedure: k4286 
o|contracted procedure: "(csc.scm:1039) $system" 
o|inlining procedure: k4251 
o|inlining procedure: k4251 
o|propagated global variable: out849853 ##sys#standard-output 
o|inlining procedure: k4303 
o|inlining procedure: k4303 
o|contracted procedure: "(csc.scm:1113) run" 
o|merged explicitly consed rest parameter: os214 
o|merged explicitly consed rest parameter: n217 
o|inlining procedure: k1733 
o|inlining procedure: k1733 
o|consed rest parameter at call site: "(csc.scm:514) quit" 2 
o|inlining procedure: k1745 
o|inlining procedure: k1745 
o|inlining procedure: k1772 
o|inlining procedure: k1772 
o|inlining procedure: k1785 
o|inlining procedure: k1785 
o|inlining procedure: k1799 
o|inlining procedure: k1823 
o|inlining procedure: k1823 
o|contracted procedure: "(csc.scm:576) run-linking" 
o|inlining procedure: k3726 
o|inlining procedure: k3726 
o|inlining procedure: k3738 
o|inlining procedure: k3738 
o|propagated global variable: g751753 generated-object-files 
o|inlining procedure: k3759 
o|contracted procedure: "(csc.scm:938) create-mac-bundle" 
o|inlining procedure: k4359 
o|inlining procedure: k4359 
o|inlining procedure: k3759 
o|contracted procedure: "(csc.scm:933) copy-libraries" 
o|inlining procedure: k4040 
o|inlining procedure: k4040 
o|substituted constant variable: a4051 
o|contracted procedure: "(csc.scm:962) target-lib-path" 
o|inlining procedure: k4006 
o|inlining procedure: k4006 
o|inlining procedure: k4018 
o|inlining procedure: k4018 
o|propagated global variable: tmp736738 static 
o|inlining procedure: k3784 
o|propagated global variable: tmp736738 static 
o|inlining procedure: k3784 
o|propagated global variable: r37854766 static-libs 
o|inlining procedure: k3792 
o|contracted procedure: "(csc.scm:931) rez" 
o|inlining procedure: k3792 
o|inlining procedure: k3813 
o|inlining procedure: k3813 
o|substituted constant variable: a3826 
o|inlining procedure: k3829 
o|inlining procedure: k3829 
o|propagated global variable: r38304775 host-mode 
o|substituted constant variable: link-output-flag 
o|substituted constant variable: link-output-flag 
o|inlining procedure: k3874 
o|inlining procedure: k3874 
o|inlining procedure: k3889 
o|inlining procedure: k3889 
o|inlining procedure: k3953 
o|inlining procedure: k3953 
o|propagated global variable: g674678 object-files 
o|inlining procedure: k1877 
o|inlining procedure: k1877 
o|propagated global variable: out252256 ##sys#standard-output 
o|contracted procedure: "(csc.scm:565) run-compilation" 
o|substituted constant variable: compile-only-flag 
o|inlining procedure: k3485 
o|inlining procedure: k3485 
o|substituted constant variable: compile-output-flag 
o|substituted constant variable: compile-output-flag 
o|inlining procedure: k3537 
o|inlining procedure: k3537 
o|inlining procedure: k3554 
o|inlining procedure: k3554 
o|propagated global variable: g615617 generated-rc-files 
o|inlining procedure: k3574 
o|inlining procedure: k3574 
o|propagated global variable: g598600 generated-c-files 
o|inlining procedure: k3597 
o|inlining procedure: k3597 
o|propagated global variable: g577579 rc-files 
o|contracted procedure: "(csc.scm:859) create-win-manifest" 
o|inlining procedure: k3641 
o|inlining procedure: k3641 
o|propagated global variable: g548550 c-files 
o|inlining procedure: k1895 
o|inlining procedure: k1895 
o|inlining procedure: k1909 
o|propagated global variable: a19084798 object-files 
o|inlining procedure: k1909 
o|propagated global variable: a19084799 c-files 
o|consed rest parameter at call site: "(csc.scm:546) quit" 2 
o|contracted procedure: "(csc.scm:561) run-translation" 
o|inlining procedure: k3336 
o|inlining procedure: k3336 
o|inlining procedure: k3363 
o|inlining procedure: k3363 
o|inlining procedure: k3381 
o|inlining procedure: k3381 
o|substituted constant variable: a3389 
o|inlining procedure: k3398 
o|substituted constant variable: generated-scheme-files 
o|inlining procedure: k3398 
o|inlining procedure: k3410 
o|inlining procedure: k3410 
o|substituted constant variable: generated-scheme-files 
o|substituted constant variable: generated-scheme-files 
o|inlining procedure: k3430 
o|inlining procedure: k3430 
o|propagated global variable: g472474 scheme-files 
o|inlining procedure: k1934 
o|inlining procedure: k1934 
o|contracted procedure: "(csc.scm:535) builtin-link-options" 
o|inlining procedure: k1609 
o|inlining procedure: k1609 
o|inlining procedure: k1590 
o|inlining procedure: k1590 
o|inlining procedure: k1648 
o|inlining procedure: k1648 
o|inlining procedure: k1657 
o|inlining procedure: k1657 
o|inlining procedure: k1799 
o|contracted procedure: "(csc.scm:583) usage" 
o|inlining procedure: k2012 
o|inlining procedure: k2012 
o|inlining procedure: k2040 
o|inlining procedure: k2040 
o|inlining procedure: k2061 
o|inlining procedure: k2061 
o|inlining procedure: k2083 
o|inlining procedure: k2083 
o|inlining procedure: k2099 
o|inlining procedure: k2099 
o|inlining procedure: k2121 
o|inlining procedure: k2121 
o|inlining procedure: k2143 
o|inlining procedure: k2143 
o|inlining procedure: k2163 
o|inlining procedure: k2163 
o|consed rest parameter at call site: "(csc.scm:621) t-options210" 1 
o|inlining procedure: k2179 
o|consed rest parameter at call site: "(csc.scm:627) t-options210" 1 
o|inlining procedure: k2179 
o|consed rest parameter at call site: "(csc.scm:630) t-options210" 1 
o|inlining procedure: k2206 
o|consed rest parameter at call site: "(csc.scm:633) t-options210" 1 
o|inlining procedure: k2206 
o|inlining procedure: k2225 
o|inlining procedure: k2225 
o|inlining procedure: k2239 
o|inlining procedure: k2239 
o|consed rest parameter at call site: "(csc.scm:643) t-options210" 1 
o|consed rest parameter at call site: "(csc.scm:641) check211" 3 
o|inlining procedure: k2279 
o|inlining procedure: k2279 
o|inlining procedure: k2295 
o|inlining procedure: k2295 
o|inlining procedure: k2331 
o|inlining procedure: k2331 
o|inlining procedure: k2346 
o|inlining procedure: k2346 
o|consed rest parameter at call site: "(csc.scm:667) check211" 3 
o|inlining procedure: k2359 
o|consed rest parameter at call site: "(csc.scm:672) check211" 3 
o|inlining procedure: k2359 
o|inlining procedure: k2388 
o|inlining procedure: k2388 
o|inlining procedure: k2408 
o|inlining procedure: k2408 
o|inlining procedure: k2428 
o|inlining procedure: k2428 
o|inlining procedure: k2448 
o|inlining procedure: k2448 
o|inlining procedure: k2468 
o|inlining procedure: k2468 
o|inlining procedure: k2487 
o|inlining procedure: k2487 
o|consed rest parameter at call site: "(csc.scm:694) check211" 3 
o|inlining procedure: k2514 
o|consed rest parameter at call site: "(csc.scm:698) check211" 3 
o|inlining procedure: k2514 
o|consed rest parameter at call site: "(csc.scm:702) check211" 3 
o|inlining procedure: k2546 
o|consed rest parameter at call site: "(csc.scm:706) check211" 3 
o|inlining procedure: k2546 
o|consed rest parameter at call site: "(csc.scm:710) check211" 3 
o|inlining procedure: k2580 
o|consed rest parameter at call site: "(csc.scm:713) check211" 3 
o|inlining procedure: k2580 
o|inlining procedure: k2615 
o|consed rest parameter at call site: "(csc.scm:719) check211" 3 
o|inlining procedure: k2615 
o|inlining procedure: k2649 
o|inlining procedure: k2649 
o|substituted constant variable: a2671 
o|contracted procedure: k2675 
o|propagated global variable: r2676 mingw 
o|inlining procedure: k2672 
o|inlining procedure: k2672 
o|consed rest parameter at call site: "(csc.scm:723) check211" 3 
o|inlining procedure: k2681 
o|inlining procedure: k2681 
o|inlining procedure: k2707 
o|inlining procedure: k2707 
o|consed rest parameter at call site: "(csc.scm:741) t-options210" 1 
o|inlining procedure: k2731 
o|consed rest parameter at call site: "(csc.scm:746) t-options210" 1 
o|consed rest parameter at call site: "(csc.scm:743) check211" 3 
o|inlining procedure: k2731 
o|consed rest parameter at call site: "(csc.scm:749) t-options210" 1 
o|inlining procedure: k2758 
o|inlining procedure: k2777 
o|inlining procedure: k2777 
o|inlining procedure: k2803 
o|consed rest parameter at call site: "(csc.scm:759) t-options210" 1 
o|inlining procedure: k2803 
o|inlining procedure: k2821 
o|inlining procedure: k2821 
o|inlining procedure: k2831 
o|inlining procedure: k2831 
o|inlining procedure: k2852 
o|substituted constant variable: a2867 
o|inlining procedure: k2878 
o|inlining procedure: k2878 
o|inlining procedure: k2852 
o|consed rest parameter at call site: "(csc.scm:770) quit" 2 
o|consed rest parameter at call site: "(csc.scm:771) quit" 2 
o|substituted constant variable: a2919 
o|substituted constant variable: a2924 
o|substituted constant variable: a2931 
o|substituted constant variable: a2935 
o|substituted constant variable: a2938 
o|substituted constant variable: a2941 
o|substituted constant variable: a2944 
o|substituted constant variable: a2947 
o|inlining procedure: k2758 
o|contracted procedure: k2968 
o|inlining procedure: k2965 
o|inlining procedure: k2991 
o|inlining procedure: k2991 
o|inlining procedure: k3024 
o|inlining procedure: k3024 
o|inlining procedure: k2965 
o|inlining procedure: k3064 
o|inlining procedure: k3064 
o|consed rest parameter at call site: "(csc.scm:795) quit" 2 
o|substituted constant variable: a3078 
o|substituted constant variable: a3087 
o|substituted constant variable: a3091 
o|substituted constant variable: a3096 
o|substituted constant variable: a3103 
o|substituted constant variable: constant62 
o|substituted constant variable: constant59 
o|substituted constant variable: constant66 
o|substituted constant variable: a3106 
o|substituted constant variable: a3115 
o|substituted constant variable: a3117 
o|substituted constant variable: a3119 
o|substituted constant variable: a3121 
o|substituted constant variable: a3123 
o|substituted constant variable: a3125 
o|substituted constant variable: a3127 
o|substituted constant variable: a3129 
o|substituted constant variable: a3131 
o|substituted constant variable: a3133 
o|substituted constant variable: a3135 
o|substituted constant variable: a3140 
o|substituted constant variable: a3142 
o|inlining procedure: k3145 
o|inlining procedure: k3145 
o|substituted constant variable: a3152 
o|substituted constant variable: a3154 
o|substituted constant variable: a3156 
o|substituted constant variable: a3158 
o|substituted constant variable: a3160 
o|substituted constant variable: a3162 
o|substituted constant variable: a3164 
o|substituted constant variable: a3166 
o|substituted constant variable: a3168 
o|substituted constant variable: a3170 
o|substituted constant variable: a3172 
o|substituted constant variable: a3174 
o|substituted constant variable: a3179 
o|substituted constant variable: a3181 
o|substituted constant variable: a3186 
o|substituted constant variable: a3188 
o|substituted constant variable: a3190 
o|substituted constant variable: a3192 
o|substituted constant variable: a3194 
o|substituted constant variable: a3196 
o|substituted constant variable: a3198 
o|substituted constant variable: a3200 
o|substituted constant variable: a3205 
o|substituted constant variable: a3207 
o|substituted constant variable: a3212 
o|substituted constant variable: a3214 
o|substituted constant variable: a3216 
o|substituted constant variable: a3218 
o|substituted constant variable: a3220 
o|substituted constant variable: a3225 
o|substituted constant variable: a3227 
o|substituted constant variable: a3232 
o|substituted constant variable: a3234 
o|substituted constant variable: a3239 
o|substituted constant variable: a3241 
o|substituted constant variable: a3246 
o|substituted constant variable: a3248 
o|substituted constant variable: a3250 
o|substituted constant variable: a3252 
o|substituted constant variable: a3254 
o|substituted constant variable: a3256 
o|substituted constant variable: a3258 
o|substituted constant variable: a3260 
o|substituted constant variable: a3262 
o|substituted constant variable: a3264 
o|substituted constant variable: a3266 
o|substituted constant variable: a3268 
o|substituted constant variable: a3270 
o|substituted constant variable: a3272 
o|substituted constant variable: a3274 
o|substituted constant variable: a3279 
o|substituted constant variable: a3281 
o|inlining procedure: k4444 
o|inlining procedure: k4444 
o|inlining procedure: k4448 
o|inlining procedure: k4448 
o|inlining procedure: k4481 
o|inlining procedure: k4481 
o|inlining procedure: k4462 
o|inlining procedure: k4462 
o|inlining procedure: k4526 
o|inlining procedure: k4526 
o|inlining procedure: k4538 
o|inlining procedure: k4538 
o|substituted constant variable: a4561 
o|folded constant expression: (string->list (quote "PHhsfiENxubvwAOeWkctgSJM")) 
o|inlining procedure: k4588 
o|inlining procedure: k4588 
o|inlining procedure: k4597 
o|inlining procedure: k4597 
o|inlining procedure: k4617 
o|inlining procedure: k4617 
o|propagated global variable: r46184954 cygwin 
o|inlining procedure: k4621 
o|inlining procedure: k4621 
o|inlining procedure: k4630 
o|inlining procedure: k4630 
o|inlining procedure: k4639 
o|inlining procedure: k4639 
o|inlining procedure: k4648 
o|inlining procedure: k4648 
o|inlining procedure: k4657 
o|inlining procedure: k4657 
o|inlining procedure: k4681 
o|inlining procedure: k4681 
o|simplifications: ((if . 2)) 
o|replaced variables: 470 
o|removed binding forms: 206 
o|removed side-effect free assignment to unused variable: link-output-flag 
o|removed side-effect free assignment to unused variable: compile-output-flag 
o|removed side-effect free assignment to unused variable: default-translation-optimization-options 
o|removed side-effect free assignment to unused variable: constant59 
o|removed side-effect free assignment to unused variable: constant62 
o|removed side-effect free assignment to unused variable: constant66 
o|contracted procedure: k1516 
o|removed side-effect free assignment to unused variable: generated-scheme-files 
o|removed side-effect free assignment to unused variable: compile-only-flag 
o|substituted constant variable: a37014705 
o|substituted constant variable: nonstatic-compilation-options 
o|substituted constant variable: a40844709 
o|substituted constant variable: a40844710 
o|substituted constant variable: a40964711 
o|substituted constant variable: a40964712 
o|substituted constant variable: r41034713 
o|propagated global variable: r41394717 static 
o|substituted constant variable: f_41664723 
o|substituted constant variable: r42524729 
o|substituted constant variable: r42524732 
o|substituted constant variable: r17464739 
o|substituted constant variable: r17464739 
o|inlining procedure: k1772 
o|inlining procedure: k1772 
o|substituted constant variable: a17714744 
o|substituted constant variable: a40394758 
o|inlining procedure: k4040 
o|substituted constant variable: r40194763 
o|propagated global variable: r37854764 static 
o|propagated global variable: a37834767 static-libs 
o|inlining procedure: k3880 
o|substituted constant variable: a18764782 
o|substituted constant variable: a18764783 
o|substituted constant variable: r34864785 
o|substituted constant variable: a33624802 
o|inlining procedure: k3363 
o|inlining procedure: k3363 
o|substituted constant variable: a33804804 
o|inlining procedure: k3381 
o|inlining procedure: k3381 
o|substituted constant variable: r15914820 
o|substituted constant variable: r15914820 
o|substituted constant variable: a16474822 
o|inlining procedure: k1996 
o|inlining procedure: k1996 
o|inlining procedure: k1996 
o|inlining procedure: k1996 
o|inlining procedure: k1996 
o|inlining procedure: k1996 
o|inlining procedure: k1996 
o|inlining procedure: k1996 
o|inlining procedure: k1996 
o|inlining procedure: k1996 
o|inlining procedure: k1996 
o|inlining procedure: k1996 
o|inlining procedure: k1996 
o|inlining procedure: k1996 
o|inlining procedure: k1996 
o|inlining procedure: k1996 
o|inlining procedure: k1996 
o|inlining procedure: k1996 
o|inlining procedure: k1996 
o|inlining procedure: k1996 
o|inlining procedure: k1996 
o|inlining procedure: k1996 
o|inlining procedure: k1996 
o|inlining procedure: k1996 
o|inlining procedure: k1996 
o|inlining procedure: k1996 
o|inlining procedure: k1996 
o|inlining procedure: k1996 
o|inlining procedure: k1996 
o|inlining procedure: k1996 
o|inlining procedure: k1996 
o|inlining procedure: k1996 
o|inlining procedure: k1996 
o|inlining procedure: k1996 
o|inlining procedure: k1996 
o|inlining procedure: k1996 
o|inlining procedure: k1996 
o|inlining procedure: k1996 
o|inlining procedure: k1996 
o|inlining procedure: k1996 
o|inlining procedure: k1996 
o|inlining procedure: k1996 
o|inlining procedure: k1996 
o|substituted constant variable: r26734899 
o|inlining procedure: k1996 
o|substituted constant variable: r26824902 
o|inlining procedure: k1996 
o|inlining procedure: k1996 
o|inlining procedure: k1996 
o|inlining procedure: k1996 
o|inlining procedure: k1996 
o|inlining procedure: k1996 
o|inlining procedure: k1996 
o|inlining procedure: k1996 
o|inlining procedure: k1996 
o|inlining procedure: k1996 
o|substituted constant variable: r44454935 
o|substituted constant variable: r44454935 
o|substituted constant variable: r44634943 
o|substituted constant variable: r44634943 
o|replaced variables: 61 
o|removed binding forms: 506 
o|removed conditional forms: 1 
o|removed side-effect free assignment to unused variable: nonstatic-compilation-options 
o|substituted constant variable: r1517 
o|inlining procedure: "(csc.scm:978) quotewrap" 
o|inlining procedure: "(csc.scm:977) quotewrap" 
o|inlining procedure: k4129 
o|propagated global variable: r41305303 static 
o|inlining procedure: k4129 
o|propagated global variable: r41305304 static-libs 
o|inlining procedure: k4295 
o|propagated global variable: a42945307 last-exit-code 
o|inlining procedure: k4295 
o|propagated global variable: a42945308 last-exit-code 
o|inlining procedure: k4301 
o|substituted constant variable: a17714971 
o|substituted constant variable: a17714972 
o|substituted constant variable: a40394977 
o|inlining procedure: k4009 
o|inlining procedure: k4009 
o|inlining procedure: k3774 
o|propagated global variable: r37755317 gui 
o|inlining procedure: k3774 
o|propagated global variable: r37854764 static 
o|inlining procedure: "(csc.scm:1052) quotewrap" 
o|inlining procedure: "(csc.scm:1051) quotewrap" 
o|inlining procedure: "(csc.scm:921) quotewrap" 
o|inlining procedure: "(csc.scm:914) quotewrap" 
o|propagated global variable: str305335 target-filename 
o|inlining procedure: "(csc.scm:903) quotewrap" 
o|propagated global variable: str305340 target-filename 
o|inlining procedure: "(csc.scm:896) quotewrap" 
o|inlining procedure: "(csc.scm:895) quotewrap" 
o|inlining procedure: "(csc.scm:889) quotewrap" 
o|propagated global variable: str305355 target-filename 
o|inlining procedure: "(csc.scm:888) quotewrap" 
o|inlining procedure: "(csc.scm:575) quotewrap" 
o|inlining procedure: "(csc.scm:574) quotewrap" 
o|propagated global variable: str305372 target-filename 
o|inlining procedure: "(csc.scm:848) quotewrap" 
o|inlining procedure: "(csc.scm:847) quotewrap" 
o|inlining procedure: "(csc.scm:867) quotewrap" 
o|inlining procedure: "(csc.scm:867) quotewrap" 
o|inlining procedure: k1879 
o|inlining procedure: k1914 
o|substituted constant variable: a33624997 
o|substituted constant variable: a33624998 
o|inlining procedure: "(csc.scm:817) quotewrap" 
o|inlining procedure: "(csc.scm:813) quotewrap" 
o|substituted constant variable: a33804999 
o|substituted constant variable: a33805000 
o|inlining procedure: k1963 
o|inlining procedure: "(csc.scm:220) quotewrap" 
o|inlining procedure: "(csc.scm:109) quotewrap" 
o|inlining procedure: "(csc.scm:108) quotewrap" 
o|inlining procedure: "(csc.scm:107) quotewrap" 
o|inlining procedure: "(csc.scm:106) quotewrap" 
o|inlining procedure: "(csc.scm:105) quotewrap" 
o|inlining procedure: "(csc.scm:99) quotewrap" 
o|inlining procedure: "(csc.scm:95) quotewrap" 
o|removed binding forms: 198 
o|Removed `not' forms: 2 
o|substituted constant variable: r40105313 
o|contracted procedure: k4009 
o|propagated global variable: r4010 host-mode 
o|substituted constant variable: r40105315 
o|substituted constant variable: r37755318 
o|contracted procedure: k1879 
o|propagated global variable: r1880 shared 
o|substituted constant variable: r18805404 
o|substituted constant variable: r19155405 
o|substituted constant variable: short-options 
o|replaced variables: 42 
o|removed binding forms: 17 
o|removed conditional forms: 5 
o|removed side-effect free assignment to unused variable: short-options 
o|removed binding forms: 47 
o|removed binding forms: 1 
o|simplifications: ((if . 34) (##core#call . 306)) 
o|  call simplifications:
o|    assq
o|    ##sys#call-with-values
o|    string-ci=?
o|    ##sys#size	4
o|    fx>	4
o|    string
o|    string->number
o|    cadr
o|    cdr	14
o|    number?
o|    first	2
o|    ##sys#list
o|    ##sys#fudge	2
o|    member	6
o|    string=?	2
o|    number->string
o|    length	2
o|    >=	2
o|    eq?	74
o|    zero?	2
o|    char=?	7
o|    string->list	2
o|    null?	8
o|    car	16
o|    memq	4
o|    char-whitespace?	2
o|    list->string
o|    not	8
o|    ##sys#check-list	10
o|    pair?	13
o|    cons	41
o|    ##sys#setslot	6
o|    ##sys#slot	26
o|    list	30
o|    ##sys#apply
o|    write-char	8
o|contracted procedure: k1371 
o|contracted procedure: k1375 
o|contracted procedure: k1380 
o|contracted procedure: k1384 
o|contracted procedure: k1420 
o|contracted procedure: k1424 
o|contracted procedure: k1437 
o|contracted procedure: k1548 
o|contracted procedure: k1552 
o|contracted procedure: k4516 
o|contracted procedure: k1561 
o|contracted procedure: k3666 
o|contracted procedure: k3677 
o|contracted procedure: k3680 
o|contracted procedure: k3689 
o|contracted procedure: k3699 
o|contracted procedure: k3704 
o|inlining procedure: k4127 
o|inlining procedure: k4127 
o|contracted procedure: k4169 
o|contracted procedure: k4172 
o|contracted procedure: k4177 
o|contracted procedure: k4198 
o|contracted procedure: k4223 
o|contracted procedure: k4254 
o|inlining procedure: k4288 
o|inlining procedure: k4288 
o|contracted procedure: k4258 
o|contracted procedure: k1742 
o|contracted procedure: k1748 
o|inlining procedure: k1735 
o|contracted procedure: k1745 
o|inlining procedure: k1735 
o|contracted procedure: k1767 
o|contracted procedure: k1782 
o|contracted procedure: k1789 
o|contracted procedure: k1801 
o|contracted procedure: k3711 
o|contracted procedure: k3729 
o|contracted procedure: k3740 
o|contracted procedure: k3749 
o|contracted procedure: k3752 
o|propagated global variable: g751753 generated-object-files 
o|contracted procedure: k3762 
o|contracted procedure: k4385 
o|contracted procedure: k4382 
o|contracted procedure: k4379 
o|contracted procedure: k4045 
o|contracted procedure: k4015 
o|contracted procedure: k3795 
o|contracted procedure: k3827 
o|contracted procedure: k3839 
o|contracted procedure: k3845 
o|contracted procedure: k3891 
o|contracted procedure: k3903 
o|contracted procedure: k3955 
o|contracted procedure: k3958 
o|contracted procedure: k3967 
o|contracted procedure: k3977 
o|propagated global variable: g674678 object-files 
o|contracted procedure: k1831 
o|contracted procedure: k3457 
o|contracted procedure: k3461 
o|contracted procedure: k3471 
o|contracted procedure: k3468 
o|contracted procedure: k3485 
o|contracted procedure: k3495 
o|contracted procedure: k3509 
o|contracted procedure: k3513 
o|contracted procedure: k3520 
o|contracted procedure: k3528 
o|contracted procedure: k3540 
o|contracted procedure: k3545 
o|contracted procedure: k3556 
o|contracted procedure: k3565 
o|contracted procedure: k3568 
o|propagated global variable: g615617 generated-rc-files 
o|contracted procedure: k3576 
o|contracted procedure: k3585 
o|contracted procedure: k3588 
o|propagated global variable: g598600 generated-c-files 
o|contracted procedure: k3599 
o|contracted procedure: k3608 
o|contracted procedure: k3611 
o|propagated global variable: g577579 rc-files 
o|contracted procedure: k3621 
o|contracted procedure: k3625 
o|contracted procedure: k4423 
o|contracted procedure: k4420 
o|contracted procedure: k4417 
o|contracted procedure: k3643 
o|contracted procedure: k3652 
o|contracted procedure: k3655 
o|propagated global variable: g548550 c-files 
o|contracted procedure: k1888 
o|contracted procedure: k1911 
o|contracted procedure: k1920 
o|contracted procedure: k1914 
o|contracted procedure: k3301 
o|contracted procedure: k3304 
o|contracted procedure: k3368 
o|contracted procedure: k3322 
o|contracted procedure: k3327 
o|contracted procedure: k3338 
o|contracted procedure: k3341 
o|contracted procedure: k3350 
o|contracted procedure: k3360 
o|contracted procedure: k3391 
o|contracted procedure: k3386 
o|contracted procedure: k3378 
o|contracted procedure: k3393 
o|contracted procedure: k3401 
o|contracted procedure: k3412 
o|contracted procedure: k3421 
o|contracted procedure: k3424 
o|contracted procedure: k3432 
o|contracted procedure: k3441 
o|contracted procedure: k3444 
o|propagated global variable: g472474 scheme-files 
o|contracted procedure: k1941 
o|contracted procedure: k1947 
o|contracted procedure: k1949 
o|contracted procedure: k1953 
o|contracted procedure: k1611 
o|contracted procedure: k1614 
o|contracted procedure: k1623 
o|contracted procedure: k1633 
o|contracted procedure: k1650 
o|contracted procedure: k1991 
o|contracted procedure: k2002 
o|contracted procedure: k2004 
o|contracted procedure: k1715 
o|contracted procedure: k1712 
o|contracted procedure: k1709 
o|contracted procedure: k1706 
o|contracted procedure: k1703 
o|contracted procedure: k1700 
o|contracted procedure: k1697 
o|contracted procedure: k2015 
o|contracted procedure: k2029 
o|contracted procedure: k2043 
o|contracted procedure: k2051 
o|contracted procedure: k2057 
o|contracted procedure: k2064 
o|contracted procedure: k2075 
o|contracted procedure: k2086 
o|contracted procedure: k2094 
o|contracted procedure: k2102 
o|contracted procedure: k2113 
o|contracted procedure: k2124 
o|contracted procedure: k2135 
o|contracted procedure: k2146 
o|contracted procedure: k2154 
o|contracted procedure: k2156 
o|contracted procedure: k2168 
o|contracted procedure: k2176 
o|contracted procedure: k2182 
o|contracted procedure: k2184 
o|contracted procedure: k2188 
o|contracted procedure: k2197 
o|contracted procedure: k2199 
o|contracted procedure: k2209 
o|contracted procedure: k2211 
o|contracted procedure: k2221 
o|contracted procedure: k2228 
o|contracted procedure: k2235 
o|contracted procedure: k2242 
o|contracted procedure: k2244 
o|contracted procedure: k2249 
o|contracted procedure: k2255 
o|contracted procedure: k2257 
o|contracted procedure: k2271 
o|contracted procedure: k2277 
o|contracted procedure: k2274 
o|contracted procedure: k2282 
o|contracted procedure: k2291 
o|contracted procedure: k2298 
o|contracted procedure: k2303 
o|contracted procedure: k2310 
o|contracted procedure: k2326 
o|contracted procedure: k2334 
o|contracted procedure: k2341 
o|contracted procedure: k23494861 
o|contracted procedure: k2357 
o|contracted procedure: k23494866 
o|contracted procedure: k2362 
o|contracted procedure: k2364 
o|contracted procedure: k2369 
o|contracted procedure: k2372 
o|contracted procedure: k2379 
o|contracted procedure: k2381 
o|contracted procedure: k2391 
o|contracted procedure: k2401 
o|contracted procedure: k2411 
o|contracted procedure: k2421 
o|contracted procedure: k2431 
o|contracted procedure: k2441 
o|contracted procedure: k2451 
o|contracted procedure: k2461 
o|contracted procedure: k2471 
o|contracted procedure: k2479 
o|contracted procedure: k2490 
o|contracted procedure: k2492 
o|contracted procedure: k2501 
o|contracted procedure: k2507 
o|contracted procedure: k2511 
o|contracted procedure: k2517 
o|contracted procedure: k2523 
o|contracted procedure: k2527 
o|contracted procedure: k2533 
o|contracted procedure: k2539 
o|contracted procedure: k2543 
o|contracted procedure: k2549 
o|contracted procedure: k2555 
o|contracted procedure: k2559 
o|contracted procedure: k2565 
o|contracted procedure: k2575 
o|contracted procedure: k2578 
o|contracted procedure: k2583 
o|contracted procedure: k2593 
o|contracted procedure: k2600 
o|contracted procedure: k2605 
o|contracted procedure: k2613 
o|contracted procedure: k2618 
o|contracted procedure: k2628 
o|contracted procedure: k2635 
o|contracted procedure: k2640 
o|contracted procedure: k2646 
o|contracted procedure: k26524893 
o|contracted procedure: k2663 
o|contracted procedure: k26524898 
o|contracted procedure: k2684 
o|contracted procedure: k2690 
o|contracted procedure: k2705 
o|contracted procedure: k2717 
o|contracted procedure: k2713 
o|contracted procedure: k2725 
o|contracted procedure: k2734 
o|contracted procedure: k2739 
o|contracted procedure: k2741 
o|contracted procedure: k2746 
o|contracted procedure: k2767 
o|contracted procedure: k2775 
o|contracted procedure: k2780 
o|contracted procedure: k2788 
o|contracted procedure: k2793 
o|contracted procedure: k2801 
o|contracted procedure: k2806 
o|contracted procedure: k2818 
o|contracted procedure: k2829 
o|contracted procedure: k2842 
o|contracted procedure: k2917 
o|contracted procedure: k2847 
o|contracted procedure: k2850 
o|contracted procedure: k2855 
o|contracted procedure: k2869 
o|contracted procedure: k2880 
o|contracted procedure: k2883 
o|contracted procedure: k2892 
o|contracted procedure: k2902 
o|contracted procedure: k2929 
o|contracted procedure: k2921 
o|contracted procedure: k2981 
o|contracted procedure: k2989 
o|contracted procedure: k2994 
o|contracted procedure: k3002 
o|contracted procedure: k3007 
o|contracted procedure: k3018 
o|contracted procedure: k3021 
o|contracted procedure: k3027 
o|contracted procedure: k3036 
o|contracted procedure: k3051 
o|contracted procedure: k3058 
o|contracted procedure: k2976 
o|contracted procedure: k3071 
o|contracted procedure: k3089 
o|contracted procedure: k3079 
o|contracted procedure: k3101 
o|contracted procedure: k3093 
o|contracted procedure: k3109 
o|contracted procedure: k3143 
o|contracted procedure: k4483 
o|contracted procedure: k4486 
o|contracted procedure: k4495 
o|contracted procedure: k4505 
o|simplifications: ((if . 3) (let . 41)) 
o|removed binding forms: 272 
o|inlining procedure: k3682 
o|inlining procedure: k3682 
o|inlining procedure: "(csc.scm:944) prefix" 
o|inlining procedure: k3960 
o|inlining procedure: k3960 
o|inlining procedure: k3343 
o|inlining procedure: k3343 
o|inlining procedure: k1616 
o|inlining procedure: k1616 
o|inlining procedure: "(csc.scm:272) prefix" 
o|inlining procedure: k2885 
o|inlining procedure: k2885 
o|inlining procedure: "(csc.scm:257) prefix" 
o|inlining procedure: k4488 
o|inlining procedure: k4488 
o|inlining procedure: "(csc.scm:235) prefix" 
o|inlining procedure: "(csc.scm:221) prefix" 
o|propagated global variable: str265754 default-library 
o|inlining procedure: "(csc.scm:100) prefix" 
o|inlining procedure: "(csc.scm:96) prefix" 
o|simplifications: ((let . 4)) 
o|replaced variables: 17 
o|removed binding forms: 3 
o|removed side-effect free assignment to unused variable: prefix 
o|substituted constant variable: dir275677 
o|substituted constant variable: str265676 
o|substituted constant variable: dir275722 
o|substituted constant variable: str265721 
o|substituted constant variable: dir275737 
o|substituted constant variable: str265736 
o|substituted constant variable: str265749 
o|substituted constant variable: dir275755 
o|substituted constant variable: dir275760 
o|substituted constant variable: str265759 
o|substituted constant variable: dir275765 
o|substituted constant variable: str265764 
o|simplifications: ((if . 2)) 
o|replaced variables: 19 
o|removed binding forms: 28 
o|inlining procedure: k1648 
o|inlining procedure: k4550 
o|inlining procedure: k4666 
o|inlining procedure: k4678 
o|removed binding forms: 26 
o|replaced variables: 4 
o|removed binding forms: 4 
o|direct leaf routine/allocation: use-private-repository213 6 
o|inlining procedure: "(csc.scm:646) k1996" 
o|simplifications: ((if . 1)) 
o|customizable procedures: (k1485 k4457 map-loop111136 k2481 k2701 k2703 k2752 k2761 k3043 k3010 k2834 map-loop407425 k2655 shared-build212 check211 k2159 t-options210 loop230 k1585 map-loop164189 k1926 k1928 for-each-loop465514 for-each-loop521531 k3319 map-loop485505 k1816 for-each-loop541559 k3613 k3500 for-each-loop570584 for-each-loop591601 for-each-loop608618 k3480 compiler-options map-loop662679 linker-options linker-libraries k3787 k3754 lib-path copy-files k3724 for-each-loop744754 quit k4188 fold816 k4124 k4099 command map-loop631651) 
o|calls to known targets: 233 
o|identified direct recursive calls: f_4164 1 
o|fast box initializations: 19 
o|fast global references: 374 
o|fast global assignments: 177 
o|dropping unused closure argument: f_4088 
o|dropping unused closure argument: f_4056 
o|dropping unused closure argument: f_3980 
o|dropping unused closure argument: f_4115 
o|dropping unused closure argument: f_1730 
o|dropping unused closure argument: f_1722 
o|dropping unused closure argument: f_1755 
o|dropping unused closure argument: f_1778 
o|dropping unused closure argument: f_4283 
o|dropping unused closure argument: f_3658 
o|dropping unused closure argument: f_1393 
*/
/* end of file */
