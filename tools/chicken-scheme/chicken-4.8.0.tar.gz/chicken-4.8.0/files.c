/* Generated from files.scm by the CHICKEN compiler
   http://www.call-cc.org
   2012-09-24 17:49
   Version 4.8.0 (rev 0db1908)
   linux-unix-gnu-x86-64 [ 64bit manyargs ptables ]
   compiled 2012-09-24 on debian (Linux)
   command line: files.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -feature chicken-bootstrap -no-warnings -specialize -types ./types.db -explicit-use -no-trace -output-file files.c
   unit: files
*/

#include "chicken.h"

#include <unistd.h>
#include <errno.h>

#ifndef _WIN32
# include <sys/stat.h>
# define C_mkdir(str)       C_fix(mkdir(C_c_string(str), S_IRWXU | S_IRWXG | S_IRWXO))
#else
# define C_mkdir(str)	    C_fix(mkdir(C_c_string(str)))
#endif

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_irregex_toplevel)
C_externimport void C_ccall C_irregex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_2dstructures_toplevel)
C_externimport void C_ccall C_data_2dstructures_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[106];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,21),40,100,101,108,101,116,101,45,102,105,108,101,42,32,102,105,108,101,54,50,41,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,100,57,50,32,108,57,51,41,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,42),40,102,105,108,101,45,99,111,112,121,32,111,114,105,103,102,105,108,101,55,48,32,110,101,119,102,105,108,101,55,49,32,46,32,116,109,112,54,57,55,50,41,0,0,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,100,49,51,50,32,108,49,51,51,41};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,46),40,102,105,108,101,45,109,111,118,101,32,111,114,105,103,102,105,108,101,49,49,48,32,110,101,119,102,105,108,101,49,49,49,32,46,32,116,109,112,49,48,57,49,49,50,41,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,26),40,97,98,115,111,108,117,116,101,45,112,97,116,104,110,97,109,101,63,32,112,110,49,54,52,41,0,0,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,14),40,102,95,49,48,50,54,32,99,104,49,55,51,41,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,17),40,99,104,111,112,45,112,100,115,32,115,116,114,49,54,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,115,116,114,115,49,56,49,41,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,19),40,99,111,110,99,45,100,105,114,115,32,100,105,114,115,49,55,57,41,0,0,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,27),40,99,97,110,111,110,105,99,97,108,105,122,101,45,100,105,114,115,32,100,105,114,115,49,56,53,41,0,0,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,14),40,102,95,49,49,54,54,32,99,104,50,48,55,41,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,45),40,95,109,97,107,101,45,112,97,116,104,110,97,109,101,32,108,111,99,49,57,50,32,100,105,114,49,57,51,32,102,105,108,101,49,57,52,32,101,120,116,49,57,53,41,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,43),40,109,97,107,101,45,112,97,116,104,110,97,109,101,32,100,105,114,115,50,49,55,32,102,105,108,101,50,49,56,32,46,32,116,109,112,50,49,54,50,49,57,41,0,0,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,52),40,109,97,107,101,45,97,98,115,111,108,117,116,101,45,112,97,116,104,110,97,109,101,32,100,105,114,115,50,51,48,32,102,105,108,101,50,51,49,32,46,32,116,109,112,50,50,57,50,51,50,41,0,0,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,15),40,102,95,49,50,50,57,32,100,105,114,50,52,57,41,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,26),40,100,101,99,111,109,112,111,115,101,45,112,97,116,104,110,97,109,101,32,112,110,50,53,49,41,0,0,0,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,8),40,102,95,49,51,48,57,41};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,48),40,102,95,49,51,49,52,32,100,105,114,50,53,55,50,53,56,50,54,51,32,102,105,108,101,50,53,57,50,54,48,50,54,52,32,101,120,116,50,54,49,50,54,50,50,54,53,41};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,26),40,112,97,116,104,110,97,109,101,45,100,105,114,101,99,116,111,114,121,32,112,110,50,53,54,41,0,0,0,0,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,8),40,102,95,49,51,50,51,41};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,48),40,102,95,49,51,50,56,32,100,105,114,50,55,49,50,55,50,50,55,55,32,102,105,108,101,50,55,51,50,55,52,50,55,56,32,101,120,116,50,55,53,50,55,54,50,55,57,41};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,21),40,112,97,116,104,110,97,109,101,45,102,105,108,101,32,112,110,50,55,48,41,0,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,8),40,102,95,49,51,51,55,41};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,48),40,102,95,49,51,52,50,32,100,105,114,50,56,53,50,56,54,50,57,49,32,102,105,108,101,50,56,55,50,56,56,50,57,50,32,101,120,116,50,56,57,50,57,48,50,57,51,41};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,26),40,112,97,116,104,110,97,109,101,45,101,120,116,101,110,115,105,111,110,32,112,110,50,56,52,41,0,0,0,0,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,8),40,102,95,49,51,53,49,41};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,48),40,102,95,49,51,53,54,32,100,105,114,50,57,57,51,48,48,51,48,53,32,102,105,108,101,51,48,49,51,48,50,51,48,54,32,101,120,116,51,48,51,51,48,52,51,48,55,41};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,32),40,112,97,116,104,110,97,109,101,45,115,116,114,105,112,45,100,105,114,101,99,116,111,114,121,32,112,110,50,57,56,41};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,8),40,102,95,49,51,54,56,41};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,48),40,102,95,49,51,55,51,32,100,105,114,51,49,51,51,49,52,51,49,57,32,102,105,108,101,51,49,53,51,49,54,51,50,48,32,101,120,116,51,49,55,51,49,56,51,50,49,41};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,32),40,112,97,116,104,110,97,109,101,45,115,116,114,105,112,45,101,120,116,101,110,115,105,111,110,32,112,110,51,49,50,41};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,8),40,102,95,49,51,56,53,41};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,46),40,102,95,49,51,57,48,32,95,51,50,56,51,50,57,51,51,52,32,102,105,108,101,51,51,48,51,51,49,51,51,53,32,101,120,116,51,51,50,51,51,51,51,51,54,41,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,41),40,112,97,116,104,110,97,109,101,45,114,101,112,108,97,99,101,45,100,105,114,101,99,116,111,114,121,32,112,110,51,50,54,32,100,105,114,51,50,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,8),40,102,95,49,52,48,50,41};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,45),40,102,95,49,52,48,55,32,100,105,114,51,52,51,51,52,52,51,52,57,32,95,51,52,53,51,52,54,51,53,48,32,101,120,116,51,52,55,51,52,56,51,53,49,41,0,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,37),40,112,97,116,104,110,97,109,101,45,114,101,112,108,97,99,101,45,102,105,108,101,32,112,110,51,52,49,32,102,105,108,101,51,52,50,41,0,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,8),40,102,95,49,52,49,57,41};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,46),40,102,95,49,52,50,52,32,100,105,114,51,53,56,51,53,57,51,54,52,32,102,105,108,101,51,54,48,51,54,49,51,54,53,32,95,51,54,50,51,54,51,51,54,54,41,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,41),40,112,97,116,104,110,97,109,101,45,114,101,112,108,97,99,101,45,101,120,116,101,110,115,105,111,110,32,112,110,51,53,54,32,101,120,116,51,53,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,9),40,116,101,109,112,100,105,114,41,0,0,0,0,0,0,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,13),40,102,95,49,52,56,51,32,112,52,48,52,41,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,35),40,99,114,101,97,116,101,45,116,101,109,112,111,114,97,114,121,45,102,105,108,101,32,46,32,116,109,112,51,57,52,51,57,53,41,0,0,0,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,28),40,99,114,101,97,116,101,45,116,101,109,112,111,114,97,114,121,45,100,105,114,101,99,116,111,114,121,41,0,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,18),40,97,100,100,112,97,114,116,32,112,97,114,116,115,52,49,56,41,0,0,0,0,0,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,13),40,102,95,49,54,53,56,32,112,52,54,51,41,0,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,26),40,102,111,114,45,101,97,99,104,45,108,111,111,112,52,53,51,32,103,52,54,48,52,54,54,41,0,0,0,0,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,14),40,102,95,49,55,52,48,32,99,104,52,56,48,41,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,28),40,108,111,111,112,32,105,52,52,50,32,112,114,101,118,52,52,51,32,112,97,114,116,115,52,52,52,41,0,0,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,40),40,110,111,114,109,97,108,105,122,101,45,112,97,116,104,110,97,109,101,32,112,97,116,104,52,51,48,32,46,32,116,109,112,52,50,57,52,51,49,41};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,24),40,100,105,114,101,99,116,111,114,121,45,110,117,108,108,63,32,100,105,114,52,57,53,41};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,28),40,100,101,99,111,109,112,111,115,101,45,100,105,114,101,99,116,111,114,121,32,100,105,114,53,48,52,41,0,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,14),40,102,95,49,57,54,54,32,112,110,49,52,57,41,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,14),40,102,95,49,57,55,50,32,114,116,49,53,48,41,0,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,14),40,102,95,49,57,56,49,32,114,116,49,53,50,41,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,30),40,97,98,115,111,108,117,116,101,45,112,97,116,104,110,97,109,101,45,114,111,111,116,32,112,110,49,53,55,41,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,19),40,114,111,111,116,45,111,114,105,103,105,110,32,114,116,49,53,56,41,0,0,0,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,22),40,114,111,111,116,45,100,105,114,101,99,116,111,114,121,32,114,116,49,53,57,41,0,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(f_1242)
static void C_ccall f_1242(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1342)
static void C_ccall f_1342(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1345)
static void C_ccall f_1345(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_931)
static void C_ccall f_931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1356)
static void C_ccall f_1356(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_937)
static void C_ccall f_937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1351)
static void C_ccall f_1351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1016)
static void C_ccall f_1016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1337)
static void C_ccall f_1337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1331)
static void C_ccall f_1331(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1496)
static void C_ccall f_1496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1493)
static void C_ccall f_1493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_896)
static void C_ccall f_896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1309)
static void C_ccall f_1309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_898)
static void C_ccall f_898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1430)
static void C_fcall f_1430(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1490)
static void C_ccall f_1490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_946)
static void C_ccall f_946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1437)
static void C_ccall f_1437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1928)
static void C_ccall f_1928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1303)
static void C_ccall f_1303(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_892)
static void C_ccall f_892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1038)
static void C_fcall f_1038(C_word t0,C_word t1) C_noret;
C_noret_decl(f_894)
static void C_ccall f_894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1317)
static void C_ccall f_1317(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1443)
static void C_ccall f_1443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1002)
static void C_ccall f_1002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1448)
static void C_ccall f_1448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1004)
static void C_fcall f_1004(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1314)
static void C_ccall f_1314(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1368)
static void C_ccall f_1368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1944)
static void C_ccall f_1944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1362)
static void C_ccall f_1362(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1934)
static void C_ccall f_1934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1936)
static void C_ccall f_1936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1938)
static void C_ccall f_1938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1962)
static void C_ccall f_1962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1966)
static void C_ccall f_1966(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1964)
static void C_ccall f_1964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1475)
static void C_ccall f_1475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1328)
static void C_ccall f_1328(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1413)
static void C_ccall f_1413(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1981)
static void C_ccall f_1981(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1419)
static void C_ccall f_1419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1323)
static void C_ccall f_1323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_874)
static void C_ccall f_874(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_874)
static void C_ccall f_874r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1487)
static void C_ccall f_1487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1483)
static void C_ccall f_1483(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1424)
static void C_ccall f_1424(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1972)
static void C_ccall f_1972(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1178)
static void C_ccall f_1178(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1178)
static void C_ccall f_1178r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1156)
static void C_ccall f_1156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1854)
static void C_ccall f_1854(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1453)
static void C_ccall f_1453(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1453)
static void C_ccall f_1453r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_910)
static void C_fcall f_910(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_919)
static void C_ccall f_919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1134)
static void C_ccall f_1134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2002)
static void C_ccall f_2002(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1189)
static void C_ccall f_1189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_830)
static void C_ccall f_830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1166)
static void C_ccall f_1166(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_749)
static void C_ccall f_749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_745)
static void C_ccall f_745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_747)
static void C_ccall f_747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1465)
static void C_fcall f_1465(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1469)
static void C_ccall f_1469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1402)
static void C_ccall f_1402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_921)
static void C_ccall f_921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_923)
static void C_ccall f_923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_925)
static void C_ccall f_925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1778)
static void C_ccall f_1778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1407)
static void C_ccall f_1407(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_791)
static void C_ccall f_791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_799)
static void C_fcall f_799(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_797)
static void C_ccall f_797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1892)
static void C_ccall f_1892(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1746)
static void C_ccall f_1746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1748)
static void C_fcall f_1748(C_word t0,C_word t1) C_noret;
C_noret_decl(f_781)
static void C_ccall f_781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_783)
static void C_ccall f_783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_785)
static void C_ccall f_785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1863)
static C_word C_fcall f_1863(C_word t0);
C_noret_decl(f_1861)
static void C_ccall f_1861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_787)
static void C_ccall f_787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_789)
static void C_ccall f_789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1523)
static void C_ccall f_1523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1740)
static void C_ccall f_1740(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_902)
static void C_ccall f_902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_900)
static void C_ccall f_900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_908)
static void C_ccall f_908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1197)
static void C_ccall f_1197(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1197)
static void C_ccall f_1197r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1529)
static void C_ccall f_1529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1736)
static void C_ccall f_1736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1513)
static void C_fcall f_1513(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1257)
static void C_ccall f_1257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1998)
static void C_ccall f_1998(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1507)
static void C_ccall f_1507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1992)
static void C_ccall f_1992(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1990)
static void C_ccall f_1990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_818)
static void C_ccall f_818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(C_files_toplevel)
C_externexport void C_ccall C_files_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1564)
static C_word C_fcall f_1564(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_1705)
static void C_fcall f_1705(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1266)
static void C_ccall f_1266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1269)
static void C_ccall f_1269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1140)
static void C_fcall f_1140(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1517)
static void C_ccall f_1517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1026)
static void C_ccall f_1026(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_810)
static void C_ccall f_810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_812)
static void C_ccall f_812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_808)
static void C_ccall f_808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1714)
static void C_ccall f_1714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1114)
static void C_fcall f_1114(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1616)
static void C_fcall f_1616(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1544)
static void C_ccall f_1544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1541)
static void C_ccall f_1541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1277)
static void C_ccall f_1277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1275)
static void C_ccall f_1275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1625)
static void C_fcall f_1625(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1047)
static void C_fcall f_1047(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1683)
static void C_fcall f_1683(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1272)
static void C_ccall f_1272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1553)
static void C_ccall f_1553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1550)
static void C_ccall f_1550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1547)
static void C_ccall f_1547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1289)
static void C_ccall f_1289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1633)
static void C_ccall f_1633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1286)
static void C_ccall f_1286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_824)
static void C_ccall f_824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1556)
static void C_ccall f_1556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1298)
static void C_ccall f_1298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1292)
static void C_ccall f_1292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1653)
static void C_ccall f_1653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_763)
static void C_ccall f_763(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_763)
static void C_ccall f_763r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1657)
static void C_ccall f_1657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1658)
static void C_ccall f_1658(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1655)
static void C_ccall f_1655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1661)
static void C_ccall f_1661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_751)
static void C_ccall f_751(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_758)
static void C_ccall f_758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1672)
static void C_ccall f_1672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1674)
static void C_ccall f_1674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1670)
static void C_ccall f_1670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1073)
static void C_ccall f_1073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1076)
static void C_ccall f_1076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1676)
static void C_ccall f_1676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_990)
static void C_fcall f_990(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1600)
static void C_ccall f_1600(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1600)
static void C_ccall f_1600r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_992)
static void C_ccall f_992(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1385)
static void C_ccall f_1385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1694)
static void C_ccall f_1694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1690)
static void C_ccall f_1690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1396)
static void C_ccall f_1396(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1208)
static void C_ccall f_1208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1390)
static void C_ccall f_1390(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1211)
static void C_ccall f_1211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1214)
static void C_ccall f_1214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1379)
static void C_ccall f_1379(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1373)
static void C_ccall f_1373(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1229)
static void C_ccall f_1229(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1226)
static void C_ccall f_1226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1228)
static void C_ccall f_1228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1794)
static void C_fcall f_1794(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1798)
static void C_ccall f_1798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1085)
static void C_fcall f_1085(C_word t0,C_word t1,C_word t2) C_noret;

C_noret_decl(trf_1430)
static void C_fcall trf_1430(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1430(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1430(t0,t1);}

C_noret_decl(trf_1038)
static void C_fcall trf_1038(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1038(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1038(t0,t1);}

C_noret_decl(trf_1004)
static void C_fcall trf_1004(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1004(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1004(t0,t1);}

C_noret_decl(trf_910)
static void C_fcall trf_910(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_910(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_910(t0,t1,t2,t3);}

C_noret_decl(trf_1465)
static void C_fcall trf_1465(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1465(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1465(t0,t1);}

C_noret_decl(trf_799)
static void C_fcall trf_799(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_799(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_799(t0,t1,t2,t3);}

C_noret_decl(trf_1748)
static void C_fcall trf_1748(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1748(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1748(t0,t1);}

C_noret_decl(trf_1513)
static void C_fcall trf_1513(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1513(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1513(t0,t1);}

C_noret_decl(trf_1705)
static void C_fcall trf_1705(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1705(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1705(t0,t1,t2);}

C_noret_decl(trf_1140)
static void C_fcall trf_1140(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1140(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1140(t0,t1);}

C_noret_decl(trf_1114)
static void C_fcall trf_1114(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1114(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1114(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1616)
static void C_fcall trf_1616(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1616(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1616(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1625)
static void C_fcall trf_1625(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1625(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1625(t0,t1);}

C_noret_decl(trf_1047)
static void C_fcall trf_1047(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1047(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1047(t0,t1,t2);}

C_noret_decl(trf_1683)
static void C_fcall trf_1683(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1683(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1683(t0,t1);}

C_noret_decl(trf_990)
static void C_fcall trf_990(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_990(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_990(t0,t1);}

C_noret_decl(trf_1794)
static void C_fcall trf_1794(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1794(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1794(t0,t1);}

C_noret_decl(trf_1085)
static void C_fcall trf_1085(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1085(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1085(t0,t1,t2);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

/* decompose-pathname in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1242(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1242,3,t0,t1,t2);}
t3=C_i_check_string_2(t2,lf[44]);
t4=C_block_size(t2);
t5=C_eqp(C_fix(0),t4);
if(C_truep(t5)){
/* files.scm:239: values */
C_values(5,0,t1,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE);}
else{
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1257,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* files.scm:240: irregex-search */
t7=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[4],t2);}}

/* f_1342 in pathname-extension in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1342(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1342,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* pathname-strip-directory in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1345(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1345,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1351,a[2]=t2,a[3]=((C_word)li26),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1356,a[2]=((C_word)li27),tmp=(C_word)a,a+=3,tmp);
/* files.scm:270: ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* k930 in k924 in loop in k907 in k901 in k899 in k897 in k895 in k893 in k891 in file-move in k748 in k746 in k744 */
static void C_ccall f_931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_fixnum_plus(((C_word*)t0)[2],((C_word*)t0)[3]);
/* files.scm:133: loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_910(t3,((C_word*)t0)[5],t1,t2);}

/* f_1356 in pathname-strip-directory in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1356(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1356,5,t0,t1,t2,t3,t4);}
/* files.scm:272: make-pathname */
t5=*((C_word*)lf[29]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,C_SCHEME_FALSE,t3,t4);}

/* k935 in k893 in k891 in file-move in k748 in k746 in k744 */
static void C_ccall f_937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
if(C_truep(((C_word*)t0)[2])){
t2=((C_word*)t0)[3];
f_896(2,t2,((C_word*)t0)[2]);}
else{
/* files.scm:116: ##sys#error */
t2=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[17],lf[18],((C_word*)t0)[4]);}}
else{
t2=((C_word*)t0)[3];
f_896(2,t2,C_SCHEME_FALSE);}}

/* f_1351 in pathname-strip-directory in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1351,2,t0,t1);}
/* files.scm:271: decompose-pathname */
t2=*((C_word*)lf[44]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* k1014 in chop-pds in k989 in k748 in k746 in k744 */
static void C_ccall f_1016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=C_fixnum_difference(((C_word*)t0)[2],C_fix(1));
/* files.scm:167: ##sys#substring */
((C_proc5)C_fast_retrieve_proc(*((C_word*)lf[27]+1)))(5,*((C_word*)lf[27]+1),((C_word*)t0)[3],((C_word*)t0)[4],C_fix(0),t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}}

/* f_1337 in pathname-extension in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1337,2,t0,t1);}
/* files.scm:266: decompose-pathname */
t2=*((C_word*)lf[44]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-extension in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1331(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1331,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1337,a[2]=t2,a[3]=((C_word)li23),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1342,a[2]=((C_word)li24),tmp=(C_word)a,a+=3,tmp);
/* files.scm:265: ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* k1495 in k1492 in k1486 in loop in create-temporary-file in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm:316: string-append */
t2=*((C_word*)lf[31]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],lf[64],t1);}

/* k1492 in k1486 in loop in create-temporary-file in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1493,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1496,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=C_fudge(C_fix(33));
/* files.scm:320: ##sys#number->string */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[65]+1)))(3,*((C_word*)lf[65]+1),t2,t3);}

/* k895 in k893 in k891 in file-move in k748 in k746 in k744 */
static void C_ccall f_896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_896,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_898,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* files.scm:120: open-input-file */
t3=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],lf[10]);}

/* f_1309 in pathname-directory in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1309,2,t0,t1);}
/* files.scm:256: decompose-pathname */
t2=*((C_word*)lf[44]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* k897 in k895 in k893 in k891 in file-move in k748 in k746 in k744 */
static void C_ccall f_898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_898,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_900,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* files.scm:121: open-output-file */
t3=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[5],lf[10]);}

/* tempdir in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_fcall f_1430(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1430,NULL,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[2])[1];
if(C_truep(t2)){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1437,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* files.scm:303: get-environment-variable */
t4=*((C_word*)lf[57]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[60]);}}

/* k1489 in k1486 in loop in create-temporary-file in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm:314: make-pathname */
t2=*((C_word*)lf[29]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1,((C_word*)t0)[4]);}

/* k944 in k891 in file-move in k748 in k746 in k744 */
static void C_ccall f_946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* files.scm:113: ##sys#error */
t2=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[17],lf[19],((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[2];
f_894(2,t2,C_SCHEME_UNDEFINED);}}

/* k1436 in tempdir in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1437,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1443,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* files.scm:304: get-environment-variable */
t3=*((C_word*)lf[57]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[59]);}}

/* k1927 in k1943 in k1937 in k1935 in k1933 in decompose-directory in k1961 in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1928,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[2]);
/* files.scm:450: values */
C_values(5,0,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5],t2);}

/* pathname-directory in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1303(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1303,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1309,a[2]=t2,a[3]=((C_word)li17),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1314,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp);
/* files.scm:255: ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* k891 in file-move in k748 in k746 in k744 */
static void C_ccall f_892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_892,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_894,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_946,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* files.scm:112: directory-exists? */
t4=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* conc-dirs in k989 in k748 in k746 in k744 */
static void C_fcall f_1038(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1038,NULL,2,t1,t2);}
t3=C_i_check_list_2(t2,lf[29]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1047,a[2]=t5,a[3]=((C_word)li8),tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_1047(t7,t1,t2);}

/* k893 in k891 in file-move in k748 in k746 in k744 */
static void C_ccall f_894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_894,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_896,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_937,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* files.scm:114: file-exists? */
t4=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[5]);}

/* pathname-file in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1317(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1317,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1323,a[2]=t2,a[3]=((C_word)li20),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1328,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp);
/* files.scm:260: ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* k1442 in k1436 in tempdir in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1443,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1448,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* files.scm:305: get-environment-variable */
t3=*((C_word*)lf[57]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[58]);}}

/* k1001 in absolute-pathname? in k989 in k748 in k746 in k744 */
static void C_ccall f_1002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm:158: irregex-match-data? */
t2=*((C_word*)lf[25]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1447 in k1442 in k1436 in tempdir in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t2=lf[56];
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* chop-pds in k989 in k748 in k746 in k744 */
static void C_fcall f_1004(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1004,NULL,2,t1,t2);}
if(C_truep(t2)){
t3=C_block_size(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1016,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_fixnum_greater_or_equal_p(t3,C_fix(1)))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1026,a[2]=((C_word)li6),tmp=(C_word)a,a+=3,tmp);
t6=C_fixnum_difference(t3,C_fix(1));
t7=C_subchar(t2,t6);
/* files.scm:166: g171 */
t8=t5;
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t4,t7);}
else{
t5=t4;
f_1016(2,t5,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* f_1314 in pathname-directory in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1314(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1314,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}

/* f_1368 in pathname-strip-extension in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1368,2,t0,t1);}
/* files.scm:276: decompose-pathname */
t2=*((C_word*)lf[44]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* k1943 in k1937 in k1935 in k1933 in decompose-directory in k1961 in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1944,2,t0,t1);}
t2=C_i_nullp(((C_word*)t0)[2]);
t3=(C_truep(t2)?C_SCHEME_FALSE:((C_word*)t0)[2]);
t4=((C_word*)t0)[3];
if(C_truep(t4)){
t5=C_i_car(t3);
t6=C_block_size(t4);
if(C_truep(C_substring_compare(t4,t5,C_fix(0),C_fix(0),t6))){
t7=C_u_i_cdr(t3);
t8=C_block_size(t5);
t9=C_block_size(t8);
t10=C_eqp(t6,t9);
if(C_truep(t10)){
/* files.scm:450: values */
C_values(5,0,((C_word*)t0)[4],((C_word*)t0)[3],t1,t7);}
else{
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1928,a[2]=t7,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* files.scm:446: ##sys#substring */
((C_proc5)C_fast_retrieve_proc(*((C_word*)lf[27]+1)))(5,*((C_word*)lf[27]+1),t11,t5,t6,t8);}}
else{
/* files.scm:450: values */
C_values(5,0,((C_word*)t0)[4],((C_word*)t0)[3],t1,t3);}}
else{
/* files.scm:450: values */
C_values(5,0,((C_word*)t0)[4],((C_word*)t0)[3],t1,t3);}}

/* pathname-strip-extension in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1362(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1362,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1368,a[2]=t2,a[3]=((C_word)li29),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1373,a[2]=((C_word)li30),tmp=(C_word)a,a+=3,tmp);
/* files.scm:275: ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* k1933 in decompose-directory in k1961 in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1934,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1936,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* files.scm:448: absolute-pathname-root */
t3=lf[21];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k1935 in k1933 in decompose-directory in k1961 in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1936,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1938,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* files.scm:449: root-origin */
t3=lf[22];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k1937 in k1935 in k1933 in decompose-directory in k1961 in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1938,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1944,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* files.scm:450: root-directory */
t3=lf[23];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k1961 in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1962,2,t0,t1);}
t2=C_eqp(t1,lf[73]);
t3=(C_truep(t2)?lf[74]:lf[75]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1564,a[2]=((C_word)li47),tmp=(C_word)a,a+=3,tmp);
t5=C_mutate((C_word*)lf[79]+1 /* (set! normalize-pathname ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1600,a[2]=t3,a[3]=t4,a[4]=((C_word)li52),tmp=(C_word)a,a+=5,tmp));
t6=C_mutate((C_word*)lf[90]+1 /* (set! directory-null? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1854,a[2]=((C_word)li54),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[95]+1 /* (set! decompose-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1892,a[2]=((C_word)li55),tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_UNDEFINED);}

/* f_1966 in k1963 in k748 in k746 in k744 */
static void C_ccall f_1966(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1966,3,t0,t1,t2);}
/* files.scm:148: irregex-match */
t3=*((C_word*)lf[101]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,((C_word*)t0)[2],t2);}

/* k1963 in k748 in k746 in k744 */
static void C_ccall f_1964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1964,2,t0,t1);}
t2=C_mutate(&lf[21] /* (set! absolute-pathname-root ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1966,a[2]=t1,a[3]=((C_word)li56),tmp=(C_word)a,a+=4,tmp));
t3=C_mutate(&lf[22] /* (set! root-origin ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1972,a[2]=((C_word)li57),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate(&lf[23] /* (set! root-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1981,a[2]=((C_word)li58),tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t0)[2];
f_990(t5,t4);}

/* k1473 in k1468 in loop in create-temporary-file in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1475,2,t0,t1);}
if(C_truep(t1)){
/* files.scm:323: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_1465(t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1483,a[2]=((C_word*)t0)[4],a[3]=((C_word)li42),tmp=(C_word)a,a+=4,tmp);
/* files.scm:324: call-with-output-file */
t3=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[4],t2);}}

/* f_1328 in pathname-file in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1328(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1328,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}

/* pathname-replace-extension in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1413(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1413,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1419,a[2]=t2,a[3]=((C_word)li38),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1424,a[2]=t3,a[3]=((C_word)li39),tmp=(C_word)a,a+=4,tmp);
/* files.scm:290: ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}

/* f_1981 in k1963 in k748 in k746 in k744 */
static void C_ccall f_1981(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1981,3,t0,t1,t2);}
if(C_truep(t2)){
/* files.scm:150: irregex-match-substring */
t3=*((C_word*)lf[45]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,C_fix(2));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* f_1419 in pathname-replace-extension in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1419,2,t0,t1);}
/* files.scm:291: decompose-pathname */
t2=*((C_word*)lf[44]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* f_1323 in pathname-file in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1323,2,t0,t1);}
/* files.scm:261: decompose-pathname */
t2=*((C_word*)lf[44]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* file-move in k748 in k746 in k744 */
static void C_ccall f_874(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr4r,(void*)f_874r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_874r(t0,t1,t2,t3,t4);}}

static void C_ccall f_874r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a=C_alloc(7);
t5=C_i_nullp(t4);
t6=(C_truep(t5)?C_SCHEME_FALSE:C_i_car(t4));
t7=C_i_nullp(t4);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:C_i_cdr(t4));
t9=C_i_nullp(t8);
t10=(C_truep(t9)?C_fix(1024):C_i_car(t8));
t11=C_i_nullp(t8);
t12=(C_truep(t11)?C_SCHEME_END_OF_LIST:C_i_cdr(t8));
t13=C_i_check_string_2(t2,lf[17]);
t14=C_i_check_string_2(t3,lf[17]);
t15=C_i_check_number_2(t10,lf[17]);
t16=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_892,a[2]=t2,a[3]=t10,a[4]=t1,a[5]=t3,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_integerp(t10))){
if(C_truep(C_fixnum_greaterp(t10,C_fix(0)))){
t17=t16;
f_892(2,t17,C_SCHEME_UNDEFINED);}
else{
/* files.scm:108: ##sys#error */
t17=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t17+1)))(5,t17,t16,lf[17],lf[20],t10);}}
else{
/* files.scm:108: ##sys#error */
t17=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t17+1)))(5,t17,t16,lf[17],lf[20],t10);}}

/* k1486 in loop in create-temporary-file in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1487,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1490,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1493,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* files.scm:318: number->string */
C_number_to_string(4,0,t3,((C_word*)t0)[5],C_fix(16));}

/* f_1483 in k1473 in k1468 in loop in create-temporary-file in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1483(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1483,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}

/* f_1424 in pathname-replace-extension in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1424(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1424,5,t0,t1,t2,t3,t4);}
/* files.scm:292: make-pathname */
t5=*((C_word*)lf[29]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,t3,((C_word*)t0)[2]);}

/* f_1972 in k1963 in k748 in k746 in k744 */
static void C_ccall f_1972(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1972,3,t0,t1,t2);}
if(C_truep(t2)){
/* files.scm:149: irregex-match-substring */
t3=*((C_word*)lf[45]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,C_fix(1));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* make-pathname in k989 in k748 in k746 in k744 */
static void C_ccall f_1178(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_1178r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1178r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1178r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(6);
t5=C_i_nullp(t4);
t6=(C_truep(t5)?C_SCHEME_FALSE:C_i_car(t4));
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1189,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* files.scm:213: canonicalize-dirs */
t8=((C_word*)((C_word*)t0)[3])[1];
f_1085(t8,t7,t2);}

/* k1154 in _make-pathname in k989 in k748 in k746 in k744 */
static void C_ccall f_1156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=C_block_size(((C_word*)t0)[2]);
/* files.scm:203: ##sys#substring */
((C_proc5)C_fast_retrieve_proc(*((C_word*)lf[27]+1)))(5,*((C_word*)lf[27]+1),((C_word*)t0)[3],((C_word*)t0)[2],C_fix(1),t2);}
else{
t2=((C_word*)t0)[3];
f_1134(2,t2,((C_word*)t0)[2]);}}

/* directory-null? in k1961 in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1854(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1854,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1861,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_listp(t2))){
t4=t3;
f_1861(2,t4,t2);}
else{
t4=t2;
t5=C_i_check_string_2(t4,lf[90]);
/* files.scm:415: string-split */
t6=*((C_word*)lf[93]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t3,t4,lf[94],C_SCHEME_TRUE);}}

/* create-temporary-file in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1453(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr2r,(void*)f_1453r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1453r(t0,t1,t2);}}

static void C_ccall f_1453r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(9);
t3=C_i_nullp(t2);
t4=(C_truep(t3)?lf[62]:C_i_car(t2));
t5=C_i_check_string_2(t4,lf[61]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1465,a[2]=t7,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word)li43),tmp=(C_word)a,a+=7,tmp));
t9=((C_word*)t7)[1];
f_1465(t9,t1);}

/* loop in k907 in k901 in k899 in k897 in k895 in k893 in k891 in file-move in k748 in k746 in k744 */
static void C_fcall f_910(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_910,NULL,4,t0,t1,t2,t3);}
t4=C_eqp(C_fix(0),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_919,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* files.scm:127: close-input-port */
t6=*((C_word*)lf[5]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[4]);}
else{
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_925,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
/* files.scm:132: write-string */
t6=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,((C_word*)t0)[7],t2,((C_word*)t0)[3]);}}

/* k918 in loop in k907 in k901 in k899 in k897 in k895 in k893 in k891 in file-move in k748 in k746 in k744 */
static void C_ccall f_919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_919,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_921,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* files.scm:128: close-output-port */
t3=*((C_word*)lf[4]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k1133 in _make-pathname in k989 in k748 in k746 in k744 */
static void C_ccall f_1134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1134,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1140,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=C_block_size(((C_word*)t0)[4]);
if(C_truep(C_fixnum_greaterp(t3,C_fix(0)))){
t4=C_subchar(((C_word*)t0)[4],C_fix(0));
t5=C_i_char_equalp(t4,C_make_character(46));
t6=t2;
f_1140(t6,C_i_not(t5));}
else{
t4=t2;
f_1140(t4,C_SCHEME_FALSE);}}

/* root-directory in k1989 in k748 in k746 in k744 */
static void C_ccall f_2002(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2002,3,t0,t1,t2);}
if(C_truep(t2)){
/* files.scm:154: irregex-match-substring */
t3=*((C_word*)lf[45]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,C_fix(1));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k1188 in make-pathname in k989 in k748 in k746 in k744 */
static void C_ccall f_1189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm:213: _make-pathname */
f_1114(((C_word*)t0)[3],lf[29],t1,((C_word*)t0)[4],((C_word*)t0)[5]);}

/* k828 in k780 in file-copy in k748 in k746 in k744 */
static void C_ccall f_830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
if(C_truep(((C_word*)t0)[2])){
t2=((C_word*)t0)[3];
f_783(2,t2,((C_word*)t0)[2]);}
else{
/* files.scm:83: ##sys#error */
t2=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[3],lf[15],((C_word*)t0)[4]);}}
else{
t2=((C_word*)t0)[3];
f_783(2,t2,C_SCHEME_FALSE);}}

/* f_1166 in _make-pathname in k989 in k748 in k746 in k744 */
static void C_ccall f_1166(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1166,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_u_i_memq(t2,lf[38]));}

/* k748 in k746 in k744 */
static void C_ccall f_749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_749,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1 /* (set! delete-file* ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_751,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t3=C_mutate((C_word*)lf[3]+1 /* (set! file-copy ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_763,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[17]+1 /* (set! file-move ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_874,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp));
t5=lf[21] /* absolute-pathname-root */ =C_SCHEME_UNDEFINED;;
t6=lf[22] /* root-origin */ =C_SCHEME_UNDEFINED;;
t7=lf[23] /* root-directory */ =C_SCHEME_UNDEFINED;;
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_990,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(*((C_word*)lf[100]+1))){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1964,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* files.scm:147: irregex */
t10=*((C_word*)lf[97]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,lf[102]);}
else{
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1990,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* files.scm:151: irregex */
t10=*((C_word*)lf[97]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,lf[103]);}}

/* k744 */
static void C_ccall f_745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_745,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_747,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_2dstructures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k746 in k744 */
static void C_ccall f_747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_747,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_749,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* files.scm:58: register-feature! */
t3=*((C_word*)lf[104]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[105]);}

/* loop in create-temporary-file in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_fcall f_1465(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1465,NULL,2,t0,t1);}
t2=C_random_fixnum(C_fix(65536));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1469,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1487,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* files.scm:315: tempdir */
t5=((C_word*)t0)[5];
f_1430(t5,t4);}

/* k1468 in loop in create-temporary-file in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1469,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1475,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* files.scm:322: file-exists? */
t3=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* f_1402 in pathname-replace-file in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1402,2,t0,t1);}
/* files.scm:286: decompose-pathname */
t2=*((C_word*)lf[44]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* k920 in k918 in loop in k907 in k901 in k899 in k897 in k895 in k893 in k891 in file-move in k748 in k746 in k744 */
static void C_ccall f_921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_921,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_923,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* files.scm:129: delete-file */
t3=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k922 in k920 in k918 in loop in k907 in k901 in k899 in k897 in k895 in k893 in k891 in file-move in k748 in k746 in k744 */
static void C_ccall f_923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k924 in loop in k907 in k901 in k899 in k897 in k895 in k893 in k891 in file-move in k748 in k746 in k744 */
static void C_ccall f_925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_925,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_931,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* files.scm:133: read-string! */
t3=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[6],((C_word*)t0)[7],((C_word*)t0)[8]);}

/* k1777 in k1747 in k1744 in loop in normalize-pathname in k1961 in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1778,2,t0,t1);}
t2=f_1564(C_a_i(&a,9),t1,((C_word*)((C_word*)t0)[3])[1]);
/* files.scm:398: loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1616(t3,((C_word*)t0)[5],((C_word*)t0)[6],((C_word*)t0)[7],t2);}

/* f_1407 in pathname-replace-file in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1407(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1407,5,t0,t1,t2,t3,t4);}
/* files.scm:287: make-pathname */
t5=*((C_word*)lf[29]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,((C_word*)t0)[2],t4);}

/* k790 in k788 in k786 in k784 in k782 in k780 in file-copy in k748 in k746 in k744 */
static void C_ccall f_791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_791,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_797,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* files.scm:92: read-string! */
t3=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3]);}

/* loop in k796 in k790 in k788 in k786 in k784 in k782 in k780 in file-copy in k748 in k746 in k744 */
static void C_fcall f_799(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_799,NULL,4,t0,t1,t2,t3);}
t4=C_eqp(C_fix(0),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_808,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* files.scm:96: close-input-port */
t6=*((C_word*)lf[5]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[3]);}
else{
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_812,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[3],tmp=(C_word)a,a+=9,tmp);
/* files.scm:100: write-string */
t6=*((C_word*)lf[7]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,((C_word*)t0)[6],t2,((C_word*)t0)[2]);}}

/* k796 in k790 in k788 in k786 in k784 in k782 in k780 in file-copy in k748 in k746 in k744 */
static void C_ccall f_797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_797,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_799,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word)li1),tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_799(t5,((C_word*)t0)[6],t1,C_fix(0));}

/* decompose-directory in k1961 in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1892(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1892,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1934,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=t2;
t5=C_i_check_string_2(t4,lf[95]);
/* files.scm:415: string-split */
t6=*((C_word*)lf[93]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t3,t4,lf[94],C_SCHEME_FALSE);}

/* k1744 in loop in normalize-pathname in k1961 in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1746,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1748,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(C_i_nullp(((C_word*)((C_word*)t0)[6])[1]))){
t3=C_eqp(((C_word*)t0)[2],((C_word*)t0)[3]);
if(C_truep(t3)){
t4=C_set_block_item(((C_word*)t0)[9],0,C_SCHEME_TRUE);
t5=t2;
f_1748(t5,t4);}
else{
t4=t2;
f_1748(t4,C_SCHEME_UNDEFINED);}}
else{
t3=t2;
f_1748(t3,C_SCHEME_UNDEFINED);}}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1794,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
if(C_truep(C_i_nullp(((C_word*)((C_word*)t0)[6])[1]))){
t3=((C_word*)t0)[8];
t4=((C_word*)t0)[2];
t5=C_subchar(t3,t4);
t6=C_i_char_equalp(t5,C_make_character(58));
t7=t2;
f_1794(t7,(C_truep(t6)?C_eqp(lf[74],((C_word*)t0)[11]):C_SCHEME_FALSE));}
else{
t3=t2;
f_1794(t3,C_SCHEME_FALSE);}}}

/* k1747 in k1744 in loop in normalize-pathname in k1961 in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_fcall f_1748(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1748,NULL,2,t0,t1);}
t2=C_eqp(((C_word*)t0)[2],((C_word*)t0)[3]);
if(C_truep(t2)){
t3=C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
t4=C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
/* files.scm:397: loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_1616(t5,((C_word*)t0)[5],t3,t4,((C_word*)((C_word*)t0)[6])[1]);}
else{
t3=C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
t4=C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1778,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=t4,tmp=(C_word)a,a+=8,tmp);
/* files.scm:400: ##sys#substring */
((C_proc5)C_fast_retrieve_proc(*((C_word*)lf[27]+1)))(5,*((C_word*)lf[27]+1),t5,((C_word*)t0)[8],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k780 in file-copy in k748 in k746 in k744 */
static void C_ccall f_781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_781,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_783,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_830,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* files.scm:81: file-exists? */
t4=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* k782 in k780 in file-copy in k748 in k746 in k744 */
static void C_ccall f_783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_783,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_785,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_824,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* files.scm:87: directory-exists? */
t4=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[5]);}

/* k784 in k782 in k780 in file-copy in k748 in k746 in k744 */
static void C_ccall f_785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_785,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_787,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* files.scm:89: open-input-file */
t3=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[5],lf[10]);}

/* loop in k1860 in directory-null? in k1961 in k1227 in k1225 in k989 in k748 in k746 in k744 */
static C_word C_fcall f_1863(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_stack_overflow_check;
loop:
t2=C_i_nullp(t1);
if(C_truep(t2)){
return(t2);}
else{
t3=C_i_car(t1);
if(C_truep((C_truep(C_i_equalp(t3,lf[91]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t3,lf[92]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t4=t1;
t5=C_u_i_cdr(t4);
t7=t5;
t1=t7;
goto loop;}
else{
return(C_SCHEME_FALSE);}}}

/* k1860 in directory-null? in k1961 in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1861,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1863,a[2]=((C_word)li53),tmp=(C_word)a,a+=3,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_1863(t1));}

/* k786 in k784 in k782 in k780 in file-copy in k748 in k746 in k744 */
static void C_ccall f_787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_787,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_789,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* files.scm:90: open-output-file */
t3=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[4],lf[10]);}

/* k788 in k786 in k784 in k782 in k780 in file-copy in k748 in k746 in k744 */
static void C_ccall f_789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_789,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_791,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* files.scm:91: make-string */
t3=*((C_word*)lf[8]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k1521 in k1516 in loop in create-temporary-directory in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1523,2,t0,t1);}
if(C_truep(t1)){
/* files.scm:337: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_1513(t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1529,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* files.scm:338: ##sys#make-c-string */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[71]+1)))(4,*((C_word*)lf[71]+1),t2,((C_word*)t0)[4],lf[66]);}}

/* f_1740 in loop in normalize-pathname in k1961 in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1740(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1740,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_u_i_memq(t2,lf[89]));}

/* k901 in k899 in k897 in k895 in k893 in k891 in file-move in k748 in k746 in k744 */
static void C_ccall f_902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_902,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_908,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* files.scm:123: read-string! */
t3=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[5],t1,((C_word*)t0)[4]);}

/* k899 in k897 in k895 in k893 in k891 in file-move in k748 in k746 in k744 */
static void C_ccall f_900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_900,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_902,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* files.scm:122: make-string */
t3=*((C_word*)lf[8]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k907 in k901 in k899 in k897 in k895 in k893 in k891 in file-move in k748 in k746 in k744 */
static void C_ccall f_908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_908,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_910,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word)li3),tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_910(t5,((C_word*)t0)[7],t1,C_fix(0));}

/* make-absolute-pathname in k989 in k748 in k746 in k744 */
static void C_ccall f_1197(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_1197r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1197r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1197r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(6);
t5=C_i_nullp(t4);
t6=(C_truep(t5)?C_SCHEME_FALSE:C_i_car(t4));
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1208,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* files.scm:219: canonicalize-dirs */
t8=((C_word*)((C_word*)t0)[3])[1];
f_1085(t8,t7,t2);}

/* k1528 in k1521 in k1516 in loop in create-temporary-directory in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1529,2,t0,t1);}
t2=C_mkdir(t1);
t3=C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1541,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1544,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t6=*((C_word*)lf[70]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}}

/* k1735 in loop in normalize-pathname in k1961 in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1736,2,t0,t1);}
t2=f_1564(C_a_i(&a,9),t1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[4];
f_1625(t4,t3);}

/* loop in create-temporary-directory in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_fcall f_1513(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1513,NULL,2,t0,t1);}
t2=C_random_fixnum(C_fix(65536));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1517,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1547,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* files.scm:330: tempdir */
t5=((C_word*)t0)[4];
f_1430(t5,t4);}

/* k1256 in decompose-pathname in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1257,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1266,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1275,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* files.scm:243: irregex-match-substring */
t4=*((C_word*)lf[45]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t1,C_fix(1));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1277,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* files.scm:246: irregex-search */
t3=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[5],((C_word*)t0)[4]);}}

/* root-origin in k1989 in k748 in k746 in k744 */
static void C_ccall f_1998(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1998,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* create-temporary-directory in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1507,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1513,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word)li45),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_1513(t5,t1);}

/* absolute-pathname-root in k1989 in k748 in k746 in k744 */
static void C_ccall f_1992(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1992,3,t0,t1,t2);}
/* files.scm:152: irregex-match */
t3=*((C_word*)lf[101]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,((C_word*)t0)[2],t2);}

/* k1989 in k748 in k746 in k744 */
static void C_ccall f_1990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1990,2,t0,t1);}
t2=C_mutate(&lf[21] /* (set! absolute-pathname-root ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1992,a[2]=t1,a[3]=((C_word)li59),tmp=(C_word)a,a+=4,tmp));
t3=C_mutate(&lf[22] /* (set! root-origin ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1998,a[2]=((C_word)li60),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate(&lf[23] /* (set! root-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2002,a[2]=((C_word)li61),tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t0)[2];
f_990(t5,t4);}

/* k817 in k811 in loop in k796 in k790 in k788 in k786 in k784 in k782 in k780 in file-copy in k748 in k746 in k744 */
static void C_ccall f_818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_fixnum_plus(((C_word*)t0)[2],((C_word*)t0)[3]);
/* files.scm:101: loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_799(t3,((C_word*)t0)[5],t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_files_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_files_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("files_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(638)){
C_save(t1);
C_rereclaim2(638*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,106);
lf[0]=C_h_intern(&lf[0],12,"delete-file\052");
lf[1]=C_h_intern(&lf[1],11,"delete-file");
lf[2]=C_h_intern(&lf[2],12,"file-exists\077");
lf[3]=C_h_intern(&lf[3],9,"file-copy");
lf[4]=C_h_intern(&lf[4],17,"close-output-port");
lf[5]=C_h_intern(&lf[5],16,"close-input-port");
lf[6]=C_h_intern(&lf[6],12,"read-string!");
lf[7]=C_h_intern(&lf[7],12,"write-string");
lf[8]=C_h_intern(&lf[8],11,"make-string");
lf[9]=C_h_intern(&lf[9],16,"open-output-file");
lf[10]=C_h_intern(&lf[10],7,"\000binary");
lf[11]=C_h_intern(&lf[11],15,"open-input-file");
lf[12]=C_h_intern(&lf[12],9,"\003syserror");
lf[13]=C_decode_literal(C_heaptop,"\376B\000\000\030can not copy directories");
lf[14]=C_h_intern(&lf[14],17,"directory-exists\077");
lf[15]=C_decode_literal(C_heaptop,"\376B\000\000#newfile exists but clobber is false");
lf[16]=C_decode_literal(C_heaptop,"\376B\000\000/invalid blocksize given: not a positive integer");
lf[17]=C_h_intern(&lf[17],9,"file-move");
lf[18]=C_decode_literal(C_heaptop,"\376B\000\000#newfile exists but clobber is false");
lf[19]=C_decode_literal(C_heaptop,"\376B\000\000\030can not move directories");
lf[20]=C_decode_literal(C_heaptop,"\376B\000\000/invalid blocksize given: not a positive integer");
lf[24]=C_h_intern(&lf[24],18,"absolute-pathname\077");
lf[25]=C_h_intern(&lf[25],19,"irregex-match-data\077");
lf[27]=C_h_intern(&lf[27],13,"\003syssubstring");
lf[28]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000/\376\377\016");
lf[29]=C_h_intern(&lf[29],13,"make-pathname");
lf[30]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[31]=C_h_intern(&lf[31],13,"string-append");
lf[32]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[35]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[38]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000/\376\377\016");
lf[39]=C_h_intern(&lf[39],22,"make-absolute-pathname");
lf[40]=C_h_intern(&lf[40],17,"\003sysstring-append");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[44]=C_h_intern(&lf[44],18,"decompose-pathname");
lf[45]=C_h_intern(&lf[45],23,"irregex-match-substring");
lf[46]=C_h_intern(&lf[46],14,"irregex-search");
lf[47]=C_h_intern(&lf[47],18,"pathname-directory");
lf[48]=C_h_intern(&lf[48],13,"pathname-file");
lf[49]=C_h_intern(&lf[49],18,"pathname-extension");
lf[50]=C_h_intern(&lf[50],24,"pathname-strip-directory");
lf[51]=C_h_intern(&lf[51],24,"pathname-strip-extension");
lf[52]=C_h_intern(&lf[52],26,"pathname-replace-directory");
lf[53]=C_h_intern(&lf[53],21,"pathname-replace-file");
lf[54]=C_h_intern(&lf[54],26,"pathname-replace-extension");
lf[55]=C_decode_literal(C_heaptop,"\376B\000\000\004temp");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\004/tmp");
lf[57]=C_h_intern(&lf[57],24,"get-environment-variable");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\000\003TMP");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000\004TEMP");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\000\006TMPDIR");
lf[61]=C_h_intern(&lf[61],21,"create-temporary-file");
lf[62]=C_decode_literal(C_heaptop,"\376B\000\000\003tmp");
lf[63]=C_h_intern(&lf[63],21,"call-with-output-file");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[65]=C_h_intern(&lf[65],18,"\003sysnumber->string");
lf[66]=C_h_intern(&lf[66],26,"create-temporary-directory");
lf[67]=C_h_intern(&lf[67],15,"\003syssignal-hook");
lf[68]=C_h_intern(&lf[68],11,"\000file-error");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000$cannot create temporary directory - ");
lf[70]=C_h_intern(&lf[70],17,"\003syspeek-c-string");
lf[71]=C_h_intern(&lf[71],17,"\003sysmake-c-string");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[73]=C_h_intern(&lf[73],7,"mingw32");
lf[74]=C_h_intern(&lf[74],7,"windows");
lf[75]=C_h_intern(&lf[75],4,"unix");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[79]=C_h_intern(&lf[79],18,"normalize-pathname");
lf[80]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[82]=C_h_intern(&lf[82],7,"display");
lf[83]=C_h_intern(&lf[83],16,"\003syswrite-char-0");
lf[84]=C_h_intern(&lf[84],8,"for-each");
lf[85]=C_h_intern(&lf[85],20,"\003sysexpand-home-path");
lf[86]=C_h_intern(&lf[86],17,"get-output-string");
lf[87]=C_h_intern(&lf[87],16,"\003sysfast-reverse");
lf[88]=C_h_intern(&lf[88],18,"open-output-string");
lf[89]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000/\376\377\016");
lf[90]=C_h_intern(&lf[90],15,"directory-null\077");
lf[91]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[92]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[93]=C_h_intern(&lf[93],12,"string-split");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000\002/\134");
lf[95]=C_h_intern(&lf[95],19,"decompose-directory");
lf[96]=C_h_intern(&lf[96],14,"build-platform");
lf[97]=C_h_intern(&lf[97],7,"irregex");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000\034^(.\052[\134/\134\134])\077((\134.)\077[^\134/\134\134]+)$");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000&^(.\052[\134/\134\134])\077([^\134/\134\134]+)(\134.([^\134/\134\134.]+))$");
lf[100]=C_h_intern(&lf[100],20,"\003syswindows-platform");
lf[101]=C_h_intern(&lf[101],13,"irregex-match");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\026([A-Za-z]:)\077([\134/\134\134]).\052");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\012([\134/\134\134]).\052");
lf[104]=C_h_intern(&lf[104],17,"register-feature!");
lf[105]=C_h_intern(&lf[105],5,"files");
C_register_lf2(lf,106,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_745,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_irregex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* addpart in k1961 in k1227 in k1225 in k989 in k748 in k746 in k744 */
static C_word C_fcall f_1564(C_word *a,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_stack_overflow_check;
if(C_truep(C_i_string_equal_p(lf[76],t1))){
t3=t2;
return(t3);}
else{
t3=t1;
if(C_truep(C_u_i_string_equal_p(lf[77],t3))){
t4=C_i_nullp(t2);
if(C_truep(t4)){
return((C_truep(t4)?C_a_i_cons(&a,2,t1,t2):C_i_cdr(t2)));}
else{
t5=C_i_car(t2);
t6=C_i_string_equal_p(lf[78],t5);
return((C_truep(t6)?C_a_i_cons(&a,2,t1,t2):C_i_cdr(t2)));}}
else{
return(C_a_i_cons(&a,2,t1,t2));}}}

/* for-each-loop453 in k1656 in k1654 in k1652 in k1624 in loop in normalize-pathname in k1961 in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_fcall f_1705(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1705,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1714,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* files.scm:379: g454 */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1265 in k1256 in decompose-pathname in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1266,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1269,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* files.scm:244: irregex-match-substring */
t3=*((C_word*)lf[45]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],C_fix(2));}

/* k1268 in k1265 in k1256 in decompose-pathname in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1269,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1272,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* files.scm:245: irregex-match-substring */
t3=*((C_word*)lf[45]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[4],C_fix(4));}

/* k1138 in k1133 in _make-pathname in k989 in k748 in k746 in k744 */
static void C_fcall f_1140(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* files.scm:199: string-append */
t2=*((C_word*)lf[31]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],lf[36],((C_word*)t0)[5]);}
else{
/* files.scm:199: string-append */
t2=*((C_word*)lf[31]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],lf[37],((C_word*)t0)[5]);}}

/* k1516 in loop in create-temporary-directory in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1517,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1523,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* files.scm:336: directory-exists? */
t3=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* f_1026 in chop-pds in k989 in k748 in k746 in k744 */
static void C_ccall f_1026(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1026,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_u_i_memq(t2,lf[28]));}

/* k809 in k807 in loop in k796 in k790 in k788 in k786 in k784 in k782 in k780 in file-copy in k748 in k746 in k744 */
static void C_ccall f_810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k811 in loop in k796 in k790 in k788 in k786 in k784 in k782 in k780 in file-copy in k748 in k746 in k744 */
static void C_ccall f_812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_812,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_818,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* files.scm:101: read-string! */
t3=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[6],((C_word*)t0)[7],((C_word*)t0)[8]);}

/* k807 in loop in k796 in k790 in k788 in k786 in k784 in k782 in k780 in file-copy in k748 in k746 in k744 */
static void C_ccall f_808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_808,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_810,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* files.scm:97: close-output-port */
t3=*((C_word*)lf[4]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}

/* k1713 in for-each-loop453 in k1656 in k1654 in k1652 in k1624 in loop in normalize-pathname in k1961 in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[2],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_1705(t3,((C_word*)t0)[4],t2);}

/* _make-pathname in k989 in k748 in k746 in k744 */
static void C_fcall f_1114(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1114,NULL,5,t1,t2,t3,t4,t5);}
t6=(C_truep(t5)?t5:lf[34]);
t7=(C_truep(t4)?t4:lf[35]);
t8=C_i_check_string_2(t3,t2);
t9=C_i_check_string_2(t7,t2);
t10=C_i_check_string_2(t6,t2);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1134,a[2]=t1,a[3]=t3,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1156,a[2]=t7,a[3]=t11,tmp=(C_word)a,a+=4,tmp);
t13=C_block_size(t7);
if(C_truep(C_fixnum_greater_or_equal_p(t13,C_fix(1)))){
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1166,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp);
t15=C_subchar(t7,C_fix(0));
/* files.scm:202: g205 */
t16=t14;
((C_proc3)(void*)(*((C_word*)t16+1)))(3,t16,t12,t15);}
else{
t14=t12;
f_1156(2,t14,C_SCHEME_FALSE);}}

/* loop in normalize-pathname in k1961 in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_fcall f_1616(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1616,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]))){
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1625,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=t3,tmp=(C_word)a,a+=9,tmp);
if(C_truep(C_fixnum_greaterp(t2,t3))){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1736,a[2]=((C_word*)t0)[6],a[3]=t5,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* files.scm:368: ##sys#substring */
((C_proc5)C_fast_retrieve_proc(*((C_word*)lf[27]+1)))(5,*((C_word*)lf[27]+1),t7,((C_word*)t0)[7],t3,t2);}
else{
t7=t6;
f_1625(t7,C_SCHEME_UNDEFINED);}}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1740,a[2]=((C_word)li50),tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1746,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[8],a[5]=t1,a[6]=t5,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[3],a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
t8=C_i_string_ref(((C_word*)t0)[7],t2);
/* files.scm:393: g478 */
t9=t6;
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,t8);}}

/* k1543 in k1528 in k1521 in k1516 in loop in create-temporary-directory in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm:343: ##sys#string-append */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[40]+1)))(4,*((C_word*)lf[40]+1),((C_word*)t0)[2],lf[69],t1);}

/* k1540 in k1528 in k1521 in k1516 in loop in create-temporary-directory in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm:341: ##sys#signal-hook */
t2=*((C_word*)lf[67]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[68],lf[66],t1,((C_word*)t0)[3]);}

/* k1276 in k1256 in decompose-pathname in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1277,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1286,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1292,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* files.scm:249: irregex-match-substring */
t4=*((C_word*)lf[45]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t1,C_fix(1));}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1298,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* files.scm:252: strip-pds */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}}

/* k1274 in k1256 in decompose-pathname in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm:243: strip-pds */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],t1);}

/* k1624 in loop in normalize-pathname in k1961 in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_fcall f_1625(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1625,NULL,2,t0,t1);}
if(C_truep(C_i_nullp(((C_word*)((C_word*)t0)[2])[1]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1633,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[5])[1])){
t3=C_a_i_string(&a,1,((C_word*)t0)[6]);
/* files.scm:371: ##sys#string-append */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[40]+1)))(4,*((C_word*)lf[40]+1),t2,t3,lf[80]);}
else{
t3=C_a_i_string(&a,1,((C_word*)t0)[6]);
/* files.scm:372: ##sys#string-append */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[40]+1)))(4,*((C_word*)lf[40]+1),t2,lf[81],t3);}}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1653,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[2],tmp=(C_word)a,a+=9,tmp);
/* files.scm:376: open-output-string */
t3=*((C_word*)lf[88]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* loop in conc-dirs in k989 in k748 in k746 in k744 */
static void C_fcall f_1047(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1047,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[30]);}
else{
t3=C_i_car(t2);
t4=C_i_string_length(t3);
t5=C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=t2;
t7=C_u_i_cdr(t6);
/* files.scm:182: loop */
t12=t1;
t13=t7;
t1=t12;
t2=t13;
goto loop;}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1073,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t7=t2;
t8=C_u_i_car(t7);
/* files.scm:184: chop-pds */
f_1004(t6,t8);}}}

/* k1682 in k1675 in k1673 in k1671 in k1668 in k1656 in k1654 in k1652 in k1624 in loop in normalize-pathname in k1961 in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_fcall f_1683(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1683,NULL,2,t0,t1);}
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1690,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* files.scm:391: ##sys#string-append */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[40]+1)))(4,*((C_word*)lf[40]+1),t2,((C_word*)((C_word*)t0)[2])[1],((C_word*)((C_word*)t0)[3])[1]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[3])[1]);}}

/* k1271 in k1268 in k1265 in k1256 in decompose-pathname in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm:242: values */
C_values(5,0,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],t1);}

/* k1552 in k1546 in loop in create-temporary-directory in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1553,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1556,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=C_fudge(C_fix(33));
/* files.scm:335: ##sys#number->string */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[65]+1)))(3,*((C_word*)lf[65]+1),t2,t3);}

/* k1549 in k1546 in loop in create-temporary-directory in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm:329: make-pathname */
t2=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* k1546 in loop in create-temporary-directory in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1547,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1550,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1553,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* files.scm:333: number->string */
C_number_to_string(4,0,t3,((C_word*)t0)[4],C_fix(16));}

/* k1288 in k1285 in k1276 in k1256 in decompose-pathname in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm:248: values */
C_values(5,0,((C_word*)t0)[2],((C_word*)t0)[3],t1,C_SCHEME_FALSE);}

/* k1632 in k1624 in loop in normalize-pathname in k1961 in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
/* files.scm:374: ##sys#string-append */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[40]+1)))(4,*((C_word*)lf[40]+1),((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}
else{
t2=t1;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k1285 in k1276 in k1256 in decompose-pathname in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1286,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1289,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* files.scm:250: irregex-match-substring */
t3=*((C_word*)lf[45]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],C_fix(2));}

/* k822 in k782 in k780 in file-copy in k748 in k746 in k744 */
static void C_ccall f_824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* files.scm:88: ##sys#error */
t2=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[3],lf[13],((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[2];
f_785(2,t2,C_SCHEME_UNDEFINED);}}

/* k1555 in k1552 in k1546 in loop in create-temporary-directory in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm:331: string-append */
t2=*((C_word*)lf[31]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4],lf[72],t1);}

/* k1297 in k1276 in k1256 in decompose-pathname in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm:252: values */
C_values(5,0,((C_word*)t0)[2],t1,C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* k1291 in k1276 in k1256 in decompose-pathname in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm:249: strip-pds */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],t1);}

/* k1652 in k1624 in loop in normalize-pathname in k1961 in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1653,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1655,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* files.scm:377: ##sys#fast-reverse */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[87]+1)))(3,*((C_word*)lf[87]+1),t2,((C_word*)((C_word*)t0)[8])[1]);}

/* file-copy in k748 in k746 in k744 */
static void C_ccall f_763(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr4r,(void*)f_763r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_763r(t0,t1,t2,t3,t4);}}

static void C_ccall f_763r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a=C_alloc(7);
t5=C_i_nullp(t4);
t6=(C_truep(t5)?C_SCHEME_FALSE:C_i_car(t4));
t7=C_i_nullp(t4);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:C_i_cdr(t4));
t9=C_i_nullp(t8);
t10=(C_truep(t9)?C_fix(1024):C_i_car(t8));
t11=C_i_nullp(t8);
t12=(C_truep(t11)?C_SCHEME_END_OF_LIST:C_i_cdr(t8));
t13=C_i_check_string_2(t2,lf[3]);
t14=C_i_check_string_2(t3,lf[3]);
t15=C_i_check_number_2(t10,lf[3]);
t16=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_781,a[2]=t10,a[3]=t1,a[4]=t3,a[5]=t2,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_integerp(t10))){
if(C_truep(C_fixnum_greaterp(t10,C_fix(0)))){
t17=t16;
f_781(2,t17,C_SCHEME_UNDEFINED);}
else{
/* files.scm:77: ##sys#error */
t17=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t17+1)))(5,t17,t16,lf[3],lf[16],t10);}}
else{
/* files.scm:77: ##sys#error */
t17=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t17+1)))(5,t17,t16,lf[3],lf[16],t10);}}

/* k1656 in k1654 in k1652 in k1624 in loop in normalize-pathname in k1961 in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1657,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1658,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li48),tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[4];
t4=C_u_i_cdr(t3);
t5=C_i_check_list_2(t4,lf[84]);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1670,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1705,a[2]=t8,a[3]=t2,a[4]=((C_word)li49),tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_1705(t10,t6,t4);}

/* f_1658 in k1656 in k1654 in k1652 in k1624 in loop in normalize-pathname in k1961 in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1658(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1658,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1661,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* files.scm:381: ##sys#write-char-0 */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[83]+1)))(4,*((C_word*)lf[83]+1),t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1654 in k1652 in k1624 in loop in normalize-pathname in k1961 in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1655,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1657,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=C_i_car(t1);
/* files.scm:378: display */
t4=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* k1660 */
static void C_ccall f_1661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm:382: display */
t2=*((C_word*)lf[82]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4]);}

/* delete-file* in k748 in k746 in k744 */
static void C_ccall f_751(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_751,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_758,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* files.scm:68: file-exists? */
t4=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k756 in delete-file* in k748 in k746 in k744 */
static void C_ccall f_758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* files.scm:68: delete-file */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k1671 in k1668 in k1656 in k1654 in k1652 in k1624 in loop in normalize-pathname in k1961 in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1672,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1674,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* files.scm:385: get-output-string */
t3=*((C_word*)lf[86]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}

/* k1673 in k1671 in k1668 in k1656 in k1654 in k1652 in k1624 in loop in normalize-pathname in k1961 in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1674,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1676,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* files.scm:386: ##sys#expand-home-path */
((C_proc3)C_fast_retrieve_proc(*((C_word*)lf[85]+1)))(3,*((C_word*)lf[85]+1),t2,t1);}

/* k1668 in k1656 in k1654 in k1652 in k1624 in loop in normalize-pathname in k1961 in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1670,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1672,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_eqp(((C_word*)t0)[7],((C_word*)t0)[8]);
if(C_truep(t3)){
/* files.scm:384: ##sys#write-char-0 */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[83]+1)))(4,*((C_word*)lf[83]+1),t2,((C_word*)t0)[5],((C_word*)t0)[6]);}
else{
t4=t2;
f_1672(2,t4,C_SCHEME_UNDEFINED);}}

/* k1072 in loop in conc-dirs in k989 in k748 in k746 in k744 */
static void C_ccall f_1073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1073,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1076,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[3];
t4=C_u_i_cdr(t3);
/* files.scm:186: loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_1047(t5,t2,t4);}

/* k1075 in k1072 in loop in conc-dirs in k989 in k748 in k746 in k744 */
static void C_ccall f_1076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm:183: string-append */
t2=*((C_word*)lf[31]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],((C_word*)t0)[3],lf[32],t1);}

/* k1675 in k1673 in k1671 in k1668 in k1656 in k1654 in k1652 in k1624 in loop in normalize-pathname in k1961 in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1676,2,t0,t1);}
t2=(*a=C_VECTOR_TYPE|1,a[1]=t1,tmp=(C_word)a,a+=2,tmp);
if(C_truep(C_i_string_equal_p(((C_word*)t0)[2],((C_word*)t2)[1]))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1683,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[5])[1])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1694,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=C_a_i_string(&a,1,((C_word*)t0)[6]);
/* files.scm:389: ##sys#string-append */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[40]+1)))(4,*((C_word*)lf[40]+1),t4,t5,((C_word*)t2)[1]);}
else{
t4=t3;
f_1683(t4,C_SCHEME_UNDEFINED);}}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t2)[1]);}}

/* k989 in k748 in k746 in k744 */
static void C_fcall f_990(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_990,NULL,2,t0,t1);}
t2=C_mutate((C_word*)lf[24]+1 /* (set! absolute-pathname? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_992,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp));
t3=C_mutate(&lf[26] /* (set! chop-pds ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1004,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1038,a[2]=((C_word)li9),tmp=(C_word)a,a+=3,tmp));
t11=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1085,a[2]=t5,a[3]=((C_word)li10),tmp=(C_word)a,a+=4,tmp));
t12=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1114,a[2]=((C_word)li12),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[29]+1 /* (set! make-pathname ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1178,a[2]=t9,a[3]=t7,a[4]=((C_word)li13),tmp=(C_word)a,a+=5,tmp));
t14=C_mutate((C_word*)lf[39]+1 /* (set! make-absolute-pathname ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1197,a[2]=t9,a[3]=t7,a[4]=((C_word)li14),tmp=(C_word)a,a+=5,tmp));
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1226,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* files.scm:228: irregex */
t16=*((C_word*)lf[97]+1);
((C_proc3)(void*)(*((C_word*)t16+1)))(3,t16,t15,lf[99]);}

/* normalize-pathname in k1961 in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1600(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr3r,(void*)f_1600r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1600r(t0,t1,t2,t3);}}

static void C_ccall f_1600r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a=C_alloc(17);
t4=C_i_nullp(t3);
t5=(C_truep(t4)?((C_word*)t0)[2]:C_i_car(t3));
t6=C_eqp(t5,lf[74]);
t7=(C_truep(t6)?C_make_character(92):C_make_character(47));
t8=C_i_check_string_2(t2,lf[79]);
t9=C_block_size(t2);
t10=C_SCHEME_FALSE;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_FALSE;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1616,a[2]=t9,a[3]=t13,a[4]=t11,a[5]=t7,a[6]=((C_word*)t0)[3],a[7]=t2,a[8]=t15,a[9]=t5,a[10]=((C_word)li51),tmp=(C_word)a,a+=11,tmp));
t17=((C_word*)t15)[1];
f_1616(t17,t1,C_fix(0),C_fix(0),C_SCHEME_END_OF_LIST);}

/* absolute-pathname? in k989 in k748 in k746 in k744 */
static void C_ccall f_992(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_992,3,t0,t1,t2);}
t3=C_i_check_string_2(t2,lf[24]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1002,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* files.scm:158: absolute-pathname-root */
t5=lf[21];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* f_1385 in pathname-replace-directory in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1385,2,t0,t1);}
/* files.scm:281: decompose-pathname */
t2=*((C_word*)lf[44]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* k1692 in k1675 in k1673 in k1671 in k1668 in k1656 in k1654 in k1652 in k1624 in loop in normalize-pathname in k1961 in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
t3=((C_word*)t0)[3];
f_1683(t3,t2);}

/* k1688 in k1682 in k1675 in k1673 in k1671 in k1668 in k1656 in k1654 in k1652 in k1624 in loop in normalize-pathname in k1961 in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* pathname-replace-file in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1396(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1396,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1402,a[2]=t2,a[3]=((C_word)li35),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1407,a[2]=t3,a[3]=((C_word)li36),tmp=(C_word)a,a+=4,tmp);
/* files.scm:285: ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}

/* k1207 in make-absolute-pathname in k989 in k748 in k746 in k744 */
static void C_ccall f_1208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1208,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1211,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1214,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* files.scm:220: absolute-pathname? */
t4=*((C_word*)lf[24]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t1);}

/* f_1390 in pathname-replace-directory in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1390(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1390,5,t0,t1,t2,t3,t4);}
/* files.scm:282: make-pathname */
t5=*((C_word*)lf[29]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,((C_word*)t0)[2],t3,t4);}

/* k1209 in k1207 in make-absolute-pathname in k989 in k748 in k746 in k744 */
static void C_ccall f_1211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm:217: _make-pathname */
f_1114(((C_word*)t0)[3],lf[39],t1,((C_word*)t0)[4],((C_word*)t0)[5]);}

/* k1212 in k1207 in make-absolute-pathname in k989 in k748 in k746 in k744 */
static void C_ccall f_1214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[2];
/* files.scm:217: _make-pathname */
f_1114(((C_word*)t0)[4],lf[39],t2,((C_word*)t0)[5],((C_word*)t0)[6]);}
else{
/* files.scm:222: ##sys#string-append */
((C_proc4)C_fast_retrieve_proc(*((C_word*)lf[40]+1)))(4,*((C_word*)lf[40]+1),((C_word*)t0)[7],lf[41],((C_word*)t0)[2]);}}

/* pathname-replace-directory in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1379(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1379,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1385,a[2]=t2,a[3]=((C_word)li32),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1390,a[2]=t3,a[3]=((C_word)li33),tmp=(C_word)a,a+=4,tmp);
/* files.scm:280: ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}

/* f_1373 in pathname-strip-extension in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1373(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1373,5,t0,t1,t2,t3,t4);}
/* files.scm:277: make-pathname */
t5=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t2,t3);}

/* f_1229 in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1229(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1229,3,t0,t1,t2);}
if(C_truep(t2)){
t3=t2;
if(C_truep((C_truep(C_i_equalp(t3,lf[42]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t3,lf[43]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
/* files.scm:235: chop-pds */
f_1004(t1,t2);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1226,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1228,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* files.scm:229: irregex */
t3=*((C_word*)lf[97]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[98]);}

/* k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[52],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1228,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1229,a[2]=((C_word)li15),tmp=(C_word)a,a+=3,tmp);
t3=C_mutate((C_word*)lf[44]+1 /* (set! decompose-pathname ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1242,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word)li16),tmp=(C_word)a,a+=6,tmp));
t4=C_mutate((C_word*)lf[47]+1 /* (set! pathname-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1303,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[48]+1 /* (set! pathname-file ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1317,a[2]=((C_word)li22),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[49]+1 /* (set! pathname-extension ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1331,a[2]=((C_word)li25),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[50]+1 /* (set! pathname-strip-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1345,a[2]=((C_word)li28),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[51]+1 /* (set! pathname-strip-extension ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1362,a[2]=((C_word)li31),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[52]+1 /* (set! pathname-replace-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1379,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[53]+1 /* (set! pathname-replace-file ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1396,a[2]=((C_word)li37),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[54]+1 /* (set! pathname-replace-extension ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1413,a[2]=((C_word)li40),tmp=(C_word)a,a+=3,tmp));
t12=C_SCHEME_FALSE;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=lf[55];
t15=*((C_word*)lf[31]+1);
t16=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1430,a[2]=t13,a[3]=((C_word)li41),tmp=(C_word)a,a+=4,tmp);
t17=C_mutate((C_word*)lf[61]+1 /* (set! create-temporary-file ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1453,a[2]=t14,a[3]=t16,a[4]=((C_word)li44),tmp=(C_word)a,a+=5,tmp));
t18=C_mutate((C_word*)lf[66]+1 /* (set! create-temporary-directory ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1507,a[2]=t14,a[3]=t16,a[4]=((C_word)li46),tmp=(C_word)a,a+=5,tmp));
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1962,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* files.scm:350: build-platform */
t20=*((C_word*)lf[96]+1);
((C_proc2)(void*)(*((C_word*)t20+1)))(2,t20,t19);}

/* k1792 in k1744 in loop in normalize-pathname in k1961 in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_fcall f_1794(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1794,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1798,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* files.scm:404: ##sys#substring */
((C_proc5)C_fast_retrieve_proc(*((C_word*)lf[27]+1)))(5,*((C_word*)lf[27]+1),t2,((C_word*)t0)[6],C_fix(0),t3);}
else{
t2=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* files.scm:406: loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1616(t3,((C_word*)t0)[5],t2,((C_word*)t0)[7],((C_word*)((C_word*)t0)[8])[1]);}}

/* k1796 in k1792 in k1744 in loop in normalize-pathname in k1961 in k1227 in k1225 in k989 in k748 in k746 in k744 */
static void C_ccall f_1798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
t3=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* files.scm:405: loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_1616(t5,((C_word*)t0)[5],t3,t4,C_SCHEME_END_OF_LIST);}

/* canonicalize-dirs in k989 in k748 in k746 in k744 */
static void C_fcall f_1085(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1085,NULL,3,t0,t1,t2);}
t3=C_i_not(t2);
t4=(C_truep(t3)?t3:C_i_nullp(t2));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[33]);}
else{
if(C_truep(C_i_stringp(t2))){
t5=C_a_i_list1(&a,1,t2);
/* files.scm:190: conc-dirs */
f_1038(t1,t5);}
else{
/* files.scm:191: conc-dirs */
f_1038(t1,t2);}}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[166] = {
{"f_1242:files_2escm",(void*)f_1242},
{"f_1342:files_2escm",(void*)f_1342},
{"f_1345:files_2escm",(void*)f_1345},
{"f_931:files_2escm",(void*)f_931},
{"f_1356:files_2escm",(void*)f_1356},
{"f_937:files_2escm",(void*)f_937},
{"f_1351:files_2escm",(void*)f_1351},
{"f_1016:files_2escm",(void*)f_1016},
{"f_1337:files_2escm",(void*)f_1337},
{"f_1331:files_2escm",(void*)f_1331},
{"f_1496:files_2escm",(void*)f_1496},
{"f_1493:files_2escm",(void*)f_1493},
{"f_896:files_2escm",(void*)f_896},
{"f_1309:files_2escm",(void*)f_1309},
{"f_898:files_2escm",(void*)f_898},
{"f_1430:files_2escm",(void*)f_1430},
{"f_1490:files_2escm",(void*)f_1490},
{"f_946:files_2escm",(void*)f_946},
{"f_1437:files_2escm",(void*)f_1437},
{"f_1928:files_2escm",(void*)f_1928},
{"f_1303:files_2escm",(void*)f_1303},
{"f_892:files_2escm",(void*)f_892},
{"f_1038:files_2escm",(void*)f_1038},
{"f_894:files_2escm",(void*)f_894},
{"f_1317:files_2escm",(void*)f_1317},
{"f_1443:files_2escm",(void*)f_1443},
{"f_1002:files_2escm",(void*)f_1002},
{"f_1448:files_2escm",(void*)f_1448},
{"f_1004:files_2escm",(void*)f_1004},
{"f_1314:files_2escm",(void*)f_1314},
{"f_1368:files_2escm",(void*)f_1368},
{"f_1944:files_2escm",(void*)f_1944},
{"f_1362:files_2escm",(void*)f_1362},
{"f_1934:files_2escm",(void*)f_1934},
{"f_1936:files_2escm",(void*)f_1936},
{"f_1938:files_2escm",(void*)f_1938},
{"f_1962:files_2escm",(void*)f_1962},
{"f_1966:files_2escm",(void*)f_1966},
{"f_1964:files_2escm",(void*)f_1964},
{"f_1475:files_2escm",(void*)f_1475},
{"f_1328:files_2escm",(void*)f_1328},
{"f_1413:files_2escm",(void*)f_1413},
{"f_1981:files_2escm",(void*)f_1981},
{"f_1419:files_2escm",(void*)f_1419},
{"f_1323:files_2escm",(void*)f_1323},
{"f_874:files_2escm",(void*)f_874},
{"f_1487:files_2escm",(void*)f_1487},
{"f_1483:files_2escm",(void*)f_1483},
{"f_1424:files_2escm",(void*)f_1424},
{"f_1972:files_2escm",(void*)f_1972},
{"f_1178:files_2escm",(void*)f_1178},
{"f_1156:files_2escm",(void*)f_1156},
{"f_1854:files_2escm",(void*)f_1854},
{"f_1453:files_2escm",(void*)f_1453},
{"f_910:files_2escm",(void*)f_910},
{"f_919:files_2escm",(void*)f_919},
{"f_1134:files_2escm",(void*)f_1134},
{"f_2002:files_2escm",(void*)f_2002},
{"f_1189:files_2escm",(void*)f_1189},
{"f_830:files_2escm",(void*)f_830},
{"f_1166:files_2escm",(void*)f_1166},
{"f_749:files_2escm",(void*)f_749},
{"f_745:files_2escm",(void*)f_745},
{"f_747:files_2escm",(void*)f_747},
{"f_1465:files_2escm",(void*)f_1465},
{"f_1469:files_2escm",(void*)f_1469},
{"f_1402:files_2escm",(void*)f_1402},
{"f_921:files_2escm",(void*)f_921},
{"f_923:files_2escm",(void*)f_923},
{"f_925:files_2escm",(void*)f_925},
{"f_1778:files_2escm",(void*)f_1778},
{"f_1407:files_2escm",(void*)f_1407},
{"f_791:files_2escm",(void*)f_791},
{"f_799:files_2escm",(void*)f_799},
{"f_797:files_2escm",(void*)f_797},
{"f_1892:files_2escm",(void*)f_1892},
{"f_1746:files_2escm",(void*)f_1746},
{"f_1748:files_2escm",(void*)f_1748},
{"f_781:files_2escm",(void*)f_781},
{"f_783:files_2escm",(void*)f_783},
{"f_785:files_2escm",(void*)f_785},
{"f_1863:files_2escm",(void*)f_1863},
{"f_1861:files_2escm",(void*)f_1861},
{"f_787:files_2escm",(void*)f_787},
{"f_789:files_2escm",(void*)f_789},
{"f_1523:files_2escm",(void*)f_1523},
{"f_1740:files_2escm",(void*)f_1740},
{"f_902:files_2escm",(void*)f_902},
{"f_900:files_2escm",(void*)f_900},
{"f_908:files_2escm",(void*)f_908},
{"f_1197:files_2escm",(void*)f_1197},
{"f_1529:files_2escm",(void*)f_1529},
{"f_1736:files_2escm",(void*)f_1736},
{"f_1513:files_2escm",(void*)f_1513},
{"f_1257:files_2escm",(void*)f_1257},
{"f_1998:files_2escm",(void*)f_1998},
{"f_1507:files_2escm",(void*)f_1507},
{"f_1992:files_2escm",(void*)f_1992},
{"f_1990:files_2escm",(void*)f_1990},
{"f_818:files_2escm",(void*)f_818},
{"toplevel:files_2escm",(void*)C_files_toplevel},
{"f_1564:files_2escm",(void*)f_1564},
{"f_1705:files_2escm",(void*)f_1705},
{"f_1266:files_2escm",(void*)f_1266},
{"f_1269:files_2escm",(void*)f_1269},
{"f_1140:files_2escm",(void*)f_1140},
{"f_1517:files_2escm",(void*)f_1517},
{"f_1026:files_2escm",(void*)f_1026},
{"f_810:files_2escm",(void*)f_810},
{"f_812:files_2escm",(void*)f_812},
{"f_808:files_2escm",(void*)f_808},
{"f_1714:files_2escm",(void*)f_1714},
{"f_1114:files_2escm",(void*)f_1114},
{"f_1616:files_2escm",(void*)f_1616},
{"f_1544:files_2escm",(void*)f_1544},
{"f_1541:files_2escm",(void*)f_1541},
{"f_1277:files_2escm",(void*)f_1277},
{"f_1275:files_2escm",(void*)f_1275},
{"f_1625:files_2escm",(void*)f_1625},
{"f_1047:files_2escm",(void*)f_1047},
{"f_1683:files_2escm",(void*)f_1683},
{"f_1272:files_2escm",(void*)f_1272},
{"f_1553:files_2escm",(void*)f_1553},
{"f_1550:files_2escm",(void*)f_1550},
{"f_1547:files_2escm",(void*)f_1547},
{"f_1289:files_2escm",(void*)f_1289},
{"f_1633:files_2escm",(void*)f_1633},
{"f_1286:files_2escm",(void*)f_1286},
{"f_824:files_2escm",(void*)f_824},
{"f_1556:files_2escm",(void*)f_1556},
{"f_1298:files_2escm",(void*)f_1298},
{"f_1292:files_2escm",(void*)f_1292},
{"f_1653:files_2escm",(void*)f_1653},
{"f_763:files_2escm",(void*)f_763},
{"f_1657:files_2escm",(void*)f_1657},
{"f_1658:files_2escm",(void*)f_1658},
{"f_1655:files_2escm",(void*)f_1655},
{"f_1661:files_2escm",(void*)f_1661},
{"f_751:files_2escm",(void*)f_751},
{"f_758:files_2escm",(void*)f_758},
{"f_1672:files_2escm",(void*)f_1672},
{"f_1674:files_2escm",(void*)f_1674},
{"f_1670:files_2escm",(void*)f_1670},
{"f_1073:files_2escm",(void*)f_1073},
{"f_1076:files_2escm",(void*)f_1076},
{"f_1676:files_2escm",(void*)f_1676},
{"f_990:files_2escm",(void*)f_990},
{"f_1600:files_2escm",(void*)f_1600},
{"f_992:files_2escm",(void*)f_992},
{"f_1385:files_2escm",(void*)f_1385},
{"f_1694:files_2escm",(void*)f_1694},
{"f_1690:files_2escm",(void*)f_1690},
{"f_1396:files_2escm",(void*)f_1396},
{"f_1208:files_2escm",(void*)f_1208},
{"f_1390:files_2escm",(void*)f_1390},
{"f_1211:files_2escm",(void*)f_1211},
{"f_1214:files_2escm",(void*)f_1214},
{"f_1379:files_2escm",(void*)f_1379},
{"f_1373:files_2escm",(void*)f_1373},
{"f_1229:files_2escm",(void*)f_1229},
{"f_1226:files_2escm",(void*)f_1226},
{"f_1228:files_2escm",(void*)f_1228},
{"f_1794:files_2escm",(void*)f_1794},
{"f_1798:files_2escm",(void*)f_1798},
{"f_1085:files_2escm",(void*)f_1085},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}

/*
S|applied compiler syntax:
S|  for-each		1
o|eliminated procedure checks: 41 
o|specializations:
o|  1 (string-ref string fixnum)
o|  1 (string=? string string)
o|  1 (car pair)
o|  5 (cdr pair)
o|  1 (zero? fixnum)
o|  3 (memq * list)
o|dropping redundant toplevel assignment: make-pathname 
o|dropping redundant toplevel assignment: make-absolute-pathname 
o|dropping redundant toplevel assignment: create-temporary-file 
o|dropping redundant toplevel assignment: create-temporary-directory 
o|Removed `not' forms: 3 
o|inlining procedure: k754 
o|inlining procedure: k754 
o|inlining procedure: k802 
o|inlining procedure: k802 
o|inlining procedure: k831 
o|inlining procedure: k831 
o|inlining procedure: k913 
o|inlining procedure: k913 
o|inlining procedure: k938 
o|inlining procedure: k938 
o|inlining procedure: k1007 
o|substituted constant variable: a1029 
o|inlining procedure: k1007 
o|inlining procedure: k1050 
o|inlining procedure: k1050 
o|inlining procedure: k1088 
o|inlining procedure: k1088 
o|inlining procedure: k1136 
o|inlining procedure: k1136 
o|substituted constant variable: a1169 
o|inlining procedure: k1209 
o|inlining procedure: k1209 
o|inlining procedure: k1231 
o|inlining procedure: k1231 
o|inlining procedure: k1247 
o|inlining procedure: k1247 
o|inlining procedure: k1278 
o|inlining procedure: k1278 
o|inlining procedure: k1433 
o|inlining procedure: k1433 
o|inlining procedure: k1444 
o|inlining procedure: k1444 
o|inlining procedure: k1470 
o|inlining procedure: k1470 
o|inlining procedure: k1518 
o|inlining procedure: k1518 
o|inlining procedure: k1567 
o|inlining procedure: k1567 
o|substituted constant variable: a1575 
o|inlining procedure: k1577 
o|inlining procedure: k1577 
o|inlining procedure: k1619 
o|inlining procedure: k1634 
o|inlining procedure: k1634 
o|inlining procedure: k1677 
o|inlining procedure: k1677 
o|inlining procedure: k1708 
o|inlining procedure: k1708 
o|inlining procedure: k1619 
o|substituted constant variable: a1743 
o|inlining procedure: k1749 
o|inlining procedure: k1749 
o|inlining procedure: k1779 
o|inlining procedure: k1779 
o|inlining procedure: k1789 
o|inlining procedure: k1789 
o|inlining procedure: k1820 
o|inlining procedure: k1820 
o|inlining procedure: k1868 
o|inlining procedure: k1868 
o|contracted procedure: "(files.scm:450) strip-origin-prefix505" 
o|contracted procedure: k1901 
o|inlining procedure: k1899 
o|contracted procedure: k1911 
o|inlining procedure: k1917 
o|inlining procedure: k1917 
o|inlining procedure: k1899 
o|substituted constant variable: patt2245 
o|substituted constant variable: patt1244 
o|inlining procedure: k1975 
o|inlining procedure: k1975 
o|inlining procedure: k1984 
o|inlining procedure: k1984 
o|inlining procedure: k2005 
o|inlining procedure: k2005 
o|replaced variables: 203 
o|removed binding forms: 64 
o|substituted constant variable: f_7532011 
o|substituted constant variable: f_10062021 
o|substituted constant variable: f_10492022 
o|substituted constant variable: f_10872024 
o|substituted constant variable: a11352026 
o|substituted constant variable: a11352027 
o|substituted constant variable: f_12302033 
o|inlining procedure: k1438 
o|inlining procedure: k1438 
o|inlining procedure: k1438 
o|inlining procedure: k1438 
o|inlining procedure: k1677 
o|inlining procedure: k1677 
o|substituted constant variable: r17802062 
o|substituted constant variable: r18212067 
o|converted assignments to bindings: (addpart416) 
o|converted assignments to bindings: (tempdir375) 
o|substituted constant variable: f_19742075 
o|substituted constant variable: f_19832077 
o|substituted constant variable: f_20042079 
o|simplifications: ((let . 2)) 
o|replaced variables: 17 
o|removed binding forms: 184 
o|removed conditional forms: 1 
o|inlining procedure: k837 
o|inlining procedure: k950 
o|inlining procedure: k1946 
o|inlining procedure: k1946 
o|inlining procedure: k1946 
o|replaced variables: 6 
o|removed binding forms: 31 
o|substituted constant variable: r8382126 
o|substituted constant variable: r9512129 
o|simplifications: ((let . 1)) 
o|replaced variables: 1 
o|removed binding forms: 5 
o|removed conditional forms: 2 
o|removed binding forms: 3 
o|simplifications: ((if . 20) (##core#call . 139)) 
o|  call simplifications:
o|    list?
o|    string-ref
o|    pair?
o|    ##sys#slot	2
o|    string	3
o|    string=?	3
o|    cons	3
o|    number->string	2
o|    ##sys#fudge	2
o|    ##sys#call-with-values	8
o|    values	8
o|    member	2
o|    fx>	2
o|    char=?	2
o|    not	2
o|    string?
o|    list
o|    ##sys#check-list	2
o|    string-length
o|    eq?	5
o|    ##sys#size	9
o|    fx>=	3
o|    fx-	2
o|    car	13
o|    null?	20
o|    cdr	5
o|    ##sys#check-string	12
o|    ##sys#check-number	2
o|    integer?	2
o|    >	2
o|    fx=	7
o|    fx+	10
o|contracted procedure: k867 
o|contracted procedure: k766 
o|contracted procedure: k861 
o|contracted procedure: k768 
o|contracted procedure: k855 
o|contracted procedure: k770 
o|contracted procedure: k849 
o|contracted procedure: k772 
o|contracted procedure: k774 
o|contracted procedure: k776 
o|contracted procedure: k778 
o|contracted procedure: k804 
o|contracted procedure: k820 
o|contracted procedure: k843 
o|contracted procedure: k837 
o|substituted constant variable: g2196 
o|contracted procedure: k980 
o|contracted procedure: k877 
o|contracted procedure: k974 
o|contracted procedure: k879 
o|contracted procedure: k968 
o|contracted procedure: k881 
o|contracted procedure: k962 
o|contracted procedure: k883 
o|contracted procedure: k885 
o|contracted procedure: k887 
o|contracted procedure: k889 
o|contracted procedure: k915 
o|contracted procedure: k933 
o|contracted procedure: k956 
o|contracted procedure: k950 
o|substituted constant variable: g2200 
o|contracted procedure: k995 
o|contracted procedure: k1009 
o|contracted procedure: k1021 
o|contracted procedure: k1023 
o|contracted procedure: k1035 
o|contracted procedure: k1041 
o|contracted procedure: k1052 
o|contracted procedure: k1055 
o|contracted procedure: k1082 
o|contracted procedure: k1060 
o|contracted procedure: k1090 
o|contracted procedure: k1092 
o|contracted procedure: k1098 
o|contracted procedure: k1105 
o|contracted procedure: k1117 
o|contracted procedure: k1120 
o|contracted procedure: k1123 
o|contracted procedure: k1125 
o|contracted procedure: k1127 
o|contracted procedure: k1152 
o|contracted procedure: k1141 
o|contracted procedure: k1148 
o|contracted procedure: k1161 
o|contracted procedure: k1175 
o|contracted procedure: k1163 
o|contracted procedure: k1190 
o|contracted procedure: k1181 
o|contracted procedure: k1218 
o|contracted procedure: k1200 
o|contracted procedure: k1236 
o|contracted procedure: k1245 
o|contracted procedure: k1300 
o|contracted procedure: k1250 
o|contracted procedure: k1500 
o|contracted procedure: k1456 
o|contracted procedure: k1459 
o|contracted procedure: k1498 
o|contracted procedure: k1533 
o|contracted procedure: k1558 
o|contracted procedure: k1957 
o|contracted procedure: k1561 
o|contracted procedure: k1569 
o|contracted procedure: k1580 
o|inlining procedure: k1582 
o|contracted procedure: k1595 
o|inlining procedure: k1582 
o|contracted procedure: k1838 
o|contracted procedure: k1603 
o|contracted procedure: k1835 
o|contracted procedure: k1606 
o|contracted procedure: k1608 
o|contracted procedure: k1610 
o|contracted procedure: k1621 
o|contracted procedure: k1629 
o|contracted procedure: k1644 
o|contracted procedure: k1650 
o|contracted procedure: k1666 
o|contracted procedure: k1679 
o|contracted procedure: k1696 
o|contracted procedure: k1698 
o|contracted procedure: k1710 
o|contracted procedure: k1719 
o|contracted procedure: k1722 
o|contracted procedure: k1725 
o|contracted procedure: k1727 
o|contracted procedure: k1752 
o|contracted procedure: k1759 
o|contracted procedure: k1762 
o|contracted procedure: k1768 
o|contracted procedure: k1771 
o|contracted procedure: k1783 
o|contracted procedure: k1779 
o|contracted procedure: k1803 
o|contracted procedure: k1806 
o|contracted procedure: k1809 
o|contracted procedure: k1815 
o|contracted procedure: k1817 
o|contracted procedure: k1823 
o|contracted procedure: k1833 
o|contracted procedure: k1848 
o|contracted procedure: k1866 
o|contracted procedure: k1883 
o|contracted procedure: k1874 
o|contracted procedure: k1885 
o|contracted procedure: k1951 
o|contracted procedure: k1949 
o|contracted procedure: k1904 
o|contracted procedure: k1906 
o|contracted procedure: k1915 
o|contracted procedure: k1930 
o|contracted procedure: k1920 
o|contracted procedure: k1946 
o|simplifications: ((if . 2) (let . 20)) 
o|removed binding forms: 120 
o|inlining procedure: "(files.scm:421) split-directory" 
o|inlining procedure: "(files.scm:447) split-directory" 
o|replaced variables: 14 
o|removed binding forms: 3 
o|removed side-effect free assignment to unused variable: split-directory 
o|substituted constant variable: loc4902250 
o|substituted constant variable: keep?4922252 
o|substituted constant variable: loc4902255 
o|substituted constant variable: keep?4922257 
o|replaced variables: 2 
o|removed binding forms: 10 
o|removed binding forms: 7 
o|direct leaf routine/allocation: addpart416 9 
o|direct leaf routine/allocation: loop496 0 
o|contracted procedure: "(files.scm:368) k1731" 
o|contracted procedure: "(files.scm:400) k1774" 
o|converted assignments to bindings: (loop496) 
o|simplifications: ((let . 1)) 
o|removed binding forms: 2 
o|customizable procedures: (k989 k1792 k1747 loop441 k1624 for-each-loop453465 k1682 loop407 tempdir375 loop401 canonicalize-dirs177 _make-pathname178 k1138 conc-dirs176 chop-pds loop180 loop131 loop91) 
o|calls to known targets: 55 
o|identified direct recursive calls: f_1047 1 
o|identified direct recursive calls: f_1863 1 
o|fast box initializations: 10 
o|fast global references: 6 
o|fast global assignments: 10 
o|dropping unused closure argument: f_1038 
o|dropping unused closure argument: f_1004 
o|dropping unused closure argument: f_1863 
o|dropping unused closure argument: f_1564 
o|dropping unused closure argument: f_1114 
*/
/* end of file */
